"""
Meal analysis module using OpenAI and Gemini APIs
Provides functions to analyze meal photos and extract nutritional information
"""
import google.generativeai as genai
import os
import json
import base64
import re
from food_log_src.prompt import UNIFIED_MEAL_ANALYSIS_PROMPT
from food_log_src.api_client import get_openai_client, get_gemini_model, get_openai_model_name, get_gemini_model_name

# Get API clients from centralized configuration
openai_client = get_openai_client()
gemini_model = get_gemini_model()
OPENAI_MODEL_NAME = get_openai_model_name()
GEMINI_MODEL_NAME = get_gemini_model_name()


def analyze_meal_photo_gemini(image_path: str) -> dict:
    """
    Analyze meal photo using Google Gemini API with unified prompt.

    Args:
        image_path (str): Path to the meal image

    Returns:
        dict: Structured analysis result or error
    """
    print(f"Starting Gemini analysis for: {image_path}")

    try:
        if not os.path.exists(image_path):
            return {"error": f"Gemini: Image file not found at '{image_path}'.", "service": "Gemini"}

        print("Uploading image to Gemini...")
        # Upload image to Gemini
        uploaded_file = genai.upload_file(image_path, mime_type="image/jpeg")

        print("🔄 Analyzing with Gemini API...")

        # Generate content with unified prompt
        response = gemini_model.generate_content([
            uploaded_file,
            UNIFIED_MEAL_ANALYSIS_PROMPT
        ])

        print("Received response from Gemini")

        # Parse response
        try:
            response_text = response.text.strip()
            print(f"Raw response length: {len(response_text)}")

            # Clean up potential markdown formatting
            if response_text.startswith("```json"):
                response_text = response_text[7:].strip()
            if response_text.endswith("```"):
                response_text = response_text[:-3].strip()

            # Extract JSON if wrapped in other text
            json_match = re.search(r'{.*}', response_text, re.DOTALL)
            if json_match:
                response_text = json_match.group(0)

            analysis = json.loads(response_text)
            analysis["service"] = "Gemini"
            print("✅ Successfully parsed Gemini response")
            return analysis

        except json.JSONDecodeError as e:
            print(f"JSON decode error: {e}")
            return {
                "error": f"Gemini: JSON parsing failed - {str(e)}",
                "raw_response": response.text[:500],
                "service": "Gemini"
            }
        except Exception as e:
            print(f"Response processing error: {e}")
            return {
                "error": f"Gemini: Response processing failed - {str(e)}",
                "raw_response": response.text[:500] if hasattr(response, 'text') else 'No text available',
                "service": "Gemini"
            }

    except Exception as e:
        print(f"Gemini API error: {e}")
        return {"error": f"Gemini: API call failed - {str(e)}", "service": "Gemini"}


def analyze_meal_photo_openai(image_path: str) -> dict:
    """
    Analyze meal photo using OpenAI GPT-4 Vision API with unified prompt.

    Args:
        image_path (str): Path to the meal image

    Returns:
        dict: Structured analysis result or error
    """
    print(f"Starting OpenAI analysis for: {image_path}")

    try:
        if not os.path.exists(image_path):
            return {"error": f"OpenAI: Image file not found at '{image_path}'.", "service": "OpenAI"}

        # Encode image to base64
        with open(image_path, "rb") as image_file:
            base64_image = base64.b64encode(image_file.read()).decode("utf-8")

        print("🔄 Analyzing with OpenAI GPT-5 API...")

        # Make API call with unified prompt
        response = openai_client.chat.completions.create(
            model=OPENAI_MODEL_NAME,
            messages=[
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "text",
                            "text": UNIFIED_MEAL_ANALYSIS_PROMPT
                        },
                        {
                            "type": "image_url",
                            "image_url": {
                                "url": f"data:image/jpeg;base64,{base64_image}",
                                "detail": "high"
                            }
                        }
                    ]
                }
            ],
            temperature=0.1,  # Very low for consistent, factual responses
            max_tokens=2500
        )

        content = response.choices[0].message.content.strip()
        print("Received response from OpenAI")

        # Parse JSON response
        try:
            # Try direct parsing first
            analysis = json.loads(content)
        except json.JSONDecodeError:
            # Extract JSON from mixed content
            json_match = re.search(r'```json\s*(.*?)\s*```', content, re.DOTALL)
            if not json_match:
                json_match = re.search(r'{.*}', content, re.DOTALL)

            if json_match:
                try:
                    json_content = json_match.group(1) if json_match.groups() else json_match.group(0)
                    analysis = json.loads(json_content)
                except json.JSONDecodeError as e:
                    return {
                        "error": f"OpenAI: JSON parsing failed - {str(e)}",
                        "raw_response": content[:500],
                        "service": "OpenAI"
                    }
            else:
                return {
                    "error": "OpenAI: No valid JSON found in response",
                    "raw_response": content[:500],
                    "service": "OpenAI"
                }

        analysis["service"] = "OpenAI"
        print("✅ Successfully parsed OpenAI response")
        return analysis

    except Exception as e:
        print(f"OpenAI API error: {e}")
        return {"error": f"OpenAI: API call failed - {str(e)}", "service": "OpenAI"}

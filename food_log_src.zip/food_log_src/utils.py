import base64
import io
from PIL import Image
from food_log_src.api_client import get_openai_client, get_openai_model_name

# Get OpenAI client from centralized configuration
client = get_openai_client()


def is_food_image(image_bytes: bytes) -> bool:
    """
    Check if image shows food being consumed/tracked for nutrition.

    Accepts: Meals, snacks, beverages ready to consume
    Rejects: Raw ingredients, live animals, cooking stages, non-food items

    Returns True if food detected, else False.
    """
    try:
        # Verify image is valid
        img = Image.open(io.BytesIO(image_bytes))
        img.verify()

        # Encode image to base64
        image_b64 = base64.b64encode(image_bytes).decode("utf-8")

        # Call OpenAI to classify food with robust prompt
        response = client.chat.completions.create(
            model=get_openai_model_name(),
            messages=[
                {
                    "role": "system",
                    "content": (
                        "You are a food classifier for a nutrition tracking app. "
                        "Users photograph meals and snacks they are eating or just ate.\n\n"

                        "ACCEPT (reply 'yes'):\n"
                        "✓ Cooked/prepared meals ready to eat (pasta, curry, grilled fish, etc.)\n"
                        "✓ Plated or served food (restaurant dishes, home-cooked meals)\n"
                        "✓ Ready-to-eat items (sushi, sandwiches, salads, burgers, pizza)\n"
                        "✓ Snacks and desserts (cookies, chips, ice cream, cake)\n"
                        "✓ Fresh produce ready to consume (fruit bowl, washed berries, cut melon)\n"
                        "✓ Packaged foods opened for eating (yogurt, cereal, granola bars)\n"
                        "✓ Beverages (coffee, juice, smoothies, soda, tea, alcohol)\n\n"

                        "REJECT (reply 'no'):\n"
                        "✗ Raw unprocessed ingredients (whole raw fish, raw chicken/meat, uncut vegetables for cooking)\n"
                        "✗ Live animals (fish in tanks, live lobster/crab, live poultry)\n"
                        "✗ Cooking ingredients (flour, sugar, eggs in carton, spices, oil bottles)\n"
                        "✗ Food being prepared (chopping board with ingredients, food in pan/pot)\n"
                        "✗ Empty plates, bowls, or food containers\n"
                        "✗ Packaging without visible food inside\n"
                        "✗ Kitchen items (utensils, appliances, cookware)\n"
                        "✗ People or body parts (even if holding/eating food)\n"
                        "✗ Pet food, animal feed, or baby formula\n"
                        "✗ Supplements, vitamins, pills, or medicines\n"
                        "✗ Pictures of menus, recipe books, or food ads\n"
                        "✗ Grocery stores or food markets (wide shots of shelves/aisles)\n\n"

                        "Key test: Is this food in its final state, ready to be consumed for a meal/snack?\n"
                        "Reply strictly with 'yes' or 'no'."
                    ),
                },
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "text",
                            "text": "Is this a meal or ready-to-eat food being consumed? Reply 'yes' or 'no'.",
                        },
                        {
                            "type": "image_url",
                            "image_url": {
                                "url": f"data:image/jpeg;base64,{image_b64}"
                            },
                        },
                    ],
                },
            ],
            max_tokens=5
        )

        # Parse answer
        answer = response.choices[0].message.content.strip().lower()
        return answer.startswith("y")

    except Exception as e:
        print(f"Error in is_food_image: {e}")
        return False

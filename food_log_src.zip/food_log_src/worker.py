from food_log_src.calorie_processor import process_meal as analyze_meal_photo
import psycopg2
import requests
import json
import time
import logging
from food_log_src.config import DB_CONFIG, REQUEST_TIMEOUT, API_RETRY_COUNT, API_BASE_URL

# API Configuration
FOOD_LOG_API = " "
TIMEOUT = 25       # seconds (<29 for API Gateway safety)
RETRIES = API_RETRY_COUNT  # retry attempts from config
BACKOFF = 5        # seconds between retries

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def get_connection():
    return psycopg2.connect(**DB_CONFIG)

def fetch_unprocessed_meals(conn):
    with conn.cursor() as cur:
        cur.execute("""
            SELECT user_id, meal_id, image_url
            FROM nutrition_meals
            WHERE processed = false AND status = 'pending'
            ORDER BY created_at ASC
            LIMIT 5;
        """)
        return cur.fetchall()

def fetch_user_unprocessed_meals(conn, user_id):
    """Fetch unprocessed meals for a specific user only"""
    with conn.cursor() as cur:
        cur.execute("""
            SELECT user_id, meal_id, image_url
            FROM nutrition_meals
            WHERE user_id = %s
              AND processed = false
              AND status = 'pending'
            ORDER BY created_at ASC
            LIMIT 10;
        """, (user_id,))
        return cur.fetchall()

def send_nutrition_api(user_id, meal_id, nutrition):
    """Send nutrients to FastAPI API instead of direct DB insert."""
    analysis = nutrition.get("analysis", {})
    if not analysis:
        logger.warning(f"⚠️ No analysis data available for meal {meal_id}")
        return False

    # Build items array (aggregate nutrients)
    items = []

    # Helper function to safely get float values
    def get_float(d, key):
        try:
            v = d.get(key)
            return float(v) if v is not None else None
        except (ValueError, TypeError):
            return None

    # Calories: use minimum instead of best_estimate
    cal_range = analysis.get("total_calories", {}).get("range", {})
#    total_calories = cal_range.get("minimum")
    total_calories = analysis.get("total_calories", {}).get("best_estimate")
    if total_calories is not None:
        try:
            total_calories = int(round(float(total_calories)))
        except Exception:
            total_calories = None
    if total_calories is not None:
        items.append({"nutrient": "energy.kcal", "value": total_calories})

    macros = analysis.get("macronutrients", {})

    protein = get_float(macros.get("protein", {}), "grams")
    if protein is not None:
        items.append({"nutrient": "protein_g", "value": protein})

    carbs = get_float(macros.get("carbohydrates", {}), "grams")
    if carbs is not None:
        items.append({"nutrient": "carbs_g", "value": carbs})

    fiber = get_float(macros.get("carbohydrates", {}), "fiber_grams")
    if fiber is not None:
        items.append({"nutrient": "fiber_g", "value": fiber})

    sugar = get_float(macros.get("carbohydrates", {}), "sugar_grams")
    if sugar is not None:
        items.append({"nutrient": "sugar_g", "value": sugar})

    fat = get_float(macros.get("fats", {}), "grams")
    if fat is not None:
        items.append({"nutrient": "fat_g", "value": fat})

    sat_fat = get_float(macros.get("fats", {}), "saturated_grams")
    if sat_fat is not None:
        items.append({"nutrient": "sat_fat_g", "value": sat_fat})

    unsat_fat = get_float(macros.get("fats", {}), "unsaturated_grams")
    if unsat_fat is not None:
        items.append({"nutrient": "unsat_fat_g", "value": unsat_fat})

    # Extract food_items array from analysis
    food_items = analysis.get("food_items", [])

    # Build complete payload with items and food_items
    payload = {
        "items": items,
        "food_items": food_items if food_items else None
    }

    logger.info(f"📦 Payload for {meal_id}: {json.dumps(payload, indent=2)}")

    url = f"{API_BASE_URL}/v1/nutrition/meals/{meal_id}/nutrients?compute_mode=local_blocking"
    headers = {
        "Content-Type": "application/json",
        "x-user-id": str(user_id),
    }

    for attempt in range(RETRIES):
        try:
            logger.info(f"➡️ Sending nutrients for meal {meal_id} (Attempt {attempt+1})...")
            resp = requests.post(url, headers=headers, json=payload, timeout=TIMEOUT)
            resp.raise_for_status()
            logger.info(f"✅ API accepted nutrients for meal {meal_id}")
            return True
        except requests.RequestException as e:
            logger.warning(f"❌ Attempt {attempt+1} failed for meal {meal_id}: {e}")
            time.sleep(BACKOFF)
    logger.error(f"❌ All {RETRIES} attempts failed for meal {meal_id}")
    return False

def mark_meal_status(conn, user_id, meal_id, status):
    """Update meal status and processed flag in DB."""
    with conn.cursor() as cur:
        cur.execute("""
            UPDATE nutrition_meals
            SET processed = %s,
                status = %s,
                updated_at = NOW()
            WHERE user_id = %s AND meal_id = %s;
        """, (
            status == "done",
            status,
            user_id,
            meal_id,
        ))
    conn.commit()

def cleanup_non_food_meal(conn, user_id, meal_id, image_url):
    """
    Completely remove non-food meal from S3 and database.

    Deletes:
    - S3 image file
    - nutrition_meals record
    - nutrition_meal_nutrients record (if exists)
    - food_log record

    Args:
        conn: Database connection
        user_id: User ID
        meal_id: Meal ID to delete
        image_url: S3 URL of image to delete
    """
    import boto3
    import os
    from urllib.parse import urlparse

    logger.info(f"🗑️  Cleaning up non-food meal {meal_id} for user {user_id}")

    # Step 1: Delete from S3
    if image_url:
        try:
            s3_client = boto3.client(
                's3',
                aws_access_key_id=os.getenv('AWS_ACCESS_KEY_ID'),
                aws_secret_access_key=os.getenv('AWS_SECRET_ACCESS_KEY'),
                region_name=os.getenv('AWS_REGION', 'ap-south-1')
            )

            # Parse S3 URL: https://bucket.s3.region.amazonaws.com/key
            parsed = urlparse(image_url)
            bucket = parsed.netloc.split('.')[0]
            s3_key = parsed.path.lstrip('/')

            s3_client.delete_object(Bucket=bucket, Key=s3_key)
            logger.info(f"✅ Deleted S3: s3://{bucket}/{s3_key}")
        except Exception as e:
            logger.warning(f"⚠️  S3 deletion failed: {e} (continuing with DB cleanup)")

    # Step 2: Delete from database tables
    try:
        with conn.cursor() as cur:
            # Delete nutrients (if any)
            cur.execute(
                "DELETE FROM nutrition_meal_nutrients WHERE user_id = %s AND meal_id = %s",
                (user_id, meal_id)
            )
            nutrients_deleted = cur.rowcount

            # Delete meal
            cur.execute(
                "DELETE FROM nutrition_meals WHERE user_id = %s AND meal_id = %s",
                (user_id, meal_id)
            )
            meal_deleted = cur.rowcount

            # Delete food_log entry
            cur.execute(
                "DELETE FROM food_log WHERE user_id = %s AND s3_url = %s",
                (user_id, image_url)
            )
            log_deleted = cur.rowcount

        conn.commit()
        logger.info(
            f"✅ DB cleanup complete: {meal_deleted} meal, {nutrients_deleted} nutrients, {log_deleted} food_log"
        )
    except Exception as e:
        logger.error(f"❌ DB cleanup failed: {e}")
        conn.rollback()
        raise

def process_meal(conn, meal):
    user_id, meal_id, image_url = meal
    logger.info(f"📌 Found unprocessed meal: user={user_id}, meal={meal_id}, image={image_url}")

    mark_meal_status(conn, user_id, meal_id, "processing")

    try:
        data = analyze_meal_photo(image_url=image_url)
    except Exception as e:
        logger.error(f"❌ Error analyzing meal {meal_id}: {e}")
        mark_meal_status(conn, user_id, meal_id, "error")
        return

    # Check if non-food detected
    if data and not data.get("is_food", True):
        rejection_reason = data.get("rejection_reason", "Image does not contain food")
        logger.warning(f"🚫 Non-food detected: {meal_id} - {rejection_reason}")
        cleanup_non_food_meal(conn, user_id, meal_id, image_url)
        return  # Exit early - everything cleaned up

    # Process actual food meals
    if data and data.get("analysis"):
        logger.info(f"📊 Food analysis complete for {meal_id}")
        ok = send_nutrition_api(user_id, meal_id, data)
        if ok:
            mark_meal_status(conn, user_id, meal_id, "done")
        else:
            mark_meal_status(conn, user_id, meal_id, "error")
    else:
        mark_meal_status(conn, user_id, meal_id, "error")
        logger.error(f"❌ Meal {meal_id} marked as error after local analysis")

def process_user_meals(user_id):
    """
    Process all pending meals for a specific user.
    This function can be called directly from FastAPI for immediate processing.
    """
    conn = None
    try:
        conn = get_connection()
        logger.info(f"🎯 Processing meals for user {user_id}...")

        meals = fetch_user_unprocessed_meals(conn, user_id)

        if not meals:
            logger.info(f"No pending meals for user {user_id}")
            return

        logger.info(f"Found {len(meals)} pending meal(s) for user {user_id}")

        for meal in meals:
            process_meal(conn, meal)

        logger.info(f"✅ Completed processing {len(meals)} meal(s) for user {user_id}")

    except Exception as e:
        logger.error(f"❌ Error processing meals for user {user_id}: {e}")
        import traceback
        traceback.print_exc()
    finally:
        if conn:
            conn.close()

def main():
    """
    Optional fallback worker - polls for any stuck/failed meals.
    With the new FastAPI integration, most meals will be processed immediately.
    This worker now runs less aggressively (every 30 seconds) as a safety net.
    """
    conn = get_connection()
    logger.info("🔊 Fallback worker listening for stuck meals (polling every 30s)...")

    while True:
        meals = fetch_unprocessed_meals(conn)
        if not meals:
            time.sleep(30)  # Reduced from 5s to 30s
            continue

        logger.info(f"⚠️ Fallback worker found {len(meals)} unprocessed meal(s)")
        for meal in meals:
            process_meal(conn, meal)

        time.sleep(30)  # Wait between batches

if __name__ == "__main__":
    main()

import os
import json
import base64
import tempfile
import requests
from datetime import datetime

from food_log_src.meal_analyzer import analyze_meal_photo_openai
from food_log_src.utils import is_food_image

def process_meal(image_url: str = None, image_base64: str = None) -> dict:
    """
    Process a meal photo either from URL or base64 string.

    Performance Optimization: Added is_food_image() pre-check for fast rejection.
    - Non-food images: Rejected in 1-2 seconds (5 tokens, ~$0.001)
    - Food images: Full analysis in 2-5 seconds (2500 tokens, ~$0.05-0.10)
    - Saves 90% cost on non-food images (selfies, screenshots, etc.)
    """
    image_bytes = None
    image_path = None

    try:
        # Load image bytes
        if image_base64:
            image_bytes = base64.b64decode(image_base64)
        elif image_url:
            resp = requests.get(image_url, timeout=10)
            resp.raise_for_status()
            image_bytes = resp.content

        if not image_bytes:
            raise ValueError("No image provided")

        # STEP 1: Quick food detection (1-2 seconds, ~5 tokens)
        # Reject non-food images early to save time and API costs
        if not is_food_image(image_bytes):
            return {
                "analysis": None,
                "is_food": False,
                "timestamp": datetime.now().isoformat(),
                "rejection_reason": "Image does not contain food"
            }

        # STEP 2: Save to temporary file (only if pre-check passed)
        with tempfile.NamedTemporaryFile(delete=False, suffix=".jpg", dir="/tmp") as tmp:
            tmp.write(image_bytes)
            tmp.flush()
            image_path = tmp.name

        # STEP 3: Full nutrition analysis (2-5 seconds, ~2500 tokens)
        result = analyze_meal_photo_openai(image_path)

        return {
            "analysis": result,
            "is_food": True,
            "timestamp": datetime.now().isoformat()
        }

    finally:
        if image_path and os.path.exists(image_path):
            os.remove(image_path)

if __name__ == "__main__":
    # Example usage
    res1 = process_meal(
        image_url="https://revival365-food-log.s3.ap-south-1.amazonaws.com/tmp_image_file1947244558720828420.png"
    )
    print(json.dumps(res1, indent=2))


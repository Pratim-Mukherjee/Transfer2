"""
Unified API client module for OpenAI and Gemini
Provides singleton instances of API clients with proper configuration
"""
import google.generativeai as genai
from openai import OpenAI
from food_log_src.config import OPENAI_API_KEY, GEMINI_API_KEY, OPENAI_MODEL, GEMINI_MODEL

# Singleton instances
_openai_client = None
_gemini_model = None


def get_openai_client() -> OpenAI:
    """
    Get singleton OpenAI client instance

    Returns:
        OpenAI: Configured OpenAI client
    """
    global _openai_client

    if _openai_client is None:
        if not OPENAI_API_KEY:
            raise ValueError("OPENAI_API_KEY not configured in .env file")

        _openai_client = OpenAI(api_key=OPENAI_API_KEY)

    return _openai_client


def get_gemini_model():
    """
    Get singleton Gemini model instance

    Returns:
        GenerativeModel: Configured Gemini model
    """
    global _gemini_model

    if _gemini_model is None:
        if not GEMINI_API_KEY:
            raise ValueError("GEMINI_API_KEY not configured in .env file")

        genai.configure(api_key=GEMINI_API_KEY)
        _gemini_model = genai.GenerativeModel(GEMINI_MODEL)

    return _gemini_model


def get_openai_model_name() -> str:
    """Get configured OpenAI model name"""
    return OPENAI_MODEL


def get_gemini_model_name() -> str:
    """Get configured Gemini model name"""
    return GEMINI_MODEL

"""
Configuration module for food_log
Loads settings from environment variables with fallback defaults
"""
import os
from pathlib import Path
from dotenv import load_dotenv

# Load .env file from food_log root directory (one level up from src/)
env_path = Path(__file__).parent.parent / '.env'
load_dotenv(dotenv_path=env_path)

# API Keys
OPENAI_API_KEY = os.getenv('OPENAI_API_KEY')
GEMINI_API_KEY = os.getenv('GEMINI_API_KEY')

# Model Configuration
OPENAI_MODEL = os.getenv('OPENAI_MODEL', 'gpt-5-chat-latest')
GEMINI_MODEL = os.getenv('GEMINI_MODEL', 'gemini-2.5-flash')

# Database Configuration
DB_HOST = os.getenv('DB_HOST', 'localhost')
DB_PORT = int(os.getenv('DB_PORT', '5432'))
DB_NAME = os.getenv('DB_NAME', 'healthsync')
DB_USER = os.getenv('DB_USER', 'postgres')
DB_PASSWORD = os.getenv('DB_PASSWORD', 'postgres')

# Performance Settings
REQUEST_TIMEOUT = int(os.getenv('REQUEST_TIMEOUT', '10'))
API_RETRY_COUNT = int(os.getenv('API_RETRY_COUNT', '3'))
WORKER_MAX_CONCURRENT = int(os.getenv('WORKER_MAX_CONCURRENT', '5'))

# FastAPI Server Configuration
API_BASE_URL = os.getenv('API_BASE_URL', 'http://localhost:8000')

# Validation
if not OPENAI_API_KEY or OPENAI_API_KEY == 'your-openai-api-key-here':
    print("⚠️  WARNING: OPENAI_API_KEY not set in .env file")

if not GEMINI_API_KEY or GEMINI_API_KEY == 'your-gemini-api-key-here':
    print("⚠️  WARNING: GEMINI_API_KEY not set in .env file")

# Database connection string
DB_CONFIG = {
    "dbname": DB_NAME,
    "user": DB_USER,
    "password": DB_PASSWORD,
    "host": DB_HOST,
    "port": DB_PORT,
}

import os
os.environ['MPLCONFIGDIR'] = '/var/www/mplconfig'

import os
import pandas as pd
import matplotlib.pyplot as plt
from datetime import datetime, timedelta
import matplotlib
from matplotlib.backends.backend_pdf import PdfPages
from matplotlib import backend_tools
from matplotlib.gridspec import GridSpec, GridSpecFromSubplotSpec
from config import CONFIG, DAYS_TO_ANALYZE
from data_fetching import get_weekly_data_raw_sync
from data_processing import process_physiological_data, process_weekly_sleep_data
from meal_detection import detect_meals_weekly, filter_activity_related_spikes
from metrics import calculate_cgm_metrics_for_meal, calculate_prandial_hr_hrv_metrics
from plotting import plot_weekly_overview, plot_daily_summary_page, save_figure, plot_single_prandial_response


def main_weekly_prandial_analysis(user_id, start_date_str, num_days=DAYS_TO_ANALYZE,
                                  save_individual_meal_plots=False, show_individual_meal_plots=False,
                                  save_weekly_report_pdf=True, # New: controls PDF generation
                                  show_overview_plot_live=False, # For immediate display
                                  show_daily_summary_live=False # For immediate display of daily pages
                                 ):
    print(f"\n==== Weekly Prandial Analysis for User {user_id} from {start_date_str} ({num_days} days) ====")
    
    weekly_raw_data = get_weekly_data_raw_sync(user_id, start_date_str, num_days)

    df_cgm = process_physiological_data(weekly_raw_data.get('cgm', []), 'cgm', 'cgm')
    df_hr = process_physiological_data(weekly_raw_data.get('hr', []), 'hr', 'hr')
    df_hrv = process_physiological_data(weekly_raw_data.get('hrv', []), 'hrv', 'hrv')
    df_stress = process_physiological_data(weekly_raw_data.get('stress', []), 'stress', 'stress') # Added
    df_activity = process_physiological_data(weekly_raw_data.get('activity', []), 'activity', 'activity') # Added
    
    sleep_periods_weekly = process_weekly_sleep_data(weekly_raw_data.get('sleep', []))

    data_summary_msg = (f"Data Summary: CGM rows: {df_cgm.shape[0]}, HR: {df_hr.shape[0]}, HRV: {df_hrv.shape[0]}, "
                        f"Stress: {df_stress.shape[0]}, Activity: {df_activity.shape[0]}, "
                        f"Sleep Periods: {len(sleep_periods_weekly)}")
    print(data_summary_msg)

    detected_cgm_meals_weekly = []
    if not df_cgm.empty:
        detected_cgm_meals_weekly = detect_meals_weekly(df_cgm, CONFIG['cgm'], sleep_periods_weekly)
        print(f"Detected {len(detected_cgm_meals_weekly)} non-nocturnal CGM-based meals across the week.")
    else:
        print("No CGM data available, meal detection based on CGM skipped.")

    # Filter out activity-related spikes
    if detected_cgm_meals_weekly:
        detected_cgm_meals_weekly = filter_activity_related_spikes(detected_cgm_meals_weekly, df_hr, df_hrv)
        n_activity_related = sum(m['activity_related'] for m in detected_cgm_meals_weekly)
        print(f"Flagged {n_activity_related} meal(s) as activity-related spikes (will be excluded from clean meal analysis).")

    # --- Prepare for PDF Report ---
    pdf_path = None
    if save_weekly_report_pdf:
        pdf_filename = f"Weekly_Report_{user_id}_{start_date_str.replace('-', '')}.pdf"
        pdf_filepath = os.path.join(CONFIG['plot_output_dir'], pdf_filename)
        pdf_pages = PdfPages(pdf_filepath)
        print(f"\n--- Generating Weekly PDF Report: {pdf_filepath} ---")
    else:
        pdf_pages = None

    # --- Generate and Add Weekly Overview Plot to PDF ---
    print("\n--- Generating Comprehensive Weekly Overview Plot ---")
    fig_weekly_overview = plot_weekly_overview(
        df_cgm_weekly=df_cgm, df_hr_weekly=df_hr, df_hrv_weekly=df_hrv,
        df_stress_weekly=df_stress, df_activity_weekly=df_activity, # Pass new data
        detected_meals=detected_cgm_meals_weekly, sleep_periods=sleep_periods_weekly,
        user_id=user_id, week_start_date_str=start_date_str,
        save_plot=False, show_plot=show_overview_plot_live # Don't save separately if going to PDF
    )
    if fig_weekly_overview and pdf_pages:
        pdf_pages.savefig(fig_weekly_overview, bbox_inches='tight')
        plt.close(fig_weekly_overview)
    elif fig_weekly_overview and not show_overview_plot_live: # Close if not shown and not added to PDF
        plt.close(fig_weekly_overview)


    # --- Detailed Per-Meal Analysis (for individual plots and data for daily summaries) ---
    all_analyzed_meals_data_weekly = []
    if detected_cgm_meals_weekly:
        print(f"\n--- Starting Detailed Analysis for {len(detected_cgm_meals_weekly)} Detected Meal(s) for Individual Plots/Data ---")
        for i, meal_details in enumerate(detected_cgm_meals_weekly):
            # Note: meal_counter for analyze_and_plot_single_meal is just an iteration index here.
            # The 'meal_counter' in meal_analysis_data will be re-assigned for daily plots.
            analyzed_data = analyze_and_plot_single_meal(
                meal_details, i + 1, df_cgm, df_hr, df_hrv, user_id, CONFIG,
                save_plots=save_individual_meal_plots, 
                show_plots=show_individual_meal_plots 
            )
            if analyzed_data:
                all_analyzed_meals_data_weekly.append(analyzed_data)
    
    # --- Generate Daily Summary Pages and Add to PDF ---
    start_date_dt_obj = datetime.strptime(start_date_str, "%Y-%m-%d")

    for day_offset in range(num_days):
        current_date_obj = start_date_dt_obj + timedelta(days=day_offset)
        print(f"\n--- Generating Daily Summary Page for: {current_date_obj.strftime('%Y-%m-%d (%A')} ---")

        # Filter data for the current day
        day_start_utc = pd.Timestamp(current_date_obj, tz='UTC')
        day_end_utc = day_start_utc + pd.Timedelta(days=1)

        df_cgm_day = df_cgm[(df_cgm['timestamp'] >= day_start_utc) & (df_cgm['timestamp'] < day_end_utc)] if not df_cgm.empty else pd.DataFrame()
        df_hr_day = df_hr[(df_hr['timestamp'] >= day_start_utc) & (df_hr['timestamp'] < day_end_utc)] if not df_hr.empty else pd.DataFrame()
        df_hrv_day = df_hrv[(df_hrv['timestamp'] >= day_start_utc) & (df_hrv['timestamp'] < day_end_utc)] if not df_hrv.empty else pd.DataFrame()
        df_stress_day = df_stress[(df_stress['timestamp'] >= day_start_utc) & (df_stress['timestamp'] < day_end_utc)] if not df_stress.empty else pd.DataFrame()
        df_activity_day = df_activity[(df_activity['timestamp'] >= day_start_utc) & (df_activity['timestamp'] < day_end_utc)] if not df_activity.empty else pd.DataFrame()
        
        daily_sleep_periods_for_plot = []
        for s_start, s_end in sleep_periods_weekly:
            # Include sleep if it starts OR ends on this day, or spans it.
            # This helps visualize sleep that starts late one day and ends early the next.
            if (s_start.date() == current_date_obj.date() or 
                s_end.date() == current_date_obj.date() or
                (s_start.date() < current_date_obj.date() and s_end.date() > current_date_obj.date())):
                daily_sleep_periods_for_plot.append((s_start, s_end))
        
        daily_meals_analysis_data_for_plot = []
        for meal_data in all_analyzed_meals_data_weekly:
            if meal_data['cgm_meal_metrics']['timestamp'].date() == current_date_obj.date():
                # Create a copy to avoid modifying the original meal_counter for other uses
                daily_meals_analysis_data_for_plot.append(meal_data.copy())
        daily_meals_analysis_data_for_plot.sort(key=lambda x: x['cgm_meal_metrics']['timestamp']) # Sort by meal time
        for idx, meal_data in enumerate(daily_meals_analysis_data_for_plot,1):
            meal_data['meal_counter'] = idx
        
        print(f"Found {len(daily_meals_analysis_data_for_plot)} meals for this day.")

        fig_daily_page = plot_daily_summary_page(
            user_id, current_date_obj, daily_meals_analysis_data_for_plot,
            df_cgm_day, df_hr_day, df_hrv_day, df_stress_day, df_activity_day,
            daily_sleep_periods_for_plot, CONFIG
        )

        if fig_daily_page and pdf_pages:
            pdf_pages.savefig(fig_daily_page, bbox_inches='tight')
        
        if fig_daily_page and show_daily_summary_live:
            plt.show(block=False) # Non-blocking show
        
        if fig_daily_page: # Always close the figure after use
            plt.close(fig_daily_page)


    # --- Finalize PDF ---
    if pdf_pages:
        pdf_pages.close()
        print(f"Weekly PDF report saved: {pdf_filepath}")

    if show_daily_summary_live or show_individual_meal_plots or show_overview_plot_live:
         # If any live plots were shown, might need plt.show(block=True) here if not in an interactive env
         # For scripts, typically you'd save and then view the files.
         # Jupyter notebooks handle plt.show() differently.
         if not any(matplotlib.get_backend() == x for x in ['module://ipykernel.pylab.backend_inline', 'nbAgg']):
             print("\nCall plt.show() if plots did not display (e.g. in a non-interactive script run).")
             # plt.show() # Uncomment if needed, but can block script completion.
             
    print(f"\n==== Analysis Complete for User {user_id} ====")

def analyze_and_plot_single_meal(meal_event_details, meal_counter, df_cgm_weekly, df_hr_weekly, df_hrv_weekly, user_id, config, save_plots=True, show_plots=False):
    cgm_meal_metrics = calculate_cgm_metrics_for_meal(meal_event_details, df_cgm_weekly, config['cgm'])
    if not cgm_meal_metrics:
        print(f"Could not calculate CGM metrics for meal {meal_counter} at {meal_event_details['timestamp']}. Skipping.")
        return None

    prandial_conf = config['prandial_window']
    window_start = cgm_meal_metrics['timestamp'] - pd.Timedelta(minutes=prandial_conf['minutes_before_meal'])
    
    prandial_end = cgm_meal_metrics.get('recovery_time')
    if not prandial_end and cgm_meal_metrics.get('peak_time'):
        prandial_end = cgm_meal_metrics['peak_time'] + pd.Timedelta(minutes=prandial_conf['minutes_after_meal_peak'])
    if not prandial_end: 
        prandial_end = cgm_meal_metrics['timestamp'] + pd.Timedelta(minutes=prandial_conf['min_duration_after_start'])
    if (prandial_end - window_start).total_seconds()/60 < 30:
         prandial_end = window_start + pd.Timedelta(minutes=30) # Ensure min 30 min window

    cgm_segment = df_cgm_weekly[(df_cgm_weekly['timestamp'] >= window_start) & (df_cgm_weekly['timestamp'] <= prandial_end)]
    hr_segment = df_hr_weekly[(df_hr_weekly['timestamp'] >= window_start) & (df_hr_weekly['timestamp'] <= prandial_end)] if not df_hr_weekly.empty else pd.DataFrame()
    hrv_segment = df_hrv_weekly[(df_hrv_weekly['timestamp'] >= window_start) & (df_hrv_weekly['timestamp'] <= prandial_end)] if not df_hrv_weekly.empty else pd.DataFrame()

    hr_prandial_metrics, hrv_prandial_metrics = calculate_prandial_hr_hrv_metrics(cgm_meal_metrics, df_hr_weekly, df_hrv_weekly, prandial_conf)

    meal_analysis_data = {
        'cgm_meal_metrics': cgm_meal_metrics,
        'cgm_segment': cgm_segment, 'hr_segment': hr_segment, 'hrv_segment': hrv_segment,
        'hr_prandial_metrics': hr_prandial_metrics, 'hrv_prandial_metrics': hrv_prandial_metrics,
        'user_id': user_id, 'meal_counter': meal_counter # meal_counter might be global or daily, ensure consistency
    }

    if not cgm_segment.empty:
        if save_plots or show_plots: 
            # Create a temporary figure for the individual meal plot if needed
            # The plot_single_prandial_response is also used by summary plots, so it doesn't save/show itself
            # This block handles the explicit "individual meal plot" saving/showing
            temp_fig, _ = plot_single_prandial_response(**meal_analysis_data) # Pass dict as kwargs
            
            if temp_fig and save_plots:
                plot_dir = os.path.join(CONFIG['plot_output_dir'], "individual_meals")
                filename_prefix = f"meal_{user_id}"
                suffix = f"{meal_event_details['timestamp'].strftime('%Y%m%d_%H%M')}_M{meal_counter}"
                saved_path = save_figure(temp_fig, plot_dir, filename_prefix, suffix)
                if saved_path: print(f"Individual meal plot saved: {saved_path}")

            if temp_fig and show_plots:
                print(f"Displaying plot for Meal {meal_counter}...")
                plt.show(block=False) # Non-blocking show if in script
            
            if temp_fig: plt.close(temp_fig) # Close the temporary figure
    else:
        print(f"No CGM data in defined window for meal {meal_counter}. Individual plot skipped.")
    
    return meal_analysis_data



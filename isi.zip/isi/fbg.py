import pandas as pd
from dateutil.tz import gettz
from COMBINED_1 import get_weekly_data_raw_sync, process_physiological_data

IST = gettz("Asia/Kolkata")
FASTING_END_TIME = pd.to_datetime("07:00:00", format='%H:%M:%S').time()  # Set as needed

def calculate_fbg_from_cgm(user_id, start_date_str, num_days, fasting_end_time=FASTING_END_TIME):
    """
    Fetches CGM data using your API and calculates daily FBG (Fasting Blood Glucose).
    Returns a DataFrame with columns: date, fbg, and the average FBG for the range.
    """
    weekly_raw_data = get_weekly_data_raw_sync(user_id, start_date_str, num_days)
    df_cgm = process_physiological_data(weekly_raw_data.get('cgm', []), 'cgm', 'cgm')
    if df_cgm.empty or 'cgm_value' not in df_cgm.columns:
        print("No CGM data available for FBG calculation.")
        return pd.DataFrame(), None

    # Localize timestamps to IST
    df_cgm['timestamp'] = pd.to_datetime(df_cgm['timestamp']).dt.tz_localize(None).dt.tz_localize(IST)
    df_cgm['date'] = df_cgm['timestamp'].dt.date

    # Calculate fasting_end_datetime for each day
    df_cgm['fasting_end_datetime'] = df_cgm['timestamp'].dt.normalize() + pd.to_timedelta(fasting_end_time.strftime('%H:%M:%S'))
    df_cgm['time_diff'] = (df_cgm['fasting_end_datetime'] - df_cgm['timestamp']).dt.total_seconds().abs()

    # For each date, pick the value closest to fasting_end_time
    fbg_df = df_cgm.loc[df_cgm.groupby('date')['time_diff'].idxmin()]
    fbg_df = fbg_df[['date', 'cgm_value']].rename(columns={'cgm_value': 'fbg'}).reset_index(drop=True)

    # Calculate average FBG for the range
    avg_fbg = fbg_df['fbg'].mean() if not fbg_df.empty else None

    return fbg_df, avg_fbg

# Example usage:
if __name__ == "__main__":
    user_id = "156"
    start_date_str = "2025-04-30"
    num_days = 7
    daily_fbg, avg_fbg = calculate_fbg_from_cgm(user_id, start_date_str, num_days)
    print("Daily FBG:\n", daily_fbg)
    print("\nAverage FBG for the range:", avg_fbg)
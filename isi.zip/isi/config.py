import os
os.environ['MPLCONFIGDIR'] = '/var/www/mplconfig'

import os
import requests
import numpy as np
import pandas as pd
from scipy.signal import savgol_filter, find_peaks
from datetime import datetime, timedelta, timezone
import asyncio
import aiohttp
import nest_asyncio
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from matplotlib.backends.backend_pdf import PdfPages  # For multi-page PDF
from matplotlib.gridspec import GridSpec, GridSpecFromSubplotSpec  # For complex layouts
from sklearn.linear_model import LinearRegression
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from matplotlib.backends.backend_pdf import PdfPages # For multi-page PDF
from matplotlib.gridspec import GridSpec, GridSpecFromSubplotSpec # For complex layouts
from sklearn.linear_model import LinearRegression
import argparse
import matplotlib
import json

nest_asyncio.apply()
try:
    from IPython import get_ipython
    get_ipython().run_line_magic('matplotlib', 'inline')
except:
    pass

COMMON_USER_ID_DEFAULT = "132"
COMMON_START_DATE_DEFAULT = "2025-06-15" # Start of the week
DAYS_TO_ANALYZE = 3

CONFIG = {
    'data_cache_dir': "./data_cache_weekly",
    'cgm': {
        'data_cache_dir': "./data_cache_weekly/cgm",
        'time_windows': {'first_meal_window': ('05:00', '11:00'), 'breakfast': ('05:00', '11:00'), 'lunch': ('11:00', '15:00'), 'dinner': ('17:00', '22:00'), 'snack': ('00:00', '23:59')},
        'meal_criteria': {'min_glucose_rise': 10, 'min_rise_rate': 0.01, 'max_baseline_variation': 25, 'min_post_meal_data': 120, 'min_pre_meal_data': 30, 'min_gap_minutes': 90, 'peak_prominence': 5, 'peak_distance': 12 },
        'ip_thresholds': {'strong': 0.07, 'moderate': 0.05, 'diminished': 0.01},
        'is_thresholds': {'high': 0.020, 'good': 0.015, 'moderate': 0.010},
        'smoothing': {'default_window': 2, 'minimum_window': 1, 'poly_order': 1}
    },
    'hr': {
        'data_cache_dir': "./data_cache_weekly/hr",
        'smoothing': {'default_window': 9, 'minimum_window': 1, 'poly_order': 2},
        'activity_spike_thresholds':{
            'exercise_hr':100
        }
    },
    'hrv': {
        'data_cache_dir': "./data_cache_weekly/hrv",
        'smoothing': {'default_window': 11, 'minimum_window': 5, 'poly_order': 2},
        'activity_spike_thresholds':{
            'low_hrv':30
        }
    },
    'sleep': {
        'data_cache_dir': "./data_cache_weekly/sleep",
    },
    'stress': { # Placeholder for Stress data
        'data_cache_dir': "./data_cache_weekly/stress",
        'smoothing': {'default_window': 11, 'minimum_window': 5, 'poly_order': 3}
    },
    'activity': { # Placeholder for Activity data
        'data_cache_dir': "./data_cache_weekly/activity",
        'smoothing': {'default_window': 11, 'minimum_window': 5, 'poly_order': 3}
    },
    'prandial_window': {
        'minutes_before_meal': 30,
        'minutes_after_meal_peak': 120,
        'min_duration_after_start': 150
    },
    'plot_output_dir': "./prandial_analysis_plots" # Centralized output directory for plots
}

os.makedirs(CONFIG['data_cache_dir'], exist_ok=True)
for key in ['cgm', 'hr', 'hrv', 'sleep', 'stress', 'activity']: # Added stress and activity
    if key in CONFIG and 'data_cache_dir' in CONFIG[key]:
        os.makedirs(CONFIG[key]['data_cache_dir'], exist_ok=True)
os.makedirs(CONFIG['plot_output_dir'], exist_ok=True)


API_BASE_URL_CGM = "https://devapi.revival365ai.com/data/chart"
API_BASE_URL_BAND = "https://devapi.revival365ai.com/data/chart/sleep_readings"
BAND_HEADERS = {} # IMPORTANT: Populate if API requires authentication
# Example: BAND_HEADERS = {"Authorization": "Bearer YOUR_API_TOKEN"}
if __name__ == "__main__":
    print(COMMON_USER_ID_DEFAULT, COMMON_START_DATE_DEFAULT, DAYS_TO_ANALYZE)

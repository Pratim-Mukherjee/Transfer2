import pandas as pd
import numpy as np
from scipy.signal import savgol_filter
from config import CONFIG
from pandas import Timestamp
from datetime import datetime, timezone, timedelta

def process_physiological_data(raw_data_list, data_type_name, config_key):
    if not raw_data_list: return pd.DataFrame()
    df = pd.DataFrame(raw_data_list)
    if df.empty or 'timestamp' not in df.columns or 'value' not in df.columns: return pd.DataFrame()

    df['timestamp'] = pd.to_datetime(df['timestamp'])
    if df['timestamp'].dt.tz is None: df['timestamp'] = df['timestamp'].dt.tz_localize('UTC')
    else: df['timestamp'] = df['timestamp'].dt.tz_convert('UTC')

    df = df.sort_values('timestamp').drop_duplicates(subset=['timestamp'])
    df = df.rename(columns={'value': f"{data_type_name}_value"})
    df = df.dropna(subset=[f"{data_type_name}_value"])
    if df.empty: return pd.DataFrame()

    # Handle potential non-numeric values before resampling and interpolation
    df[f"{data_type_name}_value"] = pd.to_numeric(df[f"{data_type_name}_value"], errors='coerce')
    df = df.dropna(subset=[f"{data_type_name}_value"])
    if df.empty: return pd.DataFrame()


    df = df.set_index('timestamp').resample('5min').mean(numeric_only=True)
    df[f"{data_type_name}_value"] = df[f"{data_type_name}_value"].interpolate(method='time', limit=12).ffill(limit=3).bfill(limit=3)
    df = df.dropna(subset=[f"{data_type_name}_value"])
    if df.empty: return pd.DataFrame()

    # Ensure config_key exists for smoothing parameters
    if config_key not in CONFIG or 'smoothing' not in CONFIG[config_key]:
        print(f"Warning: Smoothing configuration for {config_key} not found. Using default rolling mean.")
        df[f"{data_type_name}_smoothed"] = df[f"{data_type_name}_value"].rolling(window=min(3, len(df)), center=True, min_periods=1).mean()
    else:
        smoothing_conf = CONFIG[config_key]['smoothing']
        win_len = smoothing_conf.get('default_window', 9) # Use .get for safety
        min_win = smoothing_conf.get('minimum_window', 2)
        poly = smoothing_conf.get('poly_order', 1)

        if len(df) < win_len * 2 : 
            win_len = max(min_win, len(df) // 3)
        if win_len % 2 == 0: win_len += 1
        if win_len <= poly: win_len = poly + (1 if poly % 2 != 0 else 2)

        if len(df) > win_len : df[f"{data_type_name}_smoothed"] = savgol_filter(df[f"{data_type_name}_value"].values, window_length=win_len, polyorder=poly)
        else: df[f"{data_type_name}_smoothed"] = df[f"{data_type_name}_value"].rolling(window=min(3, len(df)), center=True, min_periods=1).mean()
    
    df[f"{data_type_name}_smoothed"] = df[f"{data_type_name}_smoothed"].fillna(df[f"{data_type_name}_value"])


    df = df.reset_index()
    tdiffs = df['timestamp'].diff().dt.total_seconds() / 60
    if len(tdiffs)>0 and pd.isna(tdiffs.iloc[0]): tdiffs.iloc[0] = tdiffs.mean() if tdiffs.notna().any() else 5.0
    
    # RoC calculations - only for CGM for now, or specific types
    if data_type_name == 'cgm': # Or add other types if RoC is needed for them
        roc_col, roc_raw_col, roc_sm_col = f"{data_type_name}_roc", f"{data_type_name}_roc_raw", f"{data_type_name}_roc_smooth"
        df[roc_col] = (df[f"{data_type_name}_smoothed"].diff() / tdiffs).replace([np.inf, -np.inf], np.nan).fillna(0)
        df[roc_raw_col] = (df[f"{data_type_name}_value"].diff() / tdiffs).replace([np.inf, -np.inf], np.nan).fillna(0)

        if len(df) > win_len and 'smoothing' in CONFIG.get(config_key, {}): # Check win_len again
             df[roc_sm_col] = savgol_filter(df[roc_col].values, window_length=win_len, polyorder=poly)
        else: df[roc_sm_col] = df[roc_col].rolling(window=min(3, len(df)), center=True, min_periods=1).mean()
        df[roc_sm_col] = df[roc_sm_col].fillna(df[roc_col])
    return df
def process_weekly_sleep_data(daily_sleep_data_tuples):
    all_sleep_periods = []
    if daily_sleep_data_tuples: # Ensure it's not None
        for period_tuple in daily_sleep_data_tuples:
            if period_tuple and period_tuple[0] is not None and period_tuple[1] is not None:
                all_sleep_periods.append(period_tuple)
    return all_sleep_periods

def is_sleeping(value):
    if value is None: return False
    return value != 4 # Assuming 4 is awake

def get_sleep_window(readings_list):
    if not readings_list: return None, None
    non_awake_readings = []
    for r in readings_list:
        if 'value' in r and 'timestamp' in r and is_sleeping(r['value']):
            try:
                ts_str = r['timestamp']
                if isinstance(ts_str, str):
                    dt_obj = datetime.fromisoformat(ts_str.replace('Z', '+00:00'))
                elif isinstance(ts_str, datetime):
                    dt_obj = ts_str
                else:
                    dt_obj = pd.to_datetime(ts_str).to_pydatetime()

                if dt_obj.tzinfo is None:
                    dt_obj = dt_obj.replace(tzinfo=timezone.utc)
                else:
                    dt_obj = dt_obj.astimezone(timezone.utc)
                non_awake_readings.append({'timestamp': dt_obj, 'value': r['value']})
            except Exception as e:
                print(f"Warning: Could not parse timestamp {r['timestamp']} in sleep data: {e}")
                continue
    
    if not non_awake_readings: return None, None
    non_awake_readings.sort(key=lambda x: x['timestamp'])
    return non_awake_readings[0]['timestamp'], non_awake_readings[-1]['timestamp']
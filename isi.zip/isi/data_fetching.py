import os
import json
import asyncio
import aiohttp
from datetime import datetime, timedelta
from config import CONFIG, API_BASE_URL_BAND, BAND_HEADERS
from data_processing import get_sleep_window  # if used


async def fetch_single_reading_type_daily_async(session, user_id, date_str, reading_type, api_url_template, cache_subdir_key, data_key_in_json):
    url = api_url_template.format(user_id=user_id, date_str=date_str)
    # Ensure cache_subdir_key exists in CONFIG and has 'data_cache_dir'
    if cache_subdir_key not in CONFIG or 'data_cache_dir' not in CONFIG[cache_subdir_key]:
        print(f"Warning: Configuration for {cache_subdir_key} not found. Skipping cache for {reading_type}.")
        cache_file = None
    else:
        cache_dir = CONFIG[cache_subdir_key]['data_cache_dir']
        cache_file = os.path.join(cache_dir, f"{user_id}_{date_str}_{reading_type}.json")

    if cache_file and os.path.exists(cache_file):
        try:
            with open(cache_file, 'r') as f: data_json = json.load(f)
            return date_str, reading_type, data_json.get(data_key_in_json, []) if data_key_in_json else data_json
        except Exception as e: print(f"Error reading cached {reading_type} for {date_str}: {e}")
    try:
        async with session.get(url, headers=BAND_HEADERS, timeout=20) as response:
            response.raise_for_status()
            data_json = await response.json()
            if cache_file:
                with open(cache_file, 'w') as f: json.dump(data_json, f)
            return date_str, reading_type, data_json.get(data_key_in_json, []) if data_key_in_json else data_json
    except Exception as e:
        print(f"Error fetching {reading_type} for {user_id} on {date_str}: {e}")
        return date_str, reading_type, []
    
async def fetch_sleep_data_daily_async(session, user_id, date_str):
    api_url_template = f"{API_BASE_URL_BAND}/{{user_id}}/{{date_str}}"
    url = api_url_template.format(user_id=user_id, date_str=date_str)
    cache_dir = CONFIG['sleep']['data_cache_dir']
    cache_file = os.path.join(cache_dir, f"{user_id}_{date_str}_sleep.json")
    sleep_data_json = None
    if os.path.exists(cache_file):
        try:
            with open(cache_file, 'r') as f: sleep_data_json = json.load(f)
        except Exception as e: print(f"Error reading cached sleep data for {date_str}: {e}")

    if sleep_data_json is None:
        try:
            async with session.get(url, headers=BAND_HEADERS, timeout=20) as response:
                response.raise_for_status()
                sleep_data_json = await response.json()
                with open(cache_file, 'w') as f: json.dump(sleep_data_json, f)
        except Exception as e:
            print(f"Error fetching sleep data for {user_id} on {date_str}: {e}")
            return date_str, 'sleep', (None, None)
    if sleep_data_json:
        raw_sleep_readings = sleep_data_json.get('sleep_readings', [])
        sleep_start_dt, sleep_end_dt = get_sleep_window(raw_sleep_readings)
        return date_str, 'sleep', (sleep_start_dt, sleep_end_dt)
    return date_str, 'sleep', (None, None)

async def fetch_all_data_for_week_async(user_id, start_date_str, num_days):
    all_data_promises = []
    start_date_obj = datetime.strptime(start_date_str, "%Y-%m-%d")
    async with aiohttp.ClientSession() as session:
        for i in range(num_days):
            current_date_obj = start_date_obj + timedelta(days=i)
            current_date_str = current_date_obj.strftime("%Y-%m-%d")
            all_data_promises.append(fetch_single_reading_type_daily_async(session, user_id, current_date_str, 'cgm', "https://devapi.revival365ai.com/data/chart/glucose-readings/{user_id}/{date_str}", 'cgm', 'glucose_readings'))
            all_data_promises.append(fetch_single_reading_type_daily_async(session, user_id, current_date_str, 'hr', f"{API_BASE_URL_BAND}/hr_readings/{{user_id}}/{{date_str}}", 'hr', 'heartrate_readings'))
            all_data_promises.append(fetch_single_reading_type_daily_async(session, user_id, current_date_str, 'hrv', f"{API_BASE_URL_BAND}/hrv_readings/{{user_id}}/{{date_str}}", 'hrv', 'hrv_readings'))
            all_data_promises.append(fetch_single_reading_type_daily_async(session, user_id, current_date_str, 'stress', f"{API_BASE_URL_BAND}/stress_readings/{{user_id}}/{{date_str}}", 'stress', 'stress_readings')) # Added Stress
            all_data_promises.append(fetch_single_reading_type_daily_async(session, user_id, current_date_str, 'activity', f"{API_BASE_URL_BAND}/activity_readings/{{user_id}}/{{date_str}}", 'activity', 'activity_readings')) # Added Activity
            all_data_promises.append(fetch_sleep_data_daily_async(session, user_id, current_date_str))
        daily_results = await asyncio.gather(*all_data_promises)
    
    weekly_data_raw = {'cgm': [], 'hr': [], 'hrv': [], 'sleep': [], 'stress': [], 'activity': []} # Added stress, activity
    for date_str_res, type_res, data_res in daily_results:
        if type_res == 'sleep': weekly_data_raw[type_res].append(data_res) # Sleep data is (start, end) tuples per day
        elif data_res: weekly_data_raw[type_res].extend(data_res) # Other data is list of readings
    return weekly_data_raw

def get_weekly_data_raw_sync(user_id, start_date_str, num_days):
    try:
        loop = asyncio.get_event_loop()
        if loop.is_closed(): asyncio.set_event_loop(asyncio.new_event_loop()); loop = asyncio.get_event_loop()
        return loop.run_until_complete(fetch_all_data_for_week_async(user_id, start_date_str, num_days))
    except RuntimeError:
        try: return asyncio.run(fetch_all_data_for_week_async(user_id, start_date_str, num_days))
        except RuntimeError as e_run: print(f"Asyncio.run failed: {e_run}"); return {'cgm': [], 'hr': [], 'hrv': [], 'sleep':[], 'stress':[], 'activity':[]}

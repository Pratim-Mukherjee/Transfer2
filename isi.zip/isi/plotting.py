import os
os.environ['MPLCONFIGDIR'] = '/var/www/mplconfig'

import pandas as pd
import os
import matplotlib
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from matplotlib.backends.backend_pdf import PdfPages
from matplotlib.gridspec import GridSpec, GridSpecFromSubplotSpec
from matplotlib import axes
from config import CONFIG




def plot_single_prandial_response(cgm_meal_metrics, df_cgm_segment, df_hr_segment, df_hrv_segment,
                                  hr_prandial_metrics, hrv_prandial_metrics,
                                  user_id, meal_counter, fig_ax=None):
    if fig_ax:
        fig, ax1 = fig_ax
    else:
        fig, ax1 = plt.subplots(figsize=(16, 9)) 

    meal_time = cgm_meal_metrics['timestamp']
    extra_labels = []
    if cgm_meal_metrics.get('sleep_related', False):
        extra_labels.append("Sleep-Related Meal")
    if cgm_meal_metrics.get('activity_related', False):
        extra_labels.append("Activity-Related Meal")
    if cgm_meal_metrics.get('cortisol_related', False):
        extra_labels.append("Cortisol-Related Meal")

    extra_str = " | ".join(extra_labels)
    title = f"Meal {meal_counter} ({cgm_meal_metrics['meal_type']}) on {meal_time.strftime('%Y-%m-%d %H:%M')}"
    if extra_str:
        title += f"\n[{extra_str}]"

    if fig_ax is None: 
        fig.suptitle(f"Prandial Response for User {user_id}\n{title}", fontsize=14, y=0.98)
    else: 
        ax1.set_title(title, fontsize=10)

    title = f"Meal {meal_counter} ({cgm_meal_metrics['meal_type']}) on {meal_time.strftime('%Y-%m-%d %H:%M')}"
    if fig_ax is None: 
        fig.suptitle(f"Prandial Response for User {user_id}\n{title}", fontsize=14, y=0.98)
    else: 
        ax1.set_title(title, fontsize=10)

    if not df_cgm_segment.empty:
        ax1.plot(df_cgm_segment['timestamp'], df_cgm_segment['cgm_value'], color='lightgrey', alpha=0.6, label='CGM Raw')
        ax1.plot(df_cgm_segment['timestamp'], df_cgm_segment['cgm_smoothed'], color='blue', linewidth=1.5, label='CGM (mg/dL)')
        ax1.axhline(y=cgm_meal_metrics['baseline'], color='blue', linestyle=':', alpha=0.5, lw=1, label=f"Base: {cgm_meal_metrics['baseline']:.0f}")
        if pd.notna(cgm_meal_metrics['peak_time']) and pd.notna(cgm_meal_metrics['peak']):
             ax1.plot(cgm_meal_metrics['peak_time'], cgm_meal_metrics['peak'], 'bP', markersize=7, label=f"Peak: {cgm_meal_metrics['peak']:.0f}")
            # Mark inflection point with a star
        if pd.notna(cgm_meal_metrics['inflection_time']) and pd.notna(cgm_meal_metrics['inflection_value']):
            ax1.plot(
                cgm_meal_metrics['inflection_time'],
                cgm_meal_metrics['inflection_value'],
                marker='*', color='magenta', markersize=14, label='Inflection Point'
            )
        
    ax1.set_ylabel("Glucose (mg/dL)", color="blue", fontsize=9)
    ax1.tick_params(axis='y', labelcolor='blue', labelsize=8)
    ax1.tick_params(axis='x', labelsize=8)
    ax1.grid(True, axis='y', linestyle=':', alpha=0.5, color='blue')

    ax2 = ax1.twinx()
    hr_color, hrv_color = 'red', 'green'
    if not df_hr_segment.empty:
        ax2.plot(df_hr_segment['timestamp'], df_hr_segment['hr_smoothed'], color=hr_color, linestyle='-', alpha=0.7, lw=1.5, label='HR (bpm)')
        if hr_prandial_metrics.get('pre_meal_avg_hr') and pd.notna(hr_prandial_metrics['pre_meal_avg_hr']):
            ax2.axhline(y=hr_prandial_metrics['pre_meal_avg_hr'], color=hr_color, linestyle=':', alpha=0.4, lw=1, label=f"Pre HR: {hr_prandial_metrics['pre_meal_avg_hr']:.0f}")
    if not df_hrv_segment.empty:
        ax2.plot(df_hrv_segment['timestamp'], df_hrv_segment['hrv_smoothed'], color=hrv_color, linestyle='--', alpha=0.7, lw=1.5, label='HRV (ms)')
        if hrv_prandial_metrics.get('pre_meal_avg_hrv') and pd.notna(hrv_prandial_metrics['pre_meal_avg_hrv']):
            ax2.axhline(y=hrv_prandial_metrics['pre_meal_avg_hrv'], color=hrv_color, linestyle=':', alpha=0.4, lw=1, label=f"Pre HRV: {hrv_prandial_metrics['pre_meal_avg_hrv']:.0f}")

    if not df_hr_segment.empty or not df_hrv_segment.empty:
        ax2.set_ylabel("HR / HRV", fontsize=9) 
        ax2.tick_params(axis='y', labelsize=8)
    else:
        ax2.set_yticks([]) # Hide y-axis if no HR/HRV data

    all_timestamps = []
    if not df_cgm_segment.empty: all_timestamps.extend(df_cgm_segment['timestamp'])
    if not df_hr_segment.empty: all_timestamps.extend(df_hr_segment['timestamp'])
    if not df_hrv_segment.empty: all_timestamps.extend(df_hrv_segment['timestamp'])
    if all_timestamps:
        ax1.set_xlim(min(all_timestamps) - pd.Timedelta(minutes=5), max(all_timestamps) + pd.Timedelta(minutes=5))

    ax1.xaxis.set_major_formatter(mdates.DateFormatter('%H:%M'))
    plt.setp(ax1.get_xticklabels(), rotation=30, ha='right')

    metrics_text = (
        f"Time: {cgm_meal_metrics['timestamp'].strftime('%Y-%m-%d %H:%M')}\n"
        f"Type: {cgm_meal_metrics['meal_type']}  Conf: {cgm_meal_metrics['confidence']}\n"
        f"Baseline: {cgm_meal_metrics['baseline']:.1f}\n"
        f"Peak: {cgm_meal_metrics['peak']:.1f} at {cgm_meal_metrics['peak_time'].strftime('%H:%M')}\n"
        f"Peak Height: {cgm_meal_metrics['peak_height']:.1f}\n"
        f"Time to Peak: {cgm_meal_metrics['time_to_peak']:.1f} min\n"
        f"Inflection: {cgm_meal_metrics['inflection_value']:.1f} at {cgm_meal_metrics['inflection_time'].strftime('%H:%M')}\n"
        f"IP: {cgm_meal_metrics['ip']:.3f} ({cgm_meal_metrics['ip_normalized']:.1f}%)\n"
        f"IS: {cgm_meal_metrics['is']:.3f} ({cgm_meal_metrics['is_normalized']:.1f}%)\n"
        f"Initial Slope: {cgm_meal_metrics['initial_slope']:.3f}\n"
        f"Post Slope: {cgm_meal_metrics['post_slope']:.3f}\n"
        f"Decline Slope: {cgm_meal_metrics['decline_slope']:.3f}\n"
        f"AUC: {cgm_meal_metrics['auc']:.1f}\n"
        f"Recovery: {cgm_meal_metrics['recovery_time'].strftime('%H:%M') if cgm_meal_metrics['recovery_time'] else 'N/A'}\n"
        f"GI (est): {cgm_meal_metrics['estimated_gi']:.1f}\n"
        f"Activity-Related: {'Yes' if cgm_meal_metrics.get('activity_related', False) else 'No'}\n"
        f"Sleep-Related: {'Yes' if cgm_meal_metrics.get('sleep_related', False) else 'No'}\n"
        f"Cortisol-Related: {'Yes' if cgm_meal_metrics.get('cortisol_related', False) else 'No'}\n"
    )
    if hr_prandial_metrics.get('meal_avg_hr') and pd.notna(hr_prandial_metrics.get('meal_avg_hr')):
        metrics_text += f"HR Avg: {hr_prandial_metrics['meal_avg_hr']:.0f} ({hr_prandial_metrics.get('meal_avg_hr_change_from_base', 0):+.0f})\n"
    if hrv_prandial_metrics.get('meal_avg_hrv') and pd.notna(hrv_prandial_metrics.get('meal_avg_hrv')):
        metrics_text += f"HRV Avg: {hrv_prandial_metrics['meal_avg_hrv']:.0f} ({hrv_prandial_metrics.get('meal_avg_hrv_change_from_base', 0):+.0f})"
    
    ax1.text(0.02, 0.02, metrics_text, transform=ax1.transAxes, fontsize=7,
             verticalalignment='bottom', bbox=dict(boxstyle='round,pad=0.3', fc='whitesmoke', alpha=0.7))

    # Legend handling is deferred to the calling function (daily/weekly summary) for consolidated legends
    if fig_ax is None: 
        lines1, labels1 = ax1.get_legend_handles_labels()
        lines2, labels2 = ax2.get_legend_handles_labels()
        custom_handles = []
        custom_labels = []
        from matplotlib.patches import Patch
        from matplotlib.lines import Line2D
        if cgm_meal_metrics.get('sleep_related', False):
            custom_handles.append(Patch(color='slateblue', alpha=0.3, label='Sleep-Related Meal'))
            custom_labels.append('Sleep-Related Meal')
        if cgm_meal_metrics.get('activity_related', False):
            custom_handles.append(Line2D([0], [0], color='red', lw=2, label='Activity-Related Meal'))
            custom_labels.append('Activity-Related Meal')
        if cgm_meal_metrics.get('cortisol_related', False):
            custom_handles.append(Patch(color='gold', alpha=0.3, label='Cortisol-Related Meal'))
            custom_labels.append('Cortisol-Related Meal')


        # Combine all legend entries, ensuring uniqueness
        all_lines = lines1 + lines2 + custom_handles
        all_labels = labels1 + labels2 + custom_labels
        unique_legend = dict(zip(all_labels, all_lines))
        ax1.legend(unique_legend.values(), unique_legend.keys(), loc='upper right', fontsize=8)
        plt.tight_layout(rect=[0.02, 0.02, 0.98, 0.90])
    
    return fig, ax1

def save_figure(fig, directory, filename_prefix, identifier_suffix):
    if fig is None: return None
    os.makedirs(directory, exist_ok=True)
    filename = f"{filename_prefix}_{identifier_suffix}.png"
    filepath = os.path.join(directory, filename)
    try:
        fig.savefig(filepath, dpi=150, bbox_inches='tight')
        return filepath
    except Exception as e:
        print(f"Error saving figure {filepath}: {e}")
    return None
def plot_meal_responses_panel(fig, spec, all_meal_analysis_data, user_id, date_str_title_suffix):
    """
    Plots multiple meal responses into a given GridSpec position.
    Returns handles for a consolidated legend.
    """
    if not all_meal_analysis_data:
        # Create a dummy ax in the spec and annotate no meals
        ax = fig.add_subplot(spec)
        ax.text(0.5, 0.5, f"No meals detected on {date_str_title_suffix}", horizontalalignment='center', verticalalignment='center', transform=ax.transAxes)
        ax.set_xticks([])
        ax.set_yticks([])
        return [], []


    num_meals = len(all_meal_analysis_data)
    cols = 2 if num_meals > 2 else 1 # Max 2 meal plots side-by-side in this panel
    if num_meals == 1: cols = 1
    rows = (num_meals + cols - 1) // cols

    inner_gs = GridSpecFromSubplotSpec(rows, cols, subplot_spec=spec, wspace=0.3, hspace=0.4)
    
    # Collect legend items from the first meal plot that has all elements
    legend_lines, legend_labels = [], []
    legend_items_collected = False

    for i, meal_data in enumerate(all_meal_analysis_data):
        ax1 = fig.add_subplot(inner_gs[i // cols, i % cols])
        _, current_ax = plot_single_prandial_response(
            cgm_meal_metrics=meal_data['cgm_meal_metrics'],
            df_cgm_segment=meal_data['cgm_segment'],
            df_hr_segment=meal_data['hr_segment'],
            df_hrv_segment=meal_data['hrv_segment'],
            hr_prandial_metrics=meal_data['hr_prandial_metrics'],
            hrv_prandial_metrics=meal_data['hrv_prandial_metrics'],
            user_id=user_id,
            meal_counter=meal_data['meal_counter'], # This should be unique daily counter
            fig_ax=(fig, ax1)
        )
        if not legend_items_collected: # Collect legend from first plot
            lines1, labels1 = current_ax.get_legend_handles_labels()
            ax2_twin = None
            for child in current_ax.get_children(): # Find twinx
                if isinstance(child, matplotlib.axes.Axes) and child is not current_ax and hasattr(child, 'get_legend_handles_labels'):
                    ax2_twin = child
                    break
            lines2, labels2 = [],[]
            if ax2_twin:
                lines2_cand, labels2_cand = ax2_twin.get_legend_handles_labels()
                # Filter out redundant _nolegend_ entries if any
                valid_indices = [idx for idx, lbl in enumerate(labels2_cand) if not lbl.startswith('_nolegend_')]
                lines2 = [lines2_cand[idx] for idx in valid_indices]
                labels2 = [labels2_cand[idx] for idx in valid_indices]

            # Consolidate unique legend items
            temp_legend_dict = dict(zip(labels1 + labels2, lines1 + lines2))
            legend_labels = list(temp_legend_dict.keys())
            legend_lines = list(temp_legend_dict.values())
            if legend_lines: # If any legend items found
                 legend_items_collected = True
    return legend_lines, legend_labels

def plot_weekly_overview(df_cgm_weekly, df_hr_weekly, df_hrv_weekly, 
                         df_stress_weekly, df_activity_weekly, # Added
                         detected_meals, sleep_periods,
                         user_id, week_start_date_str, save_plot=True, show_plot=False):
    if df_cgm_weekly.empty and df_hr_weekly.empty and df_hrv_weekly.empty and df_stress_weekly.empty and df_activity_weekly.empty:
        print("No data available to plot for weekly overview.")
        return None

    fig, ax1 = plt.subplots(figsize=(20, 12)) # Increased height for more data

    # --- Plot CGM Data ---
    cgm_color = 'deepskyblue'
    if not df_cgm_weekly.empty and 'raw_data' in df_cgm_weekly.columns:
        ax1.plot(df_cgm_weekly['timestamp'], df_cgm_weekly['cgm_value'], color='lightgrey', alpha=0.5, label='CGM Raw (mg/dL)')
        ax1.plot(df_cgm_weekly['timestamp'], df_cgm_weekly['raw_data'], color=cgm_color, linewidth=1.5, label='CGM Smoothed (mg/dL)')
    ax1.set_ylabel('Glucose (mg/dL)', color=cgm_color if not df_cgm_weekly.empty else 'grey', fontsize=12)
    ax1.tick_params(axis='y', labelcolor=cgm_color if not df_cgm_weekly.empty else 'grey', labelsize=10)
    ax1.tick_params(axis='x', labelsize=10)
    ax1.grid(True, axis='y', linestyle=':', alpha=0.6, color=cgm_color if not df_cgm_weekly.empty else 'grey')

    # --- Plot HR, HRV, Stress, Activity on secondary y-axes ---
    # This might require careful management of y-axes if scales are very different.
    # For simplicity, using one shared secondary axis for HR/HRV, and potentially a third for Stress/Activity if needed.
    # Or, plot Stress/Activity on ax1 if CGM is missing, or on ax2 if scales allow.
    
    ax2 = ax1.twinx()
    hr_color, hrv_color = 'orangered', 'forestgreen'
    stress_color, activity_color = 'purple', 'sienna'
    
    lines_ax2 = []
    labels_ax2 = []

    if not df_hr_weekly.empty and 'hr_smoothed' in df_hr_weekly.columns:
        l, = ax2.plot(df_hr_weekly['timestamp'], df_hr_weekly['hr_smoothed'], color=hr_color, linestyle='-', alpha=0.8, lw=1.5, label='HR (bpm)')
        lines_ax2.append(l); labels_ax2.append('HR (bpm)')
    if not df_hrv_weekly.empty and 'hrv_smoothed' in df_hrv_weekly.columns:
        l, = ax2.plot(df_hrv_weekly['timestamp'], df_hrv_weekly['hrv_smoothed'], color=hrv_color, linestyle='--', alpha=0.8, lw=1.5, label='HRV (ms)')
        lines_ax2.append(l); labels_ax2.append('HRV (ms)')

    # Tentatively plot Stress and Activity on ax2 as well. If scales are too different, a third axis (ax3) would be better.
    if not df_stress_weekly.empty and 'stress_smoothed' in df_stress_weekly.columns:
        l, = ax2.plot(df_stress_weekly['timestamp'], df_stress_weekly['stress_smoothed'], color=stress_color, linestyle=':', alpha=0.7, lw=1.5, label='Stress')
        lines_ax2.append(l); labels_ax2.append('Stress')
    if not df_activity_weekly.empty and 'activity_smoothed' in df_activity_weekly.columns:
        l, = ax2.plot(df_activity_weekly['timestamp'], df_activity_weekly['activity_smoothed'], color=activity_color, linestyle='-.', alpha=0.7, lw=1.5, label='Activity')
        lines_ax2.append(l); labels_ax2.append('Activity')


    if lines_ax2:
        ax2.set_ylabel('HR / HRV / Stress / Activity', fontsize=12) # Generic label
        ax2.tick_params(axis='y', labelsize=10)
    else:
        ax2.set_yticks([])

    # --- Mark Sleep Periods ---
    sleep_patch_added = False
    if sleep_periods:
        for sleep_start, sleep_end in sleep_periods:
            if sleep_start and sleep_end:
                ax1.axvspan(sleep_start, sleep_end, color='slateblue', alpha=0.15, zorder=-1,
                            label='_nolegend_' if sleep_patch_added else 'Sleep Period')
                sleep_patch_added = True

    # --- Mark Detected Meals ---
    meal_legend_handles = {}
    meal_colors = {'breakfast': 'gold', 'lunch': 'sandybrown', 'dinner': 'salmon', 'snack': 'lightcoral', 'first_meal': 'darkorange', 'other': 'grey'}
    if detected_meals:
        for meal in detected_meals:
            meal_time = meal['timestamp']
            meal_type = meal.get('type', 'other')
            color = meal_colors.get(meal_type, 'grey')
            label = f"Meal: {meal_type.replace('_', ' ').title()}"
            if meal.get('activity_related', False):
                ax1.axvline(meal_time, color='red', linestyle='-', linewidth=2, alpha=0.9, label='Activity-Related Meal' if 'Activity-Related Meal' not in meal_legend_handles else '_nolegend_')
                meal_legend_handles['Activity-Related Meal'] = None
            elif meal.get('sleep_related', False):
                ax1.axvline(meal_time, color='slateblue', linestyle='-', linewidth=2, alpha=0.9, label='Sleep-Related Meal' if 'Sleep-Related Meal' not in meal_legend_handles else '_nolegend_')
                meal_legend_handles['Sleep-Related Meal'] = None


            else:
                if label not in meal_legend_handles:
                    line = ax1.axvline(meal_time, color=color, linestyle='--', linewidth=1.2, alpha=0.9, label=label)
                    meal_legend_handles[label] = line
                else:
                    ax1.axvline(meal_time, color=color, linestyle='--', linewidth=1.2, alpha=0.9)

    if detected_meals:
        for meal in detected_meals:
            inflection_time = meal.get('inflection_time')
            inflection_value = meal.get('inflection_value')
            if pd.notna(inflection_time) and pd.notna(inflection_value):
                ax1.plot(
                    inflection_time,
                    inflection_value,
                    marker='*', color='magenta', markersize=14, label='Inflection Point' if 'Inflection Point' not in ax1.get_legend_handles_labels()[1] else '_nolegend_'
                )

    fig.suptitle(f"Weekly Physiological Overview for User {user_id} (Week of {week_start_date_str})", fontsize=16, y=0.97)
    ax1.xaxis.set_major_locator(mdates.DayLocator(interval=1))
    ax1.xaxis.set_major_formatter(mdates.DateFormatter('%a, %b %d'))
    ax1.xaxis.set_minor_locator(mdates.HourLocator(interval=6))
    ax1.xaxis.set_minor_formatter(mdates.DateFormatter('%H:%M'))

    all_times = []
    for df in [df_cgm_weekly, df_hr_weekly, df_hrv_weekly, df_stress_weekly, df_activity_weekly]:
        if not df.empty: all_times.extend(df['timestamp'])
    if sleep_periods:
        for s_start, s_end in sleep_periods:
            if s_start: all_times.append(s_start)
            if s_end: all_times.append(s_end)
    if detected_meals:
        for meal in detected_meals: all_times.append(meal['timestamp'])

    if all_times:
        min_time, max_time = min(all_times), max(all_times)
        ax1.set_xlim(min_time - pd.Timedelta(hours=1), max_time + pd.Timedelta(hours=1))
    
    plt.setp(ax1.get_xticklabels(which='major'), rotation=30, ha='right')
    plt.setp(ax1.get_xticklabels(which='minor'), rotation=45, ha='right', fontsize=8)
    ax1.tick_params(axis='x', which='minor', pad=7)

    lines1, labels1 = ax1.get_legend_handles_labels()
    # ax2 legend items already collected in lines_ax2, labels_ax2
    
    # Filter out _nolegend_ from ax1 labels/lines
    valid_indices_ax1 = [i for i, lbl in enumerate(labels1) if not lbl.startswith('_nolegend_')]
    lines1_filtered = [lines1[i] for i in valid_indices_ax1]
    labels1_filtered = [labels1[i] for i in valid_indices_ax1]

    # Use the explicitly created meal legend handles
    meal_lines_for_legend = list(meal_legend_handles.values())
    meal_labels_for_legend = list(meal_legend_handles.keys())


    fig.legend(lines1_filtered + lines_ax2 + meal_lines_for_legend, 
               labels1_filtered + labels_ax2 + meal_labels_for_legend,
               loc='upper center', ncol=5, bbox_to_anchor=(0.5, 0.92), fontsize=9) # Adjusted ncol

    plt.tight_layout(rect=[0.02, 0.02, 0.98, 0.88])

    filepath = None
    if save_plot:
        plot_dir = CONFIG['plot_output_dir']
        filename_prefix = f"weekly_OVERVIEW_{user_id}_{week_start_date_str.replace('-', '')}"
        filepath = save_figure(fig, plot_dir, filename_prefix, "full_week")
        if filepath: print(f"Weekly overview plot saved to {filepath}")
    if show_plot: plt.show()
    
    # plt.close(fig) # Closing deferred if adding to PDF
    return fig 

def plot_daily_context_timeline(fig, spec, current_date_obj,
                                df_cgm_day, df_stress_day, df_activity_day,
                                daily_sleep_periods, daily_meals, user_id):
    """
    Plots a 24-hour timeline for CGM, Stress, Activity, and Sleep for a single day.
    """
    ax = fig.add_subplot(spec)
    
    day_start = pd.Timestamp(current_date_obj).tz_localize('UTC') # Ensure UTC
    day_end = day_start + pd.Timedelta(days=1)
    ax.set_xlim(day_start, day_end)
    ax.xaxis.set_major_locator(mdates.HourLocator(interval=3))
    ax.xaxis.set_major_formatter(mdates.DateFormatter('%H:%M'))
    ax.set_xlabel(f"Time on {current_date_obj.strftime('%Y-%m-%d (%a)')}", fontsize=10)

    lines, labels = [], []
    
    # CGM on primary y-axis for context plot
    if not df_cgm_day.empty and 'cgm_smoothed' in df_cgm_day.columns:
        l, = ax.plot(df_cgm_day['timestamp'], df_cgm_day['cgm_smoothed'], color='deepskyblue', label='CGM', lw=1.5)
        lines.append(l); labels.append('CGM (mg/dL)')
        ax.set_ylabel('Glucose (mg/dL)', color='deepskyblue', fontsize=9)
        ax.tick_params(axis='y', labelcolor='deepskyblue', labelsize=8)
    else:
        ax.set_ylabel('Glucose (mg/dL)', color='grey', fontsize=9)
        ax.tick_params(axis='y', labelcolor='grey', labelsize=8)


    # Stress & Activity on secondary y-axis for context plot
    ax_secondary = ax.twinx()
    
    if not df_stress_day.empty and 'stress_smoothed' in df_stress_day.columns:
        l, = ax_secondary.plot(df_stress_day['timestamp'], df_stress_day['stress_smoothed'], color='purple', linestyle=':', label='Stress', lw=1.5)
        lines.append(l); labels.append('Stress') # Add to combined legend
    if not df_activity_day.empty and 'activity_smoothed' in df_activity_day.columns:
        l, = ax_secondary.plot(df_activity_day['timestamp'], df_activity_day['activity_smoothed'], color='sienna', linestyle='-.', label='Activity', lw=1.5)
        lines.append(l); labels.append('Activity') # Add to combined legend
    
    ax_secondary.set_ylabel('Stress / Activity', fontsize=9) # Generic label
    ax_secondary.tick_params(axis='y', labelsize=8)
    if df_stress_day.empty and df_activity_day.empty:
        ax_secondary.set_yticks([])


    # Sleep periods
    sleep_patch_added_ctx = False
    if daily_sleep_periods:
        total_sleep_duration_minutes = 0
        sleep_patch_added_ctx = False
        for sleep_start, sleep_end in daily_sleep_periods:
            # Ensure sleep periods are within the current day's view or clip them
            s_start_clamped = max(sleep_start, day_start)
            s_end_clamped = min(sleep_end, day_end)
            if s_start_clamped < s_end_clamped: # Only plot if there's an overlap
                if not sleep_patch_added_ctx:
                    patch = ax.axvspan(s_start_clamped, s_end_clamped, color='slateblue', alpha=0.2, zorder=-1, label='Sleep')
                    lines.append(patch)
                    labels.append('Sleep')
                    sleep_patch_added_ctx = True
                else:
                    ax.axvspan(s_start_clamped, s_end_clamped, color='slateblue', alpha=0.2, zorder=-1, label='_nolegend_')
                total_sleep_duration_minutes += (s_end_clamped - s_start_clamped).total_seconds() / 60
                # Add to legend if first time
                
                # Calculate duration of this segment
                # This calculation will be for the *visible* part of sleep on this day's plot
                total_sleep_duration_minutes += (s_end_clamped - s_start_clamped).total_seconds() / 60
        
        if total_sleep_duration_minutes > 0:
             sleep_hours = int(total_sleep_duration_minutes // 60)
             sleep_minutes = int(total_sleep_duration_minutes % 60)
             ax.text(0.98, 0.02, f"Sleep (on chart): {sleep_hours}h {sleep_minutes}m", transform=ax.transAxes,
                     ha='right', va='bottom', fontsize=8, bbox=dict(boxstyle='round,pad=0.3', fc='whitesmoke', alpha=0.7))


    # Mark meals
    meal_patch_added_ctx = False
    if daily_meals:
        for meal_data in daily_meals:
            meal_time = meal_data['cgm_meal_metrics']['timestamp']
            if day_start <= meal_time < day_end: # Ensure meal is on this day
                 ax.axvline(meal_time, color='darkorange', linestyle='--', lw=1, alpha=0.8, 
                            label='_nolegend_' if meal_patch_added_ctx else 'Meal Event')
                 meal_patch_added_ctx = True
                 # Add to legend if first time
                 if meal_patch_added_ctx and 'Meal Event' not in labels: lines.append(plt.Line2D([0], [0], color='darkorange', linestyle='--', lw=1, alpha=0.8)); labels.append('Meal Event')


    ax.set_title(f"Daily Context: {current_date_obj.strftime('%A, %B %d, %Y')}", fontsize=11)
    # ax.legend(lines, labels, loc='upper left', ncol=max(1, len(labels)//2), fontsize=8) # Legend for this subplot
    # Consolidated legend will be handled by the parent figure usually
    if lines and labels:
        ax.legend(lines, labels, loc='upper left', fontsize=8)
    return lines, labels # Return legend items for potential consolidation
def plot_daily_summary_page(user_id, current_date_obj, daily_meals_analysis_data,
                            df_cgm_day, df_hr_day, df_hrv_day, df_stress_day, df_activity_day,
                            daily_sleep_periods, config):
    """
    Creates a full page figure summarizing a single day.
    Top: Meal response plots. Bottom: Daily context timeline.
    """
    num_meals = len(daily_meals_analysis_data)
    
    # Determine layout: more space for meals if they exist
    if num_meals > 0:
        fig = plt.figure(figsize=(16, 12 + num_meals * 1)) # Adjust height based on meals
        gs = GridSpec(2, 1, height_ratios=[max(1,num_meals*0.6), 1], hspace=0.3) # Meals panel, Context panel
        meals_spec = gs[0]
        context_spec = gs[1]
    else: # No meals, only context plot
        fig = plt.figure(figsize=(16, 7))
        gs = GridSpec(1, 1)
        context_spec = gs[0]
        meals_spec = None # No meal panel

    fig.suptitle(f"Daily Summary for User {user_id} - {current_date_obj.strftime('%A, %B %d, %Y')}", fontsize=16, y=0.98)

    # Plot meal responses panel (top)
    meal_legend_lines, meal_legend_labels = [], []
    if meals_spec and num_meals > 0:
        meal_legend_lines, meal_legend_labels = plot_meal_responses_panel(fig, meals_spec, daily_meals_analysis_data, user_id, current_date_obj.strftime('%Y-%m-%d'))
    elif meals_spec: # No meals but panel exists
        ax_no_meals = fig.add_subplot(meals_spec)
        ax_no_meals.text(0.5,0.5, f"No meals detected on {current_date_obj.strftime('%Y-%m-%d')}", ha='center', va='center', fontsize=12)
        ax_no_meals.axis('off')


    # Plot daily context timeline (bottom)
    context_legend_lines, context_legend_labels = plot_daily_context_timeline(
        fig, context_spec, current_date_obj,
        df_cgm_day, df_stress_day, df_activity_day,
        daily_sleep_periods, daily_meals_analysis_data, # Pass analyzed meals for meal markers
        user_id
    )
    
    # Consolidated legend for the entire page
    # Combine unique legend items from both panels
    # This can be complex if labels overlap; prioritize meal plot legend items
    
    # Simple combined legend:
    # all_lines = meal_legend_lines + context_legend_lines
    # all_labels = meal_legend_labels + context_legend_labels
    # unique_legend = dict(zip(all_labels, all_lines))
    # fig.legend(unique_legend.values(), unique_legend.keys(), loc='upper center', ncol=5, bbox_to_anchor=(0.5, 0.95), fontsize=9)
    
    # Better: Prioritize meal legend, then add unique context items
    final_legend_dict = {}
    for line, label in zip(meal_legend_lines, meal_legend_labels):
        final_legend_dict[label] = line
    for line, label in zip(context_legend_lines, context_legend_labels):
        if label not in final_legend_dict: # Add if not already from meal panel
            final_legend_dict[label] = line
    
    if final_legend_dict:
        fig.legend(final_legend_dict.values(), final_legend_dict.keys(), loc='upper center', 
                   ncol=min(6, len(final_legend_dict)), # Max 6 columns for legend
                   bbox_to_anchor=(0.5, 0.95 if num_meals > 0 else 0.92), # Adjust based on suptitle
                   fontsize=9)

    plt.tight_layout(rect=[0.02, 0.02, 0.98, 0.93 if num_meals > 0 else 0.90]) # Adjust for suptitle and legend
    return fig

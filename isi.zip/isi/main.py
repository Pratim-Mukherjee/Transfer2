import argparse
from config import COMMON_USER_ID_DEFAULT, COMMON_START_DATE_DEFAULT, DAYS_TO_ANALYZE
from analysis import main_weekly_prandial_analysis

def main():
    print("main.py: main() started")
    parser = argparse.ArgumentParser(description="Weekly Prandial Analysis CLI")
    parser.add_argument('--user_id', type=str, default=COMMON_USER_ID_DEFAULT, help='User ID to analyze')
    parser.add_argument('--start_date', type=str, default=COMMON_START_DATE_DEFAULT, help='Start date (YYYY-MM-DD)')
    parser.add_argument('--days', type=int, default=DAYS_TO_ANALYZE, help='Number of days to analyze')
    parser.add_argument('--save-individual-meal-plots', action='store_true', help='Save individual meal plots')
    parser.add_argument('--show-individual-meal-plots', action='store_true', help='Show individual meal plots')
    parser.add_argument('--save-weekly-report-pdf', action='store_true', help='Save weekly report as PDF')
    parser.add_argument('--no-save-weekly-report-pdf', action='store_true', help='Do not save weekly report as PDF')
    parser.add_argument('--show-overview-plot-live', action='store_true', help='Show weekly overview plot interactively')
    parser.add_argument('--show-daily-summary-live', action='store_true', help='Show daily summary pages interactively')

    args = parser.parse_args()

    # Determine PDF saving based on mutually exclusive flags
    save_weekly_report_pdf = args.save_weekly_report_pdf and not args.no_save_weekly_report_pdf

    main_weekly_prandial_analysis(
        user_id=args.user_id,
        start_date_str=args.start_date,
        num_days=args.days,
        save_individual_meal_plots=args.save_individual_meal_plots,
        show_individual_meal_plots=args.show_individual_meal_plots,
        save_weekly_report_pdf=save_weekly_report_pdf,
        show_overview_plot_live=args.show_overview_plot_live,
        show_daily_summary_live=args.show_daily_summary_live
    )

if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print("Exception in main:", e)
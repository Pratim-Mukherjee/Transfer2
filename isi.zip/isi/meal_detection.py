import numpy as np
import pandas as pd
from scipy.signal import find_peaks
from config import CONFIG

def detect_cgm_spike(df_cgm, sleep_end, threshold=20, prominence=5, distance=12):
    """
    Returns True if a glucose peak > threshold mg/dL is found in the window
    30 min before to 30 min after sleep_end, using peak detection logic.
    """
    window_start = sleep_end - pd.Timedelta(minutes=30)
    window_end = sleep_end + pd.Timedelta(minutes=30)
    window_df = df_cgm[(df_cgm['timestamp'] >= window_start) & (df_cgm['timestamp'] <= window_end)]
    if window_df.empty or len(window_df) < 2:
        return False

    glucose_vals = window_df['cgm_value'].values
    # Use the same logic as meal detection for peak finding
    peaks, properties = find_peaks(
        glucose_vals,
        prominence=prominence,
        distance=distance
    )
    # Check if any detected peak is at least `threshold` above the minimum in the window
    if len(peaks) == 0:
        return False
    min_glucose = glucose_vals.min()
    for peak_idx in peaks:
        if glucose_vals[peak_idx] - min_glucose > threshold:
            return True
    return False

def detect_meals_weekly(df_cgm_weekly, config_cgm, sleep_periods_list=None):
    if df_cgm_weekly.empty or 'cgm_smoothed' not in df_cgm_weekly.columns: return []
    if sleep_periods_list is None: sleep_periods_list = []
    
    meals = []
    cfg_tw = config_cgm.get('time_windows', {})
    crit = config_cgm.get('meal_criteria', {})
    min_rise, min_rate, max_var, min_gap = crit.get('min_glucose_rise',10), crit.get('min_rise_rate',0.01), crit.get('max_baseline_variation',25), crit.get('min_gap_minutes',90)
    prominence = crit.get('peak_prominence', 5)
    distance = crit.get('peak_distance', 12)

    peaks, _ = find_peaks(df_cgm_weekly['cgm_value'], height=df_cgm_weekly['cgm_value'].quantile(0.2),
                          prominence=prominence, distance=distance)
    if len(peaks) == 0: return []

    peak_indices_in_df = df_cgm_weekly.index[peaks]
    valid_meals_candidates = []

    for p_df_idx in peak_indices_in_df:
        search_start_idx_val = max(df_cgm_weekly.index.min(), p_df_idx - 18) # 18 * 5 min = 90 min
        search_start_idx = df_cgm_weekly.index.searchsorted(search_start_idx_val)
        if search_start_idx >= len(df_cgm_weekly.index) or df_cgm_weekly.index[search_start_idx] >= p_df_idx : continue
        
        baseline_cand_df = df_cgm_weekly.loc[df_cgm_weekly.index[search_start_idx]:p_df_idx]
        if baseline_cand_df.empty: continue

        base_df_idx = baseline_cand_df['cgm_smoothed'].idxmin()
        baseline_val = df_cgm_weekly.loc[base_df_idx, 'cgm_smoothed']
        peak_val = df_cgm_weekly.loc[p_df_idx, 'cgm_smoothed']
        meal_start_timestamp = df_cgm_weekly.loc[base_df_idx, 'timestamp']

        is_nocturnal = False
        for sleep_start, sleep_end in sleep_periods_list:
            if sleep_start <= meal_start_timestamp <= sleep_end:
                is_nocturnal = True
                break

        # --- NEW: Cortisol-related logic using CGM spike around sleep end ---
        is_cortisol_related = False
        for sleep_start, sleep_end in sleep_periods_list:
            if detect_cgm_spike(
                df_cgm_weekly, sleep_end, threshold=20,
                prominence=prominence, distance=distance
            ):
                is_cortisol_related = True
                break
        # --- END NEW CORTISOL LOGIC ---

        rise = peak_val - baseline_val
        meal_cand = {
            'timestamp': meal_start_timestamp,
            'baseline': baseline_val,
            'confidence': 75,
            'type': 'pending',
            'row_index': base_df_idx,
            'peak_idx': p_df_idx,
            'glucose_rise': rise,
            'sleep_related': is_nocturnal,
            'cortisol_related': is_cortisol_related
        }

        if rise < min_rise: continue

        roc_window_df = df_cgm_weekly.loc[base_df_idx:p_df_idx]
        if roc_window_df.empty or 'cgm_roc_smooth' not in roc_window_df.columns or roc_window_df['cgm_roc_smooth'].max() < min_rate: continue

        pre_meal_stability_window_start = meal_start_timestamp - pd.Timedelta(minutes=crit.get('min_pre_meal_data', 30))
        pre_meal_stability_df = df_cgm_weekly[(df_cgm_weekly['timestamp'] >= pre_meal_stability_window_start) & (df_cgm_weekly['timestamp'] < meal_start_timestamp)]
        if not pre_meal_stability_df.empty and pre_meal_stability_df['cgm_smoothed'].std() > max_var: continue

        post_peak_window_end_time = df_cgm_weekly.loc[p_df_idx, 'timestamp'] + pd.Timedelta(minutes=crit.get('min_post_meal_data', 120))
        post_peak_df = df_cgm_weekly[(df_cgm_weekly['timestamp'] > df_cgm_weekly.loc[p_df_idx, 'timestamp']) & (df_cgm_weekly['timestamp'] <= post_peak_window_end_time)]
        if not post_peak_df.empty:
            if peak_val - post_peak_df['cgm_smoothed'].min() < rise * 0.2: continue
        
        valid_meals_candidates.append(meal_cand)

    # ...rest of your function unchanged...

    if valid_meals_candidates:
        valid_meals_candidates.sort(key=lambda x: x['glucose_rise'], reverse=True) # Prioritize larger rises
        filtered_meals = []
        for meal_cand in valid_meals_candidates:
            if not any(abs((meal_cand['timestamp'] - acc['timestamp']).total_seconds()/60) < min_gap for acc in filtered_meals):
                m_time_obj = meal_cand['timestamp'].time()
                m_type = 'other' # Default
                # Check against specific windows first (e.g., breakfast, lunch, dinner)
                # The order matters if windows overlap; more specific should come first or be mutually exclusive.
                # For simplicity, let's assume time_windows keys are 'breakfast', 'lunch', 'dinner', 'snack', 'first_meal_window'
                meal_type_found = False
                for wn, (st_str, et_str) in cfg_tw.items():
                    if wn == 'first_meal_window': continue # Handle first_meal separately or ensure it doesn't override
                    start_t = pd.to_datetime(st_str,format='%H:%M').time()
                    end_t = pd.to_datetime(et_str,format='%H:%M').time()
                    if start_t <= end_t: # Normal window (e.g., 08:00-10:00)
                        if start_t <= m_time_obj <= end_t:
                            m_type=wn; meal_type_found = True; break
                    else: # Overnight window (e.g., 22:00-02:00)
                        if m_time_obj >= start_t or m_time_obj <= end_t:
                            m_type=wn; meal_type_found = True; break
                
                if not meal_type_found and 'first_meal_window' in cfg_tw: # Check for first_meal if not classified
                    fm_start_str, fm_end_str = cfg_tw['first_meal_window']
                    if pd.to_datetime(fm_start_str,format='%H:%M').time() <= m_time_obj <= pd.to_datetime(fm_end_str,format='%H:%M').time():
                        # Additional logic: is it truly the first meal of the day?
                        # This requires knowing other meals on the same day. Simpler to just use time window for now.
                        is_first_of_day = not any(acc_m['timestamp'].date() == meal_cand['timestamp'].date() and acc_m['timestamp'] < meal_cand['timestamp'] for acc_m in filtered_meals)
                        if is_first_of_day: # or a more robust check
                           m_type = 'first_meal'

                meal_cand['type'] = m_type
                filtered_meals.append(meal_cand)
        meals = filtered_meals
    return meals
def filter_activity_related_spikes(meal_events, df_hr, df_hrv):
    """
    Flags meal events that are likely activity-related glucose spikes.
    Returns a list of meal events with an added 'activity_related' boolean field.
    """
    hr_thresh = CONFIG['hr']['activity_spike_thresholds']
    hrv_thresh = CONFIG['hrv']['activity_spike_thresholds']
    filtered_meals = []
    for meal in meal_events:
        meal_time = meal['timestamp']
        window_start = meal_time - pd.Timedelta(hours=2)
        window_end = meal_time + pd.Timedelta(minutes=30)
        
        activity_related = False # Assume not activity related initially

        # Check HR data
        if not df_hr.empty and 'timestamp' in df_hr.columns and 'hr_smoothed' in df_hr.columns:
            hr_window = df_hr[(df_hr['timestamp'] >= window_start) & (df_hr['timestamp'] <= window_end)]
            if not hr_window.empty:
                if (hr_window['hr_smoothed'] > hr_thresh['exercise_hr']).any():
                    activity_related = True

        # Check HRV data
        if not df_hrv.empty and 'timestamp' in df_hrv.columns and 'hrv_smoothed' in df_hrv.columns:
            hrv_window = df_hrv[(df_hrv['timestamp'] >= window_start) & (df_hrv['timestamp'] <= window_end)]
            if not hrv_window.empty:
                if (hrv_window['hrv_smoothed'] < hrv_thresh['low_hrv']).any():
                    activity_related = True

        meal_copy = meal.copy()
        meal_copy['activity_related'] = activity_related
        filtered_meals.append(meal_copy)
    return filtered_meals


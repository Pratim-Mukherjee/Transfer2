import pandas as pd
from COMBINED_1 import get_weekly_data_raw_sync, process_physiological_data

def fetch_cgm_dataframe(user_id, start_date_str, num_days):
    weekly_raw_data = get_weekly_data_raw_sync(user_id, start_date_str, num_days)
    df_cgm = process_physiological_data(weekly_raw_data.get('cgm', []), 'cgm', 'cgm')
    return df_cgm

def calculate_tir(df, low_threshold=70, high_threshold=150):
    if df.empty or 'cgm_value' not in df.columns:
        return pd.DataFrame(), {}
    df['date'] = df['timestamp'].dt.date
    daily = df.groupby('date').apply(lambda x: pd.Series({
        "TIR (%)": ((x['cgm_value'] >= low_threshold) & (x['cgm_value'] <= high_threshold)).mean() * 100,
        #"TAR (%)": (x['cgm_value'] > high_threshold).mean() * 100,
        #"TBR (%)": (x['cgm_value'] < low_threshold).mean() * 100,
        #"Mean Glucose": x['cgm_value'].mean()
    })).reset_index()
    tir = ((df['cgm_value'] >= low_threshold) & (df['cgm_value'] <= high_threshold)).mean() * 100
    #tar = (df['cgm_value'] > high_threshold).mean() * 100
    #tbr = (df['cgm_value'] < low_threshold).mean() * 100
    #mean_glucose = df['cgm_value'].mean()
    summary = {
        "TIR (%)": tir,
        #"TAR (%)": tar,
        #"TBR (%)": tbr,
        #"Mean Glucose": mean_glucose
    }
    return daily, summary

if __name__ == "__main__":
    user_id = "156"
    start_date_str = "2025-05-04"
    num_days = 7
    df_cgm = fetch_cgm_dataframe(user_id, start_date_str, num_days)
    daily, summary = calculate_tir(df_cgm)
    print("Daily TIR:\n", daily)
    print("\nOverall for the period:")
    for k, v in summary.items():
        print(f"{k}: {v:.2f}")
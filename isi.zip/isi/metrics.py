import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression
from scipy.signal import find_peaks
from config import CONFIG



def calculate_slope(data_series, time_series_minutes):
    if len(data_series) < 2 or len(time_series_minutes) < 2 or data_series.isna().all() or time_series_minutes.isna().all(): return 0.0
    valid_mask = ~data_series.isna() & ~time_series_minutes.isna()
    if valid_mask.sum() < 2: return 0.0
    X = np.array(time_series_minutes[valid_mask]).reshape(-1, 1); y = data_series[valid_mask].values
    try: return LinearRegression().fit(X, y).coef_[0]
    except: return 0.0

def calculate_cgm_metrics_for_meal(meal_event_details, df_cgm_weekly, config_cgm):
    if df_cgm_weekly.empty or 'cgm_value' not in df_cgm_weekly.columns: return None
    meal_df_idx = meal_event_details.get('row_index'); peak_df_idx = meal_event_details.get('peak_idx')
    if meal_df_idx is None or peak_df_idx is None or meal_df_idx not in df_cgm_weekly.index or peak_df_idx not in df_cgm_weekly.index: return None

    baseline = meal_event_details['baseline']
    meal_actual_time = df_cgm_weekly.loc[meal_df_idx, 'timestamp']
    # --- Use raw_data for peak and peak_height ---
    peak_value = df_cgm_weekly.loc[peak_df_idx, 'cgm_value']
    peak_time = df_cgm_weekly.loc[peak_df_idx, 'timestamp']
    peak_height = peak_value - baseline
    time_to_peak = (peak_time - meal_actual_time).total_seconds() / 60

    inflection_idx = meal_df_idx
    if peak_df_idx > meal_df_idx:
        inf_search_df = df_cgm_weekly.loc[meal_df_idx:peak_df_idx]
        if not inf_search_df.empty and 'cgm_roc_raw' in inf_search_df.columns and not inf_search_df['cgm_roc_raw'].empty:
            inf_idx_cand = inf_search_df['cgm_roc_raw'].idxmax()
            if df_cgm_weekly.loc[inf_idx_cand, 'cgm_roc_raw'] > 0.005: inflection_idx = inf_idx_cand
    inflection_time = df_cgm_weekly.loc[inflection_idx, 'timestamp']
    inflection_value = df_cgm_weekly.loc[inflection_idx, 'cgm_value']

    # --- Use smoothed for slopes and AUCs ---
    init_slope_df = df_cgm_weekly.loc[meal_df_idx:inflection_idx] if inflection_idx >= meal_df_idx else pd.DataFrame()
    init_slope = calculate_slope(init_slope_df['cgm_smoothed'], (init_slope_df['timestamp'] - meal_actual_time).dt.total_seconds() / 60) if not init_slope_df.empty else 0.0

    post_slope_end_idx = min(df_cgm_weekly.index.max(), inflection_idx + 3)
    post_slope_df = df_cgm_weekly.loc[inflection_idx:post_slope_end_idx] if post_slope_end_idx >= inflection_idx else pd.DataFrame()
    post_slope = calculate_slope(post_slope_df['cgm_smoothed'], (post_slope_df['timestamp'] - inflection_time).dt.total_seconds() / 60) if not post_slope_df.empty else 0.0

    decline_start_idx = min(df_cgm_weekly.index.max(), peak_df_idx + 6)
    decline_end_idx = min(df_cgm_weekly.index.max(), peak_df_idx + 18)
    decline_slope_df = df_cgm_weekly.loc[decline_start_idx:decline_end_idx] if decline_end_idx > decline_start_idx else pd.DataFrame()
    decline_slope = 0.0
    if not decline_slope_df.empty:
        decline_slope_start_time = df_cgm_weekly.loc[decline_start_idx,'timestamp']
        decline_slope = calculate_slope(decline_slope_df['cgm_smoothed'], (decline_slope_df['timestamp'] - decline_slope_start_time).dt.total_seconds() / 60)

    # --- Use raw_data for IS and IP calculations ---
    is_idx = abs(decline_slope) / peak_height if peak_height > 0 else 0
    is_norm = (is_idx / config_cgm['is_thresholds'].get('good', 0.015)) * 100 if is_idx > 0 else 0

    auc_end_time = peak_time + pd.Timedelta(minutes=120)
    auc_df = df_cgm_weekly[(df_cgm_weekly['timestamp'] >= meal_actual_time) & (df_cgm_weekly['timestamp'] <= auc_end_time)]
    auc_val = np.trapz(np.maximum(auc_df['cgm_smoothed'] - baseline, 0), (auc_df['timestamp'] - meal_actual_time).dt.total_seconds() / 60) if len(auc_df) >= 2 else 0.0

    early_auc_df = df_cgm_weekly[(df_cgm_weekly['timestamp'] >= meal_actual_time) & (df_cgm_weekly['timestamp'] <= inflection_time)]
    early_auc = np.trapz(np.maximum(early_auc_df['cgm_smoothed'] - baseline, 0), (early_auc_df['timestamp'] - meal_actual_time).dt.total_seconds() / 60) if len(early_auc_df) >= 2 else 0.0

    total_auc_2hr_df = df_cgm_weekly[(df_cgm_weekly['timestamp'] >= meal_actual_time) & (df_cgm_weekly['timestamp'] <= meal_actual_time + pd.Timedelta(minutes=120))]
    total_auc_2hr = np.trapz(np.maximum(total_auc_2hr_df['cgm_smoothed'] - baseline, 0), (total_auc_2hr_df['timestamp'] - meal_actual_time).dt.total_seconds() / 60) if len(total_auc_2hr_df) >= 2 else 0.0

    slope_diff = abs(init_slope - post_slope)
    early_phase_ratio = early_auc / total_auc_2hr if total_auc_2hr > 0 else 0
    mag_factor = np.log1p(peak_height) / 5
    ip_idx = (0.6 * slope_diff) + (0.3 * early_phase_ratio)  + (0.1 * mag_factor)
    ip_norm = min(200, max(0, (ip_idx / 0.5) * 100 if 0.5 > 0 else 0)) # Assuming 0.5 is a reference for good IP

    # --- Use raw_data for GI calculation ---
    est_gi = (60 - 0.35 * time_to_peak) + (15 * init_slope) + (0.4 * peak_height)

    rec_thresh = baseline * 1.1
    rec_end_time = peak_time + pd.Timedelta(minutes=180)
    rec_df = df_cgm_weekly[(df_cgm_weekly['timestamp'] >= peak_time) & (df_cgm_weekly['timestamp'] <= rec_end_time)]
    rec_pts_df = rec_df[rec_df['cgm_smoothed'] <= rec_thresh]
    rec_time = rec_pts_df['timestamp'].min() if not rec_pts_df.empty else None

    return {
        'timestamp': meal_actual_time,
        'baseline': baseline,
        'peak': peak_value,  # raw_data
        'peak_height': peak_height,  # raw_data
        'peak_time': peak_time,
        'time_to_peak': time_to_peak,
        'inflection_time': inflection_time,
        'inflection_value': inflection_value,
        'ip': round(ip_idx,4),  # uses raw peak_height
        'ip_normalized': round(ip_norm,1),
        'is': round(is_idx,4),  # uses raw peak_height
        'is_normalized': round(is_norm,1),
        'initial_slope': round(init_slope,4),
        'post_slope': round(post_slope,4),
        'decline_slope': round(decline_slope,4),
        'auc': round(auc_val,1),
        'recovery_time': rec_time,
        'recovery_complete': rec_time is not None,
        'meal_type': meal_event_details['type'],
        'confidence': meal_event_details['confidence'],
        'estimated_gi': round(est_gi,1),  # uses raw peak_height
        'sleep_related':meal_event_details.get('sleep_related', False),
        'activity_related': meal_event_details.get('activity_related', False),
        'cortisol_related': meal_event_details.get('cortisol_related', False)
    }

def calculate_metrics(meal_data, df):

    if df.empty:
        return None

    try:
        meal_idx = meal_data.get('row_index', None)
        if meal_idx is None or meal_idx not in df.index:
            meal_idx = df.index[(df['timestamp'] - meal_data['timestamp']).abs().argsort()[0]]
    except (IndexError, KeyError):
        print(f"Meal timestamp {meal_data['timestamp']} not found in dataframe")
        return None

    if meal_idx < 0 or meal_idx >= len(df):
        return None

    baseline = meal_data['baseline']
    max_idx = len(df) - 1

    window_start = max(0, meal_idx - 6)  # 30 min before meal for baseline context
    window_end = min(max_idx, meal_idx + 36)  # 3 hours after meal for full response
    meal_window = df.iloc[window_start:window_end+1]
    if len(meal_window) < 12:
        return None

    peak_start = max(meal_idx, 0)
    peak_end = min(meal_idx + 24, max_idx + 1)
    if peak_end <= peak_start:
        return None

    peak_window = df.iloc[peak_start:peak_end]
    if peak_window.empty:
        return None

    peak_idx = peak_window['cgm_value'].idxmax()
    peak_value = df.loc[peak_idx, 'cgm_value']
    peak_time = df.loc[peak_idx, 'timestamp']
    peak_height = peak_value - baseline
    time_to_peak = (peak_time - df.loc[meal_idx, 'timestamp']).total_seconds() / 60

    # Improved Inflection Point Detection
    # 1. Widen window to cover up to peak (or slightly beyond for slow responses)
    inflection_start = meal_idx
    # Set end to peak index or extend slightly for delayed responses (up to 2 hours post-meal)
    inflection_end = min(max_idx + 1, max(peak_idx + 2, meal_idx + 24))  # ~2 hours or just after peak

    if inflection_end <= inflection_start:
        inflection_idx = meal_idx
        print(f"Warning: Inflection window invalid for meal at {meal_data['timestamp']}. Using meal start.")
    else:
        inflection_window = df.iloc[inflection_start:inflection_end]
        if inflection_window.empty:
            inflection_idx = meal_idx
            print(f"Warning: Inflection window empty for meal at {meal_data['timestamp']}. Using meal start.")
        else:
            # 2. Use roc_raw to avoid smoothing impact, fallback to roc_smooth if roc_raw unavailable
            roc_col = 'roc_raw' if 'roc_raw' in inflection_window.columns else 'roc_smooth'
            print(f"Using {roc_col} for inflection point detection for meal at {meal_data['timestamp']}")

            # 3. Find potential inflection candidates: peak ROC followed by decline
            roc_values = inflection_window[roc_col]
            inflection_idx = None
            max_roc_idx = roc_values.idxmax()  # Initial candidate: max ROC

            # 4. Confirm decline after max ROC (check up to 5 points after for decline)
            if max_roc_idx in inflection_window.index:
                check_end = min(max_roc_idx + 5, inflection_end - 1)
                if check_end > max_roc_idx:
                    post_max_roc = df.iloc[max_roc_idx:check_end+1][roc_col]
                    max_roc_value = roc_values.loc[max_roc_idx]
                    # Check if ROC decreases significantly after max (at least 20% drop or crosses below threshold)
                    for i in range(1, len(post_max_roc)):
                        curr_roc = post_max_roc.iloc[i]
                        if max_roc_value > 0.1 and (curr_roc < max_roc_value * 0.8 or curr_roc < 0.05):
                            inflection_idx = max_roc_idx
                            print(f"Inflection point confirmed at {df.loc[inflection_idx, 'timestamp']} "
                                  f"with ROC peak {max_roc_value:.3f} followed by decline to {curr_roc:.3f}")
                            break

            # 5. Fallback if no decline confirmed: look for first significant ROC drop before peak
            if inflection_idx is None:
                roc_diff = roc_values.diff()
                for i in range(1, len(inflection_window)):
                    curr_idx = inflection_window.index[i]
                    if curr_idx > peak_idx:  # Stop searching after peak
                        break
                    prev_roc = roc_values.iloc[i-1]
                    curr_roc = roc_values.iloc[i]
                    roc_change = roc_diff.iloc[i] if i < len(roc_diff) else 0
                    # Significant drop in ROC or transition to near-zero/negative before peak
                    if prev_roc > 0.1 and (curr_roc < 0.05 or roc_change < -0.02):
                        inflection_idx = curr_idx
                        print(f"Inflection point found via ROC drop at {df.loc[inflection_idx, 'timestamp']} "
                              f"(ROC: {prev_roc:.3f} to {curr_roc:.3f}, change: {roc_change:.3f})")
                        break

            # 6. Final fallback with dynamic adjustment for diabetic variability
            #if inflection_idx is None:
                # If time to peak is long (>60 min), suggesting delayed response, midpoint as fallback
                #if time_to_peak > 60:
                    #inflection_idx = inflection_window.index[len(inflection_window) // 2]
                    #print(f"No clear inflection for delayed response at {meal_data['timestamp']}. "
                          #f"Using midpoint {df.loc[inflection_idx, 'timestamp']} (time to peak: {time_to_peak:.1f} min)")
                #else:
                    #inflection_idx = meal_idx
                    #print(f"No inflection point found for meal at {meal_data['timestamp']}. Using meal start.")

    inflection_time = df.loc[inflection_idx, 'timestamp']
    inflection_value = df.loc[inflection_idx, 'raw_data']

    # Calculate slopes
    initial_slope = calculate_slope(df, meal_idx, inflection_idx + 1)
    post_idx = min(inflection_idx + 1, max_idx)
    post_slope = calculate_slope(df, inflection_idx, post_idx + 1)
    decline_start = peak_idx + 6
    decline_end = min(peak_idx + 24, max_idx + 1)
    decline_slope = calculate_slope(df, decline_start, decline_end) if decline_end > decline_start else 0.0

    

    # Calculate Estimated GI using the provided formula
    estimated_gi = (60 - 0.35 * time_to_peak) + (15 * initial_slope) + (0.4 * peak_height)



    meal_time = df.loc[meal_idx, 'timestamp']
    # Calculate AUC
    auc_start = max(0, meal_idx - 6)
    auc_end = min(max_idx, peak_idx + 24)

    if auc_end > auc_start:
        response_data = df.iloc[auc_start:auc_end+1]
        if len(response_data) >= 2:
            t = [(timestamp - response_data['timestamp'].iloc[0]).total_seconds() / 60
                 for timestamp in response_data['timestamp']]
            y = np.maximum(response_data['smoothed'] - baseline, 0)
            auc_value = np.trapz(y, t)
        else:
            auc_value = 0.0
    else:
        auc_value = 0.0
    early_window = df[(df['timestamp'] >= meal_time) & (df['timestamp'] <= inflection_time)]
    if len(early_window) >= 2:
        early_t = [(t - early_window['timestamp'].iloc[0]).total_seconds() / 60 for t in early_window['timestamp']]
        early_y = np.maximum(early_window['smoothed'] - baseline, 0)
        early_auc = np.trapz(early_y, early_t)
    else:
        early_auc = 0

    # Calculate AUC for total response (up to 2 hours)
    two_hour_mark = meal_time + pd.Timedelta(minutes=120)
    total_window = df[(df['timestamp'] >= meal_time) & (df['timestamp'] <= two_hour_mark)]
    if len(total_window) >= 2:
        total_t = [(t - total_window['timestamp'].iloc[0]).total_seconds() / 60 for t in total_window['timestamp']]
        total_y = np.maximum(total_window['smoothed'] - baseline, 0)
        total_auc = np.trapz(total_y, total_t)
    else:
        total_auc = 0

    slope_differential = abs(initial_slope - post_slope)

    # 2. Early phase insulin response component (uses AUC)
    early_phase_ratio = early_auc / total_auc if total_auc > 0 else 0


    # 4. Response magnitude component (higher peak = more insulin needed)
    magnitude_factor = np.log1p(peak_height) / 5  # Logarithmic scaling to prevent overemphasis
    # Calculate insulin sensitivity index (IS)
    is_index = abs(decline_slope) / peak_height if peak_height > 0 else 0
    # Normalize IS using optimal value 0.015
    is_normalized = (is_index / 0.015) * 100 if is_index > 0 else 0
    # Combine into final formula with balanced weights
    ip_index = (0.6 * slope_differential) + (0.3 * early_phase_ratio / 100)  + (0.1 * magnitude_factor)# Normalize GI to a 0-1 scale

    # Normalize based on reference values from typical glucose responses
    # Fixed reference value based on average healthy response (no age adjustment)
    expected_response = 0.5 #TO BE CHANGED LATER BASED ON THE 75GM TEST


    # Calculate normalized percentage
    normalized_ip = (ip_index / expected_response) * 100 if expected_response > 0 else 0

    normalized_ip = min(200, max(0, normalized_ip))

    recovery_threshold = baseline * 1.1
    recovery_data = df.iloc[peak_idx:window_end+1]
    recovery_points = recovery_data[recovery_data['smoothed'] <= recovery_threshold]

    if recovery_points.empty:
        recovery_time = None
        recovery_complete = False
    else:
        recovery_idx = recovery_points.index[0]
        recovery_time = df.loc[recovery_idx, 'timestamp']
        recovery_complete = True

    return {
        'timestamp': meal_data['timestamp'],
        'meal_time': meal_data['timestamp'],
        'baseline': baseline,
        'peak': peak_value,
        'peak_height': peak_height,
        'peak_time': peak_time,
        'time_to_peak': time_to_peak,
        'inflection_time': inflection_time,
        'inflection_value': inflection_value,
        'ip': round(ip_index, 4),
        'ip_normalized': round(normalized_ip, 1),
        'is': round(is_index, 4),
        'is_normalized': round(is_normalized, 1),
        'initial_slope': round(initial_slope, 4),
        'post_slope': round(post_slope, 4),
        'decline_slope': round(decline_slope, 4),
        'auc': round(auc_value, 1),
        'recovery_time': recovery_time,
        'recovery_complete': recovery_complete,
        'meal_type': meal_data['type'],
        'confidence': meal_data['confidence'],
        'estimated_gi': round(estimated_gi, 1)
    }

def calculate_prandial_hr_hrv_metrics(meal_cgm_metrics, df_hr_weekly, df_hrv_weekly, prandial_config):
    meal_start_time = meal_cgm_metrics['timestamp']
    prandial_end_time = meal_cgm_metrics.get('recovery_time') or (meal_cgm_metrics.get('peak_time') + pd.Timedelta(minutes=prandial_config['minutes_after_meal_peak'])) if meal_cgm_metrics.get('peak_time') else meal_start_time + pd.Timedelta(minutes=prandial_config['min_duration_after_start'])
    if (prandial_end_time - meal_start_time).total_seconds()/60 < 30: prandial_end_time = meal_start_time + pd.Timedelta(minutes=30)
    window_start = meal_start_time - pd.Timedelta(minutes=prandial_config['minutes_before_meal'])
    
    hr_metrics, hrv_metrics = {}, {}

    if not df_hr_weekly.empty and 'hr_smoothed' in df_hr_weekly.columns:
        hr_df = df_hr_weekly[(df_hr_weekly['timestamp'] >= window_start) & (df_hr_weekly['timestamp'] <= prandial_end_time)]
        if not hr_df.empty:
            hr_base_df = hr_df[hr_df['timestamp'] < meal_start_time]; hr_meal_df = hr_df[hr_df['timestamp'] >= meal_start_time]
            hr_metrics['pre_meal_avg_hr'] = hr_base_df['hr_smoothed'].mean() if not hr_base_df.empty else np.nan
            if not hr_meal_df.empty:
                hr_metrics.update({'meal_avg_hr': hr_meal_df['hr_smoothed'].mean(), 'meal_peak_hr': hr_meal_df['hr_smoothed'].max(), 'meal_min_hr': hr_meal_df['hr_smoothed'].min()})
                hr_metrics['meal_hr_range'] = hr_metrics['meal_peak_hr'] - hr_metrics['meal_min_hr']
                if pd.notna(hr_metrics['pre_meal_avg_hr']): hr_metrics['meal_avg_hr_change_from_base'] = hr_metrics['meal_avg_hr'] - hr_metrics['pre_meal_avg_hr']
            else: hr_metrics.update({'meal_avg_hr': np.nan, 'meal_peak_hr': np.nan, 'meal_min_hr': np.nan, 'meal_hr_range': np.nan})
    
    if not df_hrv_weekly.empty and 'hrv_smoothed' in df_hrv_weekly.columns:
        hrv_df = df_hrv_weekly[(df_hrv_weekly['timestamp'] >= window_start) & (df_hrv_weekly['timestamp'] <= prandial_end_time)]
        if not hrv_df.empty:
            hrv_base_df = hrv_df[hrv_df['timestamp'] < meal_start_time]; hrv_meal_df = hrv_df[hrv_df['timestamp'] >= meal_start_time]
            hrv_metrics['pre_meal_avg_hrv'] = hrv_base_df['hrv_smoothed'].mean() if not hrv_base_df.empty else np.nan
            if not hrv_meal_df.empty:
                hrv_metrics.update({'meal_avg_hrv': hrv_meal_df['hrv_smoothed'].mean(), 'meal_min_hrv': hrv_meal_df['hrv_smoothed'].min(), 'meal_max_hrv': hrv_meal_df['hrv_smoothed'].max()})
                hrv_metrics['meal_hrv_range'] = hrv_metrics['meal_max_hrv'] - hrv_metrics['meal_min_hrv']
                if len(hrv_meal_df['hrv_smoothed']) > 5: hrv_metrics['meal_hrv_sdnn'] = hrv_meal_df['hrv_smoothed'].std()
                if pd.notna(hrv_metrics['pre_meal_avg_hrv']): hrv_metrics['meal_avg_hrv_change_from_base'] = hrv_metrics['meal_avg_hrv'] - hrv_metrics['pre_meal_avg_hrv']
            else: hrv_metrics.update({'meal_avg_hrv': np.nan, 'meal_min_hrv': np.nan, 'meal_max_hrv': np.nan, 'meal_hrv_range': np.nan})
    return hr_metrics, hrv_metrics

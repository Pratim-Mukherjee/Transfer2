import pandas as pd
from datetime import timedelta
from data_fetching import get_weekly_data_raw_sync
from data_processing import process_physiological_data, process_weekly_sleep_data
from meal_detection import detect_meals_weekly
from metrics import calculate_cgm_metrics_for_meal
from config import CONFIG
import json

def categorize_gi(gi_value):
    if gi_value < 55:
        return 'Low GI'
    elif gi_value < 70:
        return 'Medium GI'
    else:
        return 'High GI'

def detect_cgm_spike(df_cgm, sleep_end, threshold=20):
    window_start = sleep_end - pd.Timedelta(minutes=30)
    window_end = sleep_end + pd.Timedelta(minutes=30)
    window_df = df_cgm[(df_cgm['timestamp'] >= window_start) & (df_cgm['timestamp'] <= window_end)]
    if window_df.empty:
        return False
    glucose_vals = window_df['cgm_value'].values
    if len(glucose_vals) < 2:
        return False
    spike = glucose_vals.max() - glucose_vals.min()
    return spike > threshold

def get_meal_gi_json(user_id, start_date_str, num_days=7):
    weekly_raw_data = get_weekly_data_raw_sync(user_id, start_date_str, num_days)
    df_cgm = process_physiological_data(weekly_raw_data.get('cgm', []), 'cgm', 'cgm')
    sleep_periods_weekly = process_weekly_sleep_data(weekly_raw_data.get('sleep', []))

    detected_meals = detect_meals_weekly(df_cgm, CONFIG['cgm'], sleep_periods_weekly)
    meal_metrics = []
    for meal in detected_meals:
        metrics = calculate_cgm_metrics_for_meal(meal, df_cgm, CONFIG['cgm'])
        if metrics:
            meal_metrics.append(metrics)
    if not meal_metrics:
        return {}

    meal_df = pd.DataFrame(meal_metrics)
    meal_df['date'] = meal_df['timestamp'].dt.date

    main_meals = []
    for date, group in meal_df.groupby('date'):
        group_sorted = group.sort_values('timestamp')
        breakfast = group_sorted[group_sorted['meal_type'].str.lower().str.contains('first_meal|breakfast')]
        if not breakfast.empty:
            main_meal = breakfast.iloc[0]
        else:
            continue

        gi = main_meal['estimated_gi']
        ip = main_meal['ip']
        is_ = main_meal['is']
        gi_cat = categorize_gi(gi)

        prev_date = date - timedelta(days=1)
        prev_sleep_periods = [s for s in sleep_periods_weekly if s[0].date() == prev_date]
        is_cortisol_related = None
        if prev_sleep_periods:
            found_spike = False
            for sleep_start, sleep_end in prev_sleep_periods:
                if detect_cgm_spike(df_cgm, sleep_end, threshold=20):
                    found_spike = True
                    break
            is_cortisol_related = found_spike
        else:
            is_cortisol_related = "No sleep data"

        main_meals.append({
            'date': date,
            'gi': gi,
            'gi_category': gi_cat,
            'ip': ip,
            'is': is_,
            'cortisol_related': is_cortisol_related
        })

    if not main_meals:
        return {}

    main_meals_df = pd.DataFrame(main_meals)

    ip_reference = 0.5
    is_reference = CONFIG['cgm']['is_thresholds'].get('good', 0.015)

    def norm_ip(ip_val):
        if ip_reference > 0:
            return min(200, max(0, (ip_val / ip_reference) * 100))
        else:
            return 0

    def norm_is(is_val):
        if is_reference > 0:
            return (is_val / is_reference) * 100
        else:
            return 0

    main_meals_df['ip_norm'] = main_meals_df['ip'].apply(norm_ip)
    main_meals_df['is_norm'] = main_meals_df['is'].apply(norm_is)

    # Build JSON output in required format
    result_json = {
        str(row['date']): {
            "is_normalized": round(row['is_norm'], 2),
            "ip_normalized": round(row['ip_norm'], 2)
        }
        for _, row in main_meals_df.iterrows()
    }

    return result_json
    


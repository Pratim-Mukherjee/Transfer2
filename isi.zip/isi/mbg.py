import pandas as pd
from data_fetching import get_weekly_data_raw_sync
from data_processing import process_physiological_data

def calculate_mbg_for_date_range(user_id, start_date_str, num_days):
    # Fetch and process CGM data
    weekly_raw_data = get_weekly_data_raw_sync(user_id, start_date_str, num_days)
    df_cgm = process_physiological_data(weekly_raw_data.get('cgm', []), 'cgm', 'cgm')
    if df_cgm.empty or 'cgm_value' not in df_cgm.columns:
        print("No CGM data available for MBG calculation.")
        return pd.DataFrame(), None

    # Daily MBG for the full date range
    df_cgm['date'] = df_cgm['timestamp'].dt.date
    daily_mbg = (
        df_cgm.groupby('date')['cgm_value']
        .mean()
        .reset_index()
        .rename(columns={'cgm_value': 'mbg'})
    )

    # Filter for the exact date range
    start_date = pd.to_datetime(start_date_str).date()
    end_date = start_date + pd.Timedelta(days=num_days - 1)
    mask = (daily_mbg['date'] >= start_date) & (daily_mbg['date'] <= end_date)
    range_daily_mbg = daily_mbg.loc[mask].reset_index(drop=True)

    # MBG for the whole range (mean of daily means)
    mbg_over_range = range_daily_mbg['mbg'].mean() if not range_daily_mbg.empty else None
    #print(df_cgm[df_cgm['date'] == pd.to_datetime('2025-05-10').date()])


    return range_daily_mbg, mbg_over_range

# Example usage:
if __name__ == "__main__":
    user_id = "132"
    start_date_str = "2025-04-29"
    num_days = 7  # For May 4 to May 10, use 7
    daily_mbg, mbg = calculate_mbg_for_date_range(user_id, start_date_str, num_days)
    print("Daily MBG for the range:\n", daily_mbg)
    print("\nMBG for the whole range:\n", mbg)
    
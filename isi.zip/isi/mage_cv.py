import numpy as np
import pandas as pd
from COMBINED_1 import get_weekly_data_raw_sync, process_physiological_data

def compute_daily_mage_and_cv(user_id, start_date_str, num_days=7):
    """
    Computes daily MAGE and CV for each day, and returns their averages.
    Returns:
        daily_results: list of dicts [{'date': ..., 'MAGE': ..., 'CV': ...}, ...]
        avg_mage: float
        avg_cv: float
    """
    # Fetch and process CGM data
    weekly_raw_data = get_weekly_data_raw_sync(user_id, start_date_str, num_days)
    df_cgm = process_physiological_data(weekly_raw_data.get('cgm', []), 'cgm', 'cgm')
    if df_cgm.empty or 'cgm_value' not in df_cgm.columns:
        return [], None, None

    df_cgm['date'] = df_cgm['timestamp'].dt.date
    daily_results = []

    for date_val, day_df in df_cgm.groupby('date'):
        glucose = day_df['cgm_value'].values
        mean_glucose = np.mean(glucose)
        std_glucose = np.std(glucose)
        cv = (std_glucose / mean_glucose) * 100 if mean_glucose != 0 else 0

        # MAGE: mean of excursions > 1 SD between peaks and troughs
        peaks = np.where((glucose[1:-1] > glucose[:-2]) & (glucose[1:-1] > glucose[2:]))[0] + 1
        troughs = np.where((glucose[1:-1] < glucose[:-2]) & (glucose[1:-1] < glucose[2:]))[0] + 1

        valid_fluctuations = []
        for i in range(1, min(len(peaks), len(troughs))):
            peak_value = glucose[peaks[i]]
            trough_value = glucose[troughs[i - 1]]
            fluctuation = abs(peak_value - trough_value)
            if fluctuation > std_glucose:
                valid_fluctuations.append(fluctuation)
        mage = float(np.mean(valid_fluctuations)) if valid_fluctuations else 0

        daily_results.append({
            'date': str(date_val),
            'MAGE': round(mage, 2),
            'CV': round(cv, 2)
        })

    # Compute averages
    avg_mage = round(np.mean([d['MAGE'] for d in daily_results]), 2) if daily_results else None
    avg_cv = round(np.mean([d['CV'] for d in daily_results]), 2) if daily_results else None

    return daily_results, avg_mage, avg_cv

# Example usage:
if __name__ == "__main__":
    user_id = "156"
    start_date_str = "2025-05-04"
    num_days = 7
    daily_results, avg_mage, avg_cv = compute_daily_mage_and_cv(user_id, start_date_str, num_days)
    for d in daily_results:
        print(f"{d['date']}: MAGE={d['MAGE']}, CV={d['CV']}")
    print(f"\nAverage MAGE: {avg_mage}")
    print(f"Average CV: {avg_cv}")
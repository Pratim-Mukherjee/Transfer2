import os
import json
import psycopg2
import google.generativeai as genai

# ------------------------
# Gemini setup
# ------------------------
GEMINI_API_KEY = "AIzaSyB7zp9mqQTnQ9VMtD5queh8fCu8wXvdZO8"
GEMINI_MODEL_NAME = "gemini-2.5-flash"

genai.configure(api_key=GEMINI_API_KEY)
model = genai.GenerativeModel(GEMINI_MODEL_NAME)

# Load prompt template (combined for all meals)
with open("prompt.json", "r", encoding="utf-8") as f:
    prompt_data = json.load(f)
PROMPT_TEMPLATE = prompt_data["template"]

# ------------------------
# Helper functions
# ------------------------
def parse_macro_value(value):
    """Convert macro strings like '20-25g' or '15g' to rounded int."""
    if isinstance(value, (int, float)):
        return round(float(value))
    value = str(value).lower().replace('g','').strip()
    if '-' in value:
        parts = value.split('-')
        try:
            numbers = [float(p) for p in parts]
            return round(sum(numbers)/len(numbers))
        except ValueError:
            return 0
    else:
        try:
            return round(float(value))
        except ValueError:
            return 0

def generate_recipes_for_user(meals):
    """
    Generate all meals in one API call.
    'meals' is a dict: {"breakfast": {...macros...}, "lunch": {...}, "dinner": {...}}
    Returns dict: {"breakfast": [...recipes...], "lunch": [...], "dinner": [...]} 
    """
    # Parse numeric macros
    parsed_meals = {meal: {k: parse_macro_value(v) for k,v in macros.items()} for meal, macros in meals.items()}

    # Debug
    print(f"\n[DEBUG] Generating recipes for all meals with macros:\n{json.dumps(parsed_meals, indent=2)}")

    # Build prompt
    prompt = PROMPT_TEMPLATE.format(
        breakfast_protein=parsed_meals["breakfast"]["protein"],
        breakfast_carbs=parsed_meals["breakfast"]["carbs"],
        breakfast_fat=parsed_meals["breakfast"]["fat"],
        breakfast_calories=parsed_meals["breakfast"]["calories"],
        lunch_protein=parsed_meals["lunch"]["protein"],
        lunch_carbs=parsed_meals["lunch"]["carbs"],
        lunch_fat=parsed_meals["lunch"]["fat"],
        lunch_calories=parsed_meals["lunch"]["calories"],
        dinner_protein=parsed_meals["dinner"]["protein"],
        dinner_carbs=parsed_meals["dinner"]["carbs"],
        dinner_fat=parsed_meals["dinner"]["fat"],
        dinner_calories=parsed_meals["dinner"]["calories"]
    )

    print(f"\n[DEBUG] Prompt being sent to Gemini:\n{prompt}\n{'-'*60}")

    try:
        # ✅ Pass prompt as positional argument
        response = model.generate_content(prompt)
        text_response = response.text.strip()

        # Remove code fences if present
        if text_response.startswith("```"):
            text_response = "\n".join(text_response.splitlines()[1:-1])

        # Parse JSON
        return json.loads(text_response)

    except Exception as e:
        print(f"❌ Failed to generate recipes for user: {e}")
        return {}

# ------------------------
# Main function
# ------------------------
def main():
    conn = psycopg2.connect(
        host="localhost",
        database="healthsync",
        user="postgres",
        password="postgres",
        port=5433
    )

    with conn.cursor() as cursor:
        cursor.execute("SELECT user_id, user_protocol FROM user_protocols")
        rows = cursor.fetchall()

        for user_id, protocol_json in rows:
            if isinstance(protocol_json, dict):
                protocol = protocol_json
            elif isinstance(protocol_json, str):
                try:
                    protocol = json.loads(protocol_json)
                except json.JSONDecodeError:
                    print(f"Skipping user {user_id} (invalid JSON)")
                    continue
            else:
                print(f"Skipping user {user_id} (unknown format)")
                continue

            # Collect macros for all meals
            meal_macros = {}
            for meal in protocol.get("mealPlan", {}).get("dailySchedule", []):
                macros = meal.get("nutritionalTargets")
                if macros:
                    meal_macros[meal["mealType"]] = macros

            if not meal_macros:
                print(f"ℹ️ No macros found for user {user_id}, skipping")
                continue

            # Generate recipes in one call
            user_recipes = generate_recipes_for_user(meal_macros)
            if not user_recipes:
                print(f"❌ Failed to generate recipes for user {user_id}")
                continue

            # Update protocol with recipes
            updated = False
            for meal in protocol.get("mealPlan", {}).get("dailySchedule", []):
                if meal["mealType"] in user_recipes:
                    meal["exampleMeals"] = user_recipes[meal["mealType"]]
                    updated = True

            if updated:
                cursor.execute(
                    "UPDATE user_protocols SET user_protocol = %s WHERE user_id = %s",
                    (json.dumps(protocol), user_id)
                )
                conn.commit()
                print(f"✅ Updated recipes for user {user_id}")
            else:
                print(f"ℹ️ No updates needed for user {user_id}")

    conn.close()

# ------------------------
# Run
# ------------------------
if __name__ == "__main__":
    main()


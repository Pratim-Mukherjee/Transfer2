# Automatic_recipe_generator
python file to generate recepie for all user's daily


Python file is being run in cron job 

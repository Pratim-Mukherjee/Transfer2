const selectors = {
  root: document.getElementById("dashboard-root"),
  summaryCards: document.getElementById("summary-cards"),
  stageTableBody: document.getElementById("stage-table-body"),
  riskList: document.getElementById("risk-list"),
  journeyList: document.getElementById("journey-list"),
  journeyDetail: document.getElementById("journey-detail"),
  dataSource: document.getElementById("data-source-select"),
  refreshButton: document.getElementById("refresh-button"),
  feedbackRegion: document.getElementById("feedback-region"),
  tabGroup: document.querySelector(".tab-group"),
  tabButtons: document.querySelectorAll(".tab-button"),
  tabPanels: document.querySelectorAll("[data-tab-panel]"),
  modal: document.getElementById("data-modal"),
  modalTitle: document.getElementById("data-modal-title"),
  modalBody: document.getElementById("data-modal-body"),
  modalClose: document.getElementById("data-modal-close")
};

const state = {
  source: "file",
  isLoading: false,
  analytics: null,
  selectedJourneyId: null,
  openStageIds: new Set(),
  activeTab: "journeys"
};

const DATA_LOADER = {
  async file() {
    return fetchJson("data/ui_dashboard.json");
  },
  async api() {
    const { apiBaseUrl } = window.APP_CONFIG ?? {};
    if (!apiBaseUrl) {
      throw new Error(
        "API endpoint not configured. Provide window.APP_CONFIG.apiBaseUrl to enable live data."
      );
    }
    const base = apiBaseUrl.replace(/\/$/, "");
    return fetchJson(`${base}/dashboard`);
  }
};

initDashboard();

async function initDashboard() {
  if (!selectors.root) {
    console.error("Dashboard root element not found.");
    return;
  }

  selectors.dataSource?.addEventListener("change", handleDataSourceChange);
  selectors.refreshButton?.addEventListener("click", handleRefresh);
  selectors.summaryCards?.addEventListener("click", handleSummaryCardClick);
  selectors.journeyList?.addEventListener("click", handleJourneySelect);
  selectors.stageTableBody?.addEventListener("click", handleStageToggle);

  if (selectors.tabGroup) {
    selectors.tabGroup.addEventListener("click", handleTabClick);
  }

  if (selectors.modal) {
    selectors.modalClose?.addEventListener("click", closeModal);
    selectors.modal?.addEventListener("click", (event) => {
      if (event.target === selectors.modal) closeModal();
    });
  }

  setActiveTab(state.activeTab);
  await loadDashboardData();
}

async function handleRefresh() {
  await loadDashboardData();
}

async function handleDataSourceChange(event) {
  state.source = event.target.value;
  await loadDashboardData();
}

async function loadDashboardData() {
  try {
    setLoading(true);
    clearFeedback();

    const loader = DATA_LOADER[state.source];
    if (!loader) {
      throw new Error(`Loader for source "${state.source}" not available.`);
    }

    const analytics = await loader();
    state.analytics = analytics;
    state.openStageIds.clear();
    const journeys = analytics.journeys ?? [];
    const selected = journeys.find((journey) => journey.id === state.selectedJourneyId);
    state.selectedJourneyId = selected ? selected.id : journeys[0]?.id ?? null;

    renderSummaryCards(analytics.metrics);
    renderStageTable(analytics.stageMetrics);
    renderRiskList(analytics.risks);
    renderJourneyList(journeys);
    renderJourneyDetail(getSelectedJourney());
    renderConfigWarnings(analytics.coverage);
    setActiveTab(state.activeTab);
  } catch (error) {
    console.error(error);
    renderError(error.message || "Unable to load dashboard data.");
    state.analytics = null;
    state.selectedJourneyId = null;
    state.openStageIds.clear();
    renderSummaryCards(null);
    renderStageTable(null);
    renderRiskList([]);
    renderJourneyList([]);
    renderJourneyDetail(null);
    renderConfigWarnings(null);
  } finally {
    setLoading(false);
  }
}

function handleSummaryCardClick(event) {
  const card = event.target.closest("[data-modal-group]");
  if (!card || state.isLoading || !state.analytics) return;
  const groupKey = card.dataset.modalGroup;
  openGroupModal(groupKey);
}

function handleJourneySelect(event) {
  const button = event.target.closest("[data-journey-id]");
  if (!button || state.isLoading) return;
  state.selectedJourneyId = button.dataset.journeyId;
  renderJourneyList(state.analytics?.journeys ?? []);
  renderJourneyDetail(getSelectedJourney());
  focusJourneyDetail();
}

function handleStageToggle(event) {
  const journeyButton = event.target.closest('.link-button[data-journey-id]');
  if (journeyButton) {
    state.selectedJourneyId = journeyButton.dataset.journeyId;
    renderJourneyList(state.analytics?.journeys ?? []);
    renderJourneyDetail(getSelectedJourney());
    focusJourneyDetail();
    closeModal();
    return;
  }

  const toggle = event.target.closest(".stage-toggle");
  if (!toggle) return;
  const row = toggle.closest("[data-stage-id]");
  if (!row) return;
  const stageId = row.dataset.stageId;
  const detailRow = selectors.stageTableBody?.querySelector(
    `.stage-detail[data-stage-id="${stageId}"]`
  );
  if (!detailRow) return;

  const isOpen = state.openStageIds.has(stageId);
  if (isOpen) {
    state.openStageIds.delete(stageId);
    detailRow.hidden = true;
    toggle.setAttribute("aria-expanded", "false");
  } else {
    state.openStageIds.add(stageId);
    detailRow.hidden = false;
    toggle.setAttribute("aria-expanded", "true");
  }
}

function handleTabClick(event) {
  const button = event.target.closest(".tab-button");
  if (!button || state.isLoading) return;
  const tabKey = button.dataset.tab;
  if (!tabKey || tabKey === state.activeTab) return;
  setActiveTab(tabKey);
}

function getSelectedJourney() {
  if (!state.analytics || !state.selectedJourneyId) return null;
  return (state.analytics.journeys ?? []).find((journey) => journey.id === state.selectedJourneyId) ?? null;
}

function renderSummaryCards(metrics) {
  const container = selectors.summaryCards;
  container.innerHTML = "";
  if (!metrics) {
    container.innerHTML =
      '<p class="empty-state">Summary unavailable until data is loaded.</p>';
    return;
  }

  const cards = [
    {
      label: "Active Journeys",
      value: metrics.totalJourneys,
      delta: `${metrics.averageCompletion}% average completion`,
      modifier: "",
      groupKey: "total"
    },
    {
      label: "On Track",
      value: `${metrics.onTrackJourneys}/${metrics.totalJourneys}`,
      delta: `${metrics.onTrackRate}% tracking to plan`,
      modifier: "positive",
      groupKey: "onTrack"
    },
    {
      label: "Needs Attention",
      value: metrics.attentionJourneys,
      delta: attentionDelta(metrics),
      modifier: metrics.attentionJourneys > 0 ? "warning" : "",
      groupKey: "attention"
    },
    {
      label: "SLA Breaches",
      value: metrics.breachedJourneys,
      delta:
        metrics.slaBreaches === 1
          ? "1 breached milestone"
          : `${metrics.slaBreaches} breached milestones`,
      modifier: metrics.breachedJourneys > 0 ? "negative" : "",
      groupKey: "breached"
    }
  ];

  for (const card of cards) {
    const node = document.createElement("article");
    node.className = `summary-card ${card.modifier}`.trim();
    node.dataset.modalGroup = card.groupKey;
    node.innerHTML = `
      <span class="label">${card.label}</span>
      <p class="value">${card.value}</p>
      <p class="delta">${card.delta}</p>
    `;
    container.appendChild(node);
  }
}

function renderStageTable(stageMetrics) {
  const tbody = selectors.stageTableBody;
  tbody.innerHTML = "";
  if (!stageMetrics || stageMetrics.length === 0) {
    tbody.innerHTML =
      '<tr><td colspan="5" class="empty-state">No stage analytics available.</td></tr>';
    return;
  }

  for (const stage of stageMetrics) {
    const row = document.createElement("tr");
    row.className = "stage-row";
    row.dataset.stageId = stage.stageId;
    row.innerHTML = `
      <td>
        <button type="button" class="stage-toggle" aria-expanded="${
          state.openStageIds.has(stage.stageId) ? "true" : "false"
        }">
          <span class="stage-name">${stage.label}</span>
          <span class="stage-meta">${stage.completionRate}% complete</span>
          <span class="chevron" aria-hidden="true">&#9662;</span>
        </button>
      </td>
      <td class="stat">${stage.completed}</td>
      <td class="stat">${stage.inProgress}</td>
      <td class="stat trend-warn">${stage.atRisk}</td>
      <td class="stat trend-down">${stage.failed}</td>
    `;

    const detailRow = document.createElement("tr");
    detailRow.className = "stage-detail";
    detailRow.dataset.stageId = stage.stageId;
    detailRow.hidden = !state.openStageIds.has(stage.stageId);
    detailRow.innerHTML = `
      <td colspan="5">
        ${renderStageDetail(stage)}
      </td>
    `;

    tbody.appendChild(row);
    tbody.appendChild(detailRow);
  }
}

function renderStageDetail(stage) {
  if (!stage.activeJourneys || stage.activeJourneys.length === 0) {
    return '<p class="empty-state">No active journeys in this stage right now.</p>';
  }

  const cards = stage.activeJourneys
    .map(
      (journey) => `
        <article class="mini-card" data-journey-id="${journey.id}">
          <div class="mini-card-header">
            <h3>${journey.name}</h3>
            <span class="status-pill ${journey.stageStatus}">
              ${journey.stageStatusLabel}
            </span>
          </div>
          <p class="mini-card-meta">${journey.stageLabel}</p>
          <p class="mini-card-message">${journey.stageMessage}</p>
          <div class="mini-card-footer">
            <span>${journey.timeDelta ?? "Within SLA"}</span>
            <button type="button" class="link-button" data-journey-id="${journey.id}">
              View timeline
            </button>
          </div>
        </article>
      `
    )
    .join("");

  return `<div class="stage-detail-grid">${cards}</div>`;
}

function renderRiskList(risks) {
  const container = selectors.riskList;
  container.innerHTML = "";
  if (!risks || risks.length === 0) {
    container.innerHTML = '<p class="empty-state">No active risks right now.</p>';
    return;
  }

  for (const risk of risks) {
    const entry = document.createElement("div");
    entry.className = `risk-entry ${risk.severity}`;
    entry.innerHTML = `
      <div class="risk-header">
        <span class="pill">${risk.severityLabel}</span>
        <button type="button" class="link-button" data-journey-id="${risk.id}">
          Open timeline
        </button>
      </div>
      <h3 class="title">${risk.name}</h3>
      <p class="meta">${risk.stageLabel} &middot; ${risk.stageStatusLabel}</p>
      <p class="meta">${risk.stageMessage}</p>
      <p class="meta">${risk.timeDelta ?? "Tracking within SLA"}</p>
      <p class="action">${risk.nextAction}</p>
    `;
    entry.querySelector(".link-button")?.addEventListener("click", () => {
      state.selectedJourneyId = risk.id;
      renderJourneyList(state.analytics?.journeys ?? []);
      renderJourneyDetail(getSelectedJourney());
      focusJourneyDetail();
    });
    container.appendChild(entry);
  }
}

function renderJourneyList(journeys) {
  const container = selectors.journeyList;
  if (!container) return;
  container.innerHTML = "";

  if (!journeys || journeys.length === 0) {
    container.innerHTML = '<p class="empty-state">No journeys available.</p>';
    return;
  }

  for (const journey of journeys) {
    const button = document.createElement("button");
    button.type = "button";
    button.dataset.journeyId = journey.id;
    button.className = `journey-item${journey.id === state.selectedJourneyId ? " active" : ""}`;
    const focus = journey.focusStage ?? journey.stageStates?.[0] ?? null;
    const hint = focus?.timeDelta ?? focus?.message ?? "Review timeline";
    button.innerHTML = `
      <div class="journey-item-heading">
        <h3>${journey.name}</h3>
        <span class="status-pill ${journey.status}">${journey.statusLabel}</span>
      </div>
      <p class="journey-item-meta">${focus?.label ?? "Awaiting start"}</p>
      <p class="journey-item-sub">${hint}</p>
    `;
    container.appendChild(button);
  }
}

function renderJourneyDetail(journey) {
  const container = selectors.journeyDetail;
  if (!container) return;
  if (!journey) {
    container.innerHTML =
      '<p class="empty-state">Select a journey to see detailed SLA progress.</p>';
    return;
  }

  const focus = journey.focusStage;
  const breaches = journey.breaches ?? [];
  const breachesList = breaches
    .map((breach) => `<li>${breach.stageLabel}: ${breach.message}</li>`)
    .join("");
  const breachesBlock = breaches.length
    ? `<div class="detail-section">
        <h4>SLA Alerts</h4>
        <ul class="breach-list">${breachesList}</ul>
      </div>`
    : "";

  container.innerHTML = `
    <header class="detail-header">
      <div>
        <h2>${journey.name}</h2>
        <p>${focus?.label ?? "All stages"} &middot; ${journey.percentComplete}% complete</p>
      </div>
      <span class="status-pill ${journey.status}">${journey.statusLabel}</span>
    </header>

    <div class="detail-meta">
      <div>
        <h4>Next Action</h4>
        <p>${journey.nextAction}</p>
      </div>
      <div>
        <h4>SLA Position</h4>
        <p>${focus?.timeDelta ?? focus?.message ?? "Within SLA window"}</p>
      </div>
      <div>
        <h4>Current Stage</h4>
        <p>${focus?.label ?? "Not started"}</p>
      </div>
    </div>

    ${breachesBlock}

    <div class="detail-section">
      <h4>Timeline</h4>
      <div class="stage-timeline">
        ${journey.stageStates
          .map(
            (stage) => `
              <div class="timeline-row ${stage.status}${
                stage.slaBreached && stage.status !== "failed" ? " breached" : ""
              }">
                <span class="dot"></span>
                <div class="timeline-content">
                  <p class="stage-name">${stage.label}</p>
                  <p class="stage-meta">${composeStageMeta(stage)}</p>
                </div>
              </div>
            `
          )
          .join("")}
      </div>
    </div>
  `;
}

function openGroupModal(groupKey) {
  if (!state.analytics) return;
  const journeys = state.analytics.groups?.[groupKey] ?? [];
  if (!journeys.length) {
    renderError("No journeys in this category yet.");
    return;
  }

  const titles = {
    total: "All Active Journeys",
    onTrack: "Journeys On Track",
    attention: "Journeys Needing Attention",
    breached: "Journeys with SLA Breaches"
  };

  selectors.modalTitle.textContent = titles[groupKey] ?? "Journey Details";
  selectors.modalBody.innerHTML = journeys
    .map(
      (journey) => `
        <article class="modal-item" data-journey-id="${journey.id}">
          <header>
            <h3>${journey.name}</h3>
            <span class="status-pill ${journey.status}">${journey.statusLabel}</span>
          </header>
          <p class="modal-meta">${journey.stageLabel} &middot; ${journey.stageStatusLabel}</p>
          <p class="modal-meta">${journey.stageMessage}</p>
          <p class="modal-meta">${journey.timeDelta ?? "Within SLA"}</p>
          <p class="modal-action">${journey.nextAction}</p>
          <button type="button" class="link-button" data-journey-id="${journey.id}">
            Focus timeline
          </button>
        </article>
      `
    )
    .join("");

  selectors.modalBody.querySelectorAll(".link-button").forEach((button) =>
    button.addEventListener("click", () => {
      state.selectedJourneyId = button.dataset.journeyId;
      closeModal();
      renderJourneyList(state.analytics?.journeys ?? []);
      renderJourneyDetail(getSelectedJourney());
      focusJourneyDetail();
    })
  );

  selectors.modal?.classList.add("open");
  selectors.modal?.setAttribute("aria-hidden", "false");
  selectors.modalClose?.focus();
}

function closeModal() {
  selectors.modal?.classList.remove("open");
  selectors.modal?.setAttribute("aria-hidden", "true");
}

function renderConfigWarnings(coverage) {
  if (!coverage) {
    selectors.feedbackRegion.innerHTML = "";
    return;
  }

  const messages = [];
  if (coverage.missingSlaStages?.length) {
    const list = coverage.missingSlaStages.map((item) => item.name).join(", ");
    messages.push(`Stages with dependencies but no SLA set: ${list}.`);
  }
  if (coverage.baselineGaps?.length) {
    const list = coverage.baselineGaps.map((item) => item.name).join(", ");
    messages.push(
      `Stages with SLA but no dependency: ${list}. Journey start is used as the baseline.`
    );
  }
  if (coverage.unknownDependencies?.length) {
    for (const entry of coverage.unknownDependencies) {
      messages.push(
        `Stage ${entry.name} references missing dependencies: ${entry.missing.join(", ")}`
      );
    }
  }
  if (coverage.unusedSlaKeys?.length) {
    const list = coverage.unusedSlaKeys.map((item) => item.label).join(", ");
    messages.push(`SLA entries without matching stages: ${list}.`);
  }

  if (!messages.length) {
    selectors.feedbackRegion.innerHTML = "";
    return;
  }

  selectors.feedbackRegion.innerHTML = `
    <div class="info-banner">
      <strong>Configuration checks</strong>
      <ul>${messages.map((msg) => `<li>${msg}</li>`).join("")}</ul>
    </div>
  `;
}

function composeStageMeta(stage) {
  const bits = [];
  if (stage.timeDelta) bits.push(stage.timeDelta);
  if (stage.message && stage.message !== stage.timeDelta) bits.push(stage.message);
  if (stage.meta) bits.push(stage.meta);
  return bits.join(" • ") || "No updates available";
}

function attentionDelta(metrics) {
  const parts = [];
  if (metrics.breachedJourneys) parts.push(`${metrics.breachedJourneys} breached`);
  if (metrics.atRiskJourneys) parts.push(`${metrics.atRiskJourneys} at risk`);
  if (metrics.failedJourneys) parts.push(`${metrics.failedJourneys} failed`);
  if (metrics.stalledJourneys) parts.push(`${metrics.stalledJourneys} stalled`);
  return parts.length ? parts.join(" | ") : "All journeys on plan";
}

function focusJourneyDetail() {
  const heading = document.getElementById("journey-detail-heading");
  if (heading) {
    heading.scrollIntoView({ behavior: "smooth", block: "start" });
  }
}

function setActiveTab(tabKey) {
  state.activeTab = tabKey;
  selectors.tabButtons.forEach((button) => {
    const isActive = button.dataset.tab === tabKey;
    button.classList.toggle("active", isActive);
    button.setAttribute("aria-selected", String(isActive));
    button.setAttribute("tabindex", isActive ? "0" : "-1");
  });
  selectors.tabPanels.forEach((panel) => {
    const isActive = panel.dataset.tabPanel === tabKey;
    panel.hidden = !isActive;
    panel.classList.toggle("active", isActive);
  });
}

function setLoading(isLoading) {
  state.isLoading = isLoading;
  selectors.refreshButton.disabled = isLoading;
  selectors.root.classList.toggle("loading", isLoading);
  selectors.root.setAttribute("aria-busy", String(isLoading));
}

function clearFeedback() {
  selectors.feedbackRegion.innerHTML = "";
}

function renderError(message) {
  selectors.feedbackRegion.innerHTML = `<div class="error-banner">${message}</div>`;
}

async function fetchJson(path) {
  const response = await fetch(path, { cache: "no-store" });
  if (!response.ok) {
    const text = await response.text().catch(() => "");
    throw new Error(`Failed to load ${path}: ${response.status} ${response.statusText} ${text}`);
  }
  return response.json();
}

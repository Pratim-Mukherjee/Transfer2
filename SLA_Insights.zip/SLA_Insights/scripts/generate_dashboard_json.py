"""
Generate a UI-friendly dashboard JSON by combining SLA config and tracking history.

Usage:
    python scripts/generate_dashboard_json.py \
        --config config.json \
        --tracking data/sla_tracking.json \
        --output data/ui_dashboard.json
"""

from __future__ import annotations

import argparse
import json
from collections import deque
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple


# ---------------------------------------------------------------------------
# Utility helpers
# ---------------------------------------------------------------------------


def load_json(path: Path) -> Any:
    with path.open("r", encoding="utf-8") as fh:
        return json.load(fh)


def write_json(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as fh:
        json.dump(data, fh, indent=2, ensure_ascii=False)


def parse_timestamp(value: Optional[str]) -> Optional[datetime]:
    if not value:
        return None
    try:
        # Python >= 3.11 can parse ISO 8601 with offsets directly
        dt = datetime.fromisoformat(value)
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt
    except ValueError:
        return None


def hours_between(start: datetime, end: datetime) -> float:
    delta = end - start
    return delta.total_seconds() / 3600.0


def format_datetime(dt: Optional[datetime]) -> Optional[str]:
    if dt is None:
        return None
    return dt.isoformat()


def format_duration(hours: Optional[float]) -> Optional[str]:
    if hours is None:
        return None
    minutes = round(abs(hours) * 60)
    h, m = divmod(minutes, 60)
    parts = []
    if h:
        parts.append(f"{h}h")
    if m:
        parts.append(f"{m}m")
    if not parts:
        parts.append("0m")
    text = " ".join(parts)
    return text


def to_title_case(value: Optional[str]) -> str:
    if not value:
        return ""
    return " ".join(part.capitalize() for part in value.replace("_", " ").split())


def status_label(status: str) -> str:
    return {
        "on-track": "On Track",
        "breached": "SLA Breach",
        "at-risk": "At Risk",
        "failed": "Attention",
        "stalled": "Not Started",
    }.get(status, to_title_case(status))


def severity_label(status: str) -> str:
    return {
        "failed": "Critical Breach",
        "breached": "SLA Breach",
        "at-risk": "At Risk",
        "stalled": "Stalled",
    }.get(status, "Info")


def severity_key(status: str) -> str:
    return {
        "failed": "critical",
        "breached": "warning",
        "at-risk": "warning",
        "stalled": "idle",
    }.get(status, "info")


def severity_rank(status: str) -> int:
    return {
        "failed": 3,
        "breached": 2,
        "at-risk": 2,
        "stalled": 1,
    }.get(status, 0)


# ---------------------------------------------------------------------------
# Data structures
# ---------------------------------------------------------------------------


@dataclass
class StageDefinition:
    stage_id: str
    name: str
    depends_on: List[str] = field(default_factory=list)
    sla_hours: Optional[float] = None


@dataclass
class StageState:
    stage_id: str
    label: str
    status: str
    completed_at: Optional[datetime]
    message: str
    meta: str
    sla_breached: bool
    elapsed_hours: Optional[float]
    over_sla_hours: Optional[float]
    sla_target_hours: Optional[float]
    time_delta: Optional[str]
    baseline: Optional[datetime]

    def to_dict(self) -> Dict[str, Any]:
        return {
            "stageId": self.stage_id,
            "label": self.label,
            "status": self.status,
            "completedAt": format_datetime(self.completed_at),
            "message": self.message,
            "meta": self.meta,
            "slaBreached": self.sla_breached,
            "elapsedHours": self.elapsed_hours,
            "overSlaHours": self.over_sla_hours,
            "slaTargetHours": self.sla_target_hours,
            "timeDelta": self.time_delta,
            "baseline": format_datetime(self.baseline),
        }


@dataclass
class JourneyView:
    id: str
    name: str
    percent_complete: int
    status: str
    status_label: str
    focus_stage: Optional[StageState]
    current_stage: Optional[StageState]
    stage_states: List[StageState]
    breaches: List[Dict[str, Any]]
    severity_rank: int
    next_action: str

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "name": self.name,
            "percentComplete": self.percent_complete,
            "status": self.status,
            "statusLabel": self.status_label,
            "focusStage": self.focus_stage.to_dict() if self.focus_stage else None,
            "currentStage": self.current_stage.to_dict() if self.current_stage else None,
            "stageStates": [stage.to_dict() for stage in self.stage_states],
            "breaches": self.breaches,
            "severityRank": self.severity_rank,
            "nextAction": self.next_action,
        }


# ---------------------------------------------------------------------------
# Core computation
# ---------------------------------------------------------------------------


def compute_stage_order(stage_defs: Dict[str, StageDefinition]) -> List[str]:
    indegree = {stage_id: 0 for stage_id in stage_defs}
    adjacency = {stage_id: [] for stage_id in stage_defs}
    for stage in stage_defs.values():
        for dep in stage.depends_on:
            if dep in stage_defs:
                indegree[stage.stage_id] += 1
                adjacency[dep].append(stage.stage_id)

    queue = deque(sorted([sid for sid, degree in indegree.items() if degree == 0]))
    ordered = []
    while queue:
        sid = queue.popleft()
        ordered.append(sid)
        for neighbour in adjacency[sid]:
            indegree[neighbour] -= 1
            if indegree[neighbour] == 0:
                queue.append(neighbour)

    if len(ordered) != len(stage_defs):
        raise ValueError("Cycle detected in stage definitions.")
    return ordered


def compute_journey_start(history: List[Dict[str, Any]]) -> Optional[datetime]:
    timestamps = [
        parse_timestamp(entry.get("timestamp"))
        for entry in history
        if entry.get("timestamp")
    ]
    timestamps = [dt for dt in timestamps if dt is not None]
    if not timestamps:
        return None
    return min(timestamps)


def resolve_baseline(depends_on: Iterable[str], completion_map: Dict[str, datetime]) -> Optional[datetime]:
    baseline = None
    for dep in depends_on:
        completed_at = completion_map.get(dep)
        if completed_at and (baseline is None or completed_at > baseline):
            baseline = completed_at
    return baseline


def evaluate_stage(
    stage: StageDefinition,
    entry: Optional[Dict[str, Any]],
    completion_map: Dict[str, datetime],
    journey_start: Optional[datetime],
) -> StageState:
    baseline = resolve_baseline(stage.depends_on, completion_map)
    if baseline is None and not stage.depends_on:
        baseline = journey_start

    status = "pending"
    message = "Awaiting start"
    meta = ""
    completed_at = parse_timestamp(entry.get("timestamp")) if entry else None
    sla_breached = False
    elapsed_hours = None
    over_sla_hours = None
    time_delta = None

    if entry:
        entry_status = entry.get("status")
        timestamp = parse_timestamp(entry.get("timestamp"))
        if entry_status == "Completed":
            status = "completed"
            message = "Completed"
            meta = format_datetime(timestamp) if timestamp else ""
            if baseline and timestamp:
                elapsed_hours = hours_between(baseline, timestamp)
        elif entry_status == "Failed":
            status = "failed"
            message = f"Failed: {entry.get('reason', 'Unknown reason')}"
            meta = (
                f"Updated {format_datetime(timestamp)}" if timestamp else ""
            )
            if baseline and timestamp:
                elapsed_hours = hours_between(baseline, timestamp)
        else:
            status = "in-progress"
            message = entry_status or "In progress"
            meta = (
                f"Updated {format_datetime(timestamp)}" if timestamp else ""
            )
            if baseline:
                elapsed_hours = hours_between(baseline, datetime.now(timezone.utc))
    else:
        if baseline:
            elapsed_hours = hours_between(baseline, datetime.now(timezone.utc))
            message = "Awaiting kickoff"
            meta = f"Ready since {format_datetime(baseline)}"

    if stage.sla_hours is not None and baseline:
        reference_time = completed_at or datetime.now(timezone.utc)
        elapsed_for_sla = hours_between(baseline, reference_time)
        if elapsed_for_sla > stage.sla_hours:
            sla_breached = True
            over_sla_hours = elapsed_for_sla - stage.sla_hours
            time_delta = f"Over SLA by {format_duration(over_sla_hours)}"
            if status == "pending":
                status = "at-risk"
            if status == "completed":
                time_delta = f"Completed {format_duration(over_sla_hours)} over SLA"
        else:
            time_delta = f"Completed in {format_duration(elapsed_for_sla)} (SLA {stage.sla_hours}h)" if status == "completed" else f"Elapsed {format_duration(elapsed_for_sla)} of {stage.sla_hours}h SLA"

    return StageState(
        stage_id=stage.stage_id,
        label=stage.name,
        status=status,
        completed_at=completed_at,
        message=message,
        meta=meta,
        sla_breached=sla_breached,
        elapsed_hours=elapsed_hours,
        over_sla_hours=over_sla_hours,
        sla_target_hours=stage.sla_hours,
        time_delta=time_delta,
        baseline=baseline,
    )


def suggest_next_action(stage: Optional[StageState], journey_status: str) -> str:
    if stage is None:
        return "Review onboarding milestones and confirm next steps."
    if journey_status == "failed":
        return f"Resolve the failure at {stage.label}. {stage.message}"
    if journey_status == "breached":
        return f"Mitigate the SLA breach at {stage.label} and communicate recovery steps."
    if journey_status == "at-risk":
        return f"Follow up on {stage.label} to recover SLA."
    if journey_status == "stalled":
        return f"Kick off {stage.label} to initiate the journey."
    if stage.sla_breached:
        return f"Review {stage.label} for SLA breach follow-up."
    if stage.status == "pending":
        return f"Prepare {stage.label} to stay on track."
    if stage.status == "in-progress":
        return f"Monitor {stage.label} progress."
    return f"Validate {stage.label} completion."


def derive_journey_status(stage_states: List[StageState], percent_complete: int) -> str:
    if any(stage.status == "failed" for stage in stage_states):
        return "failed"
    if any(stage.sla_breached and stage.status != "failed" for stage in stage_states):
        return "breached"
    if any(stage.status == "at-risk" for stage in stage_states):
        return "at-risk"
    if percent_complete == 0:
        return "stalled"
    return "on-track"


def determine_focus_stage(stage_states: List[StageState]) -> Optional[StageState]:
    priorities = [
        lambda s: s.status == "failed",
        lambda s: s.status == "at-risk",
        lambda s: s.sla_breached,
        lambda s: s.status == "in-progress",
        lambda s: s.status == "pending",
    ]
    for predicate in priorities:
        for stage in stage_states:
            if predicate(stage):
                return stage
    return stage_states[-1] if stage_states else None


def determine_current_stage(stage_states: List[StageState]) -> Optional[StageState]:
    for status in ("failed", "at-risk", "in-progress"):
        for stage in stage_states:
            if stage.status == status:
                return stage
    for stage in stage_states:
        if stage.status == "pending":
            return stage
    return stage_states[-1] if stage_states else None


def map_participant_journey(
    participant: Dict[str, Any],
    stage_order: List[str],
    stage_defs: Dict[str, StageDefinition],
) -> JourneyView:
    history = participant.get("history", [])
    history_map = {entry.get("stage"): entry for entry in history if entry.get("stage")}

    completion_map: Dict[str, datetime] = {}
    stage_states: List[StageState] = []
    journey_start = compute_journey_start(history)

    for stage_id in stage_order:
        definition = stage_defs[stage_id]
        entry = history_map.get(stage_id)
        state = evaluate_stage(definition, entry, completion_map, journey_start)
        if state.completed_at:
            completion_map[stage_id] = state.completed_at
        stage_states.append(state)

    completed_count = sum(1 for stage in stage_states if stage.status == "completed")
    percent_complete = round((completed_count / len(stage_states)) * 100) if stage_states else 0
    status = derive_journey_status(stage_states, percent_complete)
    status_text = status_label(status)
    focus_stage = determine_focus_stage(stage_states)
    current_stage = determine_current_stage(stage_states)

    breaches = [
        {
            "stageId": stage.stage_id,
            "stageLabel": stage.label,
            "message": stage.time_delta or stage.message,
            "completedAt": format_datetime(stage.completed_at),
        }
        for stage in stage_states
        if stage.sla_breached
    ]

    next_action = suggest_next_action(focus_stage, status)

    return JourneyView(
        id=str(participant.get("id")),
        name=participant.get("name") or f"Participant {participant.get('id')}",
        percent_complete=percent_complete,
        status=status,
        status_label=status_text,
        focus_stage=focus_stage,
        current_stage=current_stage,
        stage_states=stage_states,
        breaches=breaches,
        severity_rank=severity_rank(status),
        next_action=next_action,
    )


def journey_callout(journey: JourneyView) -> Dict[str, Any]:
    stage = journey.focus_stage or (journey.stage_states[0] if journey.stage_states else None)
    time_delta = (
        stage.time_delta
        if stage and stage.time_delta
        else (f"Elapsed {format_duration(stage.elapsed_hours)}" if stage and stage.elapsed_hours is not None else None)
    )
    return {
        "id": journey.id,
        "name": journey.name,
        "status": journey.status,
        "statusLabel": journey.status_label,
        "stageLabel": stage.label if stage else "Not started",
        "stageStatus": stage.status if stage else "pending",
        "stageStatusLabel": "SLA Breach" if stage and stage.sla_breached and stage.status != "failed" else status_label(stage.status if stage else "pending"),
        "stageMessage": stage.message if stage else "Awaiting start",
        "timeDelta": time_delta,
        "overSlaHours": stage.over_sla_hours if stage else None,
        "nextAction": journey.next_action,
        "severity": severity_key(journey.status),
        "severityLabel": severity_label(journey.status),
        "severityRank": journey.severity_rank,
        "breachStageLabel": journey.breaches[0]["stageLabel"] if journey.breaches else None,
    }


def summarise_metrics(journeys: List[JourneyView]) -> Dict[str, Any]:
    total = len(journeys)
    completed = sum(1 for j in journeys if j.percent_complete == 100)
    on_track = sum(1 for j in journeys if j.status == "on-track")
    breached = sum(1 for j in journeys if j.breaches)
    at_risk = sum(1 for j in journeys if j.status == "at-risk")
    failed = sum(1 for j in journeys if j.status == "failed")
    stalled = sum(1 for j in journeys if j.status == "stalled")
    sla_breach_count = sum(len(j.breaches) for j in journeys)
    total_completion = sum(j.percent_complete for j in journeys)

    return {
        "totalJourneys": total,
        "completedJourneys": completed,
        "onTrackJourneys": on_track,
        "breachedJourneys": breached,
        "atRiskJourneys": at_risk,
        "failedJourneys": failed,
        "stalledJourneys": stalled,
        "attentionJourneys": total - on_track,
        "pendingAttention": total - on_track,
        "slaBreaches": sla_breach_count,
        "averageCompletion": round(total_completion / total) if total else 0,
        "onTrackRate": round((on_track / total) * 100) if total else 0,
    }


def aggregate_stage_metrics(
    journeys: List[JourneyView],
    stage_order: List[str],
    stage_defs: Dict[str, StageDefinition],
) -> List[Dict[str, Any]]:
    metrics = []
    for stage_id in stage_order:
        definition = stage_defs[stage_id]
        completed = in_progress = at_risk = failed = 0
        active_cards = []

        for journey in journeys:
            stage = next((s for s in journey.stage_states if s.stage_id == stage_id), None)
            if not stage:
                continue
            if stage.status == "completed":
                completed += 1
            elif stage.status == "failed":
                failed += 1
            elif stage.status == "at-risk":
                at_risk += 1
                active_cards.append(build_stage_card(journey, stage))
            elif stage.status in {"in-progress", "pending"}:
                in_progress += 1
                active_cards.append(build_stage_card(journey, stage))
            elif stage.sla_breached:
                active_cards.append(build_stage_card(journey, stage))

        total = completed + in_progress + at_risk + failed
        completion_rate = round((completed / total) * 100) if total else 0

        active_cards.sort(key=lambda card: (card["severityRank"], card.get("overSlaHours") or 0), reverse=True)

        metrics.append(
            {
                "stageId": stage_id,
                "label": definition.name,
                "completed": completed,
                "inProgress": in_progress,
                "atRisk": at_risk,
                "failed": failed,
                "completionRate": completion_rate,
                "activeJourneys": active_cards,
            }
        )
    return metrics


def build_stage_card(journey: JourneyView, stage: StageState) -> Dict[str, Any]:
    status = "breached" if stage.sla_breached and stage.status != "failed" else stage.status
    time_delta = stage.time_delta or (
        f"Elapsed {format_duration(stage.elapsed_hours)}" if stage.elapsed_hours is not None else None
    )
    return {
        "id": journey.id,
        "name": journey.name,
        "status": journey.status,
        "statusLabel": journey.status_label,
        "severityRank": journey.severity_rank,
        "stageLabel": stage.label,
        "stageStatus": status,
        "stageStatusLabel": "SLA Breach" if stage.sla_breached and stage.status != "failed" else status_label(stage.status),
        "stageMessage": stage.message,
        "timeDelta": time_delta,
        "overSlaHours": stage.over_sla_hours,
    }


def compute_coverage(stage_defs: Dict[str, StageDefinition], slas: Dict[str, Any]) -> Dict[str, Any]:
    missing_sla = []
    baseline_gaps = []
    unknown_dependencies = []

    stage_ids = set(stage_defs.keys())
    for stage in stage_defs.values():
        depends_existing = [dep for dep in stage.depends_on if dep in stage_ids]

        if stage.sla_hours is None and depends_existing:
            missing_sla.append({"id": stage.stage_id, "name": stage.name})

        if stage.sla_hours is not None and not depends_existing:
            baseline_gaps.append({"id": stage.stage_id, "name": stage.name})

        missing = [dep for dep in stage.depends_on if dep not in stage_ids]
        if missing:
            unknown_dependencies.append({"id": stage.stage_id, "name": stage.name, "missing": missing})

    defined_sla_keys = {stage_id.upper() for stage_id in stage_defs}
    unused_slas = [
        {"key": key, "label": to_title_case(key.lower())}
        for key in slas.keys()
        if key.upper() not in defined_sla_keys
    ]

    return {
        "missingSlaStages": missing_sla,
        "baselineGaps": baseline_gaps,
        "unknownDependencies": unknown_dependencies,
        "unusedSlaKeys": unused_slas,
    }


def assemble_output(
    journeys: List[JourneyView],
    stage_metrics: List[Dict[str, Any]],
    coverage: Dict[str, Any],
) -> Dict[str, Any]:
    metrics = summarise_metrics(journeys)
    callouts = [journey_callout(j) for j in journeys]
    risks = [
        callout
        for callout in callouts
        if callout["status"] != "on-track"
    ]
    risks.sort(key=lambda c: (c["severityRank"], c.get("overSlaHours") or 0), reverse=True)

    groups = {
        "total": callouts,
        "onTrack": [c for c in callouts if c["status"] == "on-track"],
        "attention": [c for c in callouts if c["status"] != "on-track"],
        "breached": [c for c in callouts if c["status"] in {"breached", "failed"}],
    }

    journeys_sorted = sorted(
        journeys,
        key=lambda j: (j.severity_rank, j.focus_stage.over_sla_hours if j.focus_stage else 0, j.percent_complete),
        reverse=True,
    )

    return {
        "metrics": metrics,
        "journeys": [journey.to_dict() for journey in journeys_sorted],
        "stageMetrics": stage_metrics,
        "risks": risks,
        "groups": groups,
        "coverage": coverage,
        "generatedAt": datetime.now(timezone.utc).isoformat(),
    }


def load_stage_definitions(config: Dict[str, Any]) -> Dict[str, StageDefinition]:
    stage_defs = {}
    definitions = config.get("stageDefinitions", {})
    slas = config.get("slas", {})
    for stage_id, definition in definitions.items():
        stage_defs[stage_id] = StageDefinition(
            stage_id=stage_id,
            name=definition.get("name") or to_title_case(stage_id),
            depends_on=list(definition.get("dependsOn", [])),
            sla_hours=slas.get(stage_id.upper()),
        )
    return stage_defs


def main(config_path: Path, tracking_path: Path, output_path: Path) -> None:
    config = load_json(config_path)
    tracking = load_json(tracking_path)

    stage_defs = load_stage_definitions(config)
    stage_order = compute_stage_order(stage_defs)

    journeys = [
        map_participant_journey(participant, stage_order, stage_defs)
        for participant in tracking
    ]

    stage_metrics = aggregate_stage_metrics(journeys, stage_order, stage_defs)
    coverage = compute_coverage(stage_defs, config.get("slas", {}))

    output = assemble_output(journeys, stage_metrics, coverage)
    write_json(output_path, output)
    print(f"Dashboard data written to {output_path}")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Generate UI-ready SLA dashboard JSON.")
    parser.add_argument("--config", type=Path, default=Path("config.json"), help="Path to config.json")
    parser.add_argument(
        "--tracking",
        type=Path,
        default=Path("data") / "sla_tracking.json",
        help="Path to SLA tracking JSON",
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=Path("data") / "ui_dashboard.json",
        help="Destination for UI-friendly JSON",
    )
    return parser.parse_args()


if __name__ == "__main__":
    args = parse_args()
    main(args.config, args.tracking, args.output)

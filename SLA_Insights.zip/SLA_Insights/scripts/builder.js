const els = {
  form: document.getElementById("stage-form"),
  stageId: document.getElementById("stage-id"),
  stageName: document.getElementById("stage-name"),
  stageSla: document.getElementById("stage-sla"),
  stageDepends: document.getElementById("stage-depends"),
  newStage: document.getElementById("new-stage"),
  deleteStage: document.getElementById("delete-stage"),
  download: document.getElementById("download-config"),
  reset: document.getElementById("reset-data"),
  tableBody: document.getElementById("stage-table-body"),
  warnings: document.getElementById("warnings")
};

const templates = {
  stageRow: document.getElementById("stage-row-template")
};

const deepClone = (value) =>
  typeof structuredClone === "function"
    ? structuredClone(value)
    : JSON.parse(JSON.stringify(value));

let cy;
let stageStore;
let selectedStageId = null;
let originalConfig = null;

class StageStore {
  constructor() {
    this.stages = new Map();
  }

  load(config) {
    this.stages.clear();
    const defs = config.stageDefinitions ?? {};
    const slas = config.slas ?? {};
    for (const [id, definition] of Object.entries(defs)) {
      const dependsOn = Array.isArray(definition.dependsOn) ? [...definition.dependsOn] : [];
      const slaKey = id.toUpperCase();
      this.stages.set(id, {
        id,
        name: definition.name ?? toTitleCase(id),
        dependsOn,
        sla: slas[slaKey] != null ? Number(slas[slaKey]) : null
      });
    }
  }

  getStage(id) {
    const stage = this.stages.get(id);
    return stage ? deepClone(stage) : null;
  }

  getOrderedStages() {
    const clone = new Map();
    for (const [id, stage] of this.stages.entries()) {
      clone.set(id, deepClone(stage));
    }

    const indegree = new Map();
    const adjacency = new Map();

    for (const [id, stage] of clone.entries()) {
      indegree.set(id, 0);
      adjacency.set(id, []);
    }

    for (const [id, stage] of clone.entries()) {
      for (const dep of stage.dependsOn) {
        if (!clone.has(dep)) continue;
        indegree.set(id, (indegree.get(id) ?? 0) + 1);
        adjacency.get(dep).push(id);
      }
    }

    const queue = [];
    for (const [id, degree] of indegree.entries()) {
      if (degree === 0) queue.push(id);
    }

    queue.sort();
    const ordered = [];
    while (queue.length > 0) {
      const id = queue.shift();
      ordered.push(clone.get(id));
      for (const neighbour of adjacency.get(id)) {
        indegree.set(neighbour, indegree.get(neighbour) - 1);
        if (indegree.get(neighbour) === 0) {
          queue.push(neighbour);
        }
      }
      queue.sort();
    }

    if (ordered.length !== clone.size) {
      // fallback to simple name ordering if a cycle sneaks in (should not happen)
      return Array.from(this.stages.values()).sort((a, b) => a.name.localeCompare(b.name));
    }

    return ordered;
  }

  stageExists(id) {
    return this.stages.has(id);
  }

  upsertStage(stage) {
    const nextMap = new Map(this.stages);
    nextMap.set(stage.id, deepClone(stage));

    if (this.hasCycle(nextMap)) {
      throw new Error("This dependency combination creates a cycle.");
    }

    this.stages = nextMap;
  }

  removeStage(id) {
    if (!this.stages.has(id)) return;
    const nextMap = new Map();
    for (const [stageId, stage] of this.stages.entries()) {
      if (stageId === id) continue;
      const filtered = stage.dependsOn.filter((dep) => dep !== id);
      nextMap.set(stageId, { ...stage, dependsOn: filtered });
    }
    if (this.hasCycle(nextMap)) {
      throw new Error("Deleting this stage introduces an invalid state.");
    }
    this.stages = nextMap;
  }

  hasCycle(map) {
    const indegree = new Map();
    const adjacency = new Map();

    for (const [id, stage] of map.entries()) {
      indegree.set(id, 0);
      adjacency.set(id, []);
    }

    for (const [id, stage] of map.entries()) {
      for (const dep of stage.dependsOn) {
        if (!map.has(dep)) continue;
        indegree.set(id, (indegree.get(id) ?? 0) + 1);
        adjacency.get(dep).push(id);
      }
    }

    const queue = [];
    for (const [id, degree] of indegree.entries()) {
      if (degree === 0) queue.push(id);
    }

    let visited = 0;
    while (queue.length > 0) {
      const id = queue.shift();
      visited += 1;
      for (const neighbour of adjacency.get(id)) {
        indegree.set(neighbour, indegree.get(neighbour) - 1);
        if (indegree.get(neighbour) === 0) {
          queue.push(neighbour);
        }
      }
    }
    return visited !== map.size;
  }

  getCoverage() {
    const missingSlaStages = [];
    const baselineGaps = [];
    const unknownDependencies = [];

    const stageIds = new Set(this.stages.keys());
    const slas = new Set();
    for (const stage of this.stages.values()) {
      if (stage.sla != null) {
        slas.add(stage.id.toUpperCase());
      }
    }

    for (const stage of this.stages.values()) {
      const depends = stage.dependsOn.filter((dep) => stageIds.has(dep));
      if (stage.dependsOn.some((dep) => !stageIds.has(dep))) {
        const unknown = stage.dependsOn.filter((dep) => !stageIds.has(dep));
        if (unknown.length) {
          unknownDependencies.push({
            id: stage.id,
            name: stage.name,
            missing: unknown
          });
        }
      }

      if (stage.sla == null && depends.length > 0) {
        missingSlaStages.push({ id: stage.id, name: stage.name });
      }

      if (stage.sla != null && depends.length === 0) {
        baselineGaps.push({ id: stage.id, name: stage.name });
      }
    }

    const unusedSlaKeys = [];
    for (const key of slas) {
      if (!stageIds.has(key.toLowerCase())) {
        unusedSlaKeys.push({ key, label: toTitleCase(key.toLowerCase()) });
      }
    }

    return { missingSlaStages, baselineGaps, unusedSlaKeys, unknownDependencies };
  }

  toConfig() {
    const stageDefinitions = {};
    const slas = {};
    for (const stage of this.getOrderedStages()) {
      stageDefinitions[stage.id] = {
        name: stage.name,
        dependsOn: stage.dependsOn
      };
      if (stage.sla != null && stage.sla !== "") {
        slas[stage.id.toUpperCase()] = Number(stage.sla);
      }
    }
    return { slas, stageDefinitions };
  }
}

async function init() {
  const response = await fetch("config.json", { cache: "no-store" });
  if (!response.ok) {
    throw new Error(`Unable to load config.json (${response.status})`);
  }
  const config = await response.json();
  originalConfig = deepClone(config);

  stageStore = new StageStore();
  stageStore.load(config);

  initGraph();
  bindEvents();
  renderAll();
}

function bindEvents() {
  els.form.addEventListener("submit", onSaveStage);
  els.newStage.addEventListener("click", () => selectStage(null));
  els.deleteStage.addEventListener("click", onDeleteStage);
  els.download.addEventListener("click", downloadConfig);
  els.reset.addEventListener("click", resetConfig);
}

function renderAll() {
  renderStageTable();
  updateDependsOptions();
  renderGraph();
  renderWarnings();
  updateDeleteState();
}

function renderStageTable() {
  els.tableBody.innerHTML = "";
  const stages = stageStore.getOrderedStages();
  for (const stage of stages) {
    const row = templates.stageRow.content.firstElementChild.cloneNode(true);
    row.dataset.stageId = stage.id;
    row.querySelector(".id-cell").textContent = stage.id;
    row.querySelector(".name-cell").textContent = stage.name;
    const dependsText = stage.dependsOn.length
      ? stage.dependsOn
          .map((dep) => stageStore.getStage(dep)?.name ?? dep)
          .join(", ")
      : "None";
    row.querySelector(".depends-cell").textContent = dependsText;
    row.querySelector(".sla-cell").textContent =
      stage.sla != null && stage.sla !== "" ? `${stage.sla}h` : "No SLA";
    const editButton = row.querySelector(".link-button");
    editButton.addEventListener("click", () => selectStage(stage.id));
    if (stage.id === selectedStageId) {
      row.classList.add("selected");
    }
    els.tableBody.appendChild(row);
  }
}

function updateDependsOptions() {
  const stages = stageStore.getOrderedStages();
  els.stageDepends.innerHTML = "";

  for (const stage of stages) {
    const option = document.createElement("option");
    option.value = stage.id;
    option.textContent = `${stage.name} (${stage.id})`;
    if (stage.id === selectedStageId) {
      option.disabled = true;
    }
    els.stageDepends.appendChild(option);
  }

  if (selectedStageId) {
    const stage = stageStore.getStage(selectedStageId);
    if (stage) {
      for (const option of els.stageDepends.options) {
        option.selected = stage.dependsOn.includes(option.value);
      }
    }
  }
}

function renderGraph() {
  const nodes = [];
  const edges = [];
  for (const stage of stageStore.getOrderedStages()) {
    const label =
      stage.sla != null && stage.sla !== ""
        ? `${stage.name}\n${stage.sla}h SLA`
        : `${stage.name}\nNo SLA`;
    nodes.push({
      data: {
        id: stage.id,
        label,
        rawName: stage.name
      },
      classes: [
        stage.sla == null ? "no-sla" : "has-sla",
        stage.dependsOn.length === 0 ? "root-stage" : "",
        stage.id === selectedStageId ? "selected" : ""
      ]
        .filter(Boolean)
        .join(" ")
    });

    for (const dep of stage.dependsOn) {
      if (!stageStore.stageExists(dep)) continue;
      edges.push({
        data: { id: `${dep}->${stage.id}`, source: dep, target: stage.id }
      });
    }
  }

  cy.elements().remove();
  cy.add([...nodes, ...edges]);
  cy.resize();

  cy.layout({
    name: "breadthfirst",
    directed: true,
    padding: 20,
    spacingFactor: 1.2,
    animate: false
  }).run();
  cy.fit(undefined, 60);
}

function renderWarnings() {
  const coverage = stageStore.getCoverage();
  const messages = [];

  if (coverage.missingSlaStages.length) {
    const list = coverage.missingSlaStages.map((item) => item.name).join(", ");
    messages.push(`Stages with dependencies but no SLA set: ${list}.`);
  }

  if (coverage.baselineGaps.length) {
    const list = coverage.baselineGaps.map((item) => item.name).join(", ");
    messages.push(
      `Stages with SLA but no dependency: ${list}. Journey start will be used as the baseline.`
    );
  }

  if (coverage.unknownDependencies.length) {
    for (const gap of coverage.unknownDependencies) {
      messages.push(
        `Stage ${gap.name} references missing dependencies: ${gap.missing.join(", ")}`
      );
    }
  }

  if (coverage.unusedSlaKeys.length) {
    const list = coverage.unusedSlaKeys.map((item) => item.label).join(", ");
    messages.push(`SLA entries without matching stages: ${list}.`);
  }

  if (!messages.length) {
    els.warnings.hidden = true;
    els.warnings.innerHTML = "";
    return;
  }

  els.warnings.hidden = false;
  els.warnings.innerHTML = `
    <h3>Configuration warnings</h3>
    <ul>${messages.map((msg) => `<li>${msg}</li>`).join("")}</ul>
  `;
}

function initGraph() {
  cy = cytoscape({
    container: document.getElementById("graph-container"),
    boxSelectionEnabled: false,
    autounselectify: true,
    wheelSensitivity: 0.2,
    style: [
      {
        selector: "node",
        style: {
          "background-color": "rgba(56, 189, 248, 0.35)",
          "border-width": 2,
          "border-color": "rgba(56, 189, 248, 0.8)",
          "label": "data(label)",
          "text-valign": "center",
          "text-halign": "center",
          "color": "#f8fafc",
          "font-size": 11,
          "font-weight": 600,
          "text-wrap": "wrap",
          "text-max-width": 160,
          "line-height": 1.2,
          "padding": "12px",
          "shape": "round-rectangle",
          "width": "label",
          "height": "label"
        }
      },
      {
        selector: "node.no-sla",
        style: {
          "background-color": "rgba(248, 113, 113, 0.25)",
          "border-color": "rgba(248, 113, 113, 0.85)"
        }
      },
      {
        selector: "node.selected",
        style: {
          "border-width": 4,
          "border-color": "#facc15",
          "background-color": "rgba(250, 204, 21, 0.25)"
        }
      },
      {
        selector: "edge",
        style: {
          "line-color": "rgba(148, 163, 184, 0.5)",
          "target-arrow-color": "rgba(148, 163, 184, 0.7)",
          "target-arrow-shape": "triangle",
          "curve-style": "bezier",
          "line-style": "solid",
          "width": 2
        }
      },
      {
        selector: "edge:selected",
        style: {
          "line-color": "rgba(56, 189, 248, 0.9)",
          "target-arrow-color": "rgba(56, 189, 248, 0.9)",
          "width": 3
        }
      }
    ]
  });

  window.addEventListener("resize", () => {
    if (!cy) return;
    cy.resize();
    cy.fit(undefined, 80);
  });

  cy.on("tap", "node", (event) => {
    const id = event.target.id();
    selectStage(id);
  });
}

function selectStage(stageId) {
  selectedStageId = stageId;

  if (!stageId) {
    els.form.reset();
    els.stageId.disabled = false;
    els.deleteStage.disabled = true;
    for (const option of els.stageDepends.options) {
      option.selected = false;
      option.disabled = false;
    }
    updateDependsOptions();
    highlightGraphSelection();
    highlightTableSelection();
    return;
  }

  const stage = stageStore.getStage(stageId);
  if (!stage) return;

  els.stageId.value = stage.id;
  els.stageId.disabled = true;
  els.stageName.value = stage.name;
  els.stageSla.value = stage.sla != null ? stage.sla : "";

  updateDependsOptions();
  for (const option of els.stageDepends.options) {
    option.selected = stage.dependsOn.includes(option.value);
  }

  els.deleteStage.disabled = false;
  highlightGraphSelection();
  highlightTableSelection();
}

function highlightGraphSelection() {
  if (!cy) return;
  cy.elements().removeClass("selected");
  if (!selectedStageId) return;
  const node = cy.getElementById(selectedStageId);
  if (node) {
    node.addClass("selected");
    const successors = node.successors();
    successors.addClass("selected");
    successors.connectedEdges().addClass("selected");
    const predecessors = node.predecessors();
    predecessors.addClass("selected");
    predecessors.connectedEdges().addClass("selected");
    node.connectedEdges().addClass("selected");
  }
}

function highlightTableSelection() {
  for (const row of els.tableBody.querySelectorAll("tr")) {
    row.classList.toggle("selected", row.dataset.stageId === selectedStageId);
  }
}

function updateDeleteState() {
  els.deleteStage.disabled = !selectedStageId;
}

function onSaveStage(event) {
  event.preventDefault();
  const idRaw = els.stageId.value.trim();
  if (!idRaw) {
    alert("Stage ID is required.");
    return;
  }
  const id = idRaw.toLowerCase().replace(/\s+/g, "_");
  const name = els.stageName.value.trim();
  if (!name) {
    alert("Stage name is required.");
    return;
  }

  const slaValue = els.stageSla.value.trim();
  const sla = slaValue === "" ? null : Number(slaValue);
  if (sla != null && (!Number.isFinite(sla) || sla < 0)) {
    alert("SLA hours must be a positive number.");
    return;
  }

  const dependsOn = Array.from(els.stageDepends.selectedOptions).map((option) => option.value);
  if (dependsOn.includes(id)) {
    alert("A stage cannot depend on itself.");
    return;
  }

  if (selectedStageId && selectedStageId !== id) {
    alert("Stage ID cannot be changed. Create a new stage instead.");
    return;
  }

  const stage = {
    id,
    name,
    dependsOn,
    sla
  };

  try {
    stageStore.upsertStage(stage);
    selectedStageId = id;
    renderAll();
    selectStage(id);
  } catch (error) {
    alert(error.message);
  }
}

function onDeleteStage() {
  if (!selectedStageId) return;
  const stage = stageStore.getStage(selectedStageId);
  if (!stage) return;
  const confirmed = confirm(
    `Delete stage "${stage.name}"?\nDependents will lose this dependency.`
  );
  if (!confirmed) return;
  try {
    stageStore.removeStage(selectedStageId);
    selectedStageId = null;
    renderAll();
    selectStage(null);
  } catch (error) {
    alert(error.message);
  }
}

function downloadConfig() {
  const config = stageStore.toConfig();
  const json = JSON.stringify(config, null, 2);
  const blob = new Blob([json], { type: "application/json" });
  const url = URL.createObjectURL(blob);

  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = "config.json";
  document.body.appendChild(anchor);
  anchor.click();
  document.body.removeChild(anchor);
  URL.revokeObjectURL(url);
}

function resetConfig() {
  const confirmed = confirm("Reset all changes to the original configuration?");
  if (!confirmed) return;
  stageStore.load(originalConfig);
  selectedStageId = null;
  renderAll();
  selectStage(null);
}

function toTitleCase(value) {
  return (value ?? "")
    .replace(/[_-]+/g, " ")
    .replace(/\s+/g, " ")
    .trim()
    .replace(/\w\S*/g, (word) => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase());
}

init().catch((error) => {
  console.error(error);
  alert(error.message || "Failed to initialise SLA builder.");
});

# db_main.py - Main Application with PostgreSQL Integration

import asyncio
import json
import sys
from datetime import datetime, timedelta
from database import DatabaseManager, create_database_schema
from db_fetching import DatabaseDataFetcher
from db_computations import compute_daily_metrics_db
from utils import CALIBRATION_WINDOW

def format_output_db(metrics, macro_goals=None, meals=None, hourly_burns=None, date_str=None):
    """
    Format output for database-sourced data

    Args:
        metrics: Computed daily metrics
        macro_goals: User's macro goals
        meals: Meal data
        hourly_burns: Hourly calorie burn data
        date_str: Date string

    Returns:
        Formatted output dictionary
    """

    intake = metrics.get("intake", {})
    expenditure = metrics.get("expenditure", {})

    logged_kcal = intake.get("logged_kcal", 0)
    bias_adjusted_kcal = intake.get("bias_adjusted_kcal", logged_kcal)

    rmr = expenditure.get("RMR_kcal", 0)
    aee = expenditure.get("AEE_kcal", 0)
    tee = expenditure.get("TEE_kcal", 0)
    tef = expenditure.get("TEF_kcal", 0)

    print(f"Database expenditure values in format_output - RMR: {rmr}, AEE: {aee}, TEE: {tee}")

    # Extract current macros
    current_macros = {
        "protein": intake.get("macros", {}).get("protein_g", 0),
        "carbs": intake.get("macros", {}).get("carbs_g", 0),
        "fats": intake.get("macros", {}).get("fat_g", 0),
    }

    # Set default goals
    defaults = {
        "protein": {"goal": 160, "target": 150},
        "carbs": {"goal": 220, "target": 200},
        "fats": {"goal": 75, "target": 70}
    }

    goals = macro_goals if macro_goals else defaults

    # Prepare dailyFlow with intake based on meals timestamps
    intake_flow = {hour: 0 for hour in range(25)}  # hours 0 to 24

    if meals and date_str:
        for meal in meals:
            time_str = meal.get('ts', '')
            if time_str:
                # Handle both string and datetime objects
                if isinstance(time_str, str):
                    meal_date = time_str.split('T')[0]
                    if meal_date == date_str:  # Only use meals on the target analysis date
                        hour = int(time_str.split('T')[1].split(':')[0])
                        p = meal.get('protein_g', 0)
                        c = meal.get('carbs_g', 0)
                        f = meal.get('fat_g', 0)
                        kcal = p * 4 + c * 4 + f * 9
                        intake_flow[hour] += kcal
                else:
                    # Handle datetime object
                    if time_str.date().strftime("%Y-%m-%d") == date_str:
                        hour = time_str.hour
                        p = meal.get('protein_g', 0)
                        c = meal.get('carbs_g', 0)
                        f = meal.get('fat_g', 0)
                        kcal = p * 4 + c * 4 + f * 9
                        intake_flow[hour] += kcal

    # Uniform RMR + TEF burn per hour
    rmr_tef_per_hour = (rmr + tef) / 24

    # Initialize burn_flow with constant RMR+TEF per hour (for 24 hours only)
    burn_flow = [round(rmr_tef_per_hour)] * 24

    # Add hourly AEE burn values from hourly_burns (activity)
    if hourly_burns:
        for hour, aee_val in hourly_burns.items():
            if 0 <= hour < 24:
                burn_flow[hour] += round(aee_val)

    # For hour 24 (optional, maybe just same as hour 0 to keep 25 elements)
    burn_flow.append(burn_flow[0])

    daily_flow_data = []
    for hour in range(25):
        daily_flow_data.append({
            "hour": hour, 
            "intake": intake_flow.get(hour, 0), 
            "burn": burn_flow[hour]
        })

    output = {
        "todayMetrics": {
            "currentIntake": logged_kcal,
            "currentBurn": tee,
            "projectedIntake": bias_adjusted_kcal,
            "projectedBurn": round(tee * 1.1),  # example adjustment
            "currentDeficit": logged_kcal - tee,
            "projectedDeficit": bias_adjusted_kcal - tee
        },
        "macros": {
            "protein": {
                "current": round(current_macros["protein"]),
                "goal": goals["protein"]["goal"],
                "target": goals["protein"]["target"]
            },
            "carbs": {
                "current": round(current_macros["carbs"]),
                "goal": goals["carbs"]["goal"],
                "target": goals["carbs"]["target"]
            },
            "fats": {
                "current": round(current_macros["fats"]),
                "goal": goals["fats"]["goal"],
                "target": goals["fats"]["target"]
            },
        },
        "dailyFlow": {
            "data": daily_flow_data
        }
    }

    return output

async def main_db(user_id, date_str, db_config=None):
    """
    Main function using PostgreSQL database integration

    Args:
        user_id: User ID
        date_str: Date string in YYYY-MM-DD format
        db_config: Database configuration dictionary

    Returns:
        JSON output with energy balance analysis
    """

    try:
        # Initialize database connection
        db_manager = DatabaseManager(db_config)
        data_fetcher = DatabaseDataFetcher(db_manager)

        print("✅ Database connection established")

        # Fetch user profile from database
        profile_resp = data_fetcher.fetch_user_profile(user_id)
        if "error" in profile_resp:
            return {"error": f"Profile fetch error: {profile_resp['error']}"}

        profile_data = profile_resp.get("content", {}).get("user", {})

        # Manual weight override if needed
        profile_weight = profile_data.get("weight_kg")
        if profile_weight:
            current_weight = profile_weight
        else:
            # Could add input prompt here or use a default
            current_weight = 70  # default weight
            print("⚠️ No weight found in database, using default: 70kg")

        # Fetch band data for calibration window
        start_date = (datetime.strptime(date_str, "%Y-%m-%d") - timedelta(days=CALIBRATION_WINDOW-1)).strftime("%Y-%m-%d")

        print(f"Fetching band data from {start_date} to {date_str}")
        band_data_weekly = await data_fetcher.fetch_all_band_data_async(user_id, start_date, CALIBRATION_WINDOW)

        # Format band data for current day (take the last day's data)
        band_data = {
            "cgm": band_data_weekly["cgm"][-1:] if band_data_weekly["cgm"] else [],
            "hr": band_data_weekly["hr"][-1:] if band_data_weekly["hr"] else [],
            "hrv": band_data_weekly["hrv"][-1:] if band_data_weekly["hrv"] else [],
            "activity": band_data_weekly.get("activity", []),
        }

        print(f"Band data summary - CGM: {len(band_data['cgm'])}, HR: {len(band_data['hr'])}, HRV: {len(band_data['hrv'])}, Activity: {len(band_data['activity'])}")

        # Fetch health metrics from database
        health_metrics = data_fetcher.fetch_daily_health_metrics(user_id, date_str)

        # Fetch historical weights for calibration
        end_date = date_str
        historical_weights = data_fetcher.fetch_historical_weights(user_id, start_date, end_date)
        if not historical_weights:
            historical_weights = {date_str: current_weight}

        # Calibration (placeholder - using defaults)
        from db_computations import calibrate_factors
        bias_factor, exp_correction = calibrate_factors([], list(historical_weights.values()))

        # Compute daily metrics using database data
        results = compute_daily_metrics_db(
            date_str, profile_data, band_data, health_metrics, 
            historical_weights, current_weight, bias_factor, exp_correction
        )

        hourly_burns = results.get("hourly_burns", {})

        # Fetch meals data
        meals = data_fetcher.fetch_meals_for_date(user_id, date_str)

        # Get macro goals from profile
        macro_goals = profile_data.get("macro_goals", {})

        # Format final output
        final_output = format_output_db(
            results, 
            macro_goals=macro_goals, 
            meals=meals, 
            hourly_burns=hourly_burns, 
            date_str=date_str
        )

        return final_output

    except Exception as e:
        error_msg = f"Database main execution error: {str(e)}"
        print(f"❌ {error_msg}")
        return {"error": error_msg}

    finally:
        # Close database connections
        if 'db_manager' in locals():
            db_manager.close_pool()

def setup_database_schema(db_config=None):
    """
    Set up database schema with all required tables

    Args:
        db_config: Database configuration dictionary
    """
    try:
        db_manager = DatabaseManager(db_config)
        create_database_schema(db_manager)
        db_manager.close_pool()
        print("✅ Database schema setup completed")
    except Exception as e:
        print(f"❌ Database schema setup failed: {e}")

if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("Usage: python db_main.py <user_id> <date_str> [--setup-schema]")
        print("       python db_main.py --setup-schema")
        sys.exit(1)

    # Check if schema setup is requested
    if "--setup-schema" in sys.argv:
        setup_database_schema()
        if len(sys.argv) == 2:  # Only setup requested
            sys.exit(0)

    USER_ID = int(sys.argv[1])
    DATE_STR = sys.argv[2]

    # Run the main function
    result = asyncio.run(main_db(USER_ID, DATE_STR))

    print(json.dumps(result, indent=2))

    # Save output to file
    with open("energy_balance_output_db.json", "w") as f:
        json.dump(result, f, indent=2)

    print("✅ Results saved to energy_balance_output_db.json")
# Health Metrics Energy Balance Calculator - PostgreSQL Version

This is a refactored version of your health metrics energy balance calculator that uses PostgreSQL database queries instead of JSON files for data access.

## Features

- **PostgreSQL Integration**: Complete database integration with connection pooling
- **Async Data Fetching**: Efficient async queries for better performance  
- **Data Migration**: Utility to migrate from JSON files to PostgreSQL
- **Schema Management**: Automated database schema creation and management
- **Type Safety**: Type hints throughout the codebase for better maintainability

## Project Structure

```
├── database.py          # Database connection and schema management
├── db_fetching.py       # PostgreSQL-based data fetching
├── db_computations.py   # Modified computations for database data
├── db_main.py          # Main application with database integration
├── data_migration.py    # Utility to migrate JSON data to PostgreSQL
├── requirements.txt     # Python dependencies
├── .env.example        # Environment variables template
├── utils.py            # Utility functions (unchanged)
├── interpretations.py  # Results interpretation (unchanged)
└── README.md           # This file
```

## Installation

1. **Install PostgreSQL**
   ```bash
   # Ubuntu/Debian
   sudo apt-get install postgresql postgresql-contrib

   # macOS with Homebrew
   brew install postgresql

   # Windows - Download from https://www.postgresql.org/download/
   ```

2. **Install Python Dependencies**
   ```bash
   pip install -r requirements.txt
   ```

3. **Create Database**
   ```bash
   # Connect to PostgreSQL
   sudo -u postgres psql

   # Create database and user
   CREATE DATABASE health_metrics;
   CREATE USER health_user WITH PASSWORD 'secure_password';
   GRANT ALL PRIVILEGES ON DATABASE health_metrics TO health_user;
   ```

4. **Configure Environment**
   ```bash
   # Copy environment template
   cp .env.example .env

   # Edit .env with your database credentials
   nano .env
   ```

## Database Schema

The system creates the following tables:

- **users**: User profiles (weight, height, age, gender)
- **daily_metrics**: Daily health metrics and computed values
- **meals**: Meal data with macronutrients and timestamps
- **activity_readings**: Activity data (steps, calories burned)
- **heart_rate_readings**: Heart rate measurements
- **hrv_readings**: Heart rate variability data
- **glucose_readings**: Continuous glucose monitoring data
- **user_weights**: Historical weight tracking
- **macro_goals**: User's nutrition targets

## Usage

### 1. Setup Database Schema

```bash
# Create all database tables
python db_main.py --setup-schema
```

### 2. Migrate Existing Data (Optional)

If you have existing JSON data files:

```bash
# Migrate JSON data to PostgreSQL
python data_migration.py
```

### 3. Run Energy Balance Analysis

```bash
# Run analysis for specific user and date
python db_main.py 196 2025-09-04

# With schema setup
python db_main.py 196 2025-09-04 --setup-schema
```

### 4. Insert New Data

You can insert data using the DatabaseManager class:

```python
from database import DatabaseManager
from datetime import datetime

db = DatabaseManager()

# Insert new meal
meal_query = """
    INSERT INTO meals (user_id, meal_id, ts, protein_g, carbs_g, fat_g)
    VALUES (%s, %s, %s, %s, %s, %s)
"""
db.execute_insert(meal_query, (196, 'breakfast-1', datetime.now(), 25, 45, 12))

# Insert activity data
activity_query = """
    INSERT INTO activity_readings (user_id, ts, total_calories_burned, total_steps)
    VALUES (%s, %s, %s, %s)
"""
db.execute_insert(activity_query, (196, datetime.now(), 150, 2500))
```

## Key Improvements

### 1. **Database Integration**
- Replaced JSON file reading with PostgreSQL queries
- Added connection pooling for better performance
- Implemented proper error handling and transactions

### 2. **Async Processing**
- Async data fetching for multiple data sources
- Better performance when fetching large datasets
- Non-blocking database operations

### 3. **Data Migration**
- Automated migration from JSON files
- Maintains data integrity with proper constraints
- Handles duplicate data with ON CONFLICT clauses

### 4. **Schema Management**
- Automated table creation with proper indexes
- Foreign key relationships for data integrity
- Optimized queries for common access patterns

## Configuration

### Environment Variables

Set these in your `.env` file:

```bash
# Required Database Settings
DB_HOST=localhost
DB_NAME=health_metrics  
DB_USER=your_username
DB_PASSWORD=your_password
DB_PORT=5432

# Optional API Settings (if still using external APIs)
API_BASE_URL=your_api_url
EMAIL=your_api_email
PASSWORD=your_api_password
```

### Database Connection

The system uses connection pooling for efficient database access:

```python
# Default configuration
config = {
    'host': 'localhost',
    'database': 'health_metrics',
    'user': 'postgres', 
    'password': 'password',
    'port': '5432'
}

db_manager = DatabaseManager(config)
```

## API Compatibility

The refactored system maintains the same output format as your original code, ensuring compatibility with existing downstream systems.

### Input/Output Format

**Input**: Same command line arguments
```bash
python db_main.py <user_id> <date_str>
```

**Output**: Same JSON structure
```json
{
  "todayMetrics": {
    "currentIntake": 1485,
    "currentBurn": 2030,
    "projectedIntake": 1485,
    "projectedBurn": 2233,
    "currentDeficit": -545,
    "projectedDeficit": -545
  },
  "macros": { ... },
  "dailyFlow": { ... }
}
```

## Performance Considerations

1. **Connection Pooling**: Reduces database connection overhead
2. **Async Queries**: Parallel data fetching for multiple data sources
3. **Indexing**: Optimized indexes on frequently queried columns
4. **Query Optimization**: Efficient SQL queries with proper JOINs

## Migration from JSON Files

The migration process:

1. Reads your existing JSON files (`values.json`, `activity_test.json`)
2. Creates database schema if it doesn't exist
3. Inserts data with proper type conversion
4. Handles duplicates gracefully
5. Creates relationships between related data

## Error Handling

The system includes comprehensive error handling:

- Database connection failures
- Query execution errors  
- Data validation errors
- Missing data handling
- Graceful degradation for optional metrics

## Testing

Run comprehensive tests to verify everything works:

```bash
python test_database.py
```

This will test:
- Database connection and schema creation
- Data migration from JSON files
- Main application functionality
- Output comparison between versions

## Next Steps

1. **Production Deployment**:
   - Set up PostgreSQL with proper security
   - Configure SSL connections
   - Set up database backups

2. **Performance Optimization**:
   - Add query caching
   - Implement read replicas
   - Add database monitoring

3. **Data Validation**:
   - Add input validation
   - Implement data quality checks
   - Add automated testing

4. **API Integration**:
   - Build REST API endpoints
   - Add authentication
   - Implement rate limiting

This refactored version provides a robust, scalable foundation for your health metrics analysis system while maintaining full compatibility with your existing workflow.
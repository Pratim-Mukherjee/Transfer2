# test_database.py - Test Script for Database Integration

import asyncio
import json
from database import DatabaseManager, create_database_schema
from data_migration import DataMigrator
from db_main import main_db

def test_database_setup():
    """Test database setup and schema creation"""

    print("🧪 Testing Database Setup...")

    try:
        # Test database connection
        db_manager = DatabaseManager()
        print("✅ Database connection successful")

        # Test schema creation
        create_database_schema(db_manager)
        print("✅ Database schema created successfully")

        # Close connection
        db_manager.close_pool()

        return True

    except Exception as e:
        print(f"❌ Database setup test failed: {e}")
        return False

def test_data_migration():
    """Test data migration from JSON files"""

    print("🧪 Testing Data Migration...")

    try:
        # Initialize database
        db_manager = DatabaseManager()

        # Create schema
        create_database_schema(db_manager)

        # Test migration
        migrator = DataMigrator(db_manager)
        migrator.migrate_from_json_files(
            values_json_path="values.json",
            activity_json_path="activity_test.json",
            user_id=196
        )

        print("✅ Data migration test successful")

        # Close connection
        db_manager.close_pool()

        return True

    except Exception as e:
        print(f"❌ Data migration test failed: {e}")
        return False

async def test_main_application():
    """Test the main application with database integration"""

    print("🧪 Testing Main Application...")

    try:
        # Run main application
        result = await main_db(196, "2025-09-04")

        if "error" in result:
            print(f"❌ Application test failed: {result['error']}")
            return False

        # Validate output structure
        required_keys = ["todayMetrics", "macros", "dailyFlow"]
        for key in required_keys:
            if key not in result:
                print(f"❌ Missing key in output: {key}")
                return False

        print("✅ Main application test successful")
        print(f"📊 Sample output: {json.dumps(result['todayMetrics'], indent=2)}")

        return True

    except Exception as e:
        print(f"❌ Main application test failed: {e}")
        return False

async def run_all_tests():
    """Run all database integration tests"""

    print("🚀 Starting Database Integration Tests...\n")

    # Test 1: Database Setup
    setup_success = test_database_setup()
    print()

    # Test 2: Data Migration  
    migration_success = test_data_migration()
    print()

    # Test 3: Main Application
    app_success = await test_main_application()
    print()

    # Summary
    total_tests = 3
    passed_tests = sum([setup_success, migration_success, app_success])

    print("📋 Test Results Summary:")
    print(f"   Database Setup: {'✅ PASS' if setup_success else '❌ FAIL'}")
    print(f"   Data Migration: {'✅ PASS' if migration_success else '❌ FAIL'}")
    print(f"   Main Application: {'✅ PASS' if app_success else '❌ FAIL'}")
    print(f"\n🎯 Overall: {passed_tests}/{total_tests} tests passed")

    if passed_tests == total_tests:
        print("🎉 All tests passed! Database integration is working correctly.")
    else:
        print("⚠️  Some tests failed. Please check the error messages above.")

    return passed_tests == total_tests

if __name__ == "__main__":
    # Run comprehensive tests
    success = asyncio.run(run_all_tests())

    # Exit with appropriate code
    exit(0 if success else 1)
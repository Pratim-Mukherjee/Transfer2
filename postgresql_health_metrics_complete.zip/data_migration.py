# data_migration.py - Utility to Migrate JSON Data to PostgreSQL

import json
import asyncio
from datetime import datetime
from database import DatabaseManager, create_database_schema
from typing import Dict, List

class DataMigrator:
    """Handles migration of data from JSON files to PostgreSQL database"""

    def __init__(self, db_manager: DatabaseManager):
        self.db = db_manager

    def migrate_from_json_files(self, values_json_path: str, activity_json_path: str, user_id: int = 196):
        """
        Migrate data from JSON files to database tables

        Args:
            values_json_path: Path to values.json file
            activity_json_path: Path to activity_test.json file
            user_id: User ID to associate with the data
        """

        try:
            # Read JSON files
            with open(values_json_path, 'r') as f:
                values_data = json.load(f)

            with open(activity_json_path, 'r') as f:
                activity_data = json.load(f)

            print("📁 JSON files loaded successfully")

            # Create user if not exists
            self._create_or_update_user(user_id, values_data[0] if values_data else {})

            # Migrate values.json data
            if values_data:
                self._migrate_values_data(values_data[0], user_id)

            # Migrate activity data
            if activity_data:
                self._migrate_activity_data(activity_data, user_id)

            print("✅ Data migration completed successfully")

        except Exception as e:
            print(f"❌ Data migration failed: {e}")
            raise

    def _create_or_update_user(self, user_id: int, data: Dict):
        """Create or update user in database"""

        # Extract user info (using defaults for missing data)
        user_data = {
            'user_id': user_id,
            'email': f'user_{user_id}@example.com',  # Default email
            'weight_kg': 70.0,  # Default weight
            'height_cm': 170.0,  # Default height
            'age': 30,  # Default age
            'gender': 'male'  # Default gender
        }

        # Insert or update user
        query = """
            INSERT INTO users (user_id, email, weight_kg, height_cm, age, gender)
            VALUES (%(user_id)s, %(email)s, %(weight_kg)s, %(height_cm)s, %(age)s, %(gender)s)
            ON CONFLICT (user_id) DO UPDATE SET
                weight_kg = EXCLUDED.weight_kg,
                height_cm = EXCLUDED.height_cm,
                age = EXCLUDED.age,
                gender = EXCLUDED.gender,
                updated_at = CURRENT_TIMESTAMP
        """

        self.db.execute_insert(query, tuple(user_data.values()))
        print(f"👤 User {user_id} created/updated")

    def _migrate_values_data(self, data: Dict, user_id: int):
        """Migrate values.json data to database"""

        date_str = data.get('date', '2025-09-04')

        # Migrate daily metrics
        self._migrate_daily_metrics(data, user_id, date_str)

        # Migrate meals
        if 'meals' in data:
            self._migrate_meals(data['meals'], user_id)

        # Create default macro goals
        self._create_default_macro_goals(user_id)

    def _migrate_daily_metrics(self, data: Dict, user_id: int, date_str: str):
        """Migrate daily metrics to database"""

        metrics = data.get('metrics', {})

        # Extract metrics with safe defaults
        daily_data = {
            'user_id': user_id,
            'date': date_str,
            'date_yyyymmdd': int(date_str.replace('-', '')),
            'version': data.get('version', 1),
            'carbs_total_g': self._safe_metric_value(metrics, 'carbs_total_g'),
            'distance_total_m': self._safe_metric_value(metrics, 'distance_total_m'),
            'energy_expended_active_kcal': self._safe_metric_value(metrics, 'energy_expended_active_kcal'),
            'energy_expended_basal_kcal': self._safe_metric_value(metrics, 'energy_expended_basal_kcal'),
            'energy_expended_total_kcal': self._safe_metric_value(metrics, 'energy_expended_total_kcal'),
            'energy_intake_total_kcal': self._safe_metric_value(metrics, 'energy_intake_total_kcal'),
            'fat_total_g': self._safe_metric_value(metrics, 'fat_total_g'),
            'fiber_total_g': self._safe_metric_value(metrics, 'fiber_total_g'),
            'meal_count': self._safe_metric_value(metrics, 'meal_count'),
            'photo_pending_count': self._safe_metric_value(metrics, 'photo_pending_count'),
            'protein_total_g': self._safe_metric_value(metrics, 'protein_total_g'),
            'sat_fat_total_g': self._safe_metric_value(metrics, 'sat_fat_total_g'),
            'steps_total': int(self._safe_metric_value(metrics, 'steps_total')),
            'stress_index': int(self._safe_metric_value(metrics, 'stress_index')),
            'sugar_total_g': self._safe_metric_value(metrics, 'sugar_total_g'),
            'unsat_fat_total_g': self._safe_metric_value(metrics, 'unsat_fat_total_g'),
            'hrv': self._safe_metric_value(metrics, 'hrv'),
            'rhr': int(self._safe_metric_value(metrics, 'rhr')) if self._safe_metric_value(metrics, 'rhr') else None,
            'heart_rate_latest': int(self._safe_metric_value(metrics, 'heart_rate_latest')) if self._safe_metric_value(metrics, 'heart_rate_latest') else None,
            'heart_rate_max': int(self._safe_metric_value(metrics, 'heart_rate_max')) if self._safe_metric_value(metrics, 'heart_rate_max') else None,
            'heart_rate_min': int(self._safe_metric_value(metrics, 'heart_rate_min')) if self._safe_metric_value(metrics, 'heart_rate_min') else None,
            'sleep_total_minutes': int(self._safe_metric_value(metrics, 'sleep_total_minutes')),
            'sleep_deep_minutes': int(self._safe_metric_value(metrics, 'sleep_deep_minutes')),
            'sleep_light_minutes': int(self._safe_metric_value(metrics, 'sleep_light_minutes')),
            'sleep_rem_minutes': int(self._safe_metric_value(metrics, 'sleep_rem_minutes')),
            'sleep_score': int(self._safe_metric_value(metrics, 'sleep_score')),
            'systolic_bp': int(self._safe_metric_value(metrics, 'systolic_bp')) if self._safe_metric_value(metrics, 'systolic_bp') else None,
            'diastolic_bp': int(self._safe_metric_value(metrics, 'diastolic_bp')) if self._safe_metric_value(metrics, 'diastolic_bp') else None,
            'spo2': self._safe_metric_value(metrics, 'spo2'),
            'glucose_value': self._safe_metric_value(metrics, 'glucose_value'),
            'fbs_value': self._safe_metric_value(metrics, 'fbs_value'),
        }

        # Build insert query
        columns = ', '.join(daily_data.keys())
        placeholders = ', '.join(['%s'] * len(daily_data))

        query = f"""
            INSERT INTO daily_metrics ({columns})
            VALUES ({placeholders})
            ON CONFLICT (user_id, date) DO UPDATE SET
                version = EXCLUDED.version,
                carbs_total_g = EXCLUDED.carbs_total_g,
                energy_intake_total_kcal = EXCLUDED.energy_intake_total_kcal,
                protein_total_g = EXCLUDED.protein_total_g,
                fat_total_g = EXCLUDED.fat_total_g,
                steps_total = EXCLUDED.steps_total
        """

        self.db.execute_insert(query, tuple(daily_data.values()))
        print(f"📊 Daily metrics migrated for {date_str}")

    def _migrate_meals(self, meals: List[Dict], user_id: int):
        """Migrate meals data to database"""

        for meal in meals:
            meal_data = {
                'user_id': user_id,
                'meal_id': meal.get('meal_id', 'unknown'),
                'ts': datetime.fromisoformat(meal['ts'].replace('Z', '+00:00')) if meal.get('ts') else datetime.now(),
                'meal_updated_at': datetime.fromisoformat(meal['meal_updated_at'].replace('Z', '+00:00')) if meal.get('meal_updated_at') else None,
                'protein_g': float(meal.get('protein_g', 0)),
                'carbs_g': float(meal.get('carbs_g', 0)),
                'fat_g': float(meal.get('fat_g', 0))
            }

            query = """
                INSERT INTO meals (user_id, meal_id, ts, meal_updated_at, protein_g, carbs_g, fat_g)
                VALUES (%(user_id)s, %(meal_id)s, %(ts)s, %(meal_updated_at)s, %(protein_g)s, %(carbs_g)s, %(fat_g)s)
                ON CONFLICT (user_id, meal_id, ts) DO UPDATE SET
                    meal_updated_at = EXCLUDED.meal_updated_at,
                    protein_g = EXCLUDED.protein_g,
                    carbs_g = EXCLUDED.carbs_g,
                    fat_g = EXCLUDED.fat_g
            """

            self.db.execute_insert(query, tuple(meal_data.values()))

        print(f"🍽️  {len(meals)} meals migrated")

    def _migrate_activity_data(self, activity_data: List[Dict], user_id: int):
        """Migrate activity data to database"""

        for activity in activity_data:
            activity_record = {
                'user_id': user_id,
                'ts': datetime.fromisoformat(activity['ts'].replace('Z', '+00:00')) if activity.get('ts') else datetime.now(),
                'total_calories_burned': float(activity.get('totalCaloriesBurned', 0)),
                'total_steps': int(activity.get('totalStep', 0))
            }

            query = """
                INSERT INTO activity_readings (user_id, ts, total_calories_burned, total_steps)
                VALUES (%(user_id)s, %(ts)s, %(total_calories_burned)s, %(total_steps)s)
                ON CONFLICT DO NOTHING
            """

            self.db.execute_insert(query, tuple(activity_record.values()))

        print(f"🏃 {len(activity_data)} activity records migrated")

    def _create_default_macro_goals(self, user_id: int):
        """Create default macro goals for user"""

        goals_data = {
            'user_id': user_id,
            'protein_goal': 160,
            'protein_target': 150,
            'carbs_goal': 220,
            'carbs_target': 200,
            'fats_goal': 75,
            'fats_target': 70
        }

        query = """
            INSERT INTO macro_goals (user_id, protein_goal, protein_target, carbs_goal, carbs_target, fats_goal, fats_target)
            VALUES (%(user_id)s, %(protein_goal)s, %(protein_target)s, %(carbs_goal)s, %(carbs_target)s, %(fats_goal)s, %(fats_target)s)
            ON CONFLICT (user_id) DO UPDATE SET
                protein_goal = EXCLUDED.protein_goal,
                protein_target = EXCLUDED.protein_target,
                carbs_goal = EXCLUDED.carbs_goal,
                carbs_target = EXCLUDED.carbs_target,
                fats_goal = EXCLUDED.fats_goal,
                fats_target = EXCLUDED.fats_target,
                updated_at = CURRENT_TIMESTAMP
        """

        self.db.execute_insert(query, tuple(goals_data.values()))
        print(f"🎯 Default macro goals created for user {user_id}")

    def _safe_metric_value(self, metrics: Dict, key: str) -> float:
        """Safely extract metric value with default"""
        if key in metrics and metrics[key] and 'value' in metrics[key]:
            value = metrics[key]['value']
            return float(value) if value is not None else 0.0
        return 0.0

def migrate_sample_data():
    """Migrate the sample JSON data to database"""

    try:
        # Initialize database
        db_manager = DatabaseManager()

        # Create schema
        create_database_schema(db_manager)

        # Initialize migrator
        migrator = DataMigrator(db_manager)

        # Migrate data (using the attached file names)
        migrator.migrate_from_json_files(
            values_json_path="values.json",
            activity_json_path="activity_test.json",
            user_id=196
        )

        # Close connections
        db_manager.close_pool()

        print("✅ Sample data migration completed successfully")

    except Exception as e:
        print(f"❌ Sample data migration failed: {e}")

if __name__ == "__main__":
    migrate_sample_data()
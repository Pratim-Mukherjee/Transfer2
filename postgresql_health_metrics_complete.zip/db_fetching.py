# db_fetching.py - PostgreSQL-based Data Fetching Module

import asyncio
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any
from database import DatabaseManager
import json

class DatabaseDataFetcher:
    """Handles all database queries for health metrics and user data"""

    def __init__(self, db_manager: DatabaseManager):
        self.db = db_manager

    def fetch_user_profile(self, user_id: int) -> Dict[str, Any]:
        """
        Fetch user profile information from database

        Args:
            user_id: User ID to fetch profile for

        Returns:
            Dictionary containing user profile data
        """
        try:
            query = """
                SELECT user_id, email, weight_kg, height_cm, age, gender,
                       created_at, updated_at
                FROM users 
                WHERE user_id = %s
            """

            user_data = self.db.execute_query(query, (user_id,), fetch_all=False)

            if not user_data:
                return {"error": f"User {user_id} not found"}

            # Fetch macro goals if they exist
            macro_query = """
                SELECT protein_goal, protein_target, carbs_goal, carbs_target,
                       fats_goal, fats_target
                FROM macro_goals 
                WHERE user_id = %s
            """

            macro_data = self.db.execute_query(macro_query, (user_id,), fetch_all=False)

            # Format response similar to original API structure
            response = {
                "status": 200,
                "content": {
                    "user": {
                        "user_id": user_data["user_id"],
                        "email": user_data["email"],
                        "weight_kg": float(user_data["weight_kg"]) if user_data["weight_kg"] else None,
                        "height_cm": float(user_data["height_cm"]) if user_data["height_cm"] else None,
                        "age": user_data["age"],
                        "gender": user_data["gender"]
                    }
                }
            }

            if macro_data:
                response["content"]["user"]["macro_goals"] = {
                    "protein": {
                        "goal": macro_data["protein_goal"],
                        "target": macro_data["protein_target"]
                    },
                    "carbs": {
                        "goal": macro_data["carbs_goal"],
                        "target": macro_data["carbs_target"]
                    },
                    "fats": {
                        "goal": macro_data["fats_goal"],
                        "target": macro_data["fats_target"]
                    }
                }

            return response

        except Exception as e:
            return {"error": f"Failed to fetch user profile: {str(e)}"}

    def fetch_daily_health_metrics(self, user_id: int, date_str: str) -> List[Dict[str, Any]]:
        """
        Fetch daily health metrics from database

        Args:
            user_id: User ID
            date_str: Date in YYYY-MM-DD format

        Returns:
            List of health metrics in format compatible with original code
        """
        try:
            # First get meals for the date
            meals_query = """
                SELECT protein_g, carbs_g, fat_g, ts, meal_id, meal_updated_at
                FROM meals 
                WHERE user_id = %s AND DATE(ts) = %s
                ORDER BY ts
            """

            meals_data = self.db.execute_query(meals_query, (user_id, date_str))

            # Calculate total macros from meals
            total_protein = sum(float(meal["protein_g"] or 0) for meal in meals_data)
            total_carbs = sum(float(meal["carbs_g"] or 0) for meal in meals_data)
            total_fat = sum(float(meal["fat_g"] or 0) for meal in meals_data)
            total_kcal = total_protein * 4 + total_carbs * 4 + total_fat * 9

            # Get steps from daily metrics if available
            metrics_query = """
                SELECT steps_total 
                FROM daily_metrics 
                WHERE user_id = %s AND date = %s
            """

            daily_metrics = self.db.execute_query(metrics_query, (user_id, date_str), fetch_all=False)
            steps = daily_metrics["steps_total"] if daily_metrics and daily_metrics["steps_total"] else 0

            # Return in format expected by original code
            return [
                {"metric": "energy_intake_total_kcal", "value": total_kcal},
                {"metric": "protein_total_g", "value": total_protein},
                {"metric": "carbs_total_g", "value": total_carbs},
                {"metric": "fat_total_g", "value": total_fat},
                {"metric": "steps_total", "value": steps}
            ]

        except Exception as e:
            print(f"Error fetching health metrics from database: {e}")
            return []

    def fetch_meals_for_date(self, user_id: int, date_str: str) -> List[Dict[str, Any]]:
        """
        Fetch meals for a specific date

        Args:
            user_id: User ID
            date_str: Date in YYYY-MM-DD format

        Returns:
            List of meals in original format
        """
        try:
            query = """
                SELECT user_id, meal_id, ts, meal_updated_at, protein_g, carbs_g, fat_g
                FROM meals 
                WHERE user_id = %s AND DATE(ts) = %s
                ORDER BY ts
            """

            meals = self.db.execute_query(query, (user_id, date_str))

            # Format meals to match original structure
            formatted_meals = []
            for meal in meals:
                formatted_meals.append({
                    "user_id": str(meal["user_id"]),
                    "meal_id": meal["meal_id"],
                    "ts": meal["ts"].isoformat() if meal["ts"] else None,
                    "meal_updated_at": meal["meal_updated_at"].isoformat() if meal["meal_updated_at"] else None,
                    "protein_g": float(meal["protein_g"] or 0),
                    "carbs_g": float(meal["carbs_g"] or 0),
                    "fat_g": float(meal["fat_g"] or 0)
                })

            return formatted_meals

        except Exception as e:
            print(f"Error fetching meals from database: {e}")
            return []

    def fetch_activity_readings(self, user_id: int, start_date: str, end_date: str) -> List[Dict[str, Any]]:
        """
        Fetch activity readings for date range

        Args:
            user_id: User ID
            start_date: Start date in YYYY-MM-DD format
            end_date: End date in YYYY-MM-DD format

        Returns:
            List of activity readings
        """
        try:
            query = """
                SELECT ts, total_calories_burned, total_steps
                FROM activity_readings 
                WHERE user_id = %s AND DATE(ts) BETWEEN %s AND %s
                ORDER BY ts
            """

            readings = self.db.execute_query(query, (user_id, start_date, end_date))

            # Format to match original structure
            formatted_readings = []
            for reading in readings:
                formatted_readings.append({
                    "ts": reading["ts"].isoformat() if reading["ts"] else None,
                    "totalCaloriesBurned": float(reading["total_calories_burned"] or 0),
                    "totalStep": int(reading["total_steps"] or 0)
                })

            return formatted_readings

        except Exception as e:
            print(f"Error fetching activity readings from database: {e}")
            return []

    async def fetch_all_band_data_async(self, user_id: int, start_date_str: str, num_days: int) -> Dict[str, List]:
        """
        Fetch all band data (hr, hrv, cgm, activity) for multiple days

        Args:
            user_id: User ID
            start_date_str: Start date in YYYY-MM-DD format
            num_days: Number of days to fetch

        Returns:
            Dictionary containing all band data grouped by type
        """
        try:
            end_date = datetime.strptime(start_date_str, "%Y-%m-%d") + timedelta(days=num_days-1)
            end_date_str = end_date.strftime("%Y-%m-%d")

            # Fetch all data types in parallel
            tasks = [
                self._fetch_hr_data_range(user_id, start_date_str, end_date_str),
                self._fetch_hrv_data_range(user_id, start_date_str, end_date_str),
                self._fetch_glucose_data_range(user_id, start_date_str, end_date_str),
                self._fetch_activity_data_range(user_id, start_date_str, end_date_str)
            ]

            hr_data, hrv_data, cgm_data, activity_data = await asyncio.gather(*tasks)

            # Group by days
            weekly_data = {'hr': [], 'hrv': [], 'cgm': [], 'activity': []}

            for day_offset in range(num_days):
                current_date = datetime.strptime(start_date_str, "%Y-%m-%d") + timedelta(days=day_offset)
                current_date_str = current_date.strftime("%Y-%m-%d")

                # Filter data for current day
                daily_hr = [r for r in hr_data if r["timestamp"].date() == current_date.date()]
                daily_hrv = [r for r in hrv_data if r["timestamp"].date() == current_date.date()]
                daily_cgm = [r for r in cgm_data if r["timestamp"].date() == current_date.date()]
                daily_activity = [r for r in activity_data if datetime.fromisoformat(r["ts"].replace('Z', '+00:00')).date() == current_date.date()]

                if daily_hr:
                    weekly_data['hr'].append(daily_hr)
                if daily_hrv:
                    weekly_data['hrv'].append(daily_hrv)
                if daily_cgm:
                    weekly_data['cgm'].append(daily_cgm)
                if daily_activity:
                    weekly_data['activity'].append(daily_activity)

            return weekly_data

        except Exception as e:
            print(f"Error fetching band data from database: {e}")
            return {'hr': [], 'hrv': [], 'cgm': [], 'activity': []}

    async def _fetch_hr_data_range(self, user_id: int, start_date: str, end_date: str) -> List[Dict]:
        """Fetch heart rate data for date range"""
        return await asyncio.to_thread(self._sync_fetch_hr_range, user_id, start_date, end_date)

    async def _fetch_hrv_data_range(self, user_id: int, start_date: str, end_date: str) -> List[Dict]:
        """Fetch HRV data for date range"""
        return await asyncio.to_thread(self._sync_fetch_hrv_range, user_id, start_date, end_date)

    async def _fetch_glucose_data_range(self, user_id: int, start_date: str, end_date: str) -> List[Dict]:
        """Fetch glucose data for date range"""
        return await asyncio.to_thread(self._sync_fetch_glucose_range, user_id, start_date, end_date)

    async def _fetch_activity_data_range(self, user_id: int, start_date: str, end_date: str) -> List[Dict]:
        """Fetch activity data for date range"""
        return await asyncio.to_thread(self._sync_fetch_activity_range, user_id, start_date, end_date)

    def _sync_fetch_hr_range(self, user_id: int, start_date: str, end_date: str) -> List[Dict]:
        """Synchronous heart rate data fetch"""
        query = """
            SELECT ts, heart_rate
            FROM heart_rate_readings 
            WHERE user_id = %s AND DATE(ts) BETWEEN %s AND %s
            ORDER BY ts
        """
        readings = self.db.execute_query(query, (user_id, start_date, end_date))
        return [{"timestamp": reading["ts"], "value": reading["heart_rate"]} for reading in readings]

    def _sync_fetch_hrv_range(self, user_id: int, start_date: str, end_date: str) -> List[Dict]:
        """Synchronous HRV data fetch"""
        query = """
            SELECT ts, hrv_value
            FROM hrv_readings 
            WHERE user_id = %s AND DATE(ts) BETWEEN %s AND %s
            ORDER BY ts
        """
        readings = self.db.execute_query(query, (user_id, start_date, end_date))
        return [{"timestamp": reading["ts"], "value": float(reading["hrv_value"])} for reading in readings]

    def _sync_fetch_glucose_range(self, user_id: int, start_date: str, end_date: str) -> List[Dict]:
        """Synchronous glucose data fetch"""
        query = """
            SELECT ts, glucose_value
            FROM glucose_readings 
            WHERE user_id = %s AND DATE(ts) BETWEEN %s AND %s
            ORDER BY ts
        """
        readings = self.db.execute_query(query, (user_id, start_date, end_date))
        return [{"timestamp": reading["ts"], "value": float(reading["glucose_value"])} for reading in readings]

    def _sync_fetch_activity_range(self, user_id: int, start_date: str, end_date: str) -> List[Dict]:
        """Synchronous activity data fetch"""
        query = """
            SELECT ts, total_calories_burned, total_steps
            FROM activity_readings 
            WHERE user_id = %s AND DATE(ts) BETWEEN %s AND %s
            ORDER BY ts
        """
        readings = self.db.execute_query(query, (user_id, start_date, end_date))
        return [
            {
                "ts": reading["ts"].isoformat() if reading["ts"] else None,
                "totalCaloriesBurned": float(reading["total_calories_burned"] or 0),
                "totalStep": int(reading["total_steps"] or 0)
            }
            for reading in readings
        ]
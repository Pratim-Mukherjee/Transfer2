-- setup_database.sql - Database Setup Script

-- Create database and user (run as postgres superuser)
-- psql -U postgres -f setup_database.sql

-- Create database
CREATE DATABASE health_metrics;

-- Create user with password
CREATE USER health_user WITH PASSWORD 'secure_password_here';

-- Grant privileges
GRANT ALL PRIVILEGES ON DATABASE health_metrics TO health_user;

-- Connect to the health_metrics database
\c health_metrics;

-- Grant schema privileges
GRANT ALL ON SCHEMA public TO health_user;
GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO health_user;
GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA public TO health_user;

-- Enable necessary extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Create users table
CREATE TABLE IF NOT EXISTS users (
    user_id SERIAL PRIMARY KEY,
    email VARCHAR(255) UNIQUE NOT NULL,
    weight_kg DECIMAL(5,2),
    height_cm DECIMAL(5,2),
    age INTEGER,
    gender VARCHAR(10),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create daily_metrics table
CREATE TABLE IF NOT EXISTS daily_metrics (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(user_id),
    date DATE NOT NULL,
    date_yyyymmdd INTEGER NOT NULL,
    version INTEGER DEFAULT 1,
    carbs_total_g DECIMAL(8,2) DEFAULT 0,
    distance_total_m DECIMAL(10,2) DEFAULT 0,
    energy_expended_active_kcal DECIMAL(8,2) DEFAULT 0,
    energy_expended_basal_kcal DECIMAL(8,2) DEFAULT 0,
    energy_expended_total_kcal DECIMAL(8,2) DEFAULT 0,
    energy_intake_total_kcal DECIMAL(8,2) DEFAULT 0,
    fat_total_g DECIMAL(8,2) DEFAULT 0,
    fiber_total_g DECIMAL(8,2) DEFAULT 0,
    meal_count INTEGER DEFAULT 0,
    photo_pending_count INTEGER DEFAULT 0,
    protein_total_g DECIMAL(8,2) DEFAULT 0,
    sat_fat_total_g DECIMAL(8,2) DEFAULT 0,
    steps_total INTEGER DEFAULT 0,
    stress_index INTEGER DEFAULT 0,
    sugar_total_g DECIMAL(8,2) DEFAULT 0,
    unsat_fat_total_g DECIMAL(8,2) DEFAULT 0,
    recorded_at TIMESTAMP,
    activity_score DECIMAL(5,2),
    calories_spent DECIMAL(8,2),
    hrv DECIMAL(8,2),
    rhr INTEGER,
    heart_rate_latest INTEGER,
    hrr INTEGER,
    heart_rate_max INTEGER,
    heart_rate_min INTEGER,
    sleep_total_minutes INTEGER DEFAULT 0,
    sleep_deep_minutes INTEGER DEFAULT 0,
    sleep_light_minutes INTEGER DEFAULT 0,
    sleep_rem_minutes INTEGER DEFAULT 0,
    sleep_score INTEGER DEFAULT 0,
    systolic_bp INTEGER,
    diastolic_bp INTEGER,
    spo2 DECIMAL(5,2),
    ehba1c_value DECIMAL(5,2),
    glucose_value DECIMAL(6,2),
    fbs_value DECIMAL(6,2),
    glucose_high DECIMAL(6,2),
    glucose_low DECIMAL(6,2),
    insulin_sensitivity DECIMAL(8,2),
    insulin_production DECIMAL(8,2),
    gss_day DECIMAL(8,2),
    gss_night DECIMAL(8,2),
    pai_score DECIMAL(8,2),
    days_to_reversal INTEGER,
    cgm_days_left INTEGER,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(user_id, date)
);

-- Create meals table
CREATE TABLE IF NOT EXISTS meals (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(user_id),
    meal_id VARCHAR(100) NOT NULL,
    ts TIMESTAMP NOT NULL,
    meal_updated_at TIMESTAMP,
    protein_g DECIMAL(8,2) DEFAULT 0,
    carbs_g DECIMAL(8,2) DEFAULT 0,
    fat_g DECIMAL(8,2) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(user_id, meal_id, ts)
);

-- Create activity_readings table
CREATE TABLE IF NOT EXISTS activity_readings (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(user_id),
    ts TIMESTAMP NOT NULL,
    total_calories_burned DECIMAL(8,2) DEFAULT 0,
    total_steps INTEGER DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create heart_rate_readings table
CREATE TABLE IF NOT EXISTS heart_rate_readings (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(user_id),
    ts TIMESTAMP NOT NULL,
    heart_rate INTEGER NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create hrv_readings table
CREATE TABLE IF NOT EXISTS hrv_readings (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(user_id),
    ts TIMESTAMP NOT NULL,
    hrv_value DECIMAL(8,2) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create glucose_readings table
CREATE TABLE IF NOT EXISTS glucose_readings (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(user_id),
    ts TIMESTAMP NOT NULL,
    glucose_value DECIMAL(6,2) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create user_weights table
CREATE TABLE IF NOT EXISTS user_weights (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(user_id),
    weight_kg DECIMAL(5,2) NOT NULL,
    recorded_date DATE NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(user_id, recorded_date)
);

-- Create macro_goals table
CREATE TABLE IF NOT EXISTS macro_goals (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(user_id),
    protein_goal INTEGER DEFAULT 160,
    protein_target INTEGER DEFAULT 150,
    carbs_goal INTEGER DEFAULT 220,
    carbs_target INTEGER DEFAULT 200,
    fats_goal INTEGER DEFAULT 75,
    fats_target INTEGER DEFAULT 70,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(user_id)
);

-- Create indexes for better query performance
CREATE INDEX IF NOT EXISTS idx_daily_metrics_user_date ON daily_metrics(user_id, date);
CREATE INDEX IF NOT EXISTS idx_meals_user_ts ON meals(user_id, ts);
CREATE INDEX IF NOT EXISTS idx_activity_user_ts ON activity_readings(user_id, ts);
CREATE INDEX IF NOT EXISTS idx_hr_user_ts ON heart_rate_readings(user_id, ts);
CREATE INDEX IF NOT EXISTS idx_hrv_user_ts ON hrv_readings(user_id, ts);
CREATE INDEX IF NOT EXISTS idx_glucose_user_ts ON glucose_readings(user_id, ts);
CREATE INDEX IF NOT EXISTS idx_weights_user_date ON user_weights(user_id, recorded_date);

-- Grant all permissions to health_user
GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO health_user;
GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA public TO health_user;

-- Insert sample user for testing
INSERT INTO users (user_id, email, weight_kg, height_cm, age, gender)
VALUES (196, 'test_user@example.com', 70.0, 170.0, 30, 'male')
ON CONFLICT (user_id) DO NOTHING;

-- Insert default macro goals
INSERT INTO macro_goals (user_id, protein_goal, protein_target, carbs_goal, carbs_target, fats_goal, fats_target)
VALUES (196, 160, 150, 220, 200, 75, 70)
ON CONFLICT (user_id) DO NOTHING;

-- Display confirmation
SELECT 'Database setup completed successfully!' as status;
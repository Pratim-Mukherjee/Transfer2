# db_computations.py - Modified Computations Module for Database Integration

import numpy as np
from utils import calculate_confidence, propagate_uncertainty, DEFAULT_BIAS_FACTOR, DEFAULT_EXP_CORRECTION, TEF_RATE, CAL_PER_KG_FAT, CALIBRATION_WINDOW
from collections import defaultdict
import datetime
from database import DatabaseManager
from db_fetching import DatabaseDataFetcher

def calculate_rmr_mifflin(weight_kg, height_cm, age, gender):
    """Calculate RMR using Mifflin-St Jeor equation."""
    s = 5 if gender.lower() == "male" else -161
    return 10 * weight_kg + 6.25 * height_cm - 5 * age + s

def refine_rmr_with_hr(rmr_baseline, resting_hr, hrv):
    """Refine RMR using resting HR and HRV."""
    factor = 1 + (60 - resting_hr) / 100  # Lower HR increases efficiency
    if hrv and hrv > 50:
        factor += 0.05  # High HRV slight boost
    return rmr_baseline * factor

def calculate_tef(intake_kcal):
    """Calculate Thermic Effect of Food (10% of intake)."""
    return TEF_RATE * intake_kcal

def calibrate_factors(historical_ebs, observed_weight_changes):
    """Placeholder for Bayesian calibration (defaults used)."""
    return DEFAULT_BIAS_FACTOR, DEFAULT_EXP_CORRECTION

def aggregate_activity_by_hour(activity_list):
    """Aggregate activity calories by hour from database activity data"""
    hourly_burn = defaultdict(float)

    for act in activity_list:
        ts = act.get('ts') or act.get('timestamp')
        burn = act.get('totalCaloriesBurned', 0)

        if ts and burn:
            # Handle both string and datetime objects
            if isinstance(ts, str):
                dt = datetime.datetime.fromisoformat(ts.replace('Z', '+00:00'))
            else:
                dt = ts

            hour = dt.hour
            hourly_burn[hour] += burn

    return dict(hourly_burn)

def compute_daily_metrics_db(date_str, profile, band_data, health_metrics, 
                           historical_weights=None, current_weight=None, 
                           bias_factor=DEFAULT_BIAS_FACTOR, 
                           exp_correction=DEFAULT_EXP_CORRECTION):
    """
    Compute daily energy balance metrics using database-sourced data

    Args:
        date_str: Date string in YYYY-MM-DD format
        profile: User profile data from database
        band_data: Band/wearable data from database
        health_metrics: Health metrics from database
        historical_weights: Historical weight data
        current_weight: Current weight override
        bias_factor: Intake bias correction factor
        exp_correction: Expenditure correction factor

    Returns:
        Dictionary containing computed metrics
    """

    # Extract profile with safe defaults
    weight_kg = current_weight if current_weight else profile.get("weight_kg", 70)
    age = profile.get("age", 30)
    height_cm = profile.get("height_cm", 170)
    gender = profile.get("gender", "male")

    # Extract intake from health metrics (database format)
    def safe_metric_lookup(metrics, target):
        """Safely look up metric values from database format"""
        for m in metrics:
            if isinstance(m, dict) and "metric" in m:
                if m["metric"] == target:
                    return m.get("value", 0)
        return 0

    intake_kcal = safe_metric_lookup(health_metrics, "energy_intake_total_kcal")
    protein_g = safe_metric_lookup(health_metrics, "protein_total_g")
    carbs_g = safe_metric_lookup(health_metrics, "carbs_total_g")
    fat_g = safe_metric_lookup(health_metrics, "fat_total_g")

    adjusted_intake = intake_kcal * bias_factor

    # Calculate RMR
    rmr_baseline = calculate_rmr_mifflin(weight_kg, height_cm, age, gender)

    # Get HR data for RMR refinement
    hr_readings = band_data.get("hr", [])
    if hr_readings:
        # Handle nested structure - get latest day's data
        if hr_readings and isinstance(hr_readings[0], list):
            hr_readings = hr_readings[-1] if hr_readings else []

        resting_hr = min([r["value"] for r in hr_readings] or [60]) if hr_readings else 60
    else:
        resting_hr = 60

    # Get HRV data
    hrv_readings = band_data.get("hrv", [])
    if hrv_readings:
        # Handle nested structure - get latest day's data
        if hrv_readings and isinstance(hrv_readings[0], list):
            hrv_readings = hrv_readings[-1] if hrv_readings else []

        hrv = np.mean([r["value"] for r in hrv_readings]) if hrv_readings else 50
    else:
        hrv = 50

    rmr = refine_rmr_with_hr(rmr_baseline, resting_hr, hrv)

    # Calculate AEE from activity data
    activity_readings = band_data.get("activity", [])

    # Flatten nested activity data
    flat_activity = []
    if activity_readings:
        for item in activity_readings:
            if isinstance(item, list):
                flat_activity.extend(item)
            else:
                flat_activity.append(item)

    # Aggregate hourly burns and calculate total AEE
    hourly_burns = aggregate_activity_by_hour(flat_activity)
    aee = sum(a.get("totalCaloriesBurned", 0) for a in flat_activity) if flat_activity else 0

    print(f"Database activity records: {len(flat_activity)}")
    print(f"Calculated AEE from database: {aee}")

    # Extract steps for fallback AEE calculation
    steps = 0
    if flat_activity:
        for act in flat_activity:
            if "totalStep" in act:
                steps += act["totalStep"]

    if not steps:
        steps = safe_metric_lookup(health_metrics, "steps_total")

    # Use steps to estimate AEE if no calories info
    if not aee and steps:
        aee = steps * 0.04  # rough kcal/step estimate

    # Calculate TEF
    tef = calculate_tef(adjusted_intake)

    # Calculate TEE
    tee = (rmr + aee + tef) * exp_correction

    # Calculate Energy Balance
    eb = adjusted_intake - tee

    # Calculate uncertainty ranges
    epsilon_in, epsilon_out = propagate_uncertainty(rmr, aee, tef, adjusted_intake)
    eb_low = eb - epsilon_in - epsilon_out
    eb_high = eb + epsilon_in + epsilon_out

    # Determine confidence and risk flags
    flags = []
    if intake_kcal == 0:
        flags.append("food_log_missing")
    if not band_data.get("hr"):
        flags.append("wearable_HR_incomplete")
    if not historical_weights:
        flags.append("weight_history_missing")

    conf_intake = calculate_confidence(flags)
    conf_exp = 0.85 if not flags else 0.75
    conf_body = 0.9 if current_weight or historical_weights else 0.7

    # Process CGM data
    glucose_readings = band_data.get("cgm", [])
    if glucose_readings and isinstance(glucose_readings[0], list):
        glucose_readings = glucose_readings[-1] if glucose_readings else []

    cgm_mean = np.mean([r["value"] for r in glucose_readings]) if glucose_readings else None
    cgm_var = np.std([r["value"] for r in glucose_readings]) if glucose_readings else None

    insulin_flag = "stable"
    if cgm_mean and cgm_mean > 100:
        insulin_flag = "monitor" if cgm_var and cgm_var > 15 else "stable"

    # Calculate weight trend
    weight_trend_14d = 0.0
    trend_14d = "balance"

    if historical_weights and len(historical_weights) >= 2:
        weights = [w for d, w in sorted(historical_weights.items())]
        weight_trend_14d = weights[-1] - weights[0]
        trend_14d = "deficit" if weight_trend_14d < 0 else "surplus" if weight_trend_14d > 0 else "balance"

    return {
        "date": date_str,
        "energy_balance": {
            "estimate_kcal": round(eb),
            "confidence_range_kcal": [round(eb_low), round(eb_high)],
            "trend_14d": trend_14d,
            "risk_flags": flags
        },
        "intake": {
            "logged_kcal": round(intake_kcal),
            "bias_adjusted_kcal": round(adjusted_intake),
            "macros": {
                "protein_g": round(protein_g), 
                "carbs_g": round(carbs_g), 
                "fat_g": round(fat_g)
            },
            "confidence": conf_intake
        },
        "expenditure": {
            "RMR_kcal": round(rmr),
            "AEE_kcal": round(aee),
            "TEF_kcal": round(tef),
            "TEE_kcal": round(tee),
            "confidence": conf_exp
        },
        "body_metrics": {
            "weight_kg": weight_kg,
            "weight_trend_14d": round(weight_trend_14d, 1),
            "confidence": conf_body
        },
        "calibration": {
            "intake_bias_factor": round(bias_factor, 2),
            "expenditure_correction_factor": round(exp_correction, 2)
        },
        "optional_metrics": {
            "cgm_mean_glucose": round(cgm_mean) if cgm_mean else None,
            "cgm_variability": round(cgm_var) if cgm_var else None,
            "insulin_sensitivity_flag": insulin_flag
        },
        "hourly_burns": hourly_burns
    }
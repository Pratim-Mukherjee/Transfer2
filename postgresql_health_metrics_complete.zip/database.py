# database.py - PostgreSQL Database Configuration and Connection Management

import psycopg2
from psycopg2.extras import RealDictCursor
from psycopg2.pool import SimpleConnectionPool
import os
from datetime import datetime, timedelta
import json
from typing import Dict, List, Optional, Any

class DatabaseManager:
    """Manages PostgreSQL database connections and queries for health metrics"""

    def __init__(self, config: Dict[str, str] = None):
        """
        Initialize database connection with configuration

        Args:
            config: Database configuration dictionary with keys:
                    host, database, user, password, port
        """
        if config is None:
            # Default configuration from environment variables
            config = {
                'host': os.getenv('DB_HOST', 'localhost'),
                'database': os.getenv('DB_NAME', 'health_metrics'),
                'user': os.getenv('DB_USER', 'postgres'),
                'password': os.getenv('DB_PASSWORD', 'password'),
                'port': os.getenv('DB_PORT', '5432')
            }

        self.config = config
        self.connection_pool = None
        self._initialize_connection_pool()

    def _initialize_connection_pool(self):
        """Initialize connection pool for database connections"""
        try:
            self.connection_pool = SimpleConnectionPool(
                1, 20,  # min and max connections
                host=self.config['host'],
                database=self.config['database'],
                user=self.config['user'],
                password=self.config['password'],
                port=self.config['port']
            )
            print("✅ Database connection pool initialized successfully")
        except Exception as e:
            print(f"❌ Failed to initialize database connection pool: {e}")
            raise

    def get_connection(self):
        """Get a connection from the pool"""
        return self.connection_pool.getconn()

    def put_connection(self, conn):
        """Return connection to the pool"""
        self.connection_pool.putconn(conn)

    def execute_query(self, query: str, params: tuple = None, fetch_all: bool = True):
        """
        Execute a query and return results

        Args:
            query: SQL query string
            params: Query parameters tuple
            fetch_all: If True, fetch all results; if False, fetch one

        Returns:
            Query results as list of dictionaries or single dictionary
        """
        conn = None
        try:
            conn = self.get_connection()
            cursor = conn.cursor(cursor_factory=RealDictCursor)
            cursor.execute(query, params)

            if fetch_all:
                results = [dict(row) for row in cursor.fetchall()]
            else:
                result = cursor.fetchone()
                results = dict(result) if result else None

            cursor.close()
            return results

        except Exception as e:
            print(f"❌ Database query error: {e}")
            if conn:
                conn.rollback()
            raise
        finally:
            if conn:
                self.put_connection(conn)

    def execute_insert(self, query: str, params: tuple = None):
        """
        Execute an insert/update/delete query

        Args:
            query: SQL query string
            params: Query parameters tuple

        Returns:
            Number of affected rows
        """
        conn = None
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            cursor.execute(query, params)
            affected_rows = cursor.rowcount
            conn.commit()
            cursor.close()
            return affected_rows

        except Exception as e:
            print(f"❌ Database insert error: {e}")
            if conn:
                conn.rollback()
            raise
        finally:
            if conn:
                self.put_connection(conn)

    def close_pool(self):
        """Close all connections in the pool"""
        if self.connection_pool:
            self.connection_pool.closeall()


# Database Schema Creation Queries
CREATE_SCHEMA_QUERIES = [
    """
    CREATE TABLE IF NOT EXISTS users (
        user_id SERIAL PRIMARY KEY,
        email VARCHAR(255) UNIQUE NOT NULL,
        weight_kg DECIMAL(5,2),
        height_cm DECIMAL(5,2),
        age INTEGER,
        gender VARCHAR(10),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );
    """,

    """
    CREATE TABLE IF NOT EXISTS daily_metrics (
        id SERIAL PRIMARY KEY,
        user_id INTEGER REFERENCES users(user_id),
        date DATE NOT NULL,
        date_yyyymmdd INTEGER NOT NULL,
        version INTEGER DEFAULT 1,
        carbs_total_g DECIMAL(8,2) DEFAULT 0,
        distance_total_m DECIMAL(10,2) DEFAULT 0,
        energy_expended_active_kcal DECIMAL(8,2) DEFAULT 0,
        energy_expended_basal_kcal DECIMAL(8,2) DEFAULT 0,
        energy_expended_total_kcal DECIMAL(8,2) DEFAULT 0,
        energy_intake_total_kcal DECIMAL(8,2) DEFAULT 0,
        fat_total_g DECIMAL(8,2) DEFAULT 0,
        fiber_total_g DECIMAL(8,2) DEFAULT 0,
        meal_count INTEGER DEFAULT 0,
        photo_pending_count INTEGER DEFAULT 0,
        protein_total_g DECIMAL(8,2) DEFAULT 0,
        sat_fat_total_g DECIMAL(8,2) DEFAULT 0,
        steps_total INTEGER DEFAULT 0,
        stress_index INTEGER DEFAULT 0,
        sugar_total_g DECIMAL(8,2) DEFAULT 0,
        unsat_fat_total_g DECIMAL(8,2) DEFAULT 0,
        recorded_at TIMESTAMP,
        activity_score DECIMAL(5,2),
        calories_spent DECIMAL(8,2),
        hrv DECIMAL(8,2),
        rhr INTEGER,
        heart_rate_latest INTEGER,
        hrr INTEGER,
        heart_rate_max INTEGER,
        heart_rate_min INTEGER,
        sleep_total_minutes INTEGER DEFAULT 0,
        sleep_deep_minutes INTEGER DEFAULT 0,
        sleep_light_minutes INTEGER DEFAULT 0,
        sleep_rem_minutes INTEGER DEFAULT 0,
        sleep_score INTEGER DEFAULT 0,
        systolic_bp INTEGER,
        diastolic_bp INTEGER,
        spo2 DECIMAL(5,2),
        ehba1c_value DECIMAL(5,2),
        glucose_value DECIMAL(6,2),
        fbs_value DECIMAL(6,2),
        glucose_high DECIMAL(6,2),
        glucose_low DECIMAL(6,2),
        insulin_sensitivity DECIMAL(8,2),
        insulin_production DECIMAL(8,2),
        gss_day DECIMAL(8,2),
        gss_night DECIMAL(8,2),
        pai_score DECIMAL(8,2),
        days_to_reversal INTEGER,
        cgm_days_left INTEGER,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(user_id, date)
    );
    """,

    """
    CREATE TABLE IF NOT EXISTS meals (
        id SERIAL PRIMARY KEY,
        user_id INTEGER REFERENCES users(user_id),
        meal_id VARCHAR(100) NOT NULL,
        ts TIMESTAMP NOT NULL,
        meal_updated_at TIMESTAMP,
        protein_g DECIMAL(8,2) DEFAULT 0,
        carbs_g DECIMAL(8,2) DEFAULT 0,
        fat_g DECIMAL(8,2) DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(user_id, meal_id, ts)
    );
    """,

    """
    CREATE TABLE IF NOT EXISTS activity_readings (
        id SERIAL PRIMARY KEY,
        user_id INTEGER REFERENCES users(user_id),
        ts TIMESTAMP NOT NULL,
        total_calories_burned DECIMAL(8,2) DEFAULT 0,
        total_steps INTEGER DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );
    """,

    """
    CREATE TABLE IF NOT EXISTS heart_rate_readings (
        id SERIAL PRIMARY KEY,
        user_id INTEGER REFERENCES users(user_id),
        ts TIMESTAMP NOT NULL,
        heart_rate INTEGER NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );
    """,

    """
    CREATE TABLE IF NOT EXISTS hrv_readings (
        id SERIAL PRIMARY KEY,
        user_id INTEGER REFERENCES users(user_id),
        ts TIMESTAMP NOT NULL,
        hrv_value DECIMAL(8,2) NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );
    """,

    """
    CREATE TABLE IF NOT EXISTS glucose_readings (
        id SERIAL PRIMARY KEY,
        user_id INTEGER REFERENCES users(user_id),
        ts TIMESTAMP NOT NULL,
        glucose_value DECIMAL(6,2) NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );
    """,

    """
    CREATE TABLE IF NOT EXISTS user_weights (
        id SERIAL PRIMARY KEY,
        user_id INTEGER REFERENCES users(user_id),
        weight_kg DECIMAL(5,2) NOT NULL,
        recorded_date DATE NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(user_id, recorded_date)
    );
    """,

    """
    CREATE TABLE IF NOT EXISTS macro_goals (
        id SERIAL PRIMARY KEY,
        user_id INTEGER REFERENCES users(user_id),
        protein_goal INTEGER DEFAULT 160,
        protein_target INTEGER DEFAULT 150,
        carbs_goal INTEGER DEFAULT 220,
        carbs_target INTEGER DEFAULT 200,
        fats_goal INTEGER DEFAULT 75,
        fats_target INTEGER DEFAULT 70,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(user_id)
    );
    """,

    # Indexes for better query performance
    """
    CREATE INDEX IF NOT EXISTS idx_daily_metrics_user_date ON daily_metrics(user_id, date);
    CREATE INDEX IF NOT EXISTS idx_meals_user_ts ON meals(user_id, ts);
    CREATE INDEX IF NOT EXISTS idx_activity_user_ts ON activity_readings(user_id, ts);
    CREATE INDEX IF NOT EXISTS idx_hr_user_ts ON heart_rate_readings(user_id, ts);
    CREATE INDEX IF NOT EXISTS idx_hrv_user_ts ON hrv_readings(user_id, ts);
    CREATE INDEX IF NOT EXISTS idx_glucose_user_ts ON glucose_readings(user_id, ts);
    CREATE INDEX IF NOT EXISTS idx_weights_user_date ON user_weights(user_id, recorded_date);
    """
]


def create_database_schema(db_manager: DatabaseManager):
    """Create database schema with all required tables"""
    try:
        for query in CREATE_SCHEMA_QUERIES:
            db_manager.execute_insert(query)
        print("✅ Database schema created successfully")
    except Exception as e:
        print(f"❌ Failed to create database schema: {e}")
        raise
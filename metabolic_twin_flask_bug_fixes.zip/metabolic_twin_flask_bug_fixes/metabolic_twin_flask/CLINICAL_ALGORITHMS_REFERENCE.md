# Clinical Algorithms & Decision Rules Reference
## Metabolic Twin - Diabetes Remission Protocol Generator

**Version:** 2.0
**Last Updated:** October 2025
**Purpose:** Single source of truth for all clinical algorithms, decision rules, and constraints

---

## Table of Contents

1. [Medical Inference Algorithms](#1-medical-inference-algorithms)
2. [Missing Value Calculations](#2-missing-value-calculations)
3. [Activity & Energy Expenditure](#3-activity--energy-expenditure)
4. [Protein Requirements](#4-protein-requirements)
5. [Deficiency Detection & Supplementation](#5-deficiency-detection--supplementation)
6. [Medication & Supplement Timing](#6-medication--supplement-timing)
7. [Macronutrient Distribution](#7-macronutrient-distribution)
8. [Carbohydrate Restriction Rules](#8-carbohydrate-restriction-rules)
9. [Meal Planning & Distribution](#9-meal-planning--distribution)
10. [Weekly Progression Predictions](#10-weekly-progression-predictions)
11. [Safety Constraints & Contraindications](#11-safety-constraints--contraindications)

---

## 1. Medical Inference Algorithms

### 1.1 Diabetes Stage Classification

**Algorithm:** HbA1c-based staging with multi-factorial validation

**Implementation:** `app/engines/protocol_generator.py` (lines 106-145)

**Decision Tree:**
```
IF hba1c_pct < 5.7:
    stage = "non_diabetic"
    intensity = "maintenance"

ELSE IF 5.7 ≤ hba1c_pct < 6.5:
    stage = "prediabetes"
    intensity = "moderate"

ELSE IF 6.5 ≤ hba1c_pct < 8.0:
    stage = "type2_diabetes_controlled"
    intensity = "moderate_improvement"

ELSE IF 8.0 ≤ hba1c_pct < 10.0:
    stage = "type2_diabetes_uncontrolled"
    intensity = "intensive_remission"

ELSE IF hba1c_pct ≥ 10.0:
    stage = "type2_diabetes_severe"
    intensity = "intensive_remission"
    REQUIRE: Medical supervision flag
```

**Constraints:**
- HbA1c must be ≥ 4.0 and ≤ 15.0 (physiological limits)
- Staging can be overridden by doctor via `program_type` selection
- Severe stage (≥10%) requires contraindication check

**Output Format:**
```python
{
    "name": "intensive_remission",
    "description": "Intensive Diabetes Remission",
    "weekly_target": {
        "hba1c_reduction": 0.15,  # % per week
        "weight_loss": 0.75,       # kg per week
        "fbg_reduction": 5         # mg/dL per week
    },
    "intensity": "high"
}
```

**Related Files:**
- Policy: `app/relationships/policies/program_types.json`
- Implementation: `app/engines/protocol_generator.py::determine_program_phase()`

---

### 1.2 Metabolic Risk Assessment

**Algorithm:** Multi-parameter composite risk scoring

**Implementation:** `app/engines/protocol_generator.py::assess_safety_requirements()` (lines 237-298)

**Risk Factors:**
```python
risk_score = 0

# Primary Metabolic Risks
IF hba1c_pct ≥ 8.0:          risk_score += 2
IF fbg_mgdl ≥ 150:           risk_score += 1
IF triglycerides ≥ 200:      risk_score += 1
IF hdl < 40 (male) OR < 50 (female): risk_score += 1
IF bodyfat_pct ≥ 30:         risk_score += 1

# Kidney Function Risks
IF egfr < 60:                risk_score += 2
IF egfr < 90:                risk_score += 1
IF creatinine > 1.3:         risk_score += 1

# Cardiovascular Risks
IF systolic_bp ≥ 140:        risk_score += 1  # (if available)
IF diastolic_bp ≥ 90:        risk_score += 1  # (if available)
```

**Risk Stratification:**
```
risk_score 0-2:  Low Risk → Standard protocol
risk_score 3-5:  Moderate Risk → Enhanced monitoring
risk_score 6+:   High Risk → Medical supervision required
```

**Safety Flags Generated:**
```python
{
    "overall_risk_level": "moderate",
    "requires_medical_supervision": False,
    "monitoring_frequency": "weekly",  # or "biweekly" or "monthly"
    "contraindications": [],
    "precautions": [
        "Monitor blood glucose during fasting periods",
        "Watch for hypoglycemia symptoms"
    ]
}
```

**Related Files:**
- Implementation: `app/engines/protocol_generator.py::assess_safety_requirements()`
- Thresholds: `app/relationships/policies/safety_thresholds.json`

---

## 2. Missing Value Calculations

### 2.1 Body Fat Percentage (Navy Method)

**Algorithm:** U.S. Navy circumference-based estimation

**Implementation:** `app/external_api_helper.py::calculate_navy_method_bodyfat()` (lines 374-426)

**Formulas:**

**For Males:**
```python
bodyfat_pct = (
    86.010 * log10(waist_cm - neck_cm)
    - 70.041 * log10(height_cm)
    + 36.76
)
```

**For Females:**
```python
bodyfat_pct = (
    163.205 * log10(waist_cm + hip_cm - neck_cm)
    - 97.684 * log10(height_cm)
    - 78.387
)
```

**Required Inputs:**
- **Males:** height (cm), waist (cm), neck (cm)
- **Females:** height (cm), waist (cm), hip (cm), neck (cm)

**Validation Rules:**
```python
# Input Constraints
height_cm: 100 ≤ height ≤ 250
waist_cm: 50 ≤ waist ≤ 200
neck_cm: 20 ≤ neck ≤ 60
hip_cm: 50 ≤ hip ≤ 200  # females only

# Output Constraints
bodyfat_pct: 5 ≤ result ≤ 60

# Physiological Validation
IF bodyfat_pct < 10:
    WARNING: "Unusually low - verify measurements"
IF bodyfat_pct > 45:
    WARNING: "Unusually high - verify measurements"
```

**Fallback Hierarchy:**
```
1. Use provided bodyfat_pct (if available and valid)
2. Calculate using Navy Method (if measurements complete)
3. Use population average:
   - Males: 28%
   - Females: 35%
4. Flag as "estimated" in metadata
```

**Implementation:**
```python
def get_body_fat_with_fallback(lab_reports, demographics):
    # 1. Check if bodyfat provided
    if lab_reports.get("bodyfat_pct"):
        return {
            "bodyfat_pct": lab_reports["bodyfat_pct"],
            "bodyfat_method": lab_reports.get("bodyfat_method", "provided"),
            "is_calculated": False,
            "body_measurements": extract_measurements(lab_reports)
        }

    # 2. Try Navy Method
    measurements = extract_measurements(lab_reports)
    if can_calculate_navy_method(demographics, measurements):
        bodyfat = calculate_navy_method_bodyfat(demographics, measurements)
        return {
            "bodyfat_pct": bodyfat,
            "bodyfat_method": "navy_method_calculated",
            "is_calculated": True,
            "body_measurements": measurements
        }

    # 3. Use population average
    gender = demographics.get("gender", "male")
    default = 28 if gender == "male" else 35
    return {
        "bodyfat_pct": default,
        "bodyfat_method": "population_average_estimated",
        "is_calculated": True,
        "body_measurements": {}
    }
```

**Related Files:**
- Implementation: `app/external_api_helper.py::get_body_fat_with_fallback()`
- UI Calculator: `static/body_fat_calculator.js`
- HTML: `templates/index.html` (lines 134-161)

---

### 2.2 BMR (Basal Metabolic Rate)

**Algorithm:** Mifflin-St Jeor Equation (validated as most accurate for overweight/obese populations)

**Implementation:** `app/engines/macro_calculator.py::calculate_bmr()` (lines 52-75)

**Formulas:**

**For Males:**
```python
BMR = (10 × weight_kg) + (6.25 × height_cm) - (5 × age_years) + 5
```

**For Females:**
```python
BMR = (10 × weight_kg) + (6.25 × height_cm) - (5 × age_years) - 161
```

**Example Calculation:**
```python
# Male, 45 years, 175 cm, 92 kg
BMR = (10 × 92) + (6.25 × 175) - (5 × 45) + 5
BMR = 920 + 1093.75 - 225 + 5
BMR = 1793.75 kcal/day

# Female, 52 years, 162 cm, 78 kg
BMR = (10 × 78) + (6.25 × 162) - (5 × 52) - 161
BMR = 780 + 1012.5 - 260 - 161
BMR = 1371.5 kcal/day
```

**Validation:**
```python
# Physiological constraints
IF BMR < 1000:
    WARNING: "Unusually low BMR - verify patient data"
IF BMR > 3500:
    WARNING: "Unusually high BMR - verify patient data"

# Expected ranges by gender
Males: 1400-2400 kcal/day (typical)
Females: 1100-1900 kcal/day (typical)
```

**Related Files:**
- Implementation: `app/engines/macro_calculator.py::calculate_bmr()`
- Policy: `app/relationships/policies/macro_calculation_rules.json`

---

## 3. Activity & Energy Expenditure

### 3.1 TDEE (Total Daily Energy Expenditure)

**Algorithm:** Two-component TDEE calculation

**Implementation:** `app/engines/macro_calculator.py::calculate_tdee()` (lines 97-120)

**Formula:**
```python
TDEE = (BMR × Activity_Level_Multiplier) + Average_Daily_Activity_Calories

Where:
  BMR = Basal Metabolic Rate (Mifflin-St Jeor)
  Activity_Level_Multiplier = Baseline activity factor
  Average_Daily_Activity_Calories = Planned exercise / 7
```

**Component 1: Baseline Activity Multipliers**
```python
activity_multipliers = {
    "sedentary": 1.2,      # Desk job, minimal movement
    "light": 1.375,        # Light exercise 1-3 days/week
    "moderate": 1.55,      # Moderate exercise 3-5 days/week
    "active": 1.725,       # Heavy exercise 6-7 days/week
    "very_active": 1.9     # Physical job + training
}

base_tdee = BMR × multiplier
```

**Component 2: Planned Physical Activities**
```python
# Activities are tracked with:
# - activity_type (from activity_library.json)
# - duration (minutes)
# - frequency (daily, 6×/week, 5×/week, etc.)

weekly_calories = sum([
    activity["weekly_calories"]
    for activity in physical_activities
])

daily_activity_calories = weekly_calories / 7

total_tdee = base_tdee + daily_activity_calories
```

**Example Calculation:**
```python
# Patient: Male, BMR = 1794 kcal, Activity Level = sedentary
base_tdee = 1794 × 1.2 = 2152.8 kcal/day

# Planned Activities:
# - Walking (moderate) 30 min, 5×/week → 525 kcal/week
# - Strength training 45 min, 3×/week → 540 kcal/week
# Total weekly = 1065 kcal
# Daily average = 1065 / 7 = 152.14 kcal/day

total_tdee = 2152.8 + 152.14 = 2304.94 kcal/day
```

**Related Files:**
- Implementation: `app/engines/macro_calculator.py::calculate_tdee()`
- Activity Library: `app/relationships/policies/activity_library.json`
- Policy: `app/relationships/policies/macro_calculation_rules.json`

---

### 3.2 Activity Calorie Calculation (MET Method)

**Algorithm:** Metabolic Equivalent of Task (MET) based estimation

**Implementation:** `static/activity_manager.js::calculateCalories()` (lines 91-98)

**Formula:**
```python
Calories = MET × Body_Weight_kg × Duration_hours

Where:
  MET = Metabolic Equivalent (from activity_library.json)
  Body_Weight_kg = Patient's current weight
  Duration_hours = Activity duration / 60
```

**MET Values by Activity:**
```json
{
  "walking_moderate": 3.5,        // 3-4 mph
  "jogging": 8.0,                 // 5 mph
  "running": 11.5,                // 7 mph
  "cycling_leisure": 4.0,         // <10 mph
  "cycling_moderate": 8.0,        // 12-14 mph
  "swimming_moderate": 6.0,
  "strength_training": 4.0,       // General
  "yoga_hatha": 2.5,
  "hiit": 9.0,
  "walking_slow": 2.0             // <2 mph
}
```

**Frequency Multipliers:**
```json
{
  "daily": 7.0,
  "6_times_week": 6.0,
  "5_times_week": 5.0,
  "4_times_week": 4.0,
  "3_times_week": 3.0,
  "2_times_week": 2.0,
  "once_week": 1.0
}
```

**Example Calculations:**

**Example 1: Walking**
```python
Activity: Walking (moderate pace)
MET: 3.5
Weight: 92 kg
Duration: 30 minutes (0.5 hours)
Frequency: 5 times/week

Calories per session = 3.5 × 92 × 0.5 = 161 kcal
Weekly calories = 161 × 5 = 805 kcal
Daily average = 805 / 7 = 115 kcal/day
```

**Example 2: HIIT Training**
```python
Activity: HIIT
MET: 9.0
Weight: 78 kg
Duration: 20 minutes (0.333 hours)
Frequency: 3 times/week

Calories per session = 9.0 × 78 × 0.333 = 233.6 kcal
Weekly calories = 233.6 × 3 = 700.8 kcal
Daily average = 700.8 / 7 = 100.1 kcal/day
```

**Validation Rules:**
```python
# Duration constraints
min_duration = 5 minutes
max_duration = 180 minutes (3 hours)

# Calorie constraints
IF calories_per_session < 10:
    WARNING: "Very low calorie burn - verify activity/duration"

IF calories_per_session > 1500:
    WARNING: "Very high calorie burn - verify inputs"

# MET value ranges
light_activity: MET 1.5-3.0
moderate_activity: MET 3.0-6.0
vigorous_activity: MET > 6.0
```

**Related Files:**
- Activity Library: `app/relationships/policies/activity_library.json`
- Calculator: `static/activity_manager.js::calculateCalories()`
- Backend Integration: `app/engines/macro_calculator.py::calculate_tdee()`

---

## 4. Protein Requirements

### 4.1 Protein Target Calculation

**Algorithm:** Body composition and activity-based protein allocation

**Implementation:** `app/engines/macro_calculator.py::calculate_protocol_macros()` (lines 174-209)

**Base Formula:**
```python
lean_body_mass_kg = weight_kg × (1 - bodyfat_pct/100)

protein_multiplier = get_protein_multiplier(program_intensity)

daily_protein_g = lean_body_mass_kg × protein_multiplier
```

**Protein Multipliers by Program Intensity:**
```json
{
  "maintenance": 1.6,              // Muscle preservation
  "moderate": 1.8,                 // Moderate fat loss
  "moderate_improvement": 2.0,     // Active fat loss
  "intensive_remission": 2.2       // Aggressive fat loss
}
```

**Rationale:**
- Higher protein during calorie deficit preserves lean mass
- Protein has highest thermic effect (25-30% of calories)
- Satiety effect reduces hunger during restriction
- Evidence-based range: 1.6-2.2 g/kg LBM for fat loss

**Example Calculations:**

**Example 1: Moderate Program**
```python
Patient: Male, 92 kg, 34% body fat
Lean Body Mass = 92 × (1 - 0.34) = 60.72 kg
Program: Moderate Improvement
Multiplier: 2.0 g/kg LBM

Daily Protein = 60.72 × 2.0 = 121.4 g
Protein Calories = 121.4 × 4 = 486 kcal
```

**Example 2: Intensive Program**
```python
Patient: Female, 78 kg, 38% body fat
Lean Body Mass = 78 × (1 - 0.38) = 48.36 kg
Program: Intensive Remission
Multiplier: 2.2 g/kg LBM

Daily Protein = 48.36 × 2.2 = 106.4 g
Protein Calories = 106.4 × 4 = 426 kcal
```

**Constraints:**
```python
# Minimum protein (preserve muscle mass)
min_protein_g = lean_body_mass_kg × 1.4

# Maximum protein (kidney safety)
max_protein_g = lean_body_mass_kg × 2.5

# Safety check for kidney function
IF egfr < 60:
    max_protein_g = min(max_protein_g, lean_body_mass_kg × 1.8)
    WARNING: "Reduced protein due to kidney function"

# Absolute bounds
min_absolute = 50 g/day
max_absolute = 250 g/day
```

**Related Files:**
- Implementation: `app/engines/macro_calculator.py::calculate_protocol_macros()`
- Policy: `app/relationships/policies/macro_calculation_rules.json` (lines 45-60)

---

### 4.2 Protein Distribution Across Meals

**Algorithm:** Equal protein distribution for optimal muscle protein synthesis

**Implementation:** `app/engines/meal_distributor.py::calculate_meal_distribution()` (lines 39-40)

**Formula:**
```python
protein_per_meal = total_daily_protein_g / meal_count
```

**Rationale:**
- Muscle protein synthesis maximizes at ~30-40g protein/meal
- Even distribution maintains amino acid availability
- Prevents single-meal overload (reduced absorption)

**Example Distribution:**

**3 Meals/Day:**
```python
Total Protein: 121 g/day
Meal Count: 3

Protein per meal = 121 / 3 = 40.3 g

Breakfast: 40g protein
Lunch: 40g protein
Dinner: 41g protein (rounding)
```

**4 Meals/Day:**
```python
Total Protein: 106 g/day
Meal Count: 4

Protein per meal = 106 / 4 = 26.5 g

Meal 1: 27g protein
Meal 2: 27g protein
Meal 3: 26g protein
Meal 4: 26g protein
```

**Validation:**
```python
# Per-meal protein constraints
min_protein_per_meal = 20 g  # Minimum for MPS
max_protein_per_meal = 50 g  # Optimal absorption

# Meal count constraints
IF meal_count == 1 (OMAD):
    # All protein in single meal
    # May exceed optimal, but necessary
    ALLOW: protein_per_meal > 50 g

IF meal_count >= 2:
    # Check if distribution is optimal
    IF protein_per_meal < 20:
        WARNING: "Protein per meal below optimal threshold"
    IF protein_per_meal > 50:
        SUGGEST: "Consider more meals for better protein distribution"
```

**Related Files:**
- Implementation: `app/engines/meal_distributor.py::calculate_meal_distribution()`
- Policy: `app/relationships/policies/meal_planning_rules.json`

---

## 5. Deficiency Detection & Supplementation

### 5.1 Supplement Decision Framework

**Algorithm:** Four-tier hierarchical supplementation system

**Implementation:** `app/engines/supplement_optimizer.py::analyze_supplement_needs()` (lines 7-56)

**Decision Hierarchy:**
```
Tier 1: User-Entered Supplements (Always Preserved)
  ↓
Tier 2: Lab-Based Deficiency Supplements (Evidence Required)
  ↓
Tier 3: Metabolic-Based Supplements (Triglycerides → Omega-3)
  ↓
Tier 4: Medication-Triggered Supplements (Metformin → B12)
```

**Implementation Logic:**
```python
def analyze_supplement_needs(enhanced_baseline):
    supplement_recommendations = {}

    # TIER 1: Preserve user supplements
    for supp in user_supplements:
        supplement_recommendations[f"user_{supp['name']}"] = {
            "name": supp['name'],
            "dose": supp['dose'],
            "category": "user_entered",
            "source": "patient"
        }

    # TIER 2: Lab-based deficiencies
    if lab_results:
        deficiency_supplements = get_lab_based_supplements(lab_results)
        supplement_recommendations.update(deficiency_supplements)

    # TIER 3: Metabolic-based (triglycerides)
    metabolic_supplements = get_metabolic_based_supplements(metabolic_baseline)
    supplement_recommendations.update(metabolic_supplements)

    # TIER 4: Medication-triggered
    med_supplements = get_medication_triggered_supplements(medications)
    supplement_recommendations.update(med_supplements)

    return supplement_recommendations
```

**Related Files:**
- Main Logic: `app/engines/supplement_optimizer.py`
- Thresholds: `app/relationships/policies/supplement_thresholds.json`

---

### 5.2 Vitamin B12 Deficiency Detection

**Algorithm:** Three-tier severity classification with dose escalation

**Implementation:** `app/engines/supplement_optimizer.py::get_lab_based_supplements()` (lines 72-104)

**Decision Tree:**
```
IF vitamin_b12 NOT provided:
    → No B12 supplement (no evidence)
    → Check medication triggers (Tier 4)

ELSE IF vitamin_b12 < 200 pg/mL:
    → DEFICIENT (High Severity)
    → Methylcobalamin 2000 mcg
    → Duration: 8 weeks then retest
    → Rationale: "Severe B12 deficiency - high dose needed"

ELSE IF 200 ≤ vitamin_b12 < 400 pg/mL:
    → INSUFFICIENT (Moderate Severity)
    → Methylcobalamin 1000 mcg
    → Duration: 8 weeks then retest
    → Rationale: "Low B12 levels - supplementation recommended"

ELSE IF vitamin_b12 ≥ 400 pg/mL:
    → NORMAL
    → No B12 supplement (unless medication-triggered)
```

**Reference Ranges:**
```json
{
  "deficient": {
    "max": 200,
    "severity": "high",
    "description": "Deficient - High risk"
  },
  "insufficient": {
    "min": 200,
    "max": 400,
    "severity": "moderate",
    "description": "Insufficient - Moderate risk"
  },
  "normal": {
    "min": 400,
    "severity": "none",
    "description": "Normal range"
  }
}
```

**Supplement Specifications:**
```json
{
  "deficient": {
    "supplement_name": "Vitamin B12 (Methylcobalamin)",
    "dose": "2000 mcg",
    "timing": "with_breakfast",
    "duration": "8_weeks_then_retest",
    "rationale": "Severe B12 deficiency detected - high dose needed for correction"
  },
  "insufficient": {
    "supplement_name": "Vitamin B12 (Methylcobalamin)",
    "dose": "1000 mcg",
    "timing": "with_breakfast",
    "duration": "8_weeks_then_retest",
    "rationale": "Low B12 levels - supplementation recommended"
  }
}
```

**Already Supplementing Check:**
```python
def _already_supplementing(nutrient, existing_supplements):
    """Check if patient already taking this nutrient"""
    search_terms = {
        "b12": ["b12", "b-12", "cobalamin", "methylcobalamin"],
        "vitamin d": ["vitamin d", "d3", "cholecalciferol"],
        "omega": ["omega", "fish oil", "epa", "dha"]
    }

    terms = search_terms.get(nutrient, [])
    for supp in existing_supplements:
        name_lower = supp["name"].lower()
        if any(term in name_lower for term in terms):
            return True
    return False
```

**Related Files:**
- Implementation: `app/engines/supplement_optimizer.py::get_lab_based_supplements()`
- Thresholds: `app/relationships/policies/supplement_thresholds.json` (lines 3-40)

---

### 5.3 Vitamin D Deficiency Detection

**Algorithm:** Four-tier classification with seasonal considerations

**Implementation:** `app/engines/supplement_optimizer.py::get_lab_based_supplements()` (lines 106-137)

**Decision Tree:**
```
IF vitamin_d NOT provided:
    → No Vitamin D supplement (no evidence)

ELSE IF vitamin_d < 20 ng/mL:
    → DEFICIENT (High Severity)
    → Vitamin D3 + K2: 5000 IU D3 + 100 mcg K2 (MK-7)
    → Duration: 12 weeks then retest
    → Rationale: "Vitamin D deficiency - K2 prevents calcium misallocation"

ELSE IF 20 ≤ vitamin_d < 30 ng/mL:
    → INSUFFICIENT (Moderate Severity)
    → Vitamin D3 + K2: 2000 IU D3 + 50 mcg K2 (MK-7)
    → Duration: 12 weeks then retest
    → Rationale: "Suboptimal vitamin D - maintenance dose with K2"

ELSE IF 30 ≤ vitamin_d ≤ 100 ng/mL:
    → OPTIMAL
    → No Vitamin D supplement

ELSE IF vitamin_d > 100 ng/mL:
    → EXCESS (Monitor for toxicity)
    → WARNING: "High vitamin D - monitor calcium levels"
    → No additional supplementation
```

**Reference Ranges:**
```json
{
  "deficient": {
    "max": 20,
    "severity": "high",
    "description": "Deficient - Significant health risk"
  },
  "insufficient": {
    "min": 20,
    "max": 30,
    "severity": "moderate",
    "description": "Insufficient - Suboptimal"
  },
  "normal": {
    "min": 30,
    "max": 100,
    "severity": "none",
    "description": "Optimal range"
  },
  "excess": {
    "min": 100,
    "severity": "monitor",
    "description": "High - Monitor for toxicity"
  }
}
```

**Why Vitamin D3 + K2 Combination:**
- Vitamin D increases calcium absorption
- K2 (MK-7) directs calcium to bones (not arteries)
- Prevents arterial calcification risk
- Synergistic bone health benefits

**Supplement Specifications:**
```json
{
  "deficient": {
    "supplement_name": "Vitamin D3 + K2",
    "dose": "5000 IU D3 + 100 mcg K2 (MK-7)",
    "timing": "with_breakfast",
    "duration": "12_weeks_then_retest",
    "rationale": "Vitamin D deficiency - K2 prevents calcium misallocation"
  },
  "insufficient": {
    "supplement_name": "Vitamin D3 + K2",
    "dose": "2000 IU D3 + 50 mcg K2 (MK-7)",
    "timing": "with_breakfast",
    "duration": "12_weeks_then_retest",
    "rationale": "Suboptimal vitamin D - maintenance dose with K2"
  }
}
```

**Related Files:**
- Implementation: `app/engines/supplement_optimizer.py::get_lab_based_supplements()`
- Thresholds: `app/relationships/policies/supplement_thresholds.json` (lines 41-84)

---

### 5.4 Omega-3 Supplementation (Triglyceride-Based)

**Algorithm:** Metabolic parameter-driven supplementation (NOT lab deficiency)

**Implementation:** `app/engines/supplement_optimizer.py::get_metabolic_based_supplements()` (lines 141-170)

**Decision Tree:**
```
IF triglycerides NOT provided:
    → No Omega-3 supplement

ELSE IF triglycerides ≥ 150 mg/dL:
    → ELEVATED TRIGLYCERIDES
    → Omega-3 (EPA+DHA) 2000 mg combined
    → Duration: 12 weeks then retest
    → Target: Reduce triglycerides to <150 mg/dL
    → Evidence: "Strong - Multiple trials show 20-30% TG reduction"

ELSE IF triglycerides < 150 mg/dL:
    → NORMAL
    → No Omega-3 supplement
```

**Trigger Threshold:**
```json
{
  "metabolic_parameter": "triglycerides",
  "unit": "mg/dL",
  "trigger_threshold": {
    "min": 150,
    "severity": "moderate",
    "description": "Elevated triglycerides - Omega-3 indicated"
  }
}
```

**Supplement Specification:**
```json
{
  "supplement_name": "Omega-3 (EPA+DHA)",
  "dose": "2000 mg EPA+DHA combined",
  "timing": "with_breakfast",
  "duration": "12_weeks_then_retest",
  "rationale": "Elevated triglycerides (>150 mg/dL) - Omega-3 helps reduce TG levels",
  "evidence": "Strong - Multiple trials show 20-30% triglyceride reduction",
  "target": "Reduce triglycerides to <150 mg/dL"
}
```

**Rationale for Triglyceride Threshold:**
- ATP III Guidelines: TG ≥150 mg/dL = borderline high
- Omega-3 has proven efficacy for triglyceride reduction
- EPA+DHA combination shown most effective
- Dose-response: 2-4g/day for significant TG reduction

**NOT Using Omega-3 Index:**
- Omega-3 Index test not commonly available
- Triglycerides are standard lipid panel
- Direct metabolic benefit (TG reduction)
- Cost-effective approach

**Related Files:**
- Implementation: `app/engines/supplement_optimizer.py::get_metabolic_based_supplements()`
- Thresholds: `app/relationships/policies/supplement_thresholds.json` (lines 86-106)

---

### 5.5 Medication-Triggered Supplementation

**Algorithm:** Drug-nutrient interaction prevention

**Implementation:** `app/engines/supplement_optimizer.py::get_medication_triggered_supplements()` (lines 173-210)

**Currently Supported: Metformin → B12**

**Decision Tree:**
```
FOR EACH medication IN current_medications:
    medication_name_lower = medication["name"].lower()

    IF "metformin" IN medication_name_lower:
        IF NOT already_supplementing("b12"):
            → ADD: Vitamin B12 (Methylcobalamin) 1000 mcg
            → Timing: with_breakfast
            → Duration: ongoing_while_on_medication
            → Rationale: "Metformin reduces B12 absorption - preventive supplementation"
            → Evidence: "Strong - Multiple RCTs show B12 depletion with long-term use"
            → Monitoring: "Check B12 levels every 6-12 months"
```

**Metformin-B12 Interaction:**
```json
{
  "metformin": {
    "supplement_name": "Vitamin B12 (Methylcobalamin)",
    "dose": "1000 mcg",
    "timing": "with_breakfast",
    "duration": "ongoing_while_on_medication",
    "rationale": "Metformin reduces B12 absorption - preventive supplementation recommended",
    "evidence": "Strong - Multiple RCTs show B12 depletion with long-term metformin use",
    "monitoring": "Check B12 levels every 6-12 months"
  }
}
```

**Mechanism:**
- Metformin interferes with calcium-dependent B12 absorption
- Effect increases with dose and duration
- 10-30% of long-term users develop B12 deficiency
- Preventive supplementation more effective than treatment

**Why Only Metformin:**
- Most commonly prescribed diabetes medication
- Well-documented B12 depletion mechanism
- Other medication interactions less clinically significant
- Focused, evidence-based approach

**Future Expansion Considerations:**
```python
# Potential additions (NOT currently implemented):
# - Statins → CoQ10 (controversial evidence)
# - PPIs → B12 (similar mechanism to metformin)
# - Thiazides → Magnesium (moderate evidence)
```

**Related Files:**
- Implementation: `app/engines/supplement_optimizer.py::get_medication_triggered_supplements()`
- Thresholds: `app/relationships/policies/supplement_thresholds.json` (lines 107-136)

---

## 6. Medication & Supplement Timing

### 6.1 Daily Schedule Optimization

**Algorithm:** Conflict-free timing with absorption optimization

**Implementation:** `app/engines/medication_timing.py::optimize_daily_schedule()` (lines 8-88)

**Time Slots:**
```python
time_slots = {
    "morning_fasting": "06:00-07:00",      # Before breakfast
    "with_breakfast": "07:00-08:30",
    "mid_morning": "10:00-11:00",
    "with_lunch": "12:00-14:00",
    "afternoon": "15:00-16:00",
    "with_dinner": "18:00-20:00",
    "evening": "20:00-21:00",
    "bedtime": "22:00-23:00"
}
```

**Allocation Rules:**

**1. Medications (User-Specified Times)**
```python
# User provides exact times in medical history
FOR EACH medication:
    time = medication["times"][0]  # e.g., "08:00"
    slot = determine_slot(time)

    schedule[slot].medications.append({
        "name": medication["name"],
        "dose": medication["dose"],
        "timing": "as_prescribed"
    })
```

**2. Supplements (Timing-Based Allocation)**
```python
# Supplements have recommended timing
FOR EACH supplement:
    timing = supplement["timing"]  # e.g., "with_breakfast"

    # Map to time slot
    slot_mapping = {
        "morning_fasting": "morning_fasting",
        "with_breakfast": "with_breakfast",
        "with_lunch": "with_lunch",
        "with_dinner": "with_dinner",
        "evening": "evening",
        "bedtime": "bedtime"
    }

    slot = slot_mapping[timing]
    schedule[slot].supplements.append(supplement)
```

**3. Conflict Resolution**
```python
# Check for interactions
IF slot contains both medications AND supplements:
    FOR EACH supplement IN slot:
        IF has_interaction(medications, supplement):
            # Move supplement to next available slot
            supplement_timing = move_to_next_slot(slot)
            schedule[new_slot].supplements.append(supplement)
```

**Timing Rationale:**

**Fat-Soluble Vitamins (D3, K2):**
- Take with_breakfast (meal contains fat)
- Requires dietary fat for absorption
- Morning timing for consistency

**Water-Soluble Vitamins (B12):**
- Take with_breakfast
- Empty stomach absorption OK, but meal reduces GI upset
- Morning for energy support

**Omega-3:**
- Take with_breakfast
- Requires fat for absorption
- Reduces "fishy burps" if taken with food
- Morning meal typically largest

**Example Schedule:**
```json
{
  "with_breakfast": {
    "timeSlot": "with_breakfast",
    "timeDisplay": "7:00 AM - 8:30 AM",
    "medications": [
      {
        "name": "Metformin",
        "dose": "1000mg",
        "emoji": "💊"
      }
    ],
    "supplements": [
      {
        "name": "Vitamin B12 (Methylcobalamin)",
        "dose": "1000 mcg",
        "rationale": "Metformin interaction - preventive"
      },
      {
        "name": "Vitamin D3 + K2",
        "dose": "2000 IU D3 + 50 mcg K2",
        "rationale": "Suboptimal vitamin D levels"
      },
      {
        "name": "Omega-3 (EPA+DHA)",
        "dose": "2000 mg",
        "rationale": "Elevated triglycerides"
      }
    ]
  }
}
```

**Related Files:**
- Implementation: `app/engines/medication_timing.py`
- Schedule Display: `static/ProtocolGenerator.js::displayMedicationSchedule()`

---

## 7. Macronutrient Distribution

### 7.1 Complete Macro Calculation Algorithm

**Implementation:** `app/engines/macro_calculator.py::calculate_protocol_macros()` (lines 133-230)

**Step-by-Step Process:**

**Step 1: Calculate TDEE**
```python
bmr = calculate_bmr(demographics)
tdee = calculate_tdee(demographics, activity_level, physical_activities)
```

**Step 2: Apply Calorie Deficit**
```python
deficit_kcal = doctor_decisions["calorie_deficit_kcal"]  # e.g., -600

# Validate deficit is within safe range
safe_range = get_safe_deficit_range(demographics, metabolic_baseline)
deficit_kcal = clamp(deficit_kcal, safe_range["max_deficit"], safe_range["min_deficit"])

target_calories = tdee + deficit_kcal  # TDEE is positive, deficit is negative
```

**Step 3: Calculate Protein**
```python
lean_body_mass_kg = weight_kg × (1 - bodyfat_pct/100)
protein_multiplier = get_protein_multiplier(program_intensity)
protein_g = lean_body_mass_kg × protein_multiplier
protein_calories = protein_g × 4
```

**Step 4: Calculate Carbohydrates**
```python
# Carb allocation varies by program intensity
carb_allocation_pct = get_carb_allocation(program_intensity)

# Carb allocation percentages:
# maintenance: 40%
# moderate: 30%
# moderate_improvement: 25%
# intensive_remission: 20%

carb_calories = target_calories × carb_allocation_pct
carb_g = carb_calories / 4
```

**Step 5: Calculate Fat (Fills Remainder)**
```python
fat_calories = target_calories - protein_calories - carb_calories
fat_g = fat_calories / 9

# Validate minimum fat for hormonal health
min_fat_g = weight_kg × 0.5  # Minimum 0.5g/kg
IF fat_g < min_fat_g:
    fat_g = min_fat_g
    # Recalculate carbs
    fat_calories = fat_g × 9
    carb_calories = target_calories - protein_calories - fat_calories
    carb_g = carb_calories / 4
```

**Complete Example:**
```python
# Input Parameters
Patient: Male, 45 years, 175 cm, 92 kg, 34% body fat
Activity Level: Sedentary
Activities: Walking 30 min, 5×/week (115 kcal/day)
Program: Intensive Remission
Deficit: -600 kcal

# Step 1: TDEE
BMR = (10 × 92) + (6.25 × 175) - (5 × 45) + 5 = 1794 kcal
Base TDEE = 1794 × 1.2 = 2153 kcal
Activity TDEE = 2153 + 115 = 2268 kcal

# Step 2: Target Calories
Target = 2268 - 600 = 1668 kcal

# Step 3: Protein
LBM = 92 × (1 - 0.34) = 60.72 kg
Protein = 60.72 × 2.2 = 134 g
Protein Calories = 134 × 4 = 536 kcal

# Step 4: Carbs (20% for intensive)
Carb Calories = 1668 × 0.20 = 334 kcal
Carbs = 334 / 4 = 84 g

# Step 5: Fat
Fat Calories = 1668 - 536 - 334 = 798 kcal
Fat = 798 / 9 = 89 g

# Final Macros
Calories: 1668 kcal
Protein: 134g (32% calories)
Carbs: 84g (20% calories)
Fat: 89g (48% calories)
```

**Macro Distribution by Program:**
```python
program_type_ratios = {
    "maintenance": {
        "protein_pct": 25,  # 25% calories from protein
        "carb_pct": 40,     # 40% calories from carbs
        "fat_pct": 35       # 35% calories from fat
    },
    "moderate": {
        "protein_pct": 30,
        "carb_pct": 30,
        "fat_pct": 40
    },
    "moderate_improvement": {
        "protein_pct": 32,
        "carb_pct": 25,
        "fat_pct": 43
    },
    "intensive_remission": {
        "protein_pct": 32,
        "carb_pct": 20,
        "fat_pct": 48
    }
}
```

**Related Files:**
- Main Logic: `app/engines/macro_calculator.py::calculate_protocol_macros()`
- Policy: `app/relationships/policies/macro_calculation_rules.json`

---

### 7.2 Safe Deficit Range Calculation

**Algorithm:** Patient-specific safe calorie deficit boundaries

**Implementation:** `app/engines/macro_calculator.py::get_safe_deficit_range()` (lines 232-290)

**Base Calculation:**
```python
# Maximum safe deficit (aggressive but safe)
max_deficit_pct = 0.30  # 30% of TDEE

# Minimum deficit (too small to be effective)
min_deficit_pct = 0.10  # 10% of TDEE

max_deficit = -(tdee × max_deficit_pct)
min_deficit = -(tdee × min_deficit_pct)
```

**Adjustments Based on Risk Factors:**

**1. Age Adjustment**
```python
IF age > 60:
    max_deficit = max_deficit × 0.85  # Reduce by 15%
    RATIONALE: "Older adults need more cautious approach"
```

**2. Kidney Function**
```python
IF egfr < 60:
    max_deficit = max_deficit × 0.80  # Reduce by 20%
    RATIONALE: "Impaired kidney function requires slower weight loss"

IF egfr < 45:
    max_deficit = max_deficit × 0.70  # Reduce by 30%
    RATIONALE: "Moderate-severe kidney impairment"
```

**3. BMI Consideration**
```python
bmi = weight_kg / (height_m^2)

IF bmi < 27:
    max_deficit = max_deficit × 0.75  # Reduce by 25%
    RATIONALE: "Lower BMI requires gentler deficit"

IF bmi > 35:
    max_deficit = max_deficit × 1.10  # Increase by 10%
    RATIONALE: "Higher BMI can tolerate larger deficit safely"
```

**4. HbA1c Severity**
```python
IF hba1c_pct > 10:
    # Severe diabetes - prioritize glycemic control
    # Allow slightly larger deficit for rapid improvement
    max_deficit = max_deficit × 1.05  # Increase by 5%
```

**Absolute Safety Bounds:**
```python
# Hard limits regardless of calculations
absolute_max_deficit = -1200 kcal/day
absolute_min_deficit = -200 kcal/day

# Minimum calorie floor (never go below)
min_daily_calories_male = 1200 kcal
min_daily_calories_female = 1000 kcal

# Ensure target_calories stays above minimum
IF (tdee + deficit) < min_daily_calories:
    deficit = min_daily_calories - tdee
```

**Example Calculation:**
```python
# Patient: Male, 45 years, TDEE 2268 kcal, eGFR 82, BMI 30, HbA1c 8.2

# Base range
max_deficit = -(2268 × 0.30) = -680 kcal
min_deficit = -(2268 × 0.10) = -227 kcal

# Age adjustment (45 years - no adjustment)
# Kidney adjustment (eGFR 82 - no adjustment)
# BMI adjustment (30 - no adjustment needed)
# HbA1c adjustment (8.2 - no adjustment)

# Final safe range: -680 to -227 kcal/day
# Recommended: -600 kcal (middle-upper range for good results)
```

**Deficit Recommendations by Goal:**
```python
deficit_recommendations = {
    "conservative": {
        "deficit": min_deficit + (max_deficit - min_deficit) × 0.3,
        "expected_loss": "0.25-0.5 kg/week",
        "suitable_for": "Older adults, kidney concerns"
    },
    "moderate": {
        "deficit": min_deficit + (max_deficit - min_deficit) × 0.6,
        "expected_loss": "0.5-0.75 kg/week",
        "suitable_for": "Most patients, sustainable"
    },
    "aggressive": {
        "deficit": max_deficit,
        "expected_loss": "0.75-1.0 kg/week",
        "suitable_for": "Young, healthy, high BMI, motivated"
    }
}
```

**Related Files:**
- Implementation: `app/engines/macro_calculator.py::get_safe_deficit_range()`
- Endpoint: `app/server.py::/protocol/calculate_deficit_recommendations` (lines 473-536)
- UI: `static/WizardManager.js::updateDeficitSlider()`

---

## 8. Carbohydrate Restriction Rules

### 8.1 Carb Allocation by Program Intensity

**Algorithm:** Graded carbohydrate reduction for glycemic control

**Implementation:** `app/engines/macro_calculator.py::calculate_protocol_macros()` (lines 194-209)

**Carb Allocation Percentages:**
```json
{
  "maintenance": {
    "carb_pct_of_calories": 40,
    "description": "Normal healthy carb intake",
    "target_population": "HbA1c < 5.7, maintenance phase"
  },
  "moderate": {
    "carb_pct_of_calories": 30,
    "description": "Moderate low-carb",
    "target_population": "Prediabetes, HbA1c 5.7-6.4"
  },
  "moderate_improvement": {
    "carb_pct_of_calories": 25,
    "description": "Low-carb approach",
    "target_population": "Type 2 diabetes, HbA1c 6.5-8.0"
  },
  "intensive_remission": {
    "carb_pct_of_calories": 20,
    "description": "Very low-carb / ketogenic threshold",
    "target_population": "Uncontrolled diabetes, HbA1c > 8.0"
  }
}
```

**Example Carb Calculations:**

**Maintenance (40% carbs):**
```python
Target Calories: 1800 kcal
Carb Calories: 1800 × 0.40 = 720 kcal
Carbs: 720 / 4 = 180 g/day

Per Meal (3 meals): 60g carbs/meal
```

**Moderate (30% carbs):**
```python
Target Calories: 1800 kcal
Carb Calories: 1800 × 0.30 = 540 kcal
Carbs: 540 / 4 = 135 g/day

Per Meal (3 meals): 45g carbs/meal
```

**Moderate Improvement (25% carbs):**
```python
Target Calories: 1668 kcal
Carb Calories: 1668 × 0.25 = 417 kcal
Carbs: 417 / 4 = 104 g/day

Per Meal (3 meals): 35g carbs/meal
```

**Intensive Remission (20% carbs):**
```python
Target Calories: 1668 kcal
Carb Calories: 1668 × 0.20 = 334 kcal
Carbs: 334 / 4 = 84 g/day

Per Meal (3 meals): 28g carbs/meal
```

**Rationale for Graduated Approach:**
- Insulin sensitivity improves with carb reduction
- Lower carbs → lower insulin → enhanced fat oxidation
- 20-40% range balances efficacy and sustainability
- Below 20% risks ketosis (not always goal)
- Above 40% may not improve insulin resistance

**Minimum Carb Floor:**
```python
# Prevent excessive carb restriction
min_carbs_daily = 50 g  # Prevent ketoacidosis risk

IF calculated_carbs < min_carbs_daily:
    carbs = min_carbs_daily
    ADJUST: Reduce fat proportionally to maintain calorie target
```

**Related Files:**
- Implementation: `app/engines/macro_calculator.py::calculate_protocol_macros()`
- Policy: `app/relationships/policies/macro_calculation_rules.json` (lines 61-85)

---

### 8.2 Carb Type Recommendations

**Algorithm:** Quality over quantity - complex vs simple carbs

**Implementation:** Policy-based recommendations (not enforced, educational)

**Policy:** `app/relationships/policies/meal_templates.json`

**Carb Source Hierarchy:**

**Tier 1: Preferred (Low Glycemic Index)**
```python
preferred_carbs = {
    "whole_grains": [
        "Brown rice",
        "Quinoa",
        "Oats (steel-cut)",
        "Millets (ragi, jowar, bajra)",
        "Barley"
    ],
    "legumes": [
        "Lentils (all types)",
        "Chickpeas",
        "Black beans",
        "Kidney beans"
    ],
    "vegetables": [
        "Sweet potato",
        "Butternut squash",
        "Green peas"
    ],
    "rationale": "High fiber, low GI, slow glucose release"
}
```

**Tier 2: Moderate (Medium GI, portion controlled)**
```python
moderate_carbs = {
    "grains": [
        "Whole wheat roti",
        "Whole grain bread",
        "Brown rice pasta"
    ],
    "fruits": [
        "Apple",
        "Berries",
        "Orange",
        "Pear"
    ],
    "rationale": "Acceptable with portion control"
}
```

**Tier 3: Minimize (High GI, rapid glucose spike)**
```python
minimize_carbs = {
    "refined_grains": [
        "White rice",
        "White bread",
        "Refined flour products"
    ],
    "sugars": [
        "Table sugar",
        "Honey",
        "Fruit juice",
        "Dried fruits"
    ],
    "processed": [
        "Pastries",
        "Cookies",
        "Sweetened beverages"
    ],
    "rationale": "High GI, rapid insulin spike, avoid for diabetes"
}
```

**Cultural Adaptations:**

**North Indian Non-Vegetarian:**
```json
{
  "carb_sources": ["Brown rice", "Whole wheat roti", "Millets"],
  "protein_sources": ["Chicken", "Fish", "Eggs", "Mutton"],
  "example_meal": "Chicken curry with 1 roti + dal + vegetables"
}
```

**South Indian Vegetarian:**
```json
{
  "carb_sources": ["Brown rice", "Ragi", "Quinoa"],
  "protein_sources": ["Sambar (lentils)", "Chickpea curry", "Paneer", "Curd"],
  "example_meal": "Sambar rice + vegetable curry + curd"
}
```

**Western:**
```json
{
  "carb_sources": ["Quinoa", "Sweet potato", "Oats"],
  "protein_sources": ["Grilled chicken", "Salmon", "Eggs", "Greek yogurt"],
  "example_meal": "Grilled salmon + quinoa + roasted vegetables"
}
```

**Related Files:**
- Meal Templates: `app/relationships/policies/meal_templates.json`
- Cultural Preferences: `app/relationships/policies/meal_planning_rules.json` (lines 217-244)

---

## 9. Meal Planning & Distribution

### 9.1 Meal Count Selection

**Algorithm:** Fasting window optimization with patient preference

**Implementation:** `app/engines/meal_distributor.py::calculate_meal_distribution()` (lines 16-79)

**Meal Options:**
```json
{
  "1": {
    "name": "OMAD (One Meal A Day)",
    "fasting_hours": 23,
    "eating_window_hours": 1,
    "metabolic_benefits": [
      "Extended fasting period",
      "Maximum insulin sensitivity",
      "Enhanced autophagy"
    ],
    "default_timing": "18:00"
  },
  "2": {
    "name": "Two Meals A Day",
    "fasting_hours": 16,
    "eating_window_hours": 8,
    "metabolic_benefits": [
      "Good insulin sensitivity",
      "Manageable fasting",
      "Flexibility in timing"
    ],
    "default_timings": ["12:00", "19:00"]
  },
  "3": {
    "name": "Three Meals A Day",
    "fasting_hours": 12,
    "eating_window_hours": 12,
    "metabolic_benefits": [
      "Traditional pattern",
      "Good nutrient distribution",
      "Easier compliance"
    ],
    "default_timings": ["08:00", "13:00", "19:00"]
  },
  "4": {
    "name": "Four Meals A Day",
    "fasting_hours": 10,
    "eating_window_hours": 14,
    "metabolic_benefits": [
      "Stable energy",
      "Smaller portions",
      "Reduced hunger"
    ],
    "default_timings": ["08:00", "12:00", "16:00", "20:00"]
  }
}
```

**Selection Criteria:**
```python
def recommend_meal_count(patient_profile):
    """Suggest meal count based on patient factors"""

    # Default to 3 meals (most sustainable)
    recommended = 3

    # Factors favoring fewer meals (1-2)
    IF hba1c > 8.0 AND motivated_patient:
        recommended = 2  # Aggressive insulin control

    IF experienced_with_IF:
        recommended = 2  # Already adapted

    # Factors favoring more meals (3-4)
    IF age > 65:
        recommended = 3  # Better nutrient absorption

    IF active_lifestyle OR high_calorie_needs:
        recommended = 4  # Easier to meet calorie goals

    IF prone_to_hypoglycemia:
        recommended = 3  # More stable blood sugar

    return recommended
```

**Related Files:**
- Policy: `app/relationships/policies/meal_planning_rules.json` (lines 2-78)
- Implementation: `app/engines/meal_distributor.py`
- UI: `templates/index.html` (lines 449-488)

---

### 9.2 Carb Distribution Strategies

**Algorithm:** Three strategies for insulin optimization

**Implementation:** `app/engines/meal_distributor.py::distribute_carbs()` (lines 115-141)

**Strategy 1: Distributed (Default)**
```python
# Even distribution across all meals
carbs_per_meal = total_carbs / meal_count

Example (3 meals, 90g total carbs):
  Breakfast: 30g carbs
  Lunch: 30g carbs
  Dinner: 30g carbs

Insulin Profile:
  [Spike] ---- [Spike] ---- [Spike] ----
  Multiple moderate insulin responses

Suitable for:
  - Beginners
  - Good compliance
  - Stable blood sugar management
```

**Strategy 2: Moderate (Skip carbs in ONE meal)**
```python
# Distribute carbs across (meal_count - 1) meals
# One meal is ZERO-CARB

selected_meal_to_skip = user_selection  # e.g., breakfast

carbs_per_other_meal = total_carbs / (meal_count - 1)

Example (3 meals, 90g total, skip breakfast):
  Breakfast: 0g carbs (protein + fat only)
  Lunch: 45g carbs
  Dinner: 45g carbs

Insulin Profile:
  [Fasted] ---- [Spike] ---- [Spike] ----
  Extended morning low-insulin state

Suitable for:
  - Intermediate insulin control
  - Morning fasting preference
  - Balanced approach
```

**Strategy 3: Aggressive (ALL carbs in ONE meal)**
```python
# Concentrate all carbs in single selected meal
# All other meals are ZERO-CARB

selected_meal_for_carbs = user_selection  # e.g., dinner

Example (3 meals, 90g total, all at dinner):
  Breakfast: 0g carbs
  Lunch: 0g carbs
  Dinner: 90g carbs

Insulin Profile:
  [Fasted] ---- [Fasted] ---- [SPIKE] ----
  Maximum low-insulin period (16+ hours)

Suitable for:
  - Maximum insulin optimization
  - Motivated patients
  - HbA1c > 8.0
  - Experienced with low-carb
```

**Implementation:**
```python
def distribute_carbs(total_carbs, meal_count, carb_strategy, selected_meal):
    carb_distribution = [0] * meal_count

    if carb_strategy == "distributed":
        carbs_per_meal = total_carbs / meal_count
        carb_distribution = [carbs_per_meal] * meal_count

    elif carb_strategy == "moderate":
        # Skip carbs in selected meal
        carbs_per_other_meal = total_carbs / (meal_count - 1)
        for i in range(meal_count):
            if (i + 1) != selected_meal:
                carb_distribution[i] = carbs_per_other_meal

    elif carb_strategy == "aggressive":
        # All carbs in selected meal
        carb_distribution[selected_meal - 1] = total_carbs

    return carb_distribution
```

**Strategy Effectiveness:**
```
Insulin Optimization:
  Aggressive > Moderate > Distributed

Sustainability:
  Distributed > Moderate > Aggressive

Recommended by HbA1c:
  < 7.0: Distributed
  7.0-8.5: Moderate or Distributed
  > 8.5: Aggressive or Moderate
```

**Related Files:**
- Implementation: `app/engines/meal_distributor.py::distribute_carbs()`
- Policy: `app/relationships/policies/meal_planning_rules.json` (lines 79-143)
- UI: `templates/index.html` (lines 490-525)

---

### 9.3 Per-Meal Macro Distribution

**Algorithm:** Calorie and macro allocation with strategy-based adjustments

**Implementation:** `app/engines/meal_distributor.py::calculate_meal_distribution()` (lines 16-79)

**Protein Distribution:**
```python
# Always equal protein per meal
protein_per_meal = total_protein_g / meal_count

Rationale:
  - Muscle protein synthesis maximizes at 30-40g/meal
  - Even distribution maintains anabolic state
  - Prevents single-meal protein waste
```

**Carb Distribution:**
```python
# Based on selected strategy (see 9.2)
carb_distribution = distribute_carbs(
    total_carbs,
    meal_count,
    carb_strategy,
    selected_meal
)
```

**Fat Distribution:**
```python
# Fat fills remaining calories to meet target

for i in range(meal_count):
    protein_calories = protein_per_meal × 4
    carb_calories = carb_distribution[i] × 4

    # Calculate meal target calories
    # (proportional to carb allocation or equal if distributed)

    if carb_distribution[i] > 0:
        # Carb-containing meal
        meal_target = target_calories × (carb_calories / total_carb_calories)
    else:
        # Zero-carb meal
        # Share remaining calories equally among zero-carb meals
        zero_carb_count = count_zero_carb_meals()
        meal_target = remaining_calories / zero_carb_count

    # Fat fills the gap
    fat_calories = meal_target - protein_calories - carb_calories
    fat_g = fat_calories / 9
```

**Example: Aggressive Strategy (3 meals, all carbs at dinner)**
```python
Total Daily Macros:
  Calories: 1668 kcal
  Protein: 134g (536 kcal)
  Carbs: 84g (336 kcal)
  Fat: 89g (796 kcal)

Meal Distribution:

BREAKFAST (Zero-Carb):
  Protein: 45g (180 kcal)
  Carbs: 0g (0 kcal)
  Fat: 35g (315 kcal)
  Total: 495 kcal
  Example: Eggs, cheese, spinach, avocado

LUNCH (Zero-Carb):
  Protein: 45g (180 kcal)
  Carbs: 0g (0 kcal)
  Fat: 35g (315 kcal)
  Total: 495 kcal
  Example: Grilled chicken salad with olive oil

DINNER (All Carbs):
  Protein: 44g (176 kcal)
  Carbs: 84g (336 kcal)
  Fat: 19g (166 kcal)
  Total: 678 kcal
  Example: Chicken curry + brown rice + vegetables
```

**Validation:**
```python
# Per-meal validation
min_calories_per_meal = 200
max_calories_per_meal = 1500

min_protein_per_meal = 20g
carb_meal_minimum = 10g
zero_carb_meal_max = 10g
```

**Related Files:**
- Implementation: `app/engines/meal_distributor.py::calculate_meal_distribution()`
- Validation: `app/engines/meal_distributor.py::validate_meal_distribution()`
- Policy: `app/relationships/policies/meal_planning_rules.json` (lines 245-261)

---

## 10. Weekly Progression Predictions

### 10.1 HbA1c Reduction Trajectory

**Algorithm:** Evidence-based weekly HbA1c decline

**Implementation:** `app/engines/weekly_predictor.py::predict_weekly_progression()` (lines 45-78)

**Base Reduction Rates:**
```json
{
  "intensive_remission": {
    "hba1c_reduction_per_week": 0.15,
    "rationale": "Aggressive intervention (VLCD/LCD + medication optimization)"
  },
  "moderate_improvement": {
    "hba1c_reduction_per_week": 0.10,
    "rationale": "Moderate calorie deficit + carb restriction"
  },
  "moderate": {
    "hba1c_reduction_per_week": 0.08,
    "rationale": "Lifestyle modification, prediabetes management"
  },
  "maintenance": {
    "hba1c_reduction_per_week": 0.03,
    "rationale": "Minimal change, maintaining control"
  }
}
```

**Adjustment Factors:**

**1. Baseline HbA1c Severity**
```python
# Higher baseline = faster initial drop
IF baseline_hba1c > 10:
    reduction_rate *= 1.3  # 30% faster
ELIF baseline_hba1c > 8:
    reduction_rate *= 1.15  # 15% faster
ELIF baseline_hba1c < 6.5:
    reduction_rate *= 0.8  # 20% slower (less room for improvement)
```

**2. Weight Loss Effect**
```python
# Weight loss enhances HbA1c reduction
# ~1% HbA1c reduction per 10kg weight loss (evidence-based)

weight_loss_kg = calculate_weekly_weight_loss()
hba1c_from_weight_loss = (weight_loss_kg / 10) × 1.0

total_hba1c_reduction = base_reduction + hba1c_from_weight_loss
```

**3. Medication Changes**
```python
# If medications reduced during protocol
IF medication_reduction_occurred:
    # Slower HbA1c drop (less pharmacological support)
    reduction_rate *= 0.9  # 10% slower

# If medications added/intensified
IF medication_intensified:
    reduction_rate *= 1.1  # 10% faster
```

**4. Diminishing Returns (Week-by-Week)**
```python
# As HbA1c approaches normal, reduction slows

for week in range(1, total_weeks + 1):
    current_hba1c = baseline_hba1c - cumulative_reduction

    # Diminishing factor
    if current_hba1c < 7.0:
        weekly_reduction *= 0.95  # 5% slower each week under 7.0

    if current_hba1c < 6.0:
        weekly_reduction *= 0.90  # Additional 10% slower under 6.0

    # Floor: never drop below 4.5% (physiological limit)
    predicted_hba1c = max(4.5, current_hba1c - weekly_reduction)
```

**Example Progression:**
```python
Baseline: HbA1c 8.2%
Program: Intensive Remission
Duration: 12 weeks
Base Reduction: 0.15% per week

Week  | Predicted HbA1c | Reduction | Notes
------|-----------------|-----------|------------------
0     | 8.2%           | -         | Baseline
1     | 8.05%          | -0.15%    | Initial drop
2     | 7.90%          | -0.15%    | Steady
3     | 7.75%          | -0.15%    | Steady
4     | 7.60%          | -0.15%    | Steady
5     | 7.45%          | -0.15%    | Steady
6     | 7.31%          | -0.14%    | Slight slowing
7     | 7.18%          | -0.13%    | Below 7.5%
8     | 7.06%          | -0.12%    | Approaching normal
9     | 6.95%          | -0.11%    | Below 7.0%
10    | 6.85%          | -0.10%    | Diminishing returns
11    | 6.76%          | -0.09%    | Slowing further
12    | 6.68%          | -0.08%    | Near target

Final: 6.68% (1.52% total reduction)
```

**Validation:**
```python
# Minimum HbA1c (physiological floor)
min_hba1c = 4.5

# Maximum reduction per week
max_reduction_per_week = 0.25  # Safety limit

# Total reduction cap (12 weeks)
max_total_reduction = 3.0  # Unlikely to exceed in 12 weeks
```

**Related Files:**
- Implementation: `app/engines/weekly_predictor.py::predict_hba1c_trajectory()`
- Policy: `app/relationships/policies/program_types.json`
- Display: `static/ProtocolGenerator.js::displayWeeklyProgression()`

---

### 10.2 Weight Loss Trajectory

**Algorithm:** Calorie deficit-based prediction with metabolic adaptation

**Implementation:** `app/engines/weekly_predictor.py::predict_weekly_progression()` (lines 80-135)

**Base Formula:**
```python
# 1 kg fat = 7700 kcal (thermodynamic principle)

weekly_calorie_deficit = daily_deficit × 7
predicted_fat_loss_kg = weekly_calorie_deficit / 7700

# Adjust for water weight and lean mass loss
total_weight_loss_kg = fat_loss_kg × 1.15  # ~15% water/lean mass
```

**Example:**
```python
Daily Deficit: -600 kcal
Weekly Deficit: -600 × 7 = -4200 kcal

Fat Loss: 4200 / 7700 = 0.545 kg
Total Weight Loss: 0.545 × 1.15 = 0.627 kg/week
```

**Metabolic Adaptation (Week-by-Week):**
```python
# TDEE decreases as weight decreases
# ~20-30 kcal reduction per kg lost

adaptation_factor = 1.0

for week in range(1, total_weeks + 1):
    # Recalculate TDEE based on new weight
    new_weight = baseline_weight - cumulative_weight_loss
    new_tdee = recalculate_tdee(new_weight, ...)

    # Effective deficit decreases
    effective_deficit = target_calories - new_tdee

    # Metabolic adaptation (5-10% reduction in metabolic rate)
    if week > 4:
        adaptation_factor *= 0.98  # 2% slower per week after week 4

    weekly_loss = (effective_deficit × 7 / 7700) × adaptation_factor
```

**Projection Stages:**

**Stage 1: Initial Water Loss (Weeks 1-2)**
```python
# Glycogen depletion + water loss
week_1_loss = predicted_fat_loss × 1.5  # 50% more (water)
week_2_loss = predicted_fat_loss × 1.2  # 20% more (water)
```

**Stage 2: Steady Fat Loss (Weeks 3-8)**
```python
# Consistent fat mobilization
weekly_loss = predicted_fat_loss × adaptation_factor
```

**Stage 3: Plateau Risk (Weeks 9-12)**
```python
# Metabolic adaptation kicks in
weekly_loss = predicted_fat_loss × adaptation_factor × 0.85
```

**Example 12-Week Trajectory:**
```python
Baseline Weight: 92 kg
Daily Deficit: -600 kcal
Program: Intensive Remission

Week | Weight (kg) | Loss (kg) | Cumulative | Notes
-----|-------------|-----------|------------|------------------
0    | 92.0       | -         | -          | Baseline
1    | 91.1       | -0.9      | -0.9       | Water loss
2    | 90.4       | -0.7      | -1.6       | Water + fat
3    | 89.8       | -0.6      | -2.2       | Steady fat loss
4    | 89.2       | -0.6      | -2.8       | Steady
5    | 88.6       | -0.6      | -3.4       | Steady
6    | 88.1       | -0.5      | -3.9       | Slight slowing
7    | 87.6       | -0.5      | -4.4       | Adaptation
8    | 87.1       | -0.5      | -4.9       | Adaptation
9    | 86.7       | -0.4      | -5.3       | Plateau risk
10   | 86.3       | -0.4      | -5.7       | Plateau risk
11   | 86.0       | -0.3      | -6.0       | Slowing
12   | 85.7       | -0.3      | -6.3       | Final

Total Loss: 6.3 kg (6.8% body weight)
Average: 0.525 kg/week
```

**Validation:**
```python
# Safe weight loss limits
max_weekly_loss = 1.0 kg  # 1% body weight
min_weekly_loss = 0.2 kg  # Below this, ineffective

# Alert thresholds
IF weekly_loss > 1.0:
    WARNING: "Excessive weight loss - increase calories"

IF weekly_loss < 0.2:
    WARNING: "Insufficient weight loss - reduce calories or increase activity"

# Total weight loss cap
max_total_loss_pct = 15  # % of baseline weight in 12 weeks
```

**Related Files:**
- Implementation: `app/engines/weekly_predictor.py::predict_weight_trajectory()`
- Policy: `app/relationships/policies/program_types.json`

---

### 10.3 Fasting Blood Glucose Prediction

**Algorithm:** Parallel trajectory with HbA1c reduction

**Implementation:** `app/engines/weekly_predictor.py::predict_fbg_trajectory()` (lines 137-168)

**Correlation Formula:**
```python
# Approximate relationship: HbA1c and average glucose
# Average Glucose (mg/dL) = (HbA1c% × 28.7) - 46.7

# FBG typically ~70-80% of average glucose
estimated_avg_glucose = (hba1c_pct × 28.7) - 46.7
estimated_fbg = estimated_avg_glucose × 0.75
```

**Weekly Reduction:**
```python
# FBG drops proportionally to HbA1c
hba1c_reduction_pct = weekly_hba1c_reduction / baseline_hba1c

fbg_reduction = baseline_fbg × hba1c_reduction_pct
```

**Example:**
```python
Baseline: HbA1c 8.2%, FBG 152 mg/dL
Week 1 HbA1c Reduction: 0.15%
Reduction %: 0.15 / 8.2 = 1.83%

FBG Reduction: 152 × 0.0183 = 2.78 mg/dL
Week 1 FBG: 152 - 2.78 = 149.2 mg/dL
```

**Target Validation:**
```python
# Target ranges
normal_fbg = "<100 mg/dL"
prediabetes_fbg = "100-125 mg/dL"
diabetes_fbg = ">125 mg/dL"

# Weekly targets
IF current_fbg > 125:
    target_reduction = 5-8 mg/dL per week
ELIF current_fbg > 100:
    target_reduction = 3-5 mg/dL per week
ELSE:
    target_reduction = 1-2 mg/dL per week (maintenance)
```

**12-Week Example:**
```python
Week | HbA1c | FBG (mg/dL) | Reduction | Status
-----|-------|-------------|-----------|------------------
0    | 8.2%  | 152        | -         | Baseline (High)
1    | 8.05% | 149        | -3        | High
2    | 7.90% | 146        | -3        | High
3    | 7.75% | 143        | -3        | High
4    | 7.60% | 140        | -3        | High
5    | 7.45% | 137        | -3        | High
6    | 7.31% | 134        | -3        | High
7    | 7.18% | 131        | -3        | High
8    | 7.06% | 128        | -3        | Diabetes (>125)
9    | 6.95% | 126        | -2        | Borderline
10   | 6.85% | 124        | -2        | Prediabetes
11   | 6.76% | 122        | -2        | Prediabetes
12   | 6.68% | 120        | -2        | Prediabetes

Total Reduction: 32 mg/dL (21% improvement)
```

**Related Files:**
- Implementation: `app/engines/weekly_predictor.py::predict_fbg_trajectory()`
- Display: `static/ProtocolGenerator.js::displayWeeklyProgression()`

---

### 10.4 Body Fat Percentage Trajectory

**Algorithm:** Fat loss with lean mass preservation

**Implementation:** `app/engines/weekly_predictor.py::predict_bodyfat_trajectory()` (lines 170-205)

**Calculation:**
```python
# Track fat mass and lean mass separately

fat_mass_kg = weight_kg × (bodyfat_pct / 100)
lean_mass_kg = weight_kg - fat_mass_kg

# Weekly fat loss (from calorie deficit)
weekly_fat_loss = weekly_calorie_deficit / 7700

# Lean mass preservation (high protein helps)
lean_mass_retention = 0.90  # 90% retention with adequate protein

# New composition
new_fat_mass = fat_mass_kg - weekly_fat_loss
new_lean_mass = lean_mass_kg - (weekly_weight_loss - weekly_fat_loss) × lean_mass_retention
new_weight = new_fat_mass + new_lean_mass

new_bodyfat_pct = (new_fat_mass / new_weight) × 100
```

**Example Progression:**
```python
Baseline:
  Weight: 92 kg
  Body Fat: 34%
  Fat Mass: 31.28 kg
  Lean Mass: 60.72 kg

Weekly Deficit: -4200 kcal
Fat Loss: 0.545 kg/week
Total Loss: 0.627 kg/week
Lean Loss: 0.082 kg/week (13% of loss)

Week 6:
  Weight: 88.2 kg (-3.8 kg)
  Fat Mass: 27.97 kg (-3.31 kg fat)
  Lean Mass: 60.23 kg (-0.49 kg lean)
  Body Fat: 31.7% (-2.3%)

Week 12:
  Weight: 85.4 kg (-6.6 kg)
  Fat Mass: 25.56 kg (-5.72 kg fat)
  Lean Mass: 59.84 kg (-0.88 kg lean)
  Body Fat: 29.9% (-4.1%)

Fat Loss Composition:
  87% fat, 13% lean mass (excellent preservation)
```

**Lean Mass Preservation Factors:**
```python
lean_retention_rate = 0.85  # Base rate

# Adjustments
IF protein_g_per_kg_lbm >= 2.0:
    lean_retention_rate += 0.05  # +5% with high protein

IF resistance_training_included:
    lean_retention_rate += 0.05  # +5% with strength training

IF calorie_deficit > 1000:
    lean_retention_rate -= 0.10  # -10% with extreme deficit

# Final retention
lean_retention_rate = min(0.95, max(0.75, lean_retention_rate))
```

**Related Files:**
- Implementation: `app/engines/weekly_predictor.py::predict_bodyfat_trajectory()`
- Policy: `app/relationships/policies/macro_calculation_rules.json`

---

## 11. Safety Constraints & Contraindications

### 11.1 Kidney Function Constraints

**Algorithm:** eGFR-based protocol modifications

**Implementation:** `app/engines/protocol_generator.py::assess_safety_requirements()` (lines 237-298)

**eGFR Stages & Actions:**
```python
egfr_stages = {
    "stage_1": {
        "egfr_range": "≥90 mL/min/1.73m²",
        "classification": "Normal kidney function",
        "protocol_modifications": None,
        "monitoring": "Annual check"
    },
    "stage_2": {
        "egfr_range": "60-89 mL/min/1.73m²",
        "classification": "Mildly reduced kidney function",
        "protocol_modifications": {
            "protein_max": "1.8 g/kg LBM",
            "monitoring": "Every 6 months"
        },
        "precautions": ["Monitor creatinine trends"]
    },
    "stage_3a": {
        "egfr_range": "45-59 mL/min/1.73m²",
        "classification": "Mild-moderate CKD",
        "protocol_modifications": {
            "protein_max": "1.5 g/kg LBM",
            "sodium_restriction": "2300 mg/day",
            "potassium_monitoring": True,
            "deficit_reduction": 0.85  # 15% smaller deficit
        },
        "precautions": [
            "Medical supervision required",
            "Monitor electrolytes",
            "Reduce protein if progression"
        ]
    },
    "stage_3b": {
        "egfr_range": "30-44 mL/min/1.73m²",
        "classification": "Moderate-severe CKD",
        "protocol_modifications": {
            "protein_max": "1.2 g/kg LBM",
            "phosphorus_restriction": True,
            "deficit_reduction": 0.75,  # 25% smaller deficit
            "requires_nephrologist": True
        },
        "contraindications": [
            "Intensive fasting protocols",
            "Very low carb (<50g/day)"
        ]
    },
    "stage_4": {
        "egfr_range": "15-29 mL/min/1.73m²",
        "classification": "Severe CKD",
        "protocol_modifications": {
            "protein_max": "0.8 g/kg body weight",
            "specialist_management": "Required",
            "deficit_reduction": 0.60  # 40% smaller deficit
        },
        "contraindications": [
            "Self-directed protocols",
            "Aggressive weight loss"
        ],
        "action": "REFER TO NEPHROLOGIST"
    },
    "stage_5": {
        "egfr_range": "<15 mL/min/1.73m²",
        "classification": "Kidney failure",
        "action": "NOT SUITABLE FOR PROTOCOL - REFER TO SPECIALIST"
    }
}
```

**eGFR Calculation (CKD-EPI Equation):**
```python
# If not provided, can estimate from creatinine
# CKD-EPI equation (most accurate for diabetes)

def calculate_egfr(creatinine_mg_dl, age, gender):
    if gender == "female":
        if creatinine_mg_dl <= 0.7:
            egfr = 144 × (creatinine_mg_dl / 0.7)^(-0.329) × 0.993^age
        else:
            egfr = 144 × (creatinine_mg_dl / 0.7)^(-1.209) × 0.993^age
    else:  # male
        if creatinine_mg_dl <= 0.9:
            egfr = 141 × (creatinine_mg_dl / 0.9)^(-0.411) × 0.993^age
        else:
            egfr = 141 × (creatinine_mg_dl / 0.9)^(-1.209) × 0.993^age

    return egfr
```

**Protocol Adjustments:**
```python
def apply_kidney_constraints(protocol, egfr):
    if egfr >= 90:
        return protocol  # No modifications

    elif egfr >= 60:
        # Stage 2: Mild caution
        protocol["protein_g"] = min(protocol["protein_g"], lbm × 1.8)
        protocol["monitoring_frequency"] = "biweekly"

    elif egfr >= 45:
        # Stage 3a: Moderate restriction
        protocol["protein_g"] = min(protocol["protein_g"], lbm × 1.5)
        protocol["deficit_kcal"] = protocol["deficit_kcal"] × 0.85
        protocol["sodium_max"] = 2300  # mg/day
        protocol["requires_medical_supervision"] = True

    elif egfr >= 30:
        # Stage 3b: Significant restriction
        protocol["protein_g"] = min(protocol["protein_g"], lbm × 1.2)
        protocol["deficit_kcal"] = protocol["deficit_kcal"] × 0.75
        protocol["requires_nephrologist"] = True

        # Add contraindications
        if protocol["carbs_g"] < 50:
            WARNING: "Very low carb contraindicated with eGFR < 45"

    elif egfr < 30:
        # Stage 4+: Specialist required
        return {
            "error": "eGFR < 30 requires specialist management",
            "action": "REFER TO NEPHROLOGIST",
            "contraindicated": True
        }

    return protocol
```

**Related Files:**
- Implementation: `app/engines/protocol_generator.py::assess_safety_requirements()`
- Policy: `app/relationships/policies/safety_thresholds.json`

---

### 11.2 Hypoglycemia Risk Management

**Algorithm:** Medication-based risk assessment

**Implementation:** `app/engines/protocol_generator.py::assess_safety_requirements()` (lines 280-298)

**Risk Stratification:**
```python
def assess_hypoglycemia_risk(medications, hba1c, protocol_type):
    risk_level = "low"
    precautions = []

    # High-risk medications
    high_risk_meds = {
        "sulfonylureas": ["glimepiride", "gliclazide", "glibenclamide"],
        "insulin": ["insulin", "lantus", "humalog", "novolog"]
    }

    # Check medications
    for med in medications:
        med_name_lower = med["name"].lower()

        # Sulfonylureas
        if any(drug in med_name_lower for drug in high_risk_meds["sulfonylureas"]):
            risk_level = "high"
            precautions.append({
                "medication": med["name"],
                "risk": "Sulfonylurea can cause hypoglycemia",
                "action": "Monitor blood glucose 4× daily",
                "reduction_needed": "Consider dose reduction with doctor"
            })

        # Insulin
        if any(insulin in med_name_lower for insulin in high_risk_meds["insulin"]):
            risk_level = "very_high"
            precautions.append({
                "medication": med["name"],
                "risk": "Insulin requires careful adjustment",
                "action": "Monitor BG before/after meals",
                "reduction_needed": "MUST adjust insulin doses - consult endocrinologist"
            })

    # Moderate risk: Low HbA1c + aggressive deficit
    if hba1c < 7.0 and protocol_type == "intensive_remission":
        risk_level = max(risk_level, "moderate")
        precautions.append({
            "risk": "Low baseline HbA1c + aggressive protocol",
            "action": "Monitor for symptoms: shakiness, sweating, confusion"
        })

    return {
        "risk_level": risk_level,
        "precautions": precautions,
        "monitoring_frequency": get_monitoring_frequency(risk_level)
    }

def get_monitoring_frequency(risk_level):
    frequencies = {
        "low": "Weekly fasting glucose",
        "moderate": "Daily fasting glucose",
        "high": "2× daily (fasting + post-meal)",
        "very_high": "4× daily (before meals + bedtime)"
    }
    return frequencies[risk_level]
```

**Symptom Education:**
```python
hypoglycemia_symptoms = {
    "early_warning": [
        "Shakiness or trembling",
        "Sweating",
        "Hunger",
        "Rapid heartbeat",
        "Dizziness"
    ],
    "severe": [
        "Confusion",
        "Difficulty speaking",
        "Blurred vision",
        "Loss of consciousness",
        "Seizures (emergency)"
    ],
    "action_plan": {
        "mild_symptoms": "Consume 15g fast-acting carbs (glucose tablets, juice)",
        "recheck_15min": "If still low, repeat 15g carbs",
        "severe": "Call emergency services immediately"
    }
}
```

**Medication Reduction Guidance:**
```python
reduction_guidelines = {
    "sulfonylureas": {
        "timing": "Before starting protocol",
        "reduction": "50% dose reduction recommended",
        "monitor": "Adjust based on fasting glucose"
    },
    "insulin": {
        "basal_insulin": "Reduce by 20-30% on day 1",
        "mealtime_insulin": "Reduce based on carb reduction (50% if carbs halved)",
        "critical": "REQUIRES ENDOCRINOLOGIST SUPERVISION"
    },
    "metformin": {
        "reduction": "Usually no reduction needed",
        "note": "Does not cause hypoglycemia alone"
    },
    "dpp4_inhibitors": {
        "reduction": "Usually no reduction needed",
        "note": "Low hypoglycemia risk"
    }
}
```

**Related Files:**
- Implementation: `app/engines/protocol_generator.py::assess_safety_requirements()`
- Policy: `app/relationships/policies/safety_thresholds.json`

---

### 11.3 Supplement Contraindications

**Algorithm:** Medication-supplement and condition-supplement interactions

**Implementation:** `app/engines/supplement_optimizer.py::apply_safety_checks()` (lines 213-260)

**Omega-3 Contraindications:**
```python
omega3_contraindications = {
    "bleeding_disorders": {
        "severity": "contraindicated",
        "reason": "Omega-3 has anticoagulant effects",
        "action": "DO NOT RECOMMEND"
    },
    "warfarin": {
        "severity": "caution",
        "reason": "May increase bleeding risk",
        "action": "Reduce dose to 1000mg or avoid if INR unstable",
        "monitoring": "Check INR weekly for 4 weeks"
    },
    "aspirin_high_dose": {
        "severity": "caution",
        "reason": "Combined antiplatelet effect",
        "action": "Limit to 1000mg Omega-3"
    },
    "upcoming_surgery": {
        "severity": "warning",
        "reason": "Increased bleeding risk",
        "action": "Discontinue 2 weeks before surgery"
    }
}
```

**Vitamin D3 + K2 Contraindications:**
```python
vitamin_d_contraindications = {
    "hypercalcemia": {
        "severity": "contraindicated",
        "reason": "Vitamin D increases calcium absorption",
        "action": "DO NOT RECOMMEND - Check calcium levels"
    },
    "kidney_stones_calcium": {
        "severity": "caution",
        "reason": "May increase calcium excretion",
        "action": "Limit to 2000 IU, ensure hydration (2-3L water/day)",
        "monitoring": "Check urine calcium"
    },
    "sarcoidosis": {
        "severity": "contraindicated",
        "reason": "Increased vitamin D sensitivity",
        "action": "AVOID supplementation"
    }
}
```

**B12 Contraindications:**
```python
b12_contraindications = {
    # Very few contraindications
    "cobalt_allergy": {
        "severity": "contraindicated",
        "reason": "B12 contains cobalt",
        "action": "AVOID"
    },
    "leber_disease": {
        "severity": "warning",
        "reason": "Cyanocobalamin contraindicated",
        "action": "Use Methylcobalamin or Hydroxocobalamin only"
    }
}
```

**Safety Check Implementation:**
```python
def apply_safety_checks(supplement_recommendations, patient_profile, medications):
    """Apply contraindication checks"""

    safe_supplements = {}
    warnings = []

    contraindications = patient_profile.get("medical_history", {}).get("contraindications", [])

    for key, supplement in supplement_recommendations.items():
        supp_name = supplement["name"].lower()

        # Check Omega-3
        if "omega" in supp_name:
            # Check for bleeding disorders
            if any("bleeding" in c.lower() for c in contraindications):
                warnings.append(f"CONTRAINDICATED: Omega-3 - {supplement['name']} (bleeding disorder)")
                continue  # Skip this supplement

            # Check for warfarin
            if any("warfarin" in med["name"].lower() for med in medications):
                warnings.append(f"CAUTION: Omega-3 with Warfarin - reduce dose, monitor INR")
                supplement["dose"] = "1000 mg EPA+DHA"  # Reduce dose
                supplement["monitoring"] = "Check INR weekly"

        # Check Vitamin D
        if "vitamin d" in supp_name:
            # Check for hypercalcemia
            if any("hypercalcemia" in c.lower() for c in contraindications):
                warnings.append(f"CONTRAINDICATED: Vitamin D - {supplement['name']} (hypercalcemia)")
                continue

            # Check for kidney stones
            if any("kidney stone" in c.lower() for c in contraindications):
                warnings.append(f"CAUTION: Vitamin D with kidney stones - ensure hydration")
                supplement["precautions"] = "Drink 2-3L water daily, monitor urine calcium"

        # Supplement passed safety checks
        safe_supplements[key] = supplement

    return {
        "supplements": safe_supplements,
        "warnings": warnings
    }
```

**Related Files:**
- Implementation: `app/engines/supplement_optimizer.py::apply_safety_checks()`
- Contraindications: `app/relationships/policies/supplement_thresholds.json` (lines 137-164)

---

## File Reference Index

### Policy Files (JSON)
```
app/relationships/policies/
├── macro_calculation_rules.json        # Protein, carb, fat rules
├── activity_library.json               # MET values for activities
├── meal_planning_rules.json            # Meal count, carb strategies
├── supplement_thresholds.json          # Lab ranges, deficiency triggers
├── program_types.json                  # Weekly targets by program
├── safety_thresholds.json              # eGFR, HbA1c safety limits
└── meal_templates.json                 # Cultural food preferences
```

### Python Implementation Files
```
app/engines/
├── macro_calculator.py                 # BMR, TDEE, macros
├── supplement_optimizer.py             # Deficiency detection
├── medication_timing.py                # Daily schedule
├── meal_distributor.py                 # Per-meal distribution
├── weekly_predictor.py                 # Progression predictions
├── protocol_generator.py               # Main orchestrator
└── delegate.py                         # Policy loader
```

### JavaScript Frontend Files
```
static/
├── activity_manager.js                 # Activity calorie calc
├── meal_planning_manager.js            # Meal UI logic
├── body_fat_calculator.js              # Navy method
├── BaselineProcessor.js                # Form data collection
├── ProtocolGenerator.js                # Display protocol
├── WizardManager.js                    # Navigation flow
└── PatientManager.js                   # Data population
```

### External Data Files
```
external_api_server/
└── api_server.py                       # Mock patient data (B12, Vitamin D values)
```

---

## Modification Guide

### To Change Protein Requirements:
**File:** `app/relationships/policies/macro_calculation_rules.json` (lines 45-60)
```json
{
  "protein_multipliers": {
    "intensive_remission": 2.2  // Change this value
  }
}
```

### To Change HbA1c Reduction Rates:
**File:** `app/relationships/policies/program_types.json`
```json
{
  "intensive_remission": {
    "hba1c_reduction": 0.15  // Change weekly reduction
  }
}
```

### To Add New Activity:
**File:** `app/relationships/policies/activity_library.json`
```json
{
  "activities": {
    "new_activity_name": {
      "name": "Display Name",
      "met_value": 6.5,
      "category": "cardio",
      "intensity": "moderate"
    }
  }
}
```

### To Modify Supplement Thresholds:
**File:** `app/relationships/policies/supplement_thresholds.json`
```json
{
  "vitamin_b12": {
    "ranges": {
      "deficient": {"max": 200}  // Change threshold
    }
  }
}
```

### To Adjust Safe Deficit Range:
**File:** `app/engines/macro_calculator.py::get_safe_deficit_range()`
```python
max_deficit_pct = 0.30  # Change from 30% to desired %
```

---

**END OF CLINICAL ALGORITHMS REFERENCE**

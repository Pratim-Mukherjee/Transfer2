# R365 Protocol Engine - Quick Start Guide

## Running the Application

### Step 1: Start External API Server (Terminal 1)
```bash
cd external_api_server
python api_server.py
```

Expected output:
```
============================================================
External Patient API Server
============================================================
Running on: http://localhost:9000
```

### Step 2: Start Main Application (Terminal 2)
```bash
python app/server.py
```

Expected output:
```
Running on http://localhost:5000
```

### Step 3: Open Browser
Navigate to: `http://localhost:5000`

---

## Testing the New Features

### 1. Test Body Fat Calculation (Patient P002 - Priya Sharma)

This patient has no body fat value, so it will be calculated.

1. Select "Priya Sharma" from dropdown
2. Click "Load Patient"
3. Observe:
   - Body fat field is **empty**
   - Waist: 88 cm
   - Neck: 34 cm
   - Hip: 105 cm (visible because female)
4. Click **"Calculate Body Fat"**
5. Result: ~37.8% appears in body fat field
6. Green **"Calculated"** badge appears
7. Info text: "Estimated using US Navy body fat formula"
8. Medication shows: Metformin with times **09:00, 21:00**

### 2. Test Medication with Times (Patient P001 - Rajesh Kumar)

This patient has medications with specific times.

1. Select "Rajesh Kumar" from dropdown
2. Click "Load Patient"
3. Scroll to **Current Medications** section
4. Observe:
   - **Metformin 1000mg** - Twice daily
     - Blue badges: **08:00 AM, 08:00 PM**
   - **Glimepiride 2mg** - Once daily
     - Blue badge: **08:00 AM**
5. Body fat shows: 34% with "Measured by dexa_scan"

### 3. Test Adding New Medication

1. Scroll to **Current Medications** section
2. Enter name: **Glipizide**
3. Enter dose: **5mg**
4. Select frequency: **Twice daily**
5. Two time inputs appear automatically
6. Adjust times (default: 08:00 and 20:00)
7. Click **"Add Medication"**
8. New medication appears in list with time badges

### 4. Test Manual Body Fat Calculation

1. Click **"Refresh List"** to clear form
2. Scroll to demographics
3. Select gender: **Male**
4. Enter height: **180** cm
5. Scroll to Body Measurements
6. Enter waist: **95** cm
7. Enter neck: **38** cm
8. Hip field is **hidden** (male)
9. Click **"Calculate Body Fat"**
10. Result appears: ~30.2%
11. Green "Calculated" badge shows

---

## New UI Elements

### Body Measurements Section

Located after metabolic parameters:

```
Body Measurements
(Optional - used to calculate body fat if not available)

┌─────────────────────────────────────────┐
│ Waist Circumference (cm)               │
│ *At navel for men, narrowest for women │
│ [        ]                              │
└─────────────────────────────────────────┘

┌─────────────────────────────────────────┐
│ Neck Circumference (cm)                 │
│ *Below larynx                           │
│ [        ]                              │
└─────────────────────────────────────────┘

┌─────────────────────────────────────────┐
│ Hip Circumference (cm)  [FEMALE ONLY]   │
│ *At widest point                        │
│ [        ]                              │
└─────────────────────────────────────────┘

[Calculate Body Fat]
```

### Medication Entry Enhanced

```
Current Medications

┌──────────────────────────────────────────────────┐
│ Metformin                              [Remove]  │
│ 1000mg • Twice Daily                            │
│ ⏰ 08:00 AM  ⏰ 08:00 PM                        │
└──────────────────────────────────────────────────┘

[Medication name]  [Dose]  [Frequency ▼]
⏰ [08:00]  ⏰ [20:00]  [Add Medication]
```

When you select frequency:
- **Once daily** → 1 time input appears
- **Twice daily** → 2 time inputs appear
- **Three times daily** → 3 time inputs appear
- **As needed** → No time inputs

---

## Validation Indicators

### Required Fields
- **Red left border** = Invalid/empty
- **Green left border** = Valid

### Body Fat Field
- **Green "Calculated" badge** = Calculated using Navy method
- **Info text below** = Shows calculation method

### Medication Times
- Times are **required** except for "as needed"
- Must match frequency count:
  - Once daily = 1 time
  - Twice daily = 2 times
  - Three times daily = 3 times

---

## Common Issues

### Issue: "Cannot connect to external API server"
**Solution:** Make sure terminal 1 is running the external API server on port 9000

### Issue: Body fat calculation says "Invalid measurements"
**Solution:**
- Waist must be greater than neck
- For females: waist + hip must be greater than neck
- All measurements must be positive numbers

### Issue: Can't add medication
**Solution:**
- Fill in all fields (name, dose, frequency)
- Enter the required number of times based on frequency
- Times must be in HH:MM format

### Issue: Hip field not showing for female patient
**Solution:**
- Change gender to "Female" first
- Hip field appears automatically
- If already set, try changing to Male then back to Female

---

## Mock Patient Data Summary

| Patient | Age | Gender | Body Fat | Measurements | Medications |
|---------|-----|--------|----------|--------------|-------------|
| **P001 - Rajesh Kumar** | 45 | Male | 34% (DEXA) | ✓ All | Metformin (08:00, 20:00)<br>Glimepiride (08:00) |
| **P002 - Priya Sharma** | 52 | Female | Calculate | ✓ All (incl. hip) | Metformin (09:00, 21:00) |
| **P003 - Amit Patel** | 58 | Male | Calculate | ✓ Waist, Neck | Metformin (07:30, 19:30)<br>Sitagliptin (07:30) |

---

## Next Steps After Testing

1. **Generate Protocol:**
   - After loading patient and reviewing baseline
   - Click "Generate Enhanced Baseline Profile"
   - Move to "Protocol Generation" tab
   - Click "Generate Complete Protocol"

2. **Review Generated Data:**
   - Protocol saved to: `protocols/{patient_id}_protocol_{timestamp}.json`
   - Weekly targets saved to: `weekly_targets/{patient_id}_weekly_targets_{timestamp}.json`
   - External API server also saves to `stored_protocols/` and `stored_weekly_targets/`

3. **Modify and Regenerate:**
   - Load existing patient with protocol
   - Make changes to baseline or protocol parameters
   - Regenerate protocol
   - New versions saved with new timestamps

---

## Keyboard Shortcuts

- **Tab** - Navigate between fields
- **Enter** (in time input) - Move to next time input
- **Enter** (on Add Medication button) - Add medication

---

## Tips

1. **Body Fat Priority:**
   - If API provides body fat value → uses it
   - If only measurements provided → calculates automatically
   - Can always recalculate by clicking "Calculate Body Fat"

2. **Medication Times:**
   - Default times are suggested (08:00, 20:00, 14:00)
   - Adjust to patient's actual schedule
   - Consider wake time and meal times

3. **Gender Selection:**
   - Must select gender before calculating body fat
   - Females require hip measurement
   - Gender affects which measurements are shown

---

## Troubleshooting Checklist

- [ ] External API server running on port 9000
- [ ] Main app server running on port 5000
- [ ] Browser opened to http://localhost:5000
- [ ] JavaScript console shows no errors (F12)
- [ ] Network tab shows successful API calls (F12)

For detailed documentation, see:
- [ENHANCEMENTS_SUMMARY.md](ENHANCEMENTS_SUMMARY.md) - Complete feature documentation
- [SETUP_GUIDE.md](SETUP_GUIDE.md) - Detailed setup instructions
- [external_api_server/API_SPECIFICATION.md](external_api_server/API_SPECIFICATION.md) - API documentation
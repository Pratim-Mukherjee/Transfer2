// Medication Manager with Time Entry and Edit/Remove Support
class MedicationManager {
    constructor() {
        this.medications = [];
        this.editingIndex = null;
        this.initializeEventListeners();
    }

    initializeEventListeners() {
        // Frequency change - show appropriate number of time inputs
        const frequencySelect = document.getElementById('newMedicationFrequency');
        if (frequencySelect) {
            frequencySelect.addEventListener('change', () => this.updateTimeInputs());
        }

        // Add/Update medication button
        const addBtn = document.getElementById('addMedicationBtn');
        if (addBtn) {
            addBtn.addEventListener('click', () => {
                if (this.editingIndex !== null) {
                    this.updateMedication();
                } else {
                    this.addMedication();
                }
            });
        }

        // Cancel edit button
        const cancelBtn = document.getElementById('cancelMedicationEditBtn');
        if (cancelBtn) {
            cancelBtn.addEventListener('click', () => this.cancelEdit());
        }
    }

    parseFrequencyPattern(pattern) {
        // Parse pattern like "0-0-1" or "1-0-1"
        // Returns array of meal indices where medication should be taken
        // 0 = breakfast, 1 = lunch, 2 = dinner
        if (!pattern || typeof pattern !== 'string') return [];

        const parts = pattern.split('-').map(p => parseInt(p.trim()));
        if (parts.length !== 3) return [];

        const mealIndices = [];
        parts.forEach((count, mealIndex) => {
            if (count > 0) {
                mealIndices.push(mealIndex);
            }
        });
        return mealIndices;
    }

    updateTimeInputs() {
        const frequency = document.getElementById('newMedicationFrequency').value;
        const container = document.getElementById('medicationTimesContainer');
        const patternInput = document.getElementById('customFrequencyPattern');

        // Show/hide custom pattern input
        if (frequency === 'custom_pattern') {
            patternInput.style.display = 'block';
            container.innerHTML = '';
            return;
        } else {
            patternInput.style.display = 'none';
        }

        if (!frequency || frequency === 'as_needed') {
            container.innerHTML = '';
            return;
        }

        // Determine number of times based on frequency
        let numTimes = 0;
        switch(frequency) {
            case 'once_daily': numTimes = 1; break;
            case 'twice_daily': numTimes = 2; break;
            case 'thrice_daily': numTimes = 3; break;
        }

        // Create time inputs
        container.innerHTML = '';
        for (let i = 0; i < numTimes; i++) {
            const timeInput = document.createElement('input');
            timeInput.type = 'time';
            timeInput.className = 'medication-time-input';
            timeInput.placeholder = `Time ${i + 1}`;
            timeInput.required = true;

            // Set default times
            if (i === 0) timeInput.value = '08:00';
            else if (i === 1) timeInput.value = '20:00';
            else if (i === 2) timeInput.value = '14:00';

            container.appendChild(timeInput);

            // Initialize custom timepicker if available
            if (window.timePicker) {
                window.timePicker.initializeDynamicInput(timeInput);
            }
        }
    }

    addMedication() {
        const name = document.getElementById('newMedicationName').value.trim();
        const dose = document.getElementById('newMedicationDose').value.trim();
        const frequency = document.getElementById('newMedicationFrequency').value;

        if (!name || !dose || !frequency) {
            alert('Please fill in all medication fields');
            return;
        }

        let medication = {
            name,
            dose,
            frequency
        };

        // Handle custom pattern
        if (frequency === 'custom_pattern') {
            const pattern = document.getElementById('customFrequencyPattern').value.trim();
            if (!pattern) {
                alert('Please enter a frequency pattern (e.g., 0-0-1)');
                return;
            }
            // Validate pattern format
            if (!/^\d-\d-\d$/.test(pattern)) {
                alert('Invalid pattern format. Use format like 0-0-1 or 1-0-1');
                return;
            }
            medication.frequency_pattern = pattern;
            medication.times = [];  // Times will be determined from meal schedule
        } else {
            // Get times for standard frequencies
            const timeInputs = document.querySelectorAll('#medicationTimesContainer input[type="time"]');
            const times = Array.from(timeInputs).map(input => input.value).filter(time => time);

            // Validate times are entered if required
            if (frequency !== 'as_needed' && times.length === 0) {
                alert('Please enter medication times');
                return;
            }

            // Validate correct number of times
            const expectedTimes = {
                'once_daily': 1,
                'twice_daily': 2,
                'thrice_daily': 3
            };

            if (frequency !== 'as_needed' && times.length !== expectedTimes[frequency]) {
                alert(`Please enter ${expectedTimes[frequency]} time(s) for ${frequency.replace('_', ' ')}`);
                return;
            }

            medication.times = frequency === 'as_needed' ? [] : times;
        }

        this.medications.push(medication);
        this.renderMedications();
        this.clearInputs();
    }

    editMedication(index) {
        const medication = this.medications[index];
        this.editingIndex = index;

        // Populate form
        document.getElementById('newMedicationName').value = medication.name;
        document.getElementById('newMedicationDose').value = medication.dose;
        document.getElementById('newMedicationFrequency').value = medication.frequency;

        // Update time inputs
        this.updateTimeInputs();

        // Populate times
        const timeInputs = document.querySelectorAll('#medicationTimesContainer input[type="time"]');
        medication.times.forEach((time, i) => {
            if (timeInputs[i]) {
                timeInputs[i].value = time;
            }
        });

        // Change button text and show cancel
        document.getElementById('addMedicationBtn').textContent = 'Update Medication';
        document.getElementById('cancelMedicationEditBtn').style.display = 'inline-block';

        // Scroll to form
        document.getElementById('newMedicationName').scrollIntoView({ behavior: 'smooth', block: 'center' });
    }

    updateMedication() {
        const name = document.getElementById('newMedicationName').value.trim();
        const dose = document.getElementById('newMedicationDose').value.trim();
        const frequency = document.getElementById('newMedicationFrequency').value;

        if (!name || !dose || !frequency) {
            alert('Please fill in all medication fields');
            return;
        }

        // Get times
        const timeInputs = document.querySelectorAll('#medicationTimesContainer input[type="time"]');
        const times = Array.from(timeInputs).map(input => input.value).filter(time => time);

        // Update the medication
        this.medications[this.editingIndex] = {
            name,
            dose,
            frequency,
            times: frequency === 'as_needed' ? [] : times
        };

        this.renderMedications();
        this.cancelEdit();
    }

    cancelEdit() {
        this.editingIndex = null;
        this.clearInputs();
        document.getElementById('addMedicationBtn').textContent = 'Add Medication';
        document.getElementById('cancelMedicationEditBtn').style.display = 'none';
    }

    renderMedications() {
        const container = document.getElementById('medicationList');

        if (this.medications.length === 0) {
            container.innerHTML = '<p style="color: #7f8c8d; font-style: italic;">No medications added yet</p>';
            return;
        }

        container.innerHTML = this.medications.map((med, index) => `
            <div class="medication-item">
                <div class="medication-info">
                    <div class="medication-name">${med.name}</div>
                    <div class="medication-details">
                        ${med.dose} &bull; ${med.frequency_pattern ? med.frequency_pattern : this.formatFrequency(med.frequency)}
                    </div>
                    ${med.times && med.times.length > 0 ? `
                        <div class="medication-times">
                            ${med.times.map(time => `
                                <span class="medication-time-badge">${this.formatTime(time)}</span>
                            `).join('')}
                        </div>
                    ` : ''}
                    ${med.frequency_pattern ? `
                        <div class="medication-details" style="font-size: 0.85em; color: #7f8c8d;">
                            ${this.describePattern(med.frequency_pattern)}
                        </div>
                    ` : ''}
                </div>
                <div class="item-actions">
                    <button type="button" class="btn-icon btn-edit" onclick="window.medicationManager.editMedication(${index})" title="Edit">
                        ✏️
                    </button>
                    <button type="button" class="btn-icon btn-delete" onclick="window.medicationManager.removeMedication(${index})" title="Remove">
                        🗑️
                    </button>
                </div>
            </div>
        `).join('');
    }

    removeMedication(index) {
        if (confirm(`Remove ${this.medications[index].name}?`)) {
            this.medications.splice(index, 1);
            this.renderMedications();
        }
    }

    clearInputs() {
        document.getElementById('newMedicationName').value = '';
        document.getElementById('newMedicationDose').value = '';
        document.getElementById('newMedicationFrequency').value = '';
        document.getElementById('medicationTimesContainer').innerHTML = '';
    }

    formatFrequency(frequency) {
        return frequency.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
    }

    describePattern(pattern) {
        // Describe pattern like "0-0-1" as "With dinner" or "1-2-1" as "1 at breakfast, 2 at lunch, 1 at dinner"
        const parts = pattern.split('-').map(p => parseInt(p));
        const meals = ['breakfast', 'lunch', 'dinner'];
        const descriptions = [];

        parts.forEach((count, idx) => {
            if (count > 0 && idx < meals.length) {
                if (count === 1) {
                    descriptions.push(`${meals[idx]}`);
                } else {
                    descriptions.push(`${count} at ${meals[idx]}`);
                }
            }
        });

        if (descriptions.length === 0) return 'No meals specified';
        if (descriptions.length === 1) {
            // If single meal with count 1, use simple "With breakfast" format
            if (descriptions[0].indexOf(' at ') === -1) {
                return `With ${descriptions[0]}`;
            }
            return descriptions[0];
        }
        if (descriptions.length === 2) return `${descriptions[0]} and ${descriptions[1]}`;
        return descriptions.join(', ');
    }

    formatTime(time24) {
        const [hours, minutes] = time24.split(':');
        const hour = parseInt(hours);
        const ampm = hour >= 12 ? 'PM' : 'AM';
        const hour12 = hour % 12 || 12;
        return `${hour12}:${minutes} ${ampm}`;
    }

    getMedications() {
        return this.medications;
    }

    setMedications(medications) {
        this.medications = medications || [];
        this.renderMedications();
    }

    // Populate from external data
    populateFromData(medications) {
        if (medications && Array.isArray(medications)) {
            this.medications = medications.map(med => {
                const medObj = {
                    name: med.name,
                    dose: med.dose,
                    frequency: med.frequency,
                    times: med.times || []
                };

                // Check if frequency is a pattern (e.g., "0-0-1", "1-2-1")
                if (this.isFrequencyPattern(med.frequency)) {
                    medObj.frequency_pattern = med.frequency;
                    medObj.frequency = 'custom_pattern';
                    medObj.times = []; // Pattern-based, no specific times yet
                }

                return medObj;
            });
            this.renderMedications();
        }
    }

    // Check if a frequency string is a pattern format
    isFrequencyPattern(frequency) {
        if (!frequency || typeof frequency !== 'string') return false;
        // Pattern format: digit-digit-digit (e.g., "0-0-1", "1-2-1", "2-0-2")
        return /^\d+-\d+-\d+$/.test(frequency.trim());
    }
}

// Initialize on page load
if (typeof window !== 'undefined') {
    window.medicationManager = new MedicationManager();
}
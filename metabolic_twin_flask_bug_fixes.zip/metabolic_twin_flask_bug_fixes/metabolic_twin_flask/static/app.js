// Main App.js - Core Application Controller
// Coordinates between all modules and manages application state

class MetabolicTwinApp {
    constructor() {
        this.currentPatient = null;
        this.enhancedBaseline = null;
        this.completeProtocol = null;
        this.weeklyProgression = null;
        this.medications = [];
        this.currentCGMData = null;
        
        this.init();
    }

    async init() {
        try {
            // Initialize all modules
            this.wizardManager = new WizardManager(this);
            this.patientManager = new PatientManager(this);
            this.baselineProcessor = new BaselineProcessor(this);
            this.protocolGenerator = new ProtocolGenerator(this);
            this.uiManager = new UIManager(this);
            this.activityManager = new ActivityManager(this);
            this.mealPlanningManager = new MealPlanningManager(this);

            // Initialize UI components
            this.uiManager.initializeEventListeners();
            this.uiManager.initializeSliders();
            this.uiManager.initializeTabs();

            // Initialize Activity Manager
            await this.activityManager.initialize();

            // Initialize Meal Planning Manager
            await this.mealPlanningManager.initialize();

            // Load external patients on startup
            await this.patientManager.loadExternalPatients();

            console.log('Metabolic Twin App initialized successfully');
        } catch (error) {
            console.error('Error initializing app:', error);
            this.uiManager.showMessage('Error initializing application', 'error');
        }
    }

    // Wizard navigation methods
    wizardGoToStep(step) {
        if (this.wizardManager) {
            this.wizardManager.goToStep(step);
        }
    }

    // State management methods
    setCurrentPatient(patient) {
        this.currentPatient = patient;
        this.uiManager.displayCurrentPatient(patient);
    }

    setEnhancedBaseline(baseline) {
        this.enhancedBaseline = baseline;
    }

    setCompleteProtocol(protocol) {
        this.completeProtocol = protocol;
    }

    setWeeklyProgression(progression) {
        this.weeklyProgression = progression;
    }

    setCGMData(data) {
        this.currentCGMData = data;
    }

    // Medication management
    addMedication(medication) {
        medication.id = Date.now();
        this.medications.push(medication);
        this.uiManager.updateMedicationDisplay(this.medications);
    }

    removeMedication(id) {
        this.medications = this.medications.filter(med => med.id !== id);
        this.uiManager.updateMedicationDisplay(this.medications);
    }

    setMedications(medications) {
        this.medications = medications;
        this.uiManager.updateMedicationDisplay(this.medications);
    }

    // Tab management
    enableTabs(tabNames) {
        this.uiManager.enableTabs(tabNames);
    }

    switchTab(tabName) {
        this.uiManager.switchTab(tabName);
    }

    // Reset application state
    resetForms() {
        this.enhancedBaseline = null;
        this.completeProtocol = null;
        this.weeklyProgression = null;
        this.medications = [];
        this.currentCGMData = null;
        
        this.uiManager.resetForms();
    }

    // Message display
    showMessage(message, type = 'info') {
        this.uiManager.showMessage(message, type);
    }
}

// Initialize the application when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.app = new MetabolicTwinApp();
});
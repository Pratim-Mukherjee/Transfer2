// Supplement Manager with Time Entry and Edit/Remove Support
class SupplementManager {
    constructor() {
        this.supplements = [];
        this.editingIndex = null;
        this.initializeEventListeners();
    }

    initializeEventListeners() {
        // Frequency change - show appropriate number of time inputs
        const frequencySelect = document.getElementById('newSupplementFrequency');
        if (frequencySelect) {
            frequencySelect.addEventListener('change', () => this.updateTimeInputs());
        }

        // Add/Update supplement button
        const addBtn = document.getElementById('addSupplementBtn');
        if (addBtn) {
            addBtn.addEventListener('click', () => {
                if (this.editingIndex !== null) {
                    this.updateSupplement();
                } else {
                    this.addSupplement();
                }
            });
        }

        // Cancel edit button
        const cancelBtn = document.getElementById('cancelSupplementEditBtn');
        if (cancelBtn) {
            cancelBtn.addEventListener('click', () => this.cancelEdit());
        }
    }

    updateTimeInputs() {
        const frequency = document.getElementById('newSupplementFrequency').value;
        const container = document.getElementById('supplementTimesContainer');

        if (!frequency || frequency === 'as_needed') {
            container.innerHTML = '';
            return;
        }

        // Determine number of times based on frequency
        let numTimes = 0;
        switch(frequency) {
            case 'once_daily': numTimes = 1; break;
            case 'twice_daily': numTimes = 2; break;
            case 'thrice_daily': numTimes = 3; break;
        }

        // Create time inputs
        container.innerHTML = '';
        for (let i = 0; i < numTimes; i++) {
            const timeInput = document.createElement('input');
            timeInput.type = 'time';
            timeInput.className = 'supplement-time-input';
            timeInput.placeholder = `Time ${i + 1}`;
            timeInput.required = true;

            // Set default times
            if (i === 0) timeInput.value = '08:00';
            else if (i === 1) timeInput.value = '20:00';
            else if (i === 2) timeInput.value = '14:00';

            container.appendChild(timeInput);

            // Initialize custom timepicker if available
            if (window.timePicker) {
                window.timePicker.initializeDynamicInput(timeInput);
            }
        }
    }

    addSupplement() {
        const name = document.getElementById('newSupplementName').value.trim();
        const dose = document.getElementById('newSupplementDose').value.trim();
        const frequency = document.getElementById('newSupplementFrequency').value;

        if (!name || !dose || !frequency) {
            alert('Please fill in all supplement fields');
            return;
        }

        // Get times
        const timeInputs = document.querySelectorAll('#supplementTimesContainer input[type="time"]');
        const times = Array.from(timeInputs).map(input => input.value).filter(time => time);

        // Validate times are entered if required
        if (frequency !== 'as_needed' && times.length === 0) {
            alert('Please enter supplement times');
            return;
        }

        // Validate correct number of times
        const expectedTimes = {
            'once_daily': 1,
            'twice_daily': 2,
            'thrice_daily': 3
        };

        if (frequency !== 'as_needed' && times.length !== expectedTimes[frequency]) {
            alert(`Please enter ${expectedTimes[frequency]} time(s) for ${frequency.replace('_', ' ')}`);
            return;
        }

        const supplement = {
            name,
            dose,
            frequency,
            times: frequency === 'as_needed' ? [] : times,
            source: 'current' // Mark as current supplement (not auto-recommended)
        };

        this.supplements.push(supplement);
        this.renderSupplements();
        this.clearInputs();
    }

    editSupplement(index) {
        const supplement = this.supplements[index];
        this.editingIndex = index;

        // Populate form
        document.getElementById('newSupplementName').value = supplement.name;
        document.getElementById('newSupplementDose').value = supplement.dose;
        document.getElementById('newSupplementFrequency').value = supplement.frequency;

        // Update time inputs
        this.updateTimeInputs();

        // Populate times
        const timeInputs = document.querySelectorAll('#supplementTimesContainer input[type="time"]');
        supplement.times.forEach((time, i) => {
            if (timeInputs[i]) {
                timeInputs[i].value = time;
            }
        });

        // Change button text and show cancel
        document.getElementById('addSupplementBtn').textContent = 'Update Supplement';
        document.getElementById('cancelSupplementEditBtn').style.display = 'inline-block';

        // Scroll to form
        document.getElementById('newSupplementName').scrollIntoView({ behavior: 'smooth', block: 'center' });
    }

    updateSupplement() {
        const name = document.getElementById('newSupplementName').value.trim();
        const dose = document.getElementById('newSupplementDose').value.trim();
        const frequency = document.getElementById('newSupplementFrequency').value;

        if (!name || !dose || !frequency) {
            alert('Please fill in all supplement fields');
            return;
        }

        // Get times
        const timeInputs = document.querySelectorAll('#supplementTimesContainer input[type="time"]');
        const times = Array.from(timeInputs).map(input => input.value).filter(time => time);

        // Update the supplement
        this.supplements[this.editingIndex] = {
            name,
            dose,
            frequency,
            times: frequency === 'as_needed' ? [] : times,
            source: this.supplements[this.editingIndex].source || 'current'
        };

        this.renderSupplements();
        this.cancelEdit();
    }

    cancelEdit() {
        this.editingIndex = null;
        this.clearInputs();
        document.getElementById('addSupplementBtn').textContent = 'Add Supplement';
        document.getElementById('cancelSupplementEditBtn').style.display = 'none';
    }

    removeSupplement(index) {
        if (confirm(`Remove ${this.supplements[index].name}?`)) {
            this.supplements.splice(index, 1);
            this.renderSupplements();
        }
    }

    renderSupplements() {
        const container = document.getElementById('supplementList');

        if (this.supplements.length === 0) {
            container.innerHTML = '<p style="color: #7f8c8d; font-style: italic;">No supplements added yet</p>';
            return;
        }

        // Group by source
        const current = this.supplements.filter(s => s.source === 'current');
        const recommended = this.supplements.filter(s => s.source === 'recommended');

        let html = '';

        // Current supplements
        if (current.length > 0) {
            html += '<div class="supplement-group"><h4 style="color: #2c3e50; margin-bottom: 10px; font-size: 0.95em;">Current Supplements</h4>';
            html += current.map((sup, index) => this.renderSupplementItem(sup, this.supplements.indexOf(sup), true)).join('');
            html += '</div>';
        }

        // Recommended supplements
        if (recommended.length > 0) {
            html += '<div class="supplement-group"><h4 style="color: #27ae60; margin-bottom: 10px; font-size: 0.95em;">📋 Recommended Supplements</h4>';
            html += recommended.map((sup, index) => this.renderSupplementItem(sup, this.supplements.indexOf(sup), false)).join('');
            html += '</div>';
        }

        container.innerHTML = html;
    }

    renderSupplementItem(supplement, index, allowEdit) {
        const sourceColor = supplement.source === 'current' ? '#3498db' : '#27ae60';

        return `
            <div class="medication-item" style="border-left-color: ${sourceColor};">
                <div class="medication-info">
                    <div class="medication-name">${supplement.name}</div>
                    <div class="medication-details">
                        ${supplement.dose} &bull; ${this.formatFrequency(supplement.frequency)}
                    </div>
                    ${supplement.times && supplement.times.length > 0 ? `
                        <div class="medication-times">
                            ${supplement.times.map(time => `
                                <span class="medication-time-badge" style="background-color: ${sourceColor};">${this.formatTime(time)}</span>
                            `).join('')}
                        </div>
                    ` : ''}
                    ${supplement.rationale ? `
                        <div class="supplement-rationale">
                            <small style="color: #7f8c8d; font-style: italic;">ℹ️ ${supplement.rationale}</small>
                        </div>
                    ` : ''}
                </div>
                <div class="item-actions">
                    ${allowEdit ? `
                        <button type="button" class="btn-icon btn-edit" onclick="window.supplementManager.editSupplement(${index})" title="Edit">
                            ✏️
                        </button>
                    ` : ''}
                    <button type="button" class="btn-icon btn-delete" onclick="window.supplementManager.removeSupplement(${index})" title="Remove">
                        🗑️
                    </button>
                </div>
            </div>
        `;
    }

    clearInputs() {
        document.getElementById('newSupplementName').value = '';
        document.getElementById('newSupplementDose').value = '';
        document.getElementById('newSupplementFrequency').value = '';
        document.getElementById('supplementTimesContainer').innerHTML = '';
    }

    formatFrequency(frequency) {
        return frequency.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
    }

    formatTime(time24) {
        const [hours, minutes] = time24.split(':');
        const hour = parseInt(hours);
        const ampm = hour >= 12 ? 'PM' : 'AM';
        const hour12 = hour % 12 || 12;
        return `${hour12}:${minutes} ${ampm}`;
    }

    getSupplements() {
        return this.supplements;
    }

    setSupplements(supplements) {
        this.supplements = supplements || [];
        this.renderSupplements();
    }

    // Populate from external data
    populateFromData(supplements) {
        if (supplements && Array.isArray(supplements)) {
            this.supplements = supplements.map(sup => ({
                name: sup.name,
                dose: sup.dose,
                frequency: sup.frequency,
                times: sup.times || [],
                source: sup.source || 'current',
                rationale: sup.rationale || null
            }));
            this.renderSupplements();
        }
    }

    // Add recommended supplements (from protocol generation)
    addRecommendedSupplements(recommendedSupplements) {
        if (!recommendedSupplements || Object.keys(recommendedSupplements).length === 0) {
            return;
        }

        // Get existing supplement names (case-insensitive)
        const existingNames = this.supplements.map(s => s.name.toLowerCase());

        // Add only supplements that don't already exist
        Object.entries(recommendedSupplements).forEach(([name, details]) => {
            if (!existingNames.includes(name.toLowerCase())) {
                this.supplements.push({
                    name: name.charAt(0).toUpperCase() + name.slice(1),
                    dose: details.dose,
                    frequency: details.timing || 'once_daily',
                    times: this.getDefaultTimesForFrequency(details.timing || 'once_daily'),
                    source: 'recommended',
                    rationale: details.rationale
                });
            }
        });

        this.renderSupplements();
    }

    getDefaultTimesForFrequency(frequency) {
        switch(frequency) {
            case 'once_daily':
            case 'morning':
                return ['08:00'];
            case 'twice_daily':
            case 'morning_evening':
                return ['08:00', '20:00'];
            case 'thrice_daily':
                return ['08:00', '14:00', '20:00'];
            case 'evening':
                return ['20:00'];
            default:
                return ['08:00'];
        }
    }
}

// Initialize on page load
if (typeof window !== 'undefined') {
    window.supplementManager = new SupplementManager();
}
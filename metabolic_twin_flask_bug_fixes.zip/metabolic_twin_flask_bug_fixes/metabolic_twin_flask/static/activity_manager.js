// Activity Manager - Handles physical activity tracking and calorie calculation
class ActivityManager {
    constructor(app) {
        this.app = app;
        this.activities = [];
        this.activityLibrary = null;
        this.editingIndex = null;
    }

    async initialize() {
        try {
            // Load activity library
            await this.loadActivityLibrary();

            // Initialize event listeners
            this.initializeEventListeners();

            // Populate activity dropdown
            this.populateActivityDropdown();

            console.log('Activity Manager initialized successfully');
        } catch (error) {
            console.error('Error initializing Activity Manager:', error);
        }
    }

    async loadActivityLibrary() {
        try {
            const response = await fetch('/static/activity_library.json');
            if (!response.ok) {
                // Fallback: try from policies directory
                const policyResponse = await fetch('/api/policy/activity_library');
                if (policyResponse.ok) {
                    this.activityLibrary = await policyResponse.json();
                } else {
                    throw new Error('Could not load activity library');
                }
            } else {
                this.activityLibrary = await response.json();
            }
            console.log('Activity library loaded:', Object.keys(this.activityLibrary.activities).length, 'activities');
        } catch (error) {
            console.error('Error loading activity library:', error);
            // Use minimal fallback
            this.activityLibrary = {
                activities: {
                    walking_moderate: { name: "Walking", met_value: 3.5, category: "cardio", intensity: "moderate" },
                    jogging: { name: "Jogging", met_value: 8.0, category: "cardio", intensity: "vigorous" },
                    cycling_moderate: { name: "Cycling", met_value: 6.0, category: "cardio", intensity: "moderate" }
                },
                frequency_multipliers: {
                    daily: 7.0,
                    "5_times_week": 5.0,
                    "3_times_week": 3.0
                }
            };
        }
    }

    initializeEventListeners() {
        // Activity type change - update calorie estimate
        const activityType = document.getElementById('newActivityType');
        const activityDuration = document.getElementById('newActivityDuration');

        if (activityType) {
            activityType.addEventListener('change', () => this.updateCalorieEstimate());
        }

        if (activityDuration) {
            activityDuration.addEventListener('input', () => this.updateCalorieEstimate());
        }

        // Add activity button
        const addBtn = document.getElementById('addActivityBtn');
        if (addBtn) {
            addBtn.addEventListener('click', () => this.addOrUpdateActivity());
        }

        // Cancel edit button
        const cancelBtn = document.getElementById('cancelActivityEditBtn');
        if (cancelBtn) {
            cancelBtn.addEventListener('click', () => this.cancelEdit());
        }
    }

    populateActivityDropdown() {
        const select = document.getElementById('newActivityType');
        if (!select || !this.activityLibrary) return;

        // Clear existing options except first
        select.innerHTML = '<option value="">Select activity...</option>';

        // Group activities by category
        const categories = {};
        for (const [key, activity] of Object.entries(this.activityLibrary.activities)) {
            if (!categories[activity.category]) {
                categories[activity.category] = [];
            }
            categories[activity.category].push({ key, ...activity });
        }

        // Add optgroups
        const categoryOrder = ['cardio', 'strength', 'sports', 'flexibility', 'lifestyle'];
        for (const cat of categoryOrder) {
            if (categories[cat]) {
                const optgroup = document.createElement('optgroup');
                optgroup.label = cat.charAt(0).toUpperCase() + cat.slice(1);

                categories[cat].forEach(activity => {
                    const option = document.createElement('option');
                    option.value = activity.key;
                    option.textContent = activity.name;
                    option.dataset.met = activity.met_value;
                    option.dataset.intensity = activity.intensity;
                    optgroup.appendChild(option);
                });

                select.appendChild(optgroup);
            }
        }
    }

    updateCalorieEstimate() {
        const activityType = document.getElementById('newActivityType').value;
        const duration = parseFloat(document.getElementById('newActivityDuration').value);
        const estimateSpan = document.getElementById('estimatedCalories');

        if (!activityType || !duration || !this.app.enhancedBaseline) {
            estimateSpan.textContent = '-- kcal/session';
            estimateSpan.style.color = '#7f8c8d';
            return;
        }

        const weight = this.app.enhancedBaseline.patient_profile.demographics.weight_kg;
        const calories = this.calculateCalories(activityType, duration, weight);

        estimateSpan.textContent = `~${calories} kcal/session`;
        estimateSpan.style.color = '#27ae60';
        estimateSpan.style.fontWeight = 'bold';
    }

    calculateCalories(activityKey, durationMinutes, weightKg) {
        if (!this.activityLibrary || !this.activityLibrary.activities[activityKey]) {
            return 0;
        }

        const activity = this.activityLibrary.activities[activityKey];
        const met = activity.met_value;
        const hours = durationMinutes / 60;

        // Formula: Calories = MET × weight(kg) × time(hours)
        return Math.round(met * weightKg * hours);
    }

    calculateWeeklyCalories(activityKey, durationMinutes, weightKg, frequency) {
        const sessionCalories = this.calculateCalories(activityKey, durationMinutes, weightKg);
        const multiplier = this.activityLibrary.frequency_multipliers[frequency] || 1;
        return Math.round(sessionCalories * multiplier);
    }

    addOrUpdateActivity() {
        const type = document.getElementById('newActivityType').value;
        const time = document.getElementById('newActivityTime').value;
        const duration = parseFloat(document.getElementById('newActivityDuration').value);
        const frequency = document.getElementById('newActivityFrequency').value;

        // Validation
        if (!type) {
            alert('Please select an activity type');
            return;
        }
        if (!time) {
            alert('Please select a time');
            return;
        }
        if (!duration || duration < 5) {
            alert('Please enter duration (minimum 5 minutes)');
            return;
        }
        if (!frequency) {
            alert('Please select frequency');
            return;
        }

        const activity = this.activityLibrary.activities[type];
        const weight = this.app.enhancedBaseline?.patient_profile.demographics.weight_kg || 70;

        const activityData = {
            type: type,
            name: activity.name,
            time: time,
            duration: duration,
            frequency: frequency,
            met_value: activity.met_value,
            intensity: activity.intensity,
            calories_per_session: this.calculateCalories(type, duration, weight),
            weekly_calories: this.calculateWeeklyCalories(type, duration, weight, frequency)
        };

        if (this.editingIndex !== null) {
            // Update existing
            this.activities[this.editingIndex] = activityData;
            this.editingIndex = null;
            document.getElementById('addActivityBtn').textContent = 'Add Activity';
            document.getElementById('cancelActivityEditBtn').style.display = 'none';
        } else {
            // Add new
            this.activities.push(activityData);
        }

        this.displayActivities();
        this.clearActivityForm();
        this.updateCalorieEstimate();
    }

    removeActivity(index) {
        if (confirm('Remove this activity?')) {
            this.activities.splice(index, 1);
            this.displayActivities();
        }
    }

    editActivity(index) {
        const activity = this.activities[index];

        document.getElementById('newActivityType').value = activity.type;
        document.getElementById('newActivityTime').value = activity.time;
        document.getElementById('newActivityDuration').value = activity.duration;
        document.getElementById('newActivityFrequency').value = activity.frequency;

        this.editingIndex = index;
        document.getElementById('addActivityBtn').textContent = 'Update Activity';
        document.getElementById('cancelActivityEditBtn').style.display = 'inline-block';

        this.updateCalorieEstimate();
    }

    cancelEdit() {
        this.editingIndex = null;
        document.getElementById('addActivityBtn').textContent = 'Add Activity';
        document.getElementById('cancelActivityEditBtn').style.display = 'none';
        this.clearActivityForm();
    }

    clearActivityForm() {
        document.getElementById('newActivityType').value = '';
        document.getElementById('newActivityTime').value = '';
        document.getElementById('newActivityDuration').value = '';
        document.getElementById('newActivityFrequency').value = '';
        this.updateCalorieEstimate();
    }

    displayActivities() {
        const container = document.getElementById('activityList');
        if (!container) return;

        if (this.activities.length === 0) {
            container.innerHTML = '<p style="color: #7f8c8d; font-style: italic;">No activities added yet</p>';
            return;
        }

        let totalWeeklyCalories = 0;

        container.innerHTML = this.activities.map((activity, index) => {
            totalWeeklyCalories += activity.weekly_calories;
            const dailyAvg = Math.round(activity.weekly_calories / 7);

            const frequencyLabel = {
                'daily': 'Daily',
                '6_times_week': '6×/week',
                '5_times_week': '5×/week',
                '4_times_week': '4×/week',
                '3_times_week': '3×/week',
                '2_times_week': '2×/week',
                'once_week': 'Once/week'
            }[activity.frequency] || activity.frequency;

            const intensityColor = {
                'light': '#95a5a6',
                'moderate': '#3498db',
                'vigorous': '#e67e22'
            }[activity.intensity] || '#95a5a6';

            return `
                <div class="medication-item">
                    <div class="medication-info">
                        <strong>${activity.name}</strong>
                        <span style="color: ${intensityColor}; font-size: 0.85em; margin-left: 8px;">${activity.intensity}</span>
                        <br>
                        <small>
                            ${activity.duration} min at ${activity.time} | ${frequencyLabel}<br>
                            <span style="color: #27ae60;">
                                ${activity.calories_per_session} kcal/session |
                                ${activity.weekly_calories} kcal/week (~${dailyAvg} kcal/day avg)
                            </span>
                        </small>
                    </div>
                    <div class="medication-actions">
                        <button type="button" class="btn-icon" onclick="app.activityManager.editActivity(${index})" title="Edit">✏️</button>
                        <button type="button" class="btn-icon" onclick="app.activityManager.removeActivity(${index})" title="Remove">🗑️</button>
                    </div>
                </div>
            `;
        }).join('');

        // Add total summary
        const dailyAvgTotal = Math.round(totalWeeklyCalories / 7);
        container.innerHTML += `
            <div style="margin-top: 15px; padding: 10px; background: rgba(39, 174, 96, 0.1); border-radius: 8px; border-left: 4px solid #27ae60;">
                <strong>Total Activity:</strong> ${totalWeeklyCalories} kcal/week
                <span style="color: #27ae60;">(~${dailyAvgTotal} kcal/day average)</span>
            </div>
        `;
    }

    getTotalDailyActivityCalories() {
        let totalWeekly = 0;
        for (const activity of this.activities) {
            totalWeekly += activity.weekly_calories;
        }
        return Math.round(totalWeekly / 7); // Daily average
    }

    getActivities() {
        return this.activities;
    }

    setActivities(activities) {
        this.activities = activities || [];
        this.displayActivities();
    }
}

// Make it available globally
window.ActivityManager = ActivityManager;

// Body Fat Calculator using US Navy Method
class BodyFatCalculator {
    constructor() {
        this.initializeEventListeners();
    }

    initializeEventListeners() {
        // Show/hide hip measurement based on gender
        const genderSelect = document.getElementById('gender');
        if (genderSelect) {
            genderSelect.addEventListener('change', () => this.handleGenderChange());
            // Trigger on load
            this.handleGenderChange();
        }

        // Calculate body fat button
        const calculateBtn = document.getElementById('calculateBodyFatBtn');
        if (calculateBtn) {
            calculateBtn.addEventListener('click', () => this.calculateBodyFat());
        }

        // Clear error styling when user starts typing in body fat field
        const bodyfatInput = document.getElementById('bodyfat');
        if (bodyfatInput) {
            bodyfatInput.addEventListener('input', () => {
                bodyfatInput.style.borderColor = '';
                bodyfatInput.style.boxShadow = '';
            });
        }

        // Auto-calculate when measurements change
        const measurements = ['waistCircumference', 'neckCircumference', 'hipCircumference'];
        measurements.forEach(id => {
            const input = document.getElementById(id);
            if (input) {
                input.addEventListener('blur', () => this.autoCalculateIfComplete());
            }
        });
    }

    handleGenderChange() {
        const gender = document.getElementById('gender').value;
        const hipGroup = document.getElementById('hipMeasurementGroup');
        const hipInput = document.getElementById('hipCircumference');

        if (gender === 'female') {
            hipGroup.style.display = ''; // Reset to default (will use CSS grid)
            hipInput.required = false; // We'll validate manually
        } else {
            hipGroup.style.display = 'none';
            hipInput.required = false;
            hipInput.value = ''; // Clear value
        }
    }

    autoCalculateIfComplete() {
        const gender = document.getElementById('gender').value;
        const height = parseFloat(document.getElementById('height').value);
        const waist = parseFloat(document.getElementById('waistCircumference').value);
        const neck = parseFloat(document.getElementById('neckCircumference').value);
        const hip = parseFloat(document.getElementById('hipCircumference').value);
        const bodyfatInput = document.getElementById('bodyfat');

        // Only auto-calculate if bodyfat is empty and measurements are complete
        if (bodyfatInput.value) return;

        if (gender === 'female') {
            if (height && waist && neck && hip) {
                this.calculateBodyFat();
            }
        } else {
            if (height && waist && neck) {
                this.calculateBodyFat();
            }
        }
    }

    calculateBodyFat() {
        const gender = document.getElementById('gender').value;
        const height = parseFloat(document.getElementById('height').value);
        const waist = parseFloat(document.getElementById('waistCircumference').value);
        const neck = parseFloat(document.getElementById('neckCircumference').value);
        const hip = parseFloat(document.getElementById('hipCircumference').value);

        // Validate inputs
        if (!gender || !height) {
            alert('Please enter gender and height first');
            return;
        }

        if (!waist || !neck) {
            alert('Please enter waist and neck circumference');
            return;
        }

        if (gender === 'female' && !hip) {
            alert('Hip circumference is required for females');
            return;
        }

        // Validate measurements
        if (waist <= neck) {
            alert('Waist circumference must be greater than neck circumference');
            return;
        }

        let bodyFatPercentage;

        try {
            if (gender === 'male') {
                // Male formula
                const logWaistMinusNeck = Math.log10(waist - neck);
                const logHeight = Math.log10(height);
                bodyFatPercentage = 495 / (1.0324 - 0.19077 * logWaistMinusNeck + 0.15456 * logHeight) - 450;
            } else {
                // Female formula
                if (waist + hip <= neck) {
                    alert('Invalid measurements: (waist + hip) must be greater than neck');
                    return;
                }
                const logWaistHipMinusNeck = Math.log10(waist + hip - neck);
                const logHeight = Math.log10(height);
                bodyFatPercentage = 495 / (1.29579 - 0.35004 * logWaistHipMinusNeck + 0.22100 * logHeight) - 450;
            }

            // Validate result
            if (bodyFatPercentage < 3 || bodyFatPercentage > 60) {
                alert('Calculated body fat percentage is outside normal range. Please check measurements.');
                return;
            }

            // Round to 1 decimal place
            bodyFatPercentage = Math.round(bodyFatPercentage * 10) / 10;

            // Update the body fat input
            const bodyfatInput = document.getElementById('bodyfat');
            bodyfatInput.value = bodyFatPercentage;

            // Show calculated badge
            const badge = document.getElementById('bodyfatCalculatedBadge');
            badge.style.display = 'inline';

            // Show method info
            const methodInfo = document.getElementById('bodyfatMethodInfo');
            methodInfo.textContent = 'Estimated using US Navy body fat formula';

            // Success feedback
            bodyfatInput.style.borderColor = '#27ae60';
            setTimeout(() => {
                bodyfatInput.style.borderColor = '';
            }, 2000);

        } catch (error) {
            alert('Error calculating body fat percentage. Please check your measurements.');
            console.error('Body fat calculation error:', error);
        }
    }

    // Get body fat data for submission
    getBodyFatData() {
        return {
            bodyfat_pct: parseFloat(document.getElementById('bodyfat').value) || null,
            body_measurements: {
                waist_cm: parseFloat(document.getElementById('waistCircumference').value) || null,
                neck_cm: parseFloat(document.getElementById('neckCircumference').value) || null,
                hip_cm: parseFloat(document.getElementById('hipCircumference').value) || null
            }
        };
    }

    // Populate from external data
    populateFromData(metabolic, bodyMeasurements) {
        const bodyfatInput = document.getElementById('bodyfat');
        const badge = document.getElementById('bodyfatCalculatedBadge');
        const methodInfo = document.getElementById('bodyfatMethodInfo');

        // Set body fat if available
        if (metabolic.bodyfat_pct !== null && metabolic.bodyfat_pct !== undefined) {
            bodyfatInput.value = metabolic.bodyfat_pct;

            // Show badge if calculated
            if (metabolic.bodyfat_is_calculated) {
                badge.style.display = 'inline';
                methodInfo.textContent = 'Estimated using US Navy body fat formula';
            } else if (metabolic.bodyfat_method) {
                methodInfo.textContent = `Measured by ${metabolic.bodyfat_method}`;
            }
        }

        // Set body measurements if available
        if (bodyMeasurements) {
            if (bodyMeasurements.waist_cm) {
                document.getElementById('waistCircumference').value = bodyMeasurements.waist_cm;
            }
            if (bodyMeasurements.neck_cm) {
                document.getElementById('neckCircumference').value = bodyMeasurements.neck_cm;
            }
            if (bodyMeasurements.hip_cm) {
                document.getElementById('hipCircumference').value = bodyMeasurements.hip_cm;
            }
        }
    }
}

// Initialize on page load
if (typeof window !== 'undefined') {
    window.bodyFatCalculator = new BodyFatCalculator();
}
// meal_planning_manager.js - Manages meal planning UI and configuration

class MealPlanningManager {
    constructor(app) {
        this.app = app;
        this.mealPlanningRules = null;
        this.currentMealCount = 3; // Default
        this.currentStrategy = 'distributed'; // Default
        this.selectedMeal = null;
    }

    async initialize() {
        console.log('MealPlanningManager: Initializing...');

        // Load meal planning rules from policy
        await this.loadMealPlanningRules();

        // Set up event listeners
        this.setupEventListeners();

        console.log('MealPlanningManager: Initialized');
    }

    async loadMealPlanningRules() {
        try {
            const response = await fetch('/api/policy/meal_planning_rules');
            if (!response.ok) {
                throw new Error('Failed to load meal planning rules');
            }
            this.mealPlanningRules = await response.json();
            console.log('Meal planning rules loaded:', this.mealPlanningRules);
        } catch (error) {
            console.error('Error loading meal planning rules:', error);
            throw error;
        }
    }

    setupEventListeners() {
        // Meal count radio buttons
        const mealCountRadios = document.querySelectorAll('input[name="mealCount"]');
        mealCountRadios.forEach(radio => {
            radio.addEventListener('change', (e) => {
                this.onMealCountChange(parseInt(e.target.value));
            });
        });

        // Carb strategy radio buttons
        const strategyRadios = document.querySelectorAll('input[name="carbStrategy"]');
        strategyRadios.forEach(radio => {
            radio.addEventListener('change', (e) => {
                this.onCarbStrategyChange(e.target.value);
            });
        });

        console.log('MealPlanningManager: Event listeners set up');
    }

    onMealCountChange(mealCount) {
        console.log('Meal count changed to:', mealCount);
        this.currentMealCount = mealCount;

        // Update description
        this.updateMealCountDescription(mealCount);

        // Show/hide carb strategy selector
        const carbStrategyGroup = document.getElementById('carbStrategyGroup');
        if (mealCount === 1) {
            // OMAD - hide carb strategy (all carbs in one meal by default)
            carbStrategyGroup.style.display = 'none';
            this.currentStrategy = 'all_in_one';
            this.selectedMeal = 1;  // Set selectedMeal to 1 for OMAD
        } else {
            // Multiple meals - show carb strategy
            carbStrategyGroup.style.display = 'block';
            // Reset to distributed if current strategy is all_in_one
            if (this.currentStrategy === 'all_in_one') {
                this.currentStrategy = 'distributed';
                document.querySelector('input[name="carbStrategy"][value="distributed"]').checked = true;
            }
        }

        // Update meal selection dropdown if needed
        this.updateMealSelectionDropdown();
    }

    updateMealCountDescription(mealCount) {
        const descriptionDiv = document.getElementById('mealCountDescription');
        const mealConfig = this.mealPlanningRules.meal_count_options[mealCount];

        if (!mealConfig) return;

        descriptionDiv.innerHTML = `
            <strong>${mealConfig.name}:</strong> ${mealConfig.description}
            <div style="margin-top: 8px; font-size: 0.85em;">
                <strong>Fasting Period:</strong> ${mealConfig.fasting_hours} hours |
                <strong>Eating Window:</strong> ${mealConfig.eating_window_hours} hours
            </div>
        `;
    }

    onCarbStrategyChange(strategy) {
        console.log('Carb strategy changed to:', strategy);
        this.currentStrategy = strategy;

        // Show/hide meal selection dropdown
        const mealSelectionGroup = document.getElementById('mealSelectionGroup');

        if (strategy === 'aggressive' || strategy === 'moderate') {
            mealSelectionGroup.style.display = 'block';
            this.updateMealSelectionDropdown();
        } else {
            mealSelectionGroup.style.display = 'none';
        }
    }

    updateMealSelectionDropdown() {
        const mealSelectionGroup = document.getElementById('mealSelectionGroup');
        const mealSelectionLabel = document.getElementById('mealSelectionLabel');
        const mealSelection = document.getElementById('mealSelection');
        const mealSelectionHint = document.getElementById('mealSelectionHint');

        // Only show if aggressive or moderate strategy
        if (this.currentStrategy !== 'aggressive' && this.currentStrategy !== 'moderate') {
            mealSelectionGroup.style.display = 'none';
            return;
        }

        mealSelectionGroup.style.display = 'block';

        // Get strategy config
        const strategyConfig = this.mealPlanningRules.carb_distribution_strategies[this.currentStrategy];

        // Update label
        mealSelectionLabel.textContent = strategyConfig.selection_prompt;

        // Populate dropdown with meal options
        mealSelection.innerHTML = '';
        const mealNames = this.getMealNames(this.currentMealCount);

        mealNames.forEach((name, index) => {
            const option = document.createElement('option');
            option.value = index + 1;
            option.textContent = name;
            mealSelection.appendChild(option);
        });

        // Set default selection (first meal)
        mealSelection.value = '1';
        this.selectedMeal = 1;

        // Update hint with recommendation
        const recommendation = strategyConfig.recommendations[`${this.currentMealCount}_meals`];
        if (recommendation) {
            mealSelectionHint.textContent = `Recommendation: ${recommendation}`;
        }

        // Add event listener to track selection
        mealSelection.addEventListener('change', (e) => {
            this.selectedMeal = parseInt(e.target.value);
            console.log('Selected meal:', this.selectedMeal);
        });
    }

    getMealNames(mealCount) {
        const mealConfig = this.mealPlanningRules.meal_count_options[mealCount];

        if (mealCount === 1) {
            return ['Single Meal'];
        } else if (mealCount === 2) {
            return ['First Meal', 'Second Meal'];
        } else if (mealCount === 3) {
            return ['Breakfast', 'Lunch', 'Dinner'];
        } else if (mealCount === 4) {
            return ['Breakfast', 'Mid-Morning', 'Lunch', 'Dinner'];
        }

        return [];
    }

    getMealPlanningConfiguration() {
        /**
         * Returns current meal planning configuration to be sent to backend
         */
        return {
            meal_count: this.currentMealCount,
            carb_strategy: this.currentStrategy,
            selected_meal_for_carbs: this.selectedMeal,
            meal_names: this.getMealNames(this.currentMealCount)
        };
    }

    validateMealPlanningConfiguration() {
        /**
         * Validates the current meal planning configuration
         */
        if (!this.currentMealCount) {
            return { valid: false, error: 'Meal count not selected' };
        }

        if (this.currentMealCount > 1 && !this.currentStrategy) {
            return { valid: false, error: 'Carb strategy not selected' };
        }

        if ((this.currentStrategy === 'aggressive' || this.currentStrategy === 'moderate') && !this.selectedMeal) {
            return { valid: false, error: 'Please select which meal should receive special carb allocation' };
        }

        return { valid: true };
    }
}

// Make it available globally
window.MealPlanningManager = MealPlanningManager;

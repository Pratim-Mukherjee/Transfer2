// ProtocolGenerator.js - Handles complete protocol generation and display

class ProtocolGenerator {
    constructor(app) {
        this.app = app;

        // Contraindication display names mapping
        this.contraindictionLabels = {
            'gallstone_history': 'History of Gallstones',
            'cardiovascular_disease': 'Severe Cardiovascular Disease',
            'kidney_disease': 'Chronic Kidney Disease',
            'eating_disorder_history': 'History of Eating Disorders'
        };
    }

    formatContraindication(contraindication) {
        return this.contraindictionLabels[contraindication] || contraindication;
    }

    async submitProtocolForm(e) {
        e.preventDefault();
        
        if (!this.app.enhancedBaseline) {
            this.app.showMessage('Please complete the baseline assessment first', 'error');
            return;
        }

        try {
            this.app.uiManager.showLoading('protocolForm');
            
            const protocolConfig = this.collectProtocolFormData();
            const completeProtocol = await this.generateCompleteProtocol(protocolConfig);
            
            this.app.setCompleteProtocol(completeProtocol.protocol);
            this.app.setWeeklyProgression(completeProtocol.weekly_progression);

            this.displayProtocolResults();
            this.app.enableTabs(['baseline', 'protocol', 'progress']);

            // Wizard: Move to protocol results step
            if (this.app.wizardManager) {
                this.app.wizardManager.onProtocolComplete();
            }

            // Show normal navigation buttons for newly generated protocols
            const backButton = document.getElementById('step5-back');
            const newBaselineButton = document.getElementById('step5-new-baseline');
            if (backButton) backButton.style.display = 'inline-block';
            if (newBaselineButton) newBaselineButton.style.display = 'none';

            this.app.showMessage('Complete protocol generated successfully', 'success');
            
        } catch (error) {
            this.app.showMessage(`Error generating protocol: ${error.message}`, 'error');
        } finally {
            this.app.uiManager.hideLoading('protocolForm');
        }
    }
collectProtocolFormData() {
    // Get meal planning configuration
    const mealPlanningConfig = this.app.mealPlanningManager.getMealPlanningConfiguration();

    // Validate meal planning
    const validation = this.app.mealPlanningManager.validateMealPlanningConfiguration();
    if (!validation.valid) {
        throw new Error(validation.error);
    }

    return {
        program_duration_weeks: parseInt(document.getElementById('programDuration').value),
        program_type: document.getElementById('programType').value,
        calorie_deficit_kcal: -parseInt(document.getElementById('calorieDeficit').value),  // Convert to negative
        meal_planning: mealPlanningConfig
    };
}

    async generateCompleteProtocol(protocolConfig) {
        // Get medications from enhanced baseline (which has the user-entered medications with times)
        const medications = this.app.enhancedBaseline?.patient_profile?.medical_history?.current_medications || [];

        const doctorDecisions = {
            medications: medications,
            calorie_deficit_kcal: protocolConfig.calorie_deficit_kcal
        };

        const programConfig = {
            duration_weeks: protocolConfig.program_duration_weeks,
            program_type: protocolConfig.program_type,
            meal_planning: protocolConfig.meal_planning
        };

        const response = await fetch('/protocol/generate_complete', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                patient_id: this.app.currentPatient?.patient_id || this.app.currentPatient?.name?.toLowerCase().replace(' ', '_'),
                enhanced_baseline: this.app.enhancedBaseline,
                doctor_decisions: doctorDecisions,
                program_config: programConfig
            })
        });
        
        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(errorData.details || 'Failed to generate protocol');
        }
        
        return await response.json();
    }

displayProtocolResults() {
    if (!this.app.completeProtocol) {
        console.error('No protocol data available');
        this.app.showMessage('Error: No protocol data to display', 'error');
        return;
    }

    console.log('Displaying protocol results:', this.app.completeProtocol);

    // Initialize protocol tab switching
    this.initializeProtocolTabs();

    // Display each section with error handling
    try {
        this.displayMacroTargets();
    } catch (e) {
        console.error('Error displaying macro targets:', e);
        const container = document.getElementById('macroTargets');
        if (container) container.innerHTML = '<p class="error">Error loading macro targets</p>';
    }

    try {
        this.displayMealPlan();
    } catch (e) {
        console.error('Error displaying meal plan:', e);
        const container = document.getElementById('mealPlan');
        if (container) container.innerHTML = '<p class="error">Error loading meal plan</p>';
    }

    try {
        this.displayActivityPlan();
    } catch (e) {
        console.error('Error displaying activity plan:', e);
        const container = document.getElementById('activityPlan');
        if (container) container.innerHTML = '<p class="error">Error loading activity plan</p>';
    }

    try {
        this.displayMedicationSchedule();
    } catch (e) {
        console.error('Error displaying medication schedule:', e);
        const container = document.getElementById('medicationSchedule');
        if (container) container.innerHTML = '<p class="error">Error loading medication schedule</p>';
    }

    try {
        this.displaySafetyProtocol();
    } catch (e) {
        console.error('Error displaying safety protocol:', e);
        const container = document.getElementById('safetyProtocol');
        if (container) container.innerHTML = '<p class="error">Error loading safety protocol</p>';
    }

    try {
        this.displayProtocolOverview();
    } catch (e) {
        console.error('Error displaying protocol overview:', e);
        const container = document.getElementById('protocolOverview');
        if (container) container.innerHTML = '<p class="error">Error loading protocol overview</p>';
    }

    try {
        this.displayWeeklyTargets();
    } catch (e) {
        console.error('Error displaying weekly targets:', e);
        const container = document.getElementById('weeklyTargets');
        if (container) container.innerHTML = '<p class="error">Error loading weekly targets</p>';
    }
}

initializeProtocolTabs() {
    const tabButtons = document.querySelectorAll('.protocol-tab-button');
    const tabContents = document.querySelectorAll('.protocol-tab-content');

    tabButtons.forEach(button => {
        button.addEventListener('click', () => {
            const targetTab = button.getAttribute('data-protocol-tab');

            // Remove active class from all buttons and contents
            tabButtons.forEach(btn => btn.classList.remove('active'));
            tabContents.forEach(content => content.classList.remove('active'));

            // Add active class to clicked button and target content
            button.classList.add('active');
            const targetContent = document.getElementById(`protocol-${targetTab}`);
            if (targetContent) {
                targetContent.classList.add('active');
            }
        });
    });
}
    displayMacroTargets() {
        const container = document.getElementById('macroTargets');
        const macros = this.app.completeProtocol.macroTargets;
        
        const macroCards = [
            { label: 'Total Calories', value: macros.total_calories, unit: 'kcal' },
            { label: 'Protein', value: `${macros.protein_g}g (${macros.protein_pct}%)`, unit: '' },
            { label: 'Carbs', value: `${macros.carb_g}g (${macros.carb_pct}%)`, unit: '' },
            { label: 'Fat', value: `${macros.fat_g}g (${macros.fat_pct}%)`, unit: '' },
            { label: 'Deficit', value: macros.deficit_kcal, unit: 'kcal' },
            { label: 'TDEE', value: macros.tdee, unit: 'kcal' }
        ];
        
        container.innerHTML = macroCards.map(macro => `
            <div class="metric-card">
                <div class="metric-label">${macro.label}</div>
                <div class="metric-value">${macro.value} <span class="metric-unit">${macro.unit}</span></div>
            </div>
        `).join('');
    }

    displayMealPlan() {
        const container = document.getElementById('mealPlan');
        const mealPlan = this.app.completeProtocol.mealPlan;

        // Display meal planning strategy summary
        let strategyHtml = '';
        if (mealPlan.meal_planning_strategy) {
            const strategy = mealPlan.meal_planning_strategy;
            strategyHtml = `
                <div class="meal-strategy-summary" style="background: #ecf0f1; padding: 15px; border-radius: 8px; margin-bottom: 20px;">
                    <h4 style="margin: 0 0 10px 0; color: #2c3e50;">Meal Planning Strategy</h4>
                    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 10px; font-size: 0.9em;">
                        <div><strong>Meals per Day:</strong> ${strategy.meal_count}</div>
                        <div><strong>Fasting Window:</strong> ${strategy.fasting_hours} hours</div>
                        <div><strong>Eating Window:</strong> ${strategy.eating_window_hours} hours</div>
                    </div>
                    <div style="margin-top: 10px; padding-top: 10px; border-top: 1px solid #bdc3c7;">
                        <strong>Carb Strategy:</strong> ${strategy.strategy_description}
                    </div>
                </div>
            `;
        }

        const mealsHtml = mealPlan.dailySchedule.map(meal => {
            // Add visual indicator for zero-carb meals
            const isZeroCarb = meal.meal_metadata && meal.meal_metadata.is_zero_carb;
            const isPrimaryCarb = meal.meal_metadata && meal.meal_metadata.is_primary_carb_meal;

            let mealBadge = '';
            if (isPrimaryCarb) {
                mealBadge = '<span style="background: #e74c3c; color: white; padding: 2px 8px; border-radius: 4px; font-size: 0.75em; margin-left: 10px;">ALL CARBS</span>';
            } else if (isZeroCarb) {
                mealBadge = '<span style="background: #27ae60; color: white; padding: 2px 8px; border-radius: 4px; font-size: 0.75em; margin-left: 10px;">ZERO CARB</span>';
            }

            return `
                <div class="schedule-item">
                    <div class="schedule-time">
                        ${meal.mealType.toUpperCase().replace(/_/g, ' ')} - ${meal.timeWindow}
                        ${mealBadge}
                    </div>
                    <div class="schedule-content">
                        <div class="nutrition-targets">
                            <strong>Targets:</strong> ${meal.nutritionalTargets.calories} calories,
                            ${meal.nutritionalTargets.protein} protein,
                            ${meal.nutritionalTargets.carbs} carbs,
                            ${meal.nutritionalTargets.fat} fat
                        </div>
                        <div class="meal-examples">
                            ${meal.exampleMeals.map(example => `
                                <div class="meal-example">
                                    <span class="meal-emoji">${example.emoji}</span>
                                    <div class="meal-details">
                                        <strong>${example.name}</strong>
                                        <div class="meal-description">${example.description}</div>
                                        <small>${example.culturalName} • ${example.nutritionalContent.calories} cal</small>
                                    </div>
                                </div>
                            `).join('')}
                        </div>
                    </div>
                </div>
            `;
        }).join('');

        container.innerHTML = strategyHtml + mealsHtml;
    }

    displayActivityPlan() {
        const container = document.getElementById('activityPlan');
        const activityPlan = this.app.completeProtocol.activityPlan;

        // Check if there are any activities
        if (!activityPlan.dailySchedule || activityPlan.dailySchedule.length === 0) {
            container.innerHTML = `
                <div style="padding: 20px; text-align: center; color: #7f8c8d; background: #ecf0f1; border-radius: 8px;">
                    <p style="margin: 0; font-size: 1.1em;">📋 No physical activities scheduled</p>
                    <p style="margin: 10px 0 0 0; font-size: 0.9em;">Activities can be added in Step 2: Baseline Input</p>
                </div>
            `;
            return;
        }

        container.innerHTML = activityPlan.dailySchedule.map(activity => `
            <div class="schedule-item">
                <div class="schedule-time">
                    ${activity.timeSlot.toUpperCase().replace('_', ' ')} - ${activity.timeWindow}
                </div>
                <div class="schedule-content">
                    ${activity.targets ? `
                        <div class="activity-targets">
                            <strong>Targets:</strong> ${activity.targets.duration},
                            ${activity.targets.intensity} intensity,
                            ${activity.targets.caloriesBurn} calories
                        </div>
                    ` : ''}
                    <div class="activity-examples">
                        ${activity.exampleRoutines.map(routine => `
                            <div class="activity-example">
                                <span class="activity-emoji">${routine.emoji}</span>
                                <div class="activity-details">
                                    <strong>${routine.name}</strong>
                                    <div class="activity-description">${routine.description}</div>
                                    <small>${routine.details.duration} • ${routine.details.frequency || routine.details.calories || ''}</small>
                                </div>
                            </div>
                        `).join('')}
                    </div>
                </div>
            </div>
        `).join('');
    }

    displayMedicationSchedule() {
        const container = document.getElementById('medicationSchedule');
        const medSchedule = this.app.completeProtocol.medicationSchedule;

        // Null check
        if (!medSchedule || !medSchedule.dailySchedule || medSchedule.dailySchedule.length === 0) {
            container.innerHTML = '<p class="info">No medications or supplements scheduled</p>';
            return;
        }

        container.innerHTML = medSchedule.dailySchedule.map(slot => {
            // Support both old format (timeSlot + timeDisplay) and new format (timeWindow)
            let timeText = '';
            let timeOfDay = '';

            if (slot.timeWindow) {
                // New format: use timeWindow
                timeText = slot.timeWindow;
                timeOfDay = slot.timeOfDay || 'morning';
            } else if (slot.timeDisplay) {
                // Old format: use timeDisplay
                timeText = slot.timeDisplay;
                timeOfDay = slot.timeSlot ? slot.timeSlot.toLowerCase() : 'morning';
            } else {
                timeText = 'Time not specified';
                timeOfDay = 'morning';
            }

            return `
                <div class="schedule-item">
                    <div class="schedule-time">
                        <div class="time-window">${timeText}</div>
                        <span class="time-of-day-badge ${timeOfDay}">${timeOfDay.toUpperCase()}</span>
                    </div>
                    <div class="schedule-content">
                        ${slot.medications.map(med => `
                            <div class="medication-schedule-item">
                                <span class="med-emoji">${med.emoji}</span>
                                <div class="med-details">
                                    <strong>${med.name}</strong> - ${med.dose}
                                    <div class="med-reason">${med.reason}</div>
                                    <small class="med-instructions">${med.instructions}</small>
                                </div>
                            </div>
                        `).join('')}
                    </div>
                </div>
            `;
        }).join('');
    }

    displaySafetyProtocol() {
        const container = document.getElementById('safetyProtocol');
        const safety = this.app.completeProtocol.safetyProtocol;

        container.innerHTML = `
            <div class="safety-section">
                <h5>Protocol Limits</h5>
                <ul class="safety-list">
                    <li><strong>Minimum Protein:</strong> ${safety.protocolLimits.minProtein}</li>
                    <li><strong>Minimum Calories:</strong> ${safety.protocolLimits.minCalories}</li>
                    <li><strong>Maximum Fasting:</strong> ${safety.protocolLimits.maxFastingPeriod}</li>
                </ul>
            </div>

            <div class="safety-section">
                <h5>Monitor for These Symptoms</h5>
                <ul class="caution-symptoms">
                    ${safety.cautionSymptoms.map(symptom => `<li>${symptom}</li>`).join('')}
                </ul>
            </div>

            <div class="safety-section">
                <h5>Contraindications</h5>
                <ul class="contraindications">
                    ${safety.contraindications.map(contraindication => `<li>${this.formatContraindication(contraindication)}</li>`).join('')}
                </ul>
            </div>

            <div class="safety-section">
                <h5>Emergency Symptoms (Seek Immediate Medical Attention)</h5>
                <ul class="emergency-symptoms">
                    ${safety.emergencySymptoms.map(symptom => `<li class="emergency">${symptom}</li>`).join('')}
                </ul>
            </div>

            <div class="safety-section">
                <h5>Emergency Contact</h5>
                <div class="emergency-contact">${safety.emergencyContact}</div>
            </div>
        `;
    }

    displayProtocolOverview() {
        const container = document.getElementById('protocolOverview');
        const overview = this.app.completeProtocol.protocolOverview;
        const patient = this.app.completeProtocol.patient;

        container.innerHTML = `
            <div class="overview-section">
                <h5>Patient Information</h5>
                <div class="patient-info-grid">
                    <div class="info-item">
                        <span class="info-label">Name:</span>
                        <span class="info-value">${patient.name}</span>
                    </div>
                    <div class="info-item">
                        <span class="info-label">Age:</span>
                        <span class="info-value">${patient.age} years</span>
                    </div>
                    <div class="info-item">
                        <span class="info-label">Current Phase:</span>
                        <span class="info-value">${patient.currentPhase}</span>
                    </div>
                    <div class="info-item">
                        <span class="info-label">Progress:</span>
                        <span class="info-value">${patient.progressPercentage}%</span>
                    </div>
                </div>
            </div>

            <div class="overview-section">
                <h5>Current Stage</h5>
                <div class="stage-card">
                    <h6>${overview.currentStage.name}</h6>
                    <p><strong>Duration:</strong> ${overview.currentStage.duration}</p>
                    <p><strong>Description:</strong> ${overview.currentStage.description}</p>
                    <p><strong>Expected Outcome:</strong> ${overview.currentStage.expectedOutcome}</p>
                </div>
            </div>

            <div class="overview-section">
                <h5>Upcoming Stages</h5>
                <div class="upcoming-stages">
                    ${overview.upcomingStages.map(stage => `
                        <div class="stage-card upcoming">
                            <h6>${stage.name}</h6>
                            <p>${stage.description}</p>
                        </div>
                    `).join('')}
                </div>
            </div>

            <div class="overview-section">
                <h5>Program Objectives</h5>
                <div class="objectives-card">
                    <p><strong>Primary Objective:</strong> ${overview.primaryObjective}</p>
                    <p><strong>Remission Definition:</strong> ${overview.remissionDefinition}</p>
                </div>
            </div>
        `;
    }

    displayWeeklyTargets() {
        const container = document.getElementById('weeklyTargets');

        if (!this.app.weeklyProgression || !this.app.weeklyProgression.weekly_targets) {
            container.innerHTML = '<p>Weekly progression data not available</p>';
            return;
        }

        const weeklyTargets = this.app.weeklyProgression.weekly_targets;

        container.innerHTML = `
            <div class="progression-summary-header">
                <h4>📊 Expected Program Outcomes</h4>
                <div class="projection-cards">
                    <div class="projection-card highlight">
                        <div class="card-icon">⚖️</div>
                        <div class="card-content">
                            <div class="card-label">Weight Loss</div>
                            <div class="card-value">${this.app.weeklyProgression.overall_projections.expected_weight_loss_kg} kg</div>
                            <div class="card-subtitle">Target achieved by week ${weeklyTargets.length}</div>
                        </div>
                    </div>
                    <div class="projection-card highlight">
                        <div class="card-icon">🎯</div>
                        <div class="card-content">
                            <div class="card-label">HbA1c Reduction</div>
                            <div class="card-value">${this.app.weeklyProgression.overall_projections.expected_hba1c_reduction}%</div>
                            <div class="card-subtitle">From ${weeklyTargets[0].targets.hba1c_pct}% to ${weeklyTargets[weeklyTargets.length-1].targets.hba1c_pct}%</div>
                        </div>
                    </div>
                    <div class="projection-card success">
                        <div class="card-icon">🏆</div>
                        <div class="card-content">
                            <div class="card-label">Remission Probability</div>
                            <div class="card-value">${(this.app.weeklyProgression.overall_projections.probability_remission * 100).toFixed(0)}%</div>
                            <div class="card-subtitle">Based on projected outcomes</div>
                        </div>
                    </div>
                    <div class="projection-card safe">
                        <div class="card-icon">✅</div>
                        <div class="card-content">
                            <div class="card-label">Safety Rating</div>
                            <div class="card-value">${(this.app.weeklyProgression.overall_projections.safety_score * 100).toFixed(0)}%</div>
                            <div class="card-subtitle">Program safety assessment</div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="metrics-visualization">
                <h4>📈 Projected Weekly Progression</h4>
                <p class="viz-subtitle">Expected improvements across all health metrics over ${weeklyTargets.length} weeks</p>

                ${this.renderMetricsDashboard(weeklyTargets)}
            </div>

            <div class="weekly-milestones">
                <h4>🎯 Key Milestones & Decision Points</h4>
                ${this.renderMilestonesTimeline(weeklyTargets)}
            </div>
        `;
    }

    renderMetricsDashboard(weeklyTargets) {
        const chartId = 'weeklyProgressionCharts';

        // Create container with canvas elements for charts
        setTimeout(() => {
            this.createAllCharts(weeklyTargets);
        }, 100);

        return `
            <div class="charts-container">
                <!-- Core Metrics Charts -->
                <div class="chart-section">
                    <h5>🎯 Core Health Metrics</h5>
                    <div class="chart-grid">
                        <div class="chart-wrapper">
                            <canvas id="weightChart"></canvas>
                        </div>
                        <div class="chart-wrapper">
                            <canvas id="hba1cChart"></canvas>
                        </div>
                    </div>
                    <div class="chart-grid">
                        <div class="chart-wrapper">
                            <canvas id="tirChart"></canvas>
                        </div>
                        <div class="chart-wrapper">
                            <canvas id="bodyfatChart"></canvas>
                        </div>
                    </div>
                </div>

                <!-- Pillar Scores Chart -->
                <div class="chart-section">
                    <h5>💪 Health Pillar Scores (0-100)</h5>
                    <div class="chart-wrapper-large">
                        <canvas id="pillarScoresChart"></canvas>
                    </div>
                </div>

                <!-- Metabolic Markers Charts -->
                <div class="chart-section">
                    <h5>🔬 Metabolic Markers</h5>
                    <div class="chart-grid">
                        <div class="chart-wrapper">
                            <canvas id="fbgChart"></canvas>
                        </div>
                        <div class="chart-wrapper">
                            <canvas id="cvChart"></canvas>
                        </div>
                    </div>
                </div>
            </div>
        `;
    }

    renderMilestonesTimeline(weeklyTargets) {
        const milestonesWithWeeks = [];

        weeklyTargets.forEach(week => {
            if (week.milestones && week.milestones.length > 0) {
                week.milestones.forEach(milestone => {
                    milestonesWithWeeks.push({
                        week: week.week,
                        ...milestone
                    });
                });
            }
        });

        if (milestonesWithWeeks.length === 0) {
            return '<p class="no-milestones">No specific milestones detected for this program duration.</p>';
        }

        const milestoneIcons = {
            'medication_review': '💊',
            'phase_transition': '🔄',
            'remission_assessment': '🏆',
            'safety_review': '⚠️'
        };

        return `
            <div class="milestones-timeline">
                ${milestonesWithWeeks.map(milestone => `
                    <div class="milestone-item ${milestone.type}">
                        <div class="milestone-week">Week ${milestone.week}</div>
                        <div class="milestone-icon">${milestoneIcons[milestone.type] || '📌'}</div>
                        <div class="milestone-content">
                            <div class="milestone-title">${milestone.type.replace(/_/g, ' ').toUpperCase()}</div>
                            <div class="milestone-description">${milestone.description}</div>
                            ${milestone.trigger ? `<div class="milestone-trigger">Trigger: ${milestone.trigger}</div>` : ''}
                        </div>
                    </div>
                `).join('')}
            </div>
        `;
    }

    createAllCharts(weeklyTargets) {
        // Destroy existing charts if they exist
        if (this.charts) {
            Object.values(this.charts).forEach(chart => {
                if (chart) chart.destroy();
            });
        }
        this.charts = {};

        const weeks = weeklyTargets.map(w => `Week ${w.week}`);

        // Weight Chart
        this.charts.weight = this.createLineChart('weightChart', {
            labels: weeks,
            datasets: [{
                label: 'Weight (kg)',
                data: weeklyTargets.map(w => w.targets.weight_kg),
                borderColor: '#8B5CF6',
                backgroundColor: 'rgba(139, 92, 246, 0.1)',
                tension: 0.4,
                fill: true
            }]
        }, 'Weight Progression', 'kg');

        // HbA1c Chart
        this.charts.hba1c = this.createLineChart('hba1cChart', {
            labels: weeks,
            datasets: [{
                label: 'HbA1c (%)',
                data: weeklyTargets.map(w => w.targets.hba1c_pct),
                borderColor: '#EF4444',
                backgroundColor: 'rgba(239, 68, 68, 0.1)',
                tension: 0.4,
                fill: true
            }]
        }, 'HbA1c Progression', '%');

        // Time in Range Chart
        this.charts.tir = this.createLineChart('tirChart', {
            labels: weeks,
            datasets: [{
                label: 'Time in Range (%)',
                data: weeklyTargets.map(w => w.targets.tir_pct),
                borderColor: '#10B981',
                backgroundColor: 'rgba(16, 185, 129, 0.1)',
                tension: 0.4,
                fill: true
            }]
        }, 'Time in Range', '%');

        // Body Fat Chart
        this.charts.bodyfat = this.createLineChart('bodyfatChart', {
            labels: weeks,
            datasets: [{
                label: 'Body Fat (%)',
                data: weeklyTargets.map(w => w.targets.bodyfat_pct),
                borderColor: '#6366F1',
                backgroundColor: 'rgba(99, 102, 241, 0.1)',
                tension: 0.4,
                fill: true
            }]
        }, 'Body Fat Percentage', '%');

        // Pillar Scores Multi-line Chart
        this.charts.pillars = this.createLineChart('pillarScoresChart', {
            labels: weeks,
            datasets: [
                {
                    label: 'Overall Score',
                    data: weeklyTargets.map(w => w.targets.overall_score),
                    borderColor: '#1F2937',
                    backgroundColor: 'rgba(31, 41, 55, 0.1)',
                    tension: 0.4
                },
                {
                    label: 'Safety Score',
                    data: weeklyTargets.map(w => w.targets.safety_score),
                    borderColor: '#28a745',
                    backgroundColor: 'rgba(40, 167, 69, 0.1)',
                    tension: 0.4
                },
                {
                    label: 'Glycemic Score',
                    data: weeklyTargets.map(w => w.targets.glycemic_score),
                    borderColor: '#3B82F6',
                    backgroundColor: 'rgba(59, 130, 246, 0.1)',
                    tension: 0.4
                },
                {
                    label: 'Metabolic Score',
                    data: weeklyTargets.map(w => w.targets.metabolic_score),
                    borderColor: '#6f42c1',
                    backgroundColor: 'rgba(111, 66, 193, 0.1)',
                    tension: 0.4
                },
                {
                    label: 'Liver Score',
                    data: weeklyTargets.map(w => w.targets.liver_score),
                    borderColor: '#d63384',
                    backgroundColor: 'rgba(214, 51, 132, 0.1)',
                    tension: 0.4
                },
                {
                    label: 'Pancreatic Score',
                    data: weeklyTargets.map(w => w.targets.pancreatic_score),
                    borderColor: '#0dcaf0',
                    backgroundColor: 'rgba(13, 202, 240, 0.1)',
                    tension: 0.4
                }
            ]
        }, 'Health Pillar Scores', 'Score (0-100)', { min: 0, max: 100 });

        // FBG Chart
        this.charts.fbg = this.createLineChart('fbgChart', {
            labels: weeks,
            datasets: [{
                label: 'Fasting Blood Glucose',
                data: weeklyTargets.map(w => w.targets.fbg_mgdl),
                borderColor: '#EC4899',
                backgroundColor: 'rgba(236, 72, 153, 0.1)',
                tension: 0.4,
                fill: true
            }]
        }, 'Fasting Blood Glucose', 'mg/dL');

        // CV Chart
        this.charts.cv = this.createLineChart('cvChart', {
            labels: weeks,
            datasets: [{
                label: 'Coefficient of Variation',
                data: weeklyTargets.map(w => w.targets.cv_pct),
                borderColor: '#14B8A6',
                backgroundColor: 'rgba(20, 184, 166, 0.1)',
                tension: 0.4,
                fill: true
            }]
        }, 'Glucose Variability (CV)', '%');
    }

    createLineChart(canvasId, data, title, yAxisLabel, yAxisOptions = {}) {
        const ctx = document.getElementById(canvasId);
        if (!ctx) {
            console.error(`Canvas with id ${canvasId} not found`);
            return null;
        }

        return new Chart(ctx, {
            type: 'line',
            data: data,
            options: {
                responsive: true,
                maintainAspectRatio: true,
                aspectRatio: 2,
                plugins: {
                    title: {
                        display: true,
                        text: title,
                        font: {
                            size: 16,
                            weight: 'bold'
                        },
                        padding: {
                            top: 10,
                            bottom: 20
                        }
                    },
                    legend: {
                        display: true,
                        position: 'top',
                        labels: {
                            usePointStyle: true,
                            padding: 15,
                            font: {
                                size: 12
                            }
                        }
                    },
                    tooltip: {
                        mode: 'index',
                        intersect: false,
                        backgroundColor: 'rgba(0, 0, 0, 0.8)',
                        padding: 12,
                        bodySpacing: 6,
                        titleFont: {
                            size: 14,
                            weight: 'bold'
                        },
                        bodyFont: {
                            size: 13
                        },
                        callbacks: {
                            label: function(context) {
                                let label = context.dataset.label || '';
                                if (label) {
                                    label += ': ';
                                }
                                if (context.parsed.y !== null) {
                                    label += context.parsed.y.toFixed(2) + ' ' + yAxisLabel;
                                }
                                return label;
                            }
                        }
                    }
                },
                scales: {
                    y: {
                        beginAtZero: false,
                        ...yAxisOptions,
                        title: {
                            display: true,
                            text: yAxisLabel,
                            font: {
                                size: 13,
                                weight: 'bold'
                            }
                        },
                        grid: {
                            color: 'rgba(0, 0, 0, 0.05)'
                        },
                        ticks: {
                            font: {
                                size: 11
                            }
                        }
                    },
                    x: {
                        title: {
                            display: true,
                            text: 'Program Week',
                            font: {
                                size: 13,
                                weight: 'bold'
                            }
                        },
                        grid: {
                            color: 'rgba(0, 0, 0, 0.05)'
                        },
                        ticks: {
                            font: {
                                size: 11
                            },
                            maxRotation: 45,
                            minRotation: 0
                        }
                    }
                },
                interaction: {
                    mode: 'nearest',
                    axis: 'x',
                    intersect: false
                }
            }
        });
    }

    populateReviewMedications() {
        const container = document.getElementById('reviewMedicationList');
        
        if (this.app.medications.length === 0) {
            container.innerHTML = '<p class="no-medications">No medications to review</p>';
            return;
        }

        container.innerHTML = `
            <div class="medication-review-grid">
                ${this.app.medications.map(med => `
                    <div class="medication-review-item">
                        <div class="med-review-header">
                            <strong>${med.name}</strong>
                            <span class="med-dose">${med.dose}</span>
                        </div>
                        <div class="med-review-controls">
                            <label>
                                <input type="radio" name="med_${med.id}" value="continue" checked>
                                Continue
                            </label>
                            <label>
                                <input type="radio" name="med_${med.id}" value="reduce">
                                Reduce Dose
                            </label>
                            <label>
                                <input type="radio" name="med_${med.id}" value="discontinue">
                                Discontinue
                            </label>
                        </div>
                        <div class="med-review-notes">
                            <input type="text" placeholder="Notes (optional)" class="med-notes" data-med-id="${med.id}">
                        </div>
                    </div>
                `).join('')}
            </div>
        `;
    }

    getMedicationReviewDecisions() {
        const decisions = [];
        
        this.app.medications.forEach(med => {
            const selectedOption = document.querySelector(`input[name="med_${med.id}"]:checked`);
            const notesInput = document.querySelector(`.med-notes[data-med-id="${med.id}"]`);
            
            if (selectedOption) {
                decisions.push({
                    medication_id: med.id,
                    medication_name: med.name,
                    decision: selectedOption.value,
                    notes: notesInput ? notesInput.value : ''
                });
            }
        });
        
        return decisions;
    }
}
// ProgressAssessor.js - Handles progress tracking, CGM data processing, and assessment

class ProgressAssessor {
    constructor(app) {
        this.app = app;
    }

    async handleFileUpload(file) {
        if (!file) return;
        
        if (!file.name.endsWith('.json')) {
            this.app.showMessage('Please upload a JSON file', 'error');
            return;
        }

        try {
            const text = await file.text();
            const cgmData = JSON.parse(text);
            
            this.processCGMData(cgmData);
            document.getElementById('progressForm').classList.remove('hidden');
            
        } catch (error) {
            this.app.showMessage('Error reading file: ' + error.message, 'error');
        }
    }

    processCGMData(cgmData) {
        // Process CGM data and display basic stats
        const uploadArea = document.getElementById('uploadArea');
        uploadArea.innerHTML = `
            <div class="upload-success">
                <div class="upload-icon">✅</div>
                <div class="upload-text">CGM Data Loaded Successfully</div>
                <div class="upload-subtext">${cgmData.length || 'Multiple'} readings processed</div>
            </div>
        `;
        
        // Store CGM data for progress assessment
        this.app.setCGMData(cgmData);
    }

    loadSampleData(progressType) {
        // Generate sample CGM data based on progress type
        const sampleData = this.generateSampleCGMData(progressType);
        
        this.processCGMData(sampleData);
        document.getElementById('progressForm').classList.remove('hidden');
        
        // Pre-fill some fields based on progress type
        const currentWeek = document.getElementById('currentWeek');
        currentWeek.value = 4; // Default to week 4
        
        if (progressType === 'good') {
            document.getElementById('currentHba1c').value = '6.8';
            document.getElementById('currentWeight').value = this.app.enhancedBaseline ? 
                (this.app.enhancedBaseline.patient_profile.demographics.weight_kg - 4).toString() : '';
        } else if (progressType === 'moderate') {
            document.getElementById('currentHba1c').value = '7.2';
            document.getElementById('currentWeight').value = this.app.enhancedBaseline ? 
                (this.app.enhancedBaseline.patient_profile.demographics.weight_kg - 2).toString() : '';
        } else if (progressType === 'poor') {
            document.getElementById('currentHba1c').value = '7.6';
            document.getElementById('currentWeight').value = this.app.enhancedBaseline ? 
                (this.app.enhancedBaseline.patient_profile.demographics.weight_kg - 0.5).toString() : '';
        }
        
        this.app.showMessage(`Loaded ${progressType} progress sample data`, 'success');
    }

    generateSampleCGMData(progressType) {
        // Generate realistic sample CGM data
        const dataPoints = [];
        const baseGlucose = progressType === 'good' ? 120 : progressType === 'moderate' ? 145 : 165;
        const variability = progressType === 'good' ? 20 : progressType === 'moderate' ? 35 : 50;
        
        for (let i = 0; i < 288; i++) { // 24 hours * 12 readings per hour
            const time = new Date();
            time.setMinutes(time.getMinutes() - (288 - i) * 5);
            
            const glucose = baseGlucose + (Math.random() - 0.5) * variability;
            
            dataPoints.push({
                timestamp: time.toISOString(),
                mgdl: Math.max(60, Math.min(300, glucose))
            });
        }
        
        return dataPoints;
    }

    async submitProgressForm(e) {
        e.preventDefault();
        
        if (!this.app.currentCGMData) {
            this.app.showMessage('Please upload CGM data first', 'error');
            return;
        }

        if (!this.app.completeProtocol) {
            this.app.showMessage('Please generate a protocol first', 'error');
            return;
        }

        try {
            this.app.uiManager.showLoading('progressForm');
            
            const progressData = this.collectProgressFormData();
            const progressResults = await this.assessProgress(progressData);
            
            this.displayProgressResults(progressResults);
            this.app.showMessage('Progress assessment completed', 'success');
            
        } catch (error) {
            this.app.showMessage(`Error assessing progress: ${error.message}`, 'error');
        } finally {
            this.app.uiManager.hideLoading('progressForm');
        }
    }

    collectProgressFormData() {
        return {
            currentWeek: parseInt(document.getElementById('currentWeek').value),
            currentHba1c: document.getElementById('currentHba1c').value ? 
                parseFloat(document.getElementById('currentHba1c').value) : null,
            currentWeight: document.getElementById('currentWeight').value ? 
                parseFloat(document.getElementById('currentWeight').value) : null,
            currentBodyfat: document.getElementById('currentBodyfat').value ? 
                parseFloat(document.getElementById('currentBodyfat').value) : null,
            cgmData: this.app.currentCGMData
        };
    }

    async assessProgress(progressData) {
        // Process CGM data to get current metrics
        const response = await fetch('/compute_now', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                cgm_samples: progressData.cgmData,
                labs: progressData.currentHba1c ? { hba1c_pct: progressData.currentHba1c } : {},
                body: {
                    weight_kg: progressData.currentWeight,
                    bodyfat_pct: progressData.currentBodyfat
                }
            })
        });
        
        if (!response.ok) {
            throw new Error('Failed to process current state');
        }
        
        const currentState = await response.json();
        
        // Get scoring against targets
        const scoringResponse = await fetch('/score', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                now: currentState,
                interim: { targets: this.getInterimTargets(progressData.currentWeek) },
                final: { targets: this.getFinalTargets() },
                prp: this.getPatientReferenceProfile()
            })
        });
        
        if (!scoringResponse.ok) {
            throw new Error('Failed to calculate scores');
        }
        
        const scores = await scoringResponse.json();
        
        return {
            currentState: currentState,
            scores: scores,
            weeklyProgress: this.calculateWeeklyProgress(progressData.currentWeek),
            milestones: this.detectMilestones(currentState, progressData.currentWeek),
            recommendations: this.generateRecommendations(scores, currentState)
        };
    }

    getInterimTargets(currentWeek) {
        if (!this.app.weeklyProgression) return {};
        
        const weekTarget = this.app.weeklyProgression.weekly_targets.find(w => w.week === currentWeek);
        if (!weekTarget) return {};
        
        return {
            hba1c_pct: { hi: weekTarget.targets.hba1c_pct },
            fbg_mgdl: { hi: weekTarget.targets.fbg_mgdl },
            tir_pct: { lo: 70 },
            cv_pct: { hi: 30 }
        };
    }

    getFinalTargets() {
        return {
            hba1c_pct: { hi: 6.5 },
            fbg_mgdl: { lo: 85, hi: 99 },
            tir_pct: { lo: 80 },
            cv_pct: { hi: 28 },
            ttb_min: { hi: 180 }
        };
    }

    getPatientReferenceProfile() {
        if (!this.app.enhancedBaseline) return {};
        
        return {
            metrics: {
                hba1c_pct: { mad: 0.5 },
                fbg_mgdl: { mad: 15 },
                tir_pct: { mad: 10 },
                cv_pct: { mad: 5 }
            }
        };
    }

    calculateWeeklyProgress(currentWeek) {
        if (!this.app.weeklyProgression) return null;
        
        const targetWeek = this.app.weeklyProgression.weekly_targets.find(w => w.week === currentWeek);
        const baselineWeek = this.app.weeklyProgression.weekly_targets.find(w => w.week === 1);
        
        if (!targetWeek || !baselineWeek) return null;
        
        return {
            expectedWeightLoss: baselineWeek.targets.weight_kg - targetWeek.targets.weight_kg,
            expectedHbA1cImprovement: baselineWeek.targets.hba1c_pct - targetWeek.targets.hba1c_pct,
            currentWeek: currentWeek
        };
    }

    detectMilestones(currentState, currentWeek) {
        const milestones = [];
        
        // Medication review milestone
        if (currentWeek % 4 === 0) {
            milestones.push({
                type: 'medication_review',
                message: 'Time for scheduled medication review',
                priority: 'medium'
            });
        }
        
        // Good progress milestone
        if (currentState.values.tir_pct > 75) {
            milestones.push({
                type: 'good_progress',
                message: 'Excellent glucose control achieved!',
                priority: 'low'
            });
        }
        
        // Warning milestones
        if (currentState.values.tir_pct < 50) {
            milestones.push({
                type: 'attention_needed',
                message: 'Glucose control needs attention',
                priority: 'high'
            });
        }

        // Weight loss milestones
        if (currentWeek >= 4 && this.app.enhancedBaseline) {
            const expectedWeight = this.app.enhancedBaseline.patient_profile.demographics.weight_kg - 
                (currentWeek * 0.5); // Expected 0.5kg/week loss
            const actualWeight = currentState.values.weight_kg;
            
            if (actualWeight && actualWeight < expectedWeight - 2) {
                milestones.push({
                    type: 'excessive_weight_loss',
                    message: 'Weight loss rate may be too rapid',
                    priority: 'high'
                });
            } else if (actualWeight && actualWeight > expectedWeight + 1) {
                milestones.push({
                    type: 'slow_progress',
                    message: 'Weight loss slower than expected',
                    priority: 'medium'
                });
            }
        }
        
        return milestones;
    }

    generateRecommendations(scores, currentState) {
        const recommendations = [];
        
        if (scores.overall < 60) {
            recommendations.push({
                type: 'protocol_adjustment',
                message: 'Consider adjusting protocol parameters',
                action: 'Review calorie deficit and medication timing'
            });
        }
        
        if (currentState.values.cv_pct > 35) {
            recommendations.push({
                type: 'glucose_variability',
                message: 'High glucose variability detected',
                action: 'Review meal timing and carbohydrate distribution'
            });
        }
        
        if (currentState.values.tir_pct > 80) {
            recommendations.push({
                type: 'excellent_progress',
                message: 'Outstanding progress!',
                action: 'Continue current protocol'
            });
        }

        if (currentState.values.fbg_mgdl > 130) {
            recommendations.push({
                type: 'fasting_glucose',
                message: 'Fasting glucose still elevated',
                action: 'Consider medication adjustment or timing review'
            });
        }

        if (currentState.values.mean_glucose_mgdl < 100) {
            recommendations.push({
                type: 'hypoglycemia_risk',
                message: 'Average glucose very low - monitor for hypoglycemia',
                action: 'Consider medication dose reduction'
            });
        }
        
        return recommendations;
    }

    displayProgressResults(results) {
        document.getElementById('progressResults').classList.remove('hidden');
        
        this.displayProgressScores(results.scores);
        this.displayCurrentMetrics(results.currentState);
        this.displayProgressCharts(results.currentState);
        this.displayMilestoneAlerts(results.milestones);
        this.displayRecommendations(results.recommendations);
    }

    displayProgressScores(scores) {
        const container = document.getElementById('progressScores');
        
        const scoreCards = [
            { label: 'Overall Score', value: scores.overall, unit: '%' },
            { label: 'Interim Score', value: scores.interim, unit: '%' },
            { label: 'Final Target Score', value: scores.final, unit: '%' }
        ];
        
        container.innerHTML = scoreCards.map(score => `
            <div class="metric-card ${this.getScoreClass(score.value)}">
                <div class="metric-label">${score.label}</div>
                <div class="metric-value">${score.value} <span class="metric-unit">${score.unit}</span></div>
            </div>
        `).join('');
    }

    displayCurrentMetrics(currentState) {
        const container = document.getElementById('progressScores');
        
        // Add current metrics below scores
        const metricsHtml = `
            <div class="current-metrics">
                <h4>Current Glucose Metrics</h4>
                <div class="metrics-grid">
                    <div class="metric-card">
                        <div class="metric-label">Time in Range</div>
                        <div class="metric-value">${currentState.values.tir_pct} <span class="metric-unit">%</span></div>
                    </div>
                    <div class="metric-card">
                        <div class="metric-label">Average Glucose</div>
                        <div class="metric-value">${Math.round(currentState.values.mean_glucose_mgdl)} <span class="metric-unit">mg/dL</span></div>
                    </div>
                    <div class="metric-card">
                        <div class="metric-label">Coefficient of Variation</div>
                        <div class="metric-value">${currentState.values.cv_pct} <span class="metric-unit">%</span></div>
                    </div>
                    <div class="metric-card">
                        <div class="metric-label">Fasting Glucose</div>
                        <div class="metric-value">${Math.round(currentState.values.fbg_mgdl)} <span class="metric-unit">mg/dL</span></div>
                    </div>
                </div>
            </div>
        `;
        
        container.innerHTML += metricsHtml;
    }

    getScoreClass(score) {
        if (score >= 80) return 'score-excellent';
        if (score >= 60) return 'score-good';
        if (score >= 40) return 'score-fair';
        return 'score-poor';
    }

    displayProgressCharts(currentState) {
        const container = document.getElementById('progressCharts');
        
        // Create simple visual representation of key metrics
        container.innerHTML = `
            <div class="chart-container">
                <h4>Progress Visualization</h4>
                <div class="progress-metrics">
                    <div class="progress-metric">
                        <label>Time in Range (Target: >70%)</label>
                        <div class="progress-bar">
                            <div class="progress-fill ${currentState.values.tir_pct >= 70 ? 'good' : 'needs-improvement'}" 
                                 style="width: ${Math.min(100, currentState.values.tir_pct)}%"></div>
                        </div>
                        <span>${currentState.values.tir_pct}%</span>
                    </div>
                    <div class="progress-metric">
                        <label>Coefficient of Variation (Target: <30%)</label>
                        <div class="progress-bar">
                            <div class="progress-fill ${currentState.values.cv_pct <= 30 ? 'good' : 'needs-improvement'}" 
                                 style="width: ${Math.min(100, currentState.values.cv_pct * 2)}%"></div>
                        </div>
                        <span>${currentState.values.cv_pct}%</span>
                    </div>
                    <div class="progress-metric">
                        <label>Average Glucose (Target: 100-140 mg/dL)</label>
                        <div class="metric-display ${this.getGlucoseClass(currentState.values.mean_glucose_mgdl)}">
                            ${Math.round(currentState.values.mean_glucose_mgdl)} mg/dL
                        </div>
                    </div>
                </div>
            </div>
        `;
    }

    getGlucoseClass(glucose) {
        if (glucose >= 100 && glucose <= 140) return 'good';
        if (glucose < 100 || glucose > 180) return 'poor';
        return 'fair';
    }

    displayMilestoneAlerts(milestones) {
        const container = document.getElementById('milestoneAlerts');
        
        if (!milestones || milestones.length === 0) {
            container.innerHTML = '<div class="no-milestones">No immediate milestones or alerts</div>';
            return;
        }
        
        container.innerHTML = `
            <h4>Milestones & Alerts</h4>
            ${milestones.map(milestone => `
                <div class="milestone-alert ${milestone.priority}">
                    <div class="milestone-type">${milestone.type.replace('_', ' ').toUpperCase()}</div>
                    <div class="milestone-message">${milestone.message}</div>
                </div>
            `).join('')}
        `;
    }

    displayRecommendations(recommendations) {
        if (!recommendations || recommendations.length === 0) return;
        
        const container = document.getElementById('milestoneAlerts');
        const recommendationsHtml = `
            <div class="recommendations-section">
                <h4>Clinical Recommendations</h4>
                ${recommendations.map(rec => `
                    <div class="recommendation ${rec.type}">
                        <strong>${rec.message}</strong>
                        <div class="recommendation-action">${rec.action}</div>
                    </div>
                `).join('')}
            </div>
        `;
        
        container.innerHTML += recommendationsHtml;
    }

    async updateProtocolProgression(currentWeek, adjustments) {
        if (!this.app.currentPatient) {
            throw new Error('No current patient selected');
        }

        try {
            const response = await fetch('/protocol/update_progression', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    patient_name: this.app.currentPatient.name,
                    current_week: currentWeek,
                    current_metrics: this.getCurrentMetrics(),
                    adjustments: adjustments
                })
            });
            
            if (!response.ok) {
                throw new Error('Failed to update protocol progression');
            }
            
            return await response.json();
        } catch (error) {
            console.error('Error updating progression:', error);
            throw error;
        }
    }

    getCurrentMetrics() {
        if (!this.app.currentCGMData) return {};
        
        // Get latest CGM reading
        const latestReading = this.app.currentCGMData[this.app.currentCGMData.length - 1];
        
        return {
            current_glucose: latestReading ? latestReading.mgdl : null,
            weight_kg: document.getElementById('currentWeight').value ? 
                parseFloat(document.getElementById('currentWeight').value) : null,
            hba1c_pct: document.getElementById('currentHba1c').value ? 
                parseFloat(document.getElementById('currentHba1c').value) : null,
            bodyfat_pct: document.getElementById('currentBodyfat').value ? 
                parseFloat(document.getElementById('currentBodyfat').value) : null
        };
    }
}
// Cross-browser compatible timepicker
class TimePicker {
    constructor() {
        this.pickers = new Map();
        this.initializeAllTimePickers();
    }

    initializeAllTimePickers() {
        // Find all time inputs
        const timeInputs = document.querySelectorAll('input[type="time"]');
        timeInputs.forEach(input => {
            this.convertToCustomPicker(input);
        });
    }

    convertToCustomPicker(input) {
        // Check if browser supports time input properly
        const testInput = document.createElement('input');
        testInput.type = 'time';
        const isSupported = testInput.type === 'time';

        // If browser supports it well (like Chrome), keep the native picker
        if (isSupported && !this.isFirefox()) {
            return;
        }

        // Create custom picker for Firefox and unsupported browsers
        this.createCustomPicker(input);
    }

    isFirefox() {
        return navigator.userAgent.toLowerCase().indexOf('firefox') > -1;
    }

    createCustomPicker(originalInput) {
        const wrapper = document.createElement('div');
        wrapper.className = 'custom-timepicker-wrapper';

        // Create hour select
        const hourSelect = document.createElement('select');
        hourSelect.className = 'custom-timepicker-hour';
        for (let i = 1; i <= 12; i++) {
            const option = document.createElement('option');
            option.value = i;
            option.textContent = i.toString().padStart(2, '0');
            hourSelect.appendChild(option);
        }

        // Create minute select
        const minuteSelect = document.createElement('select');
        minuteSelect.className = 'custom-timepicker-minute';
        for (let i = 0; i < 60; i += 5) {
            const option = document.createElement('option');
            option.value = i;
            option.textContent = i.toString().padStart(2, '0');
            minuteSelect.appendChild(option);
        }

        // Create AM/PM select
        const periodSelect = document.createElement('select');
        periodSelect.className = 'custom-timepicker-period';
        ['AM', 'PM'].forEach(period => {
            const option = document.createElement('option');
            option.value = period;
            option.textContent = period;
            periodSelect.appendChild(option);
        });

        // Add separators
        const separator1 = document.createElement('span');
        separator1.className = 'custom-timepicker-separator';
        separator1.textContent = ':';

        const separator2 = document.createElement('span');
        separator2.className = 'custom-timepicker-separator';
        separator2.textContent = '';

        // Assemble the picker
        wrapper.appendChild(hourSelect);
        wrapper.appendChild(separator1);
        wrapper.appendChild(minuteSelect);
        wrapper.appendChild(separator2);
        wrapper.appendChild(periodSelect);

        // Set initial value from input
        if (originalInput.value) {
            this.setCustomPickerValue(hourSelect, minuteSelect, periodSelect, originalInput.value);
        } else {
            // Set default value
            hourSelect.value = '8';
            minuteSelect.value = '0';
            periodSelect.value = 'AM';
        }

        // Update hidden input when custom picker changes
        const updateValue = () => {
            const hour = parseInt(hourSelect.value);
            const minute = minuteSelect.value;
            const period = periodSelect.value;

            let hour24 = hour;
            if (period === 'PM' && hour !== 12) {
                hour24 = hour + 12;
            } else if (period === 'AM' && hour === 12) {
                hour24 = 0;
            }

            originalInput.value = `${hour24.toString().padStart(2, '0')}:${minute}`;

            // Trigger change event
            const event = new Event('change', { bubbles: true });
            originalInput.dispatchEvent(event);
        };

        hourSelect.addEventListener('change', updateValue);
        minuteSelect.addEventListener('change', updateValue);
        periodSelect.addEventListener('change', updateValue);

        // Copy attributes from original input
        if (originalInput.id) wrapper.setAttribute('data-for', originalInput.id);
        if (originalInput.name) wrapper.setAttribute('data-name', originalInput.name);
        if (originalInput.required) {
            hourSelect.required = true;
            minuteSelect.required = true;
            periodSelect.required = true;
        }

        // Copy styles
        if (originalInput.style.flex) wrapper.style.flex = originalInput.style.flex;
        if (originalInput.className) wrapper.className += ' ' + originalInput.className;

        // Hide original input and insert custom picker
        originalInput.style.display = 'none';
        originalInput.parentNode.insertBefore(wrapper, originalInput.nextSibling);

        // Store reference
        this.pickers.set(originalInput, {
            wrapper,
            hourSelect,
            minuteSelect,
            periodSelect
        });
    }

    setCustomPickerValue(hourSelect, minuteSelect, periodSelect, timeValue) {
        // timeValue is in 24-hour format like "14:30"
        const [hours24, minutes] = timeValue.split(':');
        const hour24 = parseInt(hours24);

        let hour12 = hour24 % 12;
        if (hour12 === 0) hour12 = 12;

        const period = hour24 >= 12 ? 'PM' : 'AM';

        hourSelect.value = hour12;
        minuteSelect.value = minutes;
        periodSelect.value = period;
    }

    // Method to programmatically set value
    setValue(input, value) {
        const picker = this.pickers.get(input);
        if (picker) {
            this.setCustomPickerValue(picker.hourSelect, picker.minuteSelect, picker.periodSelect, value);
            input.value = value;
        } else {
            input.value = value;
        }
    }

    // Method to get value
    getValue(input) {
        return input.value;
    }

    // Reinitialize for dynamically added inputs
    initializeDynamicInput(input) {
        this.convertToCustomPicker(input);
    }
}

// Initialize on page load
let timePickerInstance;
if (typeof window !== 'undefined') {
    document.addEventListener('DOMContentLoaded', () => {
        timePickerInstance = new TimePicker();
        window.timePicker = timePickerInstance;
    });
}

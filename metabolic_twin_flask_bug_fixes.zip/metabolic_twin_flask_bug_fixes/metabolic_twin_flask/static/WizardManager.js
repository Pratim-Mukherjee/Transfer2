// WizardManager.js - Handles wizard navigation and state

class WizardManager {
    constructor(app) {
        this.app = app;
        this.currentStep = 2; // Start at step 2 (Baseline Input)
        this.completedSteps = [1]; // Step 1 (Patient Selection) completed when loaded
        this.maxAccessibleStep = 2;

        // Contraindication display names mapping
        this.contraindictionLabels = {
            'gallstone_history': 'History of Gallstones',
            'cardiovascular_disease': 'Severe Cardiovascular Disease',
            'kidney_disease': 'Chronic Kidney Disease',
            'eating_disorder_history': 'History of Eating Disorders'
        };

        this.initializeWizard();
    }

    formatContraindication(contraindication) {
        return this.contraindictionLabels[contraindication] || contraindication;
    }

    initializeWizard() {
        // Initialize review tab switching
        this.initializeReviewTabs();

        // Initialize protocol results tabs
        this.initializeProtocolTabs();

        // Set initial step
        this.goToStep(this.currentStep, false);
    }

    initializeReviewTabs() {
        const reviewButtons = document.querySelectorAll('.review-tab-button');
        reviewButtons.forEach(button => {
            button.addEventListener('click', () => {
                const tabName = button.getAttribute('data-review-tab');
                this.switchReviewTab(tabName);
            });
        });
    }

    initializeProtocolTabs() {
        const protocolButtons = document.querySelectorAll('.protocol-tab-button');
        protocolButtons.forEach(button => {
            button.addEventListener('click', () => {
                const tabName = button.getAttribute('data-protocol-tab');
                this.switchProtocolTab(tabName);
            });
        });
    }

    switchReviewTab(tabName) {
        // Hide all review tabs
        document.querySelectorAll('.review-tab-content').forEach(content => {
            content.classList.remove('active');
        });

        // Remove active from all buttons
        document.querySelectorAll('.review-tab-button').forEach(button => {
            button.classList.remove('active');
        });

        // Show selected tab
        const tabContent = document.getElementById(`review-${tabName}`);
        const tabButton = document.querySelector(`[data-review-tab="${tabName}"]`);

        if (tabContent) tabContent.classList.add('active');
        if (tabButton) tabButton.classList.add('active');
    }

    switchProtocolTab(tabName) {
        // Hide all protocol tabs
        document.querySelectorAll('.protocol-tab-content').forEach(content => {
            content.classList.remove('active');
        });

        // Remove active from all buttons
        document.querySelectorAll('.protocol-tab-button').forEach(button => {
            button.classList.remove('active');
        });

        // Show selected tab
        const tabContent = document.getElementById(`protocol-${tabName}`);
        const tabButton = document.querySelector(`[data-protocol-tab="${tabName}"]`);

        if (tabContent) tabContent.classList.add('active');
        if (tabButton) tabButton.classList.add('active');
    }

    goToStep(stepNumber, animate = true) {
        if (stepNumber < 1 || stepNumber > 5) {
            console.error('Invalid step number:', stepNumber);
            return;
        }

        // Update current step
        this.currentStep = stepNumber;

        // Hide all wizard content
        document.querySelectorAll('.wizard-content').forEach(content => {
            content.classList.remove('active');
        });

        // Show selected step content
        const stepContentMap = {
            1: null, // Patient selection is always visible
            2: 'step2-baseline-input',
            3: 'step3-baseline-review',
            4: 'step4-protocol-config',
            5: 'step5-protocol-results'
        };

        const contentId = stepContentMap[stepNumber];
        console.log(`Looking for content with ID: ${contentId}`);
        if (contentId) {
            const content = document.getElementById(contentId);
            console.log(`Found content element:`, content);
            if (content) {
                content.classList.add('active');
                console.log(`Added 'active' class to ${contentId}`);
            } else {
                console.error(`Element with ID '${contentId}' not found in DOM!`);
            }
        }

        // Update wizard progress indicator
        this.updateProgressIndicator(stepNumber);

        // Scroll to top
        window.scrollTo({ top: 0, behavior: animate ? 'smooth' : 'auto' });

        console.log(`Wizard navigated to step ${stepNumber}`);
    }

    updateProgressIndicator(currentStep) {
        // Update wizard step indicators
        document.querySelectorAll('.wizard-step').forEach((stepEl, index) => {
            const stepNum = index + 1;

            stepEl.classList.remove('active', 'completed');

            if (stepNum < currentStep) {
                stepEl.classList.add('completed');
            } else if (stepNum === currentStep) {
                stepEl.classList.add('active');
            }
        });

        // Update connectors
        document.querySelectorAll('.wizard-connector').forEach((connector, index) => {
            const stepNum = index + 1;

            if (stepNum < currentStep) {
                connector.classList.add('completed');
            } else {
                connector.classList.remove('completed');
            }
        });
    }

    markStepComplete(stepNumber) {
        if (!this.completedSteps.includes(stepNumber)) {
            this.completedSteps.push(stepNumber);
        }

        // Allow access to next step
        this.maxAccessibleStep = Math.max(this.maxAccessibleStep, stepNumber + 1);
    }

    canAccessStep(stepNumber) {
        return stepNumber <= this.maxAccessibleStep;
    }

    // Called after baseline form submission
    onBaselineComplete() {
        console.log('WizardManager: Baseline complete, navigating to review...');
        this.markStepComplete(2);
        this.populateBaselineReview();
        console.log('WizardManager: Review populated, navigating to step 3...');
        this.goToStep(3);
    }

    // Called after protocol generation
    onProtocolComplete() {
        this.markStepComplete(4);
        this.goToStep(5);
    }

    // Called when proceeding from Step 3 to Step 4
    async proceedToProtocolConfig() {
        try {
            // Calculate safe deficit range
            const programDuration = 12; // Default, will be updated when slider changes

            const response = await fetch('/protocol/calculate_deficit_recommendations', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    patient_profile: this.app.enhancedBaseline.patient_profile,
                    program_duration_weeks: programDuration
                })
            });

            const data = await response.json();

            console.log('Deficit recommendations:', data);

            if (data.safe_range && data.recommended) {
                // Store safe range for validation
                this.app.safeDeficitRange = data.safe_range;
                this.app.recommendedDeficit = data.recommended.recommended_deficit;

                // Update slider constraints
                this.updateDeficitSlider(data.safe_range, data.recommended.recommended_deficit);
            }

            // Proceed to step 4
            this.goToStep(4);

        } catch (error) {
            console.error('Error calculating deficit range:', error);
            this.app.showMessage('Could not calculate safe deficit range. Using defaults.', 'warning');
            this.goToStep(4);
        }
    }

    updateDeficitSlider(safeRange, recommendedDeficit) {
        const slider = document.getElementById('calorieDeficit');
        const rangeIndicator = document.getElementById('safeRangeIndicator');
        const recommendedInfo = document.getElementById('recommendedDeficitInfo');

        if (!slider) return;

        // Update slider min/max to safe range (convert from negative to positive)
        const minDeficit = Math.abs(safeRange.max_deficit); // Less aggressive
        const maxDeficit = Math.abs(safeRange.min_deficit); // More aggressive

        slider.min = minDeficit;
        slider.max = maxDeficit;
        slider.step = 50;

        // Set to recommended value
        const recommendedValue = Math.abs(recommendedDeficit);
        slider.value = recommendedValue;

        // Update display
        document.getElementById('deficitValue').textContent = `-${recommendedValue} kcal`;

        // Show safe range indicator
        if (rangeIndicator) {
            rangeIndicator.textContent = `(Safe range: -${minDeficit} to -${maxDeficit} kcal/day)`;
        }

        // Show recommended info
        if (recommendedInfo) {
            recommendedInfo.textContent = `✓ Recommended: -${recommendedValue} kcal/day based on patient profile`;
        }
    }

    populateBaselineReview() {
        if (!this.app.enhancedBaseline) {
            console.error('No baseline data to review');
            return;
        }

        const baseline = this.app.enhancedBaseline;
        const profile = baseline.patient_profile;

        // Populate Demographics
        this.populateDemographics(profile);

        // Populate Metabolic Profile
        this.populateMetabolicProfile(baseline);

        // Populate Deficit Recommendations
        this.populateDeficitRecommendations();

        // Populate Risk Analysis
        this.populateRiskAnalysis(profile);

        // Populate Medications
        this.populateMedications();
    }

    populateDemographics(profile) {
        console.log('Populating demographics...', profile);
        const container = document.getElementById('reviewDemographics');
        if (!container) {
            console.error('reviewDemographics container not found!');
            return;
        }

        const demographics = profile.demographics;
        const metabolic = profile.metabolic_baseline;

        // Calculate BMI if not present
        const bmi = metabolic.bmi || (demographics.weight_kg / Math.pow(demographics.height_cm / 100, 2));

        container.innerHTML = `
            <div class="review-item">
                <div class="review-item-label">Name</div>
                <div class="review-item-value">${demographics.name}</div>
            </div>
            <div class="review-item">
                <div class="review-item-label">Age</div>
                <div class="review-item-value">${demographics.age} years</div>
            </div>
            <div class="review-item">
                <div class="review-item-label">Gender</div>
                <div class="review-item-value">${demographics.gender}</div>
            </div>
            <div class="review-item">
                <div class="review-item-label">Height</div>
                <div class="review-item-value">${demographics.height_cm} cm</div>
            </div>
            <div class="review-item">
                <div class="review-item-label">Weight</div>
                <div class="review-item-value">${demographics.weight_kg} kg</div>
            </div>
            <div class="review-item">
                <div class="review-item-label">BMI</div>
                <div class="review-item-value">${bmi.toFixed(1)}</div>
            </div>
            <div class="review-item">
                <div class="review-item-label">HbA1c</div>
                <div class="review-item-value">${metabolic.hba1c_pct}%</div>
            </div>
            <div class="review-item">
                <div class="review-item-label">Fasting Glucose</div>
                <div class="review-item-value">${metabolic.fbg_mgdl} mg/dL</div>
            </div>
            <div class="review-item">
                <div class="review-item-label">Body Fat</div>
                <div class="review-item-value">${metabolic.bodyfat_pct}%</div>
            </div>
            <div class="review-item">
                <div class="review-item-label">Triglycerides</div>
                <div class="review-item-value">${metabolic.tg_mg_dl || 'N/A'} mg/dL</div>
            </div>
            <div class="review-item">
                <div class="review-item-label">HDL</div>
                <div class="review-item-value">${metabolic.hdl_mg_dl || 'N/A'} mg/dL</div>
            </div>
            <div class="review-item">
                <div class="review-item-label">LDL</div>
                <div class="review-item-value">${metabolic.ldl_mg_dl || 'N/A'} mg/dL</div>
            </div>
        `;
    }

    populateMetabolicProfile(baseline) {
        const container = document.getElementById('reviewMetabolicProfile');
        if (!container) return;

        const metabolic = baseline.patient_profile.metabolic_baseline;
        const demographics = baseline.patient_profile.demographics;

        // Calculate metrics
        const bmi = demographics.weight_kg / Math.pow(demographics.height_cm / 100, 2);
        const tgHdlRatio = metabolic.tg_mg_dl / metabolic.hdl_mg_dl;

        // Display key metabolic metrics with color coding based on risk
        const metrics = [
            {
                label: 'BMI',
                value: bmi.toFixed(1),
                unit: 'kg/m²',
                color: bmi > 30 ? '#e74c3c' : bmi > 25 ? '#f39c12' : '#27ae60'
            },
            {
                label: 'HbA1c',
                value: metabolic.hba1c_pct,
                unit: '%',
                color: metabolic.hba1c_pct >= 7 ? '#e74c3c' : metabolic.hba1c_pct >= 6.5 ? '#f39c12' : '#27ae60'
            },
            {
                label: 'Body Fat',
                value: metabolic.bodyfat_pct,
                unit: '%',
                color: metabolic.bodyfat_pct > 35 ? '#e74c3c' : metabolic.bodyfat_pct > 25 ? '#f39c12' : '#27ae60'
            },
            {
                label: 'eGFR',
                value: metabolic.egfr || 'N/A',
                unit: metabolic.egfr ? 'mL/min/1.73m²' : '',
                color: metabolic.egfr ? (metabolic.egfr < 60 ? '#e74c3c' : metabolic.egfr < 90 ? '#f39c12' : '#27ae60') : '#95a5a6'
            },
            {
                label: 'TG/HDL Ratio',
                value: tgHdlRatio.toFixed(1),
                unit: '',
                color: tgHdlRatio > 3 ? '#e74c3c' : tgHdlRatio > 2 ? '#f39c12' : '#27ae60'
            },
            {
                label: 'Triglycerides',
                value: metabolic.tg_mg_dl,
                unit: 'mg/dL',
                color: metabolic.tg_mg_dl >= 200 ? '#e74c3c' : metabolic.tg_mg_dl >= 150 ? '#f39c12' : '#27ae60'
            },
            {
                label: 'HDL',
                value: metabolic.hdl_mg_dl,
                unit: 'mg/dL',
                color: metabolic.hdl_mg_dl < 40 ? '#e74c3c' : metabolic.hdl_mg_dl < 50 ? '#f39c12' : '#27ae60'
            }
        ];

        container.innerHTML = '<div class="review-grid">' +
            metrics.map(metric => `
                <div class="review-item" style="border-left: 4px solid ${metric.color}">
                    <div class="review-item-label">${metric.label}</div>
                    <div class="review-item-value">${metric.value} <span class="metric-unit">${metric.unit}</span></div>
                </div>
            `).join('') +
            '</div>';
    }

    populateDeficitRecommendations() {
        const container = document.getElementById('reviewDeficitRecommendation');
        if (!container) return;

        if (!this.app.deficitRecommendations) {
            container.style.display = 'none';
            return;
        }

        const recommendations = this.app.deficitRecommendations;

        container.innerHTML = `
            <h4>Calorie Deficit Recommendations</h4>
            <div class="review-grid">
                <div class="review-item">
                    <div class="review-item-label">Safe Range</div>
                    <div class="review-item-value">${recommendations.safe_range.min_deficit} to ${recommendations.safe_range.max_deficit} kcal/day</div>
                </div>
                <div class="review-item">
                    <div class="review-item-label">Recommended Deficit</div>
                    <div class="review-item-value">${recommendations.recommended.recommended_deficit} kcal/day</div>
                </div>
                <div class="review-item">
                    <div class="review-item-label">Target Weight Loss</div>
                    <div class="review-item-value">${recommendations.recommended.target_weight_loss_kg} kg over program</div>
                </div>
                <div class="review-item">
                    <div class="review-item-label">Weekly Target</div>
                    <div class="review-item-value">${recommendations.recommended.weekly_target_kg} kg/week</div>
                </div>
            </div>
        `;
    }

    populateRiskAnalysis(profile) {
        const container = document.getElementById('reviewRiskAnalysis');
        if (!container) return;

        const contraindications = profile.medical_history?.contraindications || [];
        const metabolic = profile.metabolic_baseline;

        let riskHtml = '<div class="review-grid">';

        // Kidney function - only show if there's a risk (eGFR < 90)
        if (metabolic.egfr && metabolic.egfr < 90) {
            const riskLevel = metabolic.egfr < 60 ? 'High Risk' : 'Moderate';
            const riskColor = metabolic.egfr < 60 ? '#e74c3c' : '#f39c12';

            riskHtml += `
                <div class="review-item" style="border-left-color: ${riskColor}">
                    <div class="review-item-label">Kidney Function (eGFR)</div>
                    <div class="review-item-value">${metabolic.egfr} mL/min - ${riskLevel}</div>
                </div>
            `;
        }

        // Contraindications
        if (contraindications.length > 0) {
            const formattedContraindications = contraindications.map(c => this.formatContraindication(c)).join(', ');
            riskHtml += `
                <div class="review-item" style="border-left-color: #e74c3c">
                    <div class="review-item-label">Contraindications</div>
                    <div class="review-item-value">${formattedContraindications}</div>
                </div>
            `;
        } else {
            riskHtml += `
                <div class="review-item" style="border-left-color: #27ae60">
                    <div class="review-item-label">Contraindications</div>
                    <div class="review-item-value">None identified</div>
                </div>
            `;
        }

        riskHtml += '</div>';
        container.innerHTML = riskHtml;
    }

    populateMedications() {
        const medContainer = document.getElementById('reviewMedications');
        const suppContainer = document.getElementById('reviewSupplements');

        console.log('Populating medications...', {
            app_medications: this.app.medications,
            baseline: this.app.enhancedBaseline,
            medical_history: this.app.enhancedBaseline?.patient_profile?.medical_history
        });

        // Get medications from baseline first (most reliable source)
        const medications = (this.app.enhancedBaseline?.patient_profile?.medical_history?.current_medications) ||
            (this.app.medications && this.app.medications.length > 0 ? this.app.medications : null) ||
            (this.app.currentPatient?.current_medications) || [];

        const supplements = (this.app.enhancedBaseline?.patient_profile?.medical_history?.current_supplements) ||
            (this.app.supplements && this.app.supplements.length > 0 ? this.app.supplements : null) ||
            (this.app.currentPatient?.current_supplements) || [];

        console.log('Medications found:', medications);
        console.log('Supplements found:', supplements);

        if (medContainer) {
            if (medications && medications.length > 0) {
                medContainer.innerHTML = '<h4>Current Medications</h4><div class="review-grid">' +
                    medications.map(med => {
                        // Show frequency_pattern if it exists, otherwise show frequency
                        const frequencyDisplay = med.frequency_pattern || med.frequency;
                        return `
                        <div class="review-item">
                            <div class="review-item-label">${med.name}</div>
                            <div class="review-item-value">${med.dose} - ${frequencyDisplay}${med.times && med.times.length > 0 ? ' at ' + med.times.join(', ') : ''}</div>
                        </div>
                        `;
                    }).join('') + '</div>';
            } else {
                medContainer.innerHTML = '<p>No medications recorded</p>';
            }
        }

        if (suppContainer) {
            if (supplements && supplements.length > 0) {
                suppContainer.innerHTML = '<h4>Current Supplements</h4><div class="review-grid">' +
                    supplements.map(supp => `
                        <div class="review-item">
                            <div class="review-item-label">${supp.name}</div>
                            <div class="review-item-value">${supp.dose} - ${supp.frequency || ''}${supp.times && supp.times.length > 0 ? ' at ' + supp.times.join(', ') : ''}</div>
                        </div>
                    `).join('') + '</div>';
            } else {
                suppContainer.innerHTML = '<p>No supplements recorded</p>';
            }
        }
    }
}
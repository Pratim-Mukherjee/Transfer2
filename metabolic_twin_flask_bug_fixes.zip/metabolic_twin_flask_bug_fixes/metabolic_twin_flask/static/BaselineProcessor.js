// BaselineProcessor.js - Handles enhanced baseline assessment and analysis

class BaselineProcessor {
    constructor(app) {
        this.app = app;
    }

    async submitBaselineForm(e) {
        e.preventDefault();
        console.log('BaselineProcessor: Form submitted!');

        if (!this.app.currentPatient) {
            this.app.showMessage('Please create or select a patient first', 'error');
            return;
        }

        // Validate body fat field before processing
        const bodyfatInput = document.getElementById('bodyfat');
        const bodyfatValue = bodyfatInput.value ? bodyfatInput.value.trim() : '';

        if (!bodyfatValue || bodyfatValue === '' || isNaN(parseFloat(bodyfatValue))) {
            this.app.showMessage('Body Fat (%) is required. Please enter a valid number or use "Calculate Body Fat %" button.', 'error');
            bodyfatInput.focus();
            bodyfatInput.style.borderColor = '#e74c3c';
            bodyfatInput.style.boxShadow = '0 0 5px rgba(231, 76, 60, 0.3)';
            return;
        }

        const bodyfatNum = parseFloat(bodyfatValue);
        if (bodyfatNum < 3 || bodyfatNum > 60) {
            this.app.showMessage('Body Fat (%) must be between 3% and 60%. Please enter a valid value.', 'error');
            bodyfatInput.focus();
            bodyfatInput.style.borderColor = '#e74c3c';
            bodyfatInput.style.boxShadow = '0 0 5px rgba(231, 76, 60, 0.3)';
            return;
        }

        try {
            this.app.uiManager.showLoading('enhancedBaselineForm');
            console.log('Step 1: Loading started');

            const formData = this.collectBaselineFormData();
            console.log('Step 2: Form data collected');

            const enhancedBaseline = this.buildEnhancedBaseline(formData);
            console.log('Step 3: Enhanced baseline built');

            // Validate baseline data
            const validationResponse = await this.validateBaseline(enhancedBaseline);
            console.log('Step 4: Validation complete', validationResponse);

            if (!validationResponse.valid) {
                console.log('Validation failed, returning early');
                this.showValidationErrors(validationResponse);
                return;
            }

            // Calculate deficit recommendations
            const deficitRecommendations = await this.calculateDeficitRecommendations(enhancedBaseline);
            console.log('Step 5: Deficit recommendations calculated');

            // Analyze supplement needs
            const supplementRecommendations = await this.analyzeSupplements(enhancedBaseline);
            console.log('Step 6: Supplements analyzed');

            // Store enhanced baseline and recommendations
            this.app.setEnhancedBaseline(enhancedBaseline);
            this.app.deficitRecommendations = deficitRecommendations;
            this.app.supplementRecommendations = supplementRecommendations;
            console.log('Step 7: Enhanced baseline and recommendations stored');

            // Display results
            this.displayBaselineResults(enhancedBaseline, deficitRecommendations, supplementRecommendations);
            console.log('Step 8: Results displayed');

            // Enable protocol generation tab (legacy)
            this.app.enableTabs(['baseline', 'protocol']);
            console.log('Step 9: Tabs enabled');

            // Wizard: Move to baseline review step
            console.log('Step 10: Checking for wizardManager...', this.app.wizardManager);
            if (this.app.wizardManager) {
                console.log('Step 11: Calling onBaselineComplete()...');
                this.app.wizardManager.onBaselineComplete();
            } else {
                console.error('ERROR: wizardManager not found!');
            }

            this.app.showMessage('Enhanced baseline profile generated successfully', 'success');
            console.log('Step 12: Success message shown');

        } catch (error) {
            console.error('BaselineProcessor CATCH block:', error);
            this.app.showMessage(`Error generating baseline: ${error.message}`, 'error');
        } finally {
            this.app.uiManager.hideLoading('enhancedBaselineForm');
        }
    }

    collectBaselineFormData() {
        const form = document.getElementById('enhancedBaselineForm');
        const formData = new FormData(form);

        // Collect contraindications
        const contraindications = [];
        document.querySelectorAll('input[name="contraindications"]:checked').forEach(checkbox => {
            contraindications.push(checkbox.value);
        });

        // Collect cultural food preferences (multiple selections allowed)
        const culturalPreferences = [];
        document.querySelectorAll('input[name="culturalPreferences"]:checked').forEach(checkbox => {
            culturalPreferences.push(checkbox.value);
        });

        // Get body fat data from calculator
        const bodyFatData = window.bodyFatCalculator ? window.bodyFatCalculator.getBodyFatData() : {
            bodyfat_pct: parseFloat(formData.get('bodyfat')),
            body_measurements: {}
        };

        // Get medications with times from medication manager
        const medications = window.medicationManager ? window.medicationManager.getMedications() : [];
        console.log('BaselineProcessor: Collected medications from manager:', medications);

        // Get supplements with times from supplement manager
        const supplements = window.supplementManager ? window.supplementManager.getSupplements() : [];
        console.log('BaselineProcessor: Collected supplements from manager:', supplements);

        // Get activities from activity manager
        const activities = this.app.activityManager ? this.app.activityManager.getActivities() : [];
        console.log('BaselineProcessor: Collected activities from manager:', activities);

        // Get lab results for supplement recommendations
        const labResults = {
            vitamin_b12: formData.get('vitaminB12') ? parseFloat(formData.get('vitaminB12')) : null,
            vitamin_d: formData.get('vitaminD') ? parseFloat(formData.get('vitaminD')) : null
        };

        return {
            // Demographics
            name: this.app.currentPatient.name,
            age: parseInt(formData.get('age')),
            gender: formData.get('gender'),
            height_cm: parseInt(formData.get('height')),
            weight_kg: parseFloat(formData.get('weight')),

            // Metabolic Parameters
            hba1c_pct: parseFloat(formData.get('hba1c')),
            fbg_mgdl: formData.get('fbg') ? parseFloat(formData.get('fbg')) : null,
            tg_mg_dl: parseFloat(formData.get('triglycerides')),
            hdl_mg_dl: parseFloat(formData.get('hdl')),
            ldl_mg_dl: formData.get('ldl') ? parseFloat(formData.get('ldl')) : null,
            bodyfat_pct: bodyFatData.bodyfat_pct,
            body_measurements: bodyFatData.body_measurements,
            egfr: formData.get('egfr') ? parseFloat(formData.get('egfr')) : null,
            creatinine_mg_dl: formData.get('creatinine') ? parseFloat(formData.get('creatinine')) : null,

            // Lab Results
            lab_results: labResults,

            // Lifestyle
            wake_time: formData.get('wakeTime'),
            sleep_time: formData.get('sleepTime'),
            work_start: formData.get('workStart'),
            work_end: formData.get('workEnd'),
            cultural_food_preferences: culturalPreferences,
            activity_level: formData.get('activityLevel'),

            // Physical Activities
            activities: activities,

            // Medical
            medications: medications,
            supplements: supplements,
            contraindications: contraindications
        };
    }

    buildEnhancedBaseline(formData) {
        return {
            patient_profile: {
                demographics: {
                    name: formData.name,
                    age: formData.age,
                    gender: formData.gender,
                    height_cm: formData.height_cm,
                    weight_kg: formData.weight_kg
                },
                metabolic_baseline: {
                    hba1c_pct: formData.hba1c_pct,
                    fbg_mgdl: formData.fbg_mgdl,
                    tg_mg_dl: formData.tg_mg_dl,
                    hdl_mg_dl: formData.hdl_mg_dl,
                    ldl_mg_dl: formData.ldl_mg_dl,
                    bodyfat_pct: formData.bodyfat_pct,
                    egfr: formData.egfr,
                    creatinine_mg_dl: formData.creatinine_mg_dl
                },
                lab_results: formData.lab_results || {},
                lifestyle_constraints: {
                    wake_time: formData.wake_time,
                    sleep_time: formData.sleep_time,
                    work_schedule: `${formData.work_start}-${formData.work_end}`,
                    cultural_food_preferences: formData.cultural_food_preferences,
                    activity_level: formData.activity_level,
                    physical_activities: formData.activities || []
                },
                medical_history: {
                    current_medications: formData.medications,
                    current_supplements: formData.supplements,
                    contraindications: formData.contraindications
                }
            }
        };
    }

    async validateBaseline(enhancedBaseline) {
        const response = await fetch('/protocol/validate_baseline', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ enhanced_baseline: enhancedBaseline })
        });
        
        if (!response.ok) {
            throw new Error('Validation failed');
        }
        
        return await response.json();
    }

    async calculateDeficitRecommendations(enhancedBaseline) {
        const response = await fetch('/protocol/calculate_deficit_recommendations', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ 
                patient_profile: enhancedBaseline.patient_profile,
                program_duration_weeks: 12
            })
        });
        
        if (!response.ok) {
            throw new Error('Failed to calculate deficit recommendations');
        }
        
        return await response.json();
    }

    async analyzeSupplements(enhancedBaseline) {
        const response = await fetch('/protocol/analyze_supplements', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ enhanced_baseline: enhancedBaseline })
        });
        
        if (!response.ok) {
            throw new Error('Failed to analyze supplements');
        }
        
        return await response.json();
    }

    displayBaselineResults(enhancedBaseline, deficitRecommendations, supplementRecommendations) {
        // Check if wizard mode - skip inline display if wizard is active
        const wizardMode = document.querySelectorAll('.wizard-content').length > 0;

        if (wizardMode) {
            console.log('Wizard mode: Skipping inline baseline results display');
            // Results will be shown in Step 3 (Baseline Review) instead
            return;
        }

        // Legacy mode: Show results container
        const resultsContainer = document.getElementById('baselineResults');
        if (!resultsContainer) {
            console.warn('baselineResults container not found');
            return;
        }

        resultsContainer.classList.remove('hidden');

        // Display baseline metrics
        this.displayBaselineMetrics(enhancedBaseline);

        // Display deficit recommendations
        this.displayDeficitRecommendations(deficitRecommendations);

        // Display supplement recommendations
        this.displaySupplementRecommendations(supplementRecommendations);
    }

    displayBaselineMetrics(enhancedBaseline) {
        const container = document.getElementById('baselineMetrics');
        const metabolic = enhancedBaseline.patient_profile.metabolic_baseline;
        const demographics = enhancedBaseline.patient_profile.demographics;
        
        // Calculate BMI
        const bmi = demographics.weight_kg / Math.pow(demographics.height_cm / 100, 2);
        
        // Calculate TG/HDL ratio
        const tgHdlRatio = metabolic.tg_mg_dl / metabolic.hdl_mg_dl;
        
        const metrics = [
            { label: 'BMI', value: bmi.toFixed(1), unit: 'kg/m²' },
            { label: 'HbA1c', value: metabolic.hba1c_pct, unit: '%' },
            { label: 'Body Fat', value: metabolic.bodyfat_pct, unit: '%' },
            { label: 'TG/HDL Ratio', value: tgHdlRatio.toFixed(1), unit: '' },
            { label: 'Triglycerides', value: metabolic.tg_mg_dl, unit: 'mg/dL' },
            { label: 'HDL', value: metabolic.hdl_mg_dl, unit: 'mg/dL' }
        ];
        
        container.innerHTML = metrics.map(metric => `
            <div class="metric-card">
                <div class="metric-label">${metric.label}</div>
                <div class="metric-value">${metric.value} <span class="metric-unit">${metric.unit}</span></div>
            </div>
        `).join('');
    }
displayDeficitRecommendations(recommendations) {
    const container = document.getElementById('deficitRecommendation');
    
    container.innerHTML = `
        <h4>Calorie Deficit Recommendations</h4>
        <div class="recommendation-grid">
            <div><strong>Safe Range:</strong> ${recommendations.safe_range.min_deficit} to ${recommendations.safe_range.max_deficit} kcal/day</div>
            <div><strong>Recommended:</strong> ${recommendations.recommended.recommended_deficit} kcal/day</div>
            <div><strong>Target Weight Loss:</strong> ${recommendations.recommended.target_weight_loss_kg} kg over program</div>
            <div><strong>Weekly Target:</strong> ${recommendations.recommended.weekly_target_kg} kg/week</div>
        </div>
    `;
    
    // Update slider range and default value - USING POSITIVE VALUES
    const deficitSlider = document.getElementById('calorieDeficit');
    deficitSlider.min = Math.abs(recommendations.safe_range.max_deficit);  // 300 (was -900)
    deficitSlider.max = Math.abs(recommendations.safe_range.min_deficit);  // 900 (was -300)
    deficitSlider.value = Math.abs(recommendations.recommended.recommended_deficit);  // 600 (was -600)
    deficitSlider.dispatchEvent(new Event('input'));  // Trigger the event listener to update display
}

    displaySupplementRecommendations(recommendations) {
        const container = document.getElementById('supplementRecommendations');
        
        if (!recommendations.supplement_recommendations || Object.keys(recommendations.supplement_recommendations).length === 0) {
            container.innerHTML = '<div class="protocol-display"><h4>Supplement Analysis</h4><p>No specific supplement recommendations at this time.</p></div>';
            return;
        }

        const supplements = recommendations.supplement_recommendations;
        let supplementsHtml = '<div class="protocol-display"><h4>Recommended Supplements</h4>';
        
        Object.entries(supplements).forEach(([name, details]) => {
            if (name.startsWith('_')) return; // Skip metadata
            
            supplementsHtml += `
                <div class="supplement-item">
                    <div class="supplement-header">
                        <strong>${name.replace(/_/g, ' ').toUpperCase()}</strong>
                        <span class="supplement-dose">${details.dose}</span>
                    </div>
                    <div class="supplement-details">
                        <div><strong>Timing:</strong> ${details.timing.replace(/_/g, ' ')}</div>
                        <div><strong>Rationale:</strong> ${details.rationale}</div>
                        <div><strong>Category:</strong> ${details.category.replace(/_/g, ' ')}</div>
                    </div>
                </div>
            `;
        });
        
        supplementsHtml += '</div>';
        container.innerHTML = supplementsHtml;
    }

    showValidationErrors(validation) {
        let message = 'Validation Issues:\n';
        
        if (validation.errors && validation.errors.length > 0) {
            message += '\nErrors:\n' + validation.errors.join('\n');
        }
        
        if (validation.warnings && validation.warnings.length > 0) {
            message += '\nWarnings:\n' + validation.warnings.join('\n');
        }
        
        if (validation.suggestions && validation.suggestions.length > 0) {
            message += '\nSuggestions:\n' + validation.suggestions.join('\n');
        }
        
        this.app.showMessage(message, 'warning');
    }
}
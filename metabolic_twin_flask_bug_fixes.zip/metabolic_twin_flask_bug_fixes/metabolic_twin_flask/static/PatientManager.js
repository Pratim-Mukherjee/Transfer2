// PatientManager.js - Handles patient selection and data loading from external API

class PatientManager {
    constructor(app) {
        this.app = app;
        this.currentPatientId = null;
        this.currentPatientData = null;
    }

    async loadExternalPatients() {
        try {
            this.app.showMessage('Loading patient list...', 'info');

            const response = await fetch('/api/external/patients');
            const data = await response.json();

            if (!data.success) {
                throw new Error(data.error || 'Failed to load patients');
            }

            const select = document.getElementById('externalPatientsSelect');
            select.innerHTML = '<option value="">Select patient from your list...</option>';

            data.patients.forEach(patient => {
                const option = document.createElement('option');
                option.value = patient.patient_id;
                option.textContent = `${patient.name} (Age: ${patient.age}${patient.has_protocol ? ' - Has Protocol' : ''})`;
                option.dataset.patientName = patient.name;
                option.dataset.hasProtocol = patient.has_protocol;
                select.appendChild(option);
            });

            this.app.showMessage(`Loaded ${data.patients.length} patients`, 'success');

        } catch (error) {
            console.error('Error loading external patients:', error);
            this.app.showMessage(`Error loading patients: ${error.message}`, 'error');
        }
    }

    async loadSelectedPatient() {
        const select = document.getElementById('externalPatientsSelect');
        const patientId = select.value;

        if (!patientId) {
            this.app.showMessage('Please select a patient', 'error');
            return;
        }

        const selectedOption = select.options[select.selectedIndex];
        const patientName = selectedOption.dataset.patientName;
        const hasProtocol = selectedOption.dataset.hasProtocol === 'true';

        try {
            this.app.showMessage(`Loading data for ${patientName}...`, 'info');

            this.currentPatientId = patientId;

            // Check if protocol exists
            console.log(`Checking for existing protocol for patient: ${patientId}`);
            const protocolCheck = await fetch(`/api/external/patient/${patientId}/protocol/check`);
            const protocolData = await protocolCheck.json();

            console.log('Protocol check response:', protocolData);

            if (protocolData.success && protocolData.exists && protocolData.protocol) {
                // Protocol exists and was retrieved - load for viewing
                console.log(`Existing protocol found for ${patientName}`);
                await this.loadExistingProtocol(patientId, patientName, protocolData);
            } else {
                // No protocol - load reports for new protocol creation
                console.log(`No existing protocol for ${patientName}, loading reports for new protocol`);
                await this.loadReportsForNewProtocol(patientId, patientName);
            }

        } catch (error) {
            console.error('Error loading patient:', error);
            this.app.showMessage(`Error loading patient: ${error.message}`, 'error');
        }
    }

    async loadExistingProtocol(patientId, patientName, protocolData) {
        try {
            this.app.showMessage(`Loading existing protocol for ${patientName}...`, 'info');

            // Set current patient
            this.app.setCurrentPatient({
                patient_id: patientId,
                name: patientName,
                has_protocol: true
            });

            // Load the existing protocol data
            const protocol = protocolData.protocol;
            const weeklyTargets = protocolData.weekly_targets;

            // Store protocol for viewing
            this.app.setCompleteProtocol(protocol);
            if (weeklyTargets) {
                this.app.setWeeklyProgression(weeklyTargets);
            }

            // Mark wizard steps as accessible
            this.app.wizardManager.markStepComplete(1); // Patient selected
            this.app.wizardManager.markStepComplete(2); // Can go to baseline
            this.app.wizardManager.markStepComplete(3); // Can review
            this.app.wizardManager.markStepComplete(4); // Can configure

            // Display protocol results
            this.app.protocolGenerator.displayProtocolResults(protocol, weeklyTargets);

            // Navigate to Step 5 to show existing protocol
            this.app.wizardGoToStep(5);

            // Show "Enter New Baseline" button and hide "Back to Config" button for existing protocols
            const backButton = document.getElementById('step5-back');
            const newBaselineButton = document.getElementById('step5-new-baseline');
            if (backButton) backButton.style.display = 'none';
            if (newBaselineButton) newBaselineButton.style.display = 'inline-block';

            this.app.showMessage(`Existing protocol loaded. Review below or click "Enter New Baseline Data" to update.`, 'success');

        } catch (error) {
            console.error('Error loading existing protocol:', error);
            this.app.showMessage(`Error loading protocol: ${error.message}`, 'error');
        }
    }

    async loadReportsForNewProtocol(patientId, patientName) {
        try {
            this.app.showMessage(`Loading medical reports for ${patientName}...`, 'info');

            // Fetch medical reports
            const response = await fetch(`/api/external/patient/${patientId}/reports`);
            const data = await response.json();

            if (!data.success) {
                throw new Error(data.error || 'Failed to load patient reports');
            }

            // Set current patient
            this.app.setCurrentPatient({
                patient_id: patientId,
                name: patientName,
                has_protocol: false
            });

            // Store baseline data
            this.app.setEnhancedBaseline(data.enhanced_baseline);

            // Populate baseline form from reports
            this.populateBaselineFromReports(data.form_data);

            // Navigate to Step 2 (Baseline Input)
            this.app.wizardManager.markStepComplete(1); // Patient selected
            this.app.wizardGoToStep(2);

            this.app.showMessage(`Loaded medical reports for ${patientName}. Please review and update baseline data.`, 'success');

        } catch (error) {
            console.error('Error loading reports:', error);
            this.app.showMessage(`Error loading reports: ${error.message}`, 'error');
        }
    }

    populateBaselineFromReports(formData) {
        if (!formData) return;

        // Populate demographics
        if (formData.demographics) {
            this.setFormValue('age', formData.demographics.age);
            this.setFormValue('gender', formData.demographics.gender);
            this.setFormValue('height', formData.demographics.height_cm);
            this.setFormValue('weight', formData.demographics.weight_kg);

            // Trigger gender change to show/hide hip circumference field
            if (window.bodyFatCalculator) {
                window.bodyFatCalculator.handleGenderChange();
            }
        }

        // Populate metabolic data
        if (formData.metabolic) {
            this.setFormValue('hba1c', formData.metabolic.hba1c_pct);
            this.setFormValue('fbg', formData.metabolic.fbg_mgdl);
            this.setFormValue('triglycerides', formData.metabolic.tg_mg_dl);
            this.setFormValue('hdl', formData.metabolic.hdl_mg_dl);
            this.setFormValue('ldl', formData.metabolic.ldl_mg_dl);
            this.setFormValue('egfr', formData.metabolic.egfr);
            this.setFormValue('creatinine', formData.metabolic.creatinine_mg_dl);

            // Populate body fat using body fat calculator
            if (window.bodyFatCalculator) {
                window.bodyFatCalculator.populateFromData(formData.metabolic, formData.body_measurements || {});
            } else {
                this.setFormValue('bodyfat', formData.metabolic.bodyfat_pct);
            }
        }

        // Populate body measurements
        if (formData.body_measurements) {
            this.setFormValue('waistCircumference', formData.body_measurements.waist_cm);
            this.setFormValue('neckCircumference', formData.body_measurements.neck_cm);
            this.setFormValue('hipCircumference', formData.body_measurements.hip_cm);
        }

        // Populate laboratory results
        if (formData.lab_results) {
            this.setFormValue('vitaminB12', formData.lab_results.vitamin_b12);
            this.setFormValue('vitaminD', formData.lab_results.vitamin_d);
        }

        // Populate lifestyle
        if (formData.lifestyle) {
            this.setFormValue('wakeTime', formData.lifestyle.wake_time);
            this.setFormValue('sleepTime', formData.lifestyle.sleep_time);
            this.setFormValue('workStart', formData.lifestyle.work_start);
            this.setFormValue('workEnd', formData.lifestyle.work_end);
            this.setFormValue('culturalPreference', formData.lifestyle.cultural_food_preference);
            this.setFormValue('activityLevel', formData.lifestyle.activity_level);
        }

        // Populate medications using medication manager
        console.log('PatientManager: Populating medications...', formData.medications);
        if (formData.medications && formData.medications.length > 0) {
            if (window.medicationManager) {
                console.log('PatientManager: Using medicationManager to populate', formData.medications);
                window.medicationManager.populateFromData(formData.medications);
            } else {
                console.log('PatientManager: medicationManager not found, using app.setMedications');
                this.app.setMedications(formData.medications);
            }
        } else {
            console.log('PatientManager: No medications in patient data');
        }

        // Populate supplements using supplement manager
        console.log('PatientManager: Populating supplements...', formData.supplements);
        if (formData.supplements && formData.supplements.length > 0) {
            if (window.supplementManager) {
                console.log('PatientManager: Using supplementManager to populate', formData.supplements);
                window.supplementManager.populateFromData(formData.supplements);
            }
        } else {
            console.log('PatientManager: No supplements in patient data');
        }

        // Populate contraindications
        if (formData.contraindications && formData.contraindications.length > 0) {
            formData.contraindications.forEach(contraindication => {
                const checkbox = document.querySelector(`input[name="contraindications"][value="${contraindication}"]`);
                if (checkbox) {
                    checkbox.checked = true;
                }
            });
        }
    }

    populateBaselineFromProtocol(protocol) {
        // Extract patient data from protocol and populate form
        if (protocol.patient) {
            this.setFormValue('age', protocol.patient.age);
        }

        // Note: Protocol may not have all baseline fields
        // For full baseline, you might need to fetch reports separately
        this.app.showMessage('Protocol loaded. Some baseline fields may need manual entry for modifications.', 'info');
    }

    setFormValue(fieldId, value) {
        const field = document.getElementById(fieldId);
        if (field && value !== null && value !== undefined) {
            field.value = value;
        }
    }
}
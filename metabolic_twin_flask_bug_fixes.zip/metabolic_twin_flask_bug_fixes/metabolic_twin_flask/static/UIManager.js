// UIManager.js - Handles all UI interactions, state management, and display logic

class UIManager {
    constructor(app) {
        this.app = app;
    }

    initializeEventListeners() {
        // Patient Management - External API
        document.getElementById('loadExternalPatientBtn').addEventListener('click', () => this.app.patientManager.loadSelectedPatient());
        document.getElementById('refreshPatientsBtn').addEventListener('click', () => this.app.patientManager.loadExternalPatients());

        // Form Submissions
        document.getElementById('enhancedBaselineForm').addEventListener('submit', (e) => this.app.baselineProcessor.submitBaselineForm(e));
        document.getElementById('protocolForm').addEventListener('submit', (e) => this.app.protocolGenerator.submitProtocolForm(e));

        // Medication Management
        document.getElementById('addMedicationBtn').addEventListener('click', () => this.handleAddMedication());

        // Publish Protocol
        document.getElementById('step5-publish').addEventListener('click', () => this.publishProtocol());
    }
initializeSliders() {
    // Program Duration Slider
    const durationSlider = document.getElementById('programDuration');
    const durationValue = document.getElementById('durationValue');
    
    if (durationSlider && durationValue) {
        durationSlider.addEventListener('input', (e) => {
            durationValue.textContent = `${e.target.value} weeks`;
        });
    }

    // Calorie Deficit Slider - USE POSITIVE VALUES, DISPLAY AS NEGATIVE
    const deficitSlider = document.getElementById('calorieDeficit');
    const deficitValue = document.getElementById('deficitValue');
    
    if (deficitSlider && deficitValue) {
        deficitSlider.addEventListener('input', (e) => {
            const negativeValue = -parseInt(e.target.value);
            deficitValue.textContent = `${negativeValue} kcal`;
        });
    }
}
    initializeTabs() {
        const tabButtons = document.querySelectorAll('.tab-button');
        
        tabButtons.forEach(button => {
            button.addEventListener('click', () => {
                if (!button.disabled) {
                    this.switchTab(button.dataset.tab);
                }
            });
        });
    }

    initializeFileUpload() {
        const uploadArea = document.getElementById('uploadArea');
        const fileInput = document.getElementById('fileInput');

        uploadArea.addEventListener('click', () => fileInput.click());
        uploadArea.addEventListener('dragover', (e) => {
            e.preventDefault();
            uploadArea.classList.add('dragover');
        });
        uploadArea.addEventListener('dragleave', () => {
            uploadArea.classList.remove('dragover');
        });
        uploadArea.addEventListener('drop', (e) => {
            e.preventDefault();
            uploadArea.classList.remove('dragover');
            this.app.progressAssessor.handleFileUpload(e.dataTransfer.files[0]);
        });

        fileInput.addEventListener('change', (e) => {
            this.app.progressAssessor.handleFileUpload(e.target.files[0]);
        });
    }

    switchTab(tabName) {
        // Legacy method - now handled by wizard
        // Check if we're using wizard or old tabs
        const wizardContent = document.querySelectorAll('.wizard-content');

        if (wizardContent.length > 0) {
            // Wizard mode - delegate to wizard navigation
            console.log('Wizard mode active - use wizardGoToStep instead');
            return;
        }

        // Old tab system (fallback)
        // Hide all tab contents
        document.querySelectorAll('.tab-content').forEach(content => {
            content.classList.remove('active');
        });

        // Remove active class from all buttons
        document.querySelectorAll('.tab-button').forEach(button => {
            button.classList.remove('active');
        });

        // Show selected tab and mark button as active
        const tabElement = document.getElementById(tabName);
        const tabButton = document.querySelector(`[data-tab="${tabName}"]`);

        if (tabElement) {
            tabElement.classList.add('active');
        }
        if (tabButton) {
            tabButton.classList.add('active');
        }
    }

    enableTabs(tabNames) {
        // Legacy method - now handled by wizard
        const wizardContent = document.querySelectorAll('.wizard-content');

        if (wizardContent.length > 0) {
            // Wizard mode - no tabs to enable
            return;
        }

        // Old tab system (fallback)
        // Disable all tabs first
        document.querySelectorAll('.tab-button').forEach(button => {
            button.disabled = true;
        });

        // Enable specified tabs
        tabNames.forEach(tabName => {
            const button = document.querySelector(`[data-tab="${tabName}"]`);
            if (button) {
                button.disabled = false;
            }
        });
    }

    displayCurrentPatient(patient) {
        const display = document.getElementById('currentPatientDisplay');

        if (patient) {
            const protocolIndicator = patient.has_protocol ? ' 📋 (Has existing protocol)' : '';
            display.textContent = `Current Patient: ${patient.name}${protocolIndicator}`;
            display.style.background = 'rgba(39, 174, 96, 0.3)';
        } else {
            display.textContent = 'No patient selected';
            display.style.background = 'rgba(255, 255, 255, 0.2)';
        }
    }

    handleAddMedication() {
        const name = document.getElementById('newMedicationName').value.trim();
        const dose = document.getElementById('newMedicationDose').value.trim();
        const frequency = document.getElementById('newMedicationFrequency').value;
        
        if (!name || !dose || !frequency) {
            this.showMessage('Please fill in all medication fields', 'error');
            return;
        }

        const medication = {
            name: name,
            dose: dose,
            frequency: frequency
        };

        this.app.addMedication(medication);
        
        // Clear inputs
        document.getElementById('newMedicationName').value = '';
        document.getElementById('newMedicationDose').value = '';
        document.getElementById('newMedicationFrequency').value = '';
    }

    updateMedicationDisplay(medications) {
        const container = document.getElementById('medicationList');
        
        if (medications.length === 0) {
            container.innerHTML = '<p style="color: #7f8c8d; font-style: italic;">No medications added yet</p>';
            return;
        }

        container.innerHTML = medications.map(med => `
            <div class="medication-item">
                <div class="medication-info">
                    <strong>${med.name}</strong> - ${med.dose} (${med.frequency.replace(/_/g, ' ')})
                </div>
                <div class="medication-actions">
                    <button type="button" class="btn btn-small btn-danger" onclick="app.removeMedication(${med.id})">Remove</button>
                </div>
            </div>
        `).join('');

        // Also update the medication review section if it exists
        if (document.getElementById('reviewMedicationList')) {
            this.app.protocolGenerator.populateReviewMedications();
        }
    }

    resetForms() {
        document.getElementById('enhancedBaselineForm').reset();
        document.getElementById('protocolForm').reset();
        document.getElementById('progressForm').reset();
        
        this.updateMedicationDisplay([]);
        
        // Hide result containers
        document.getElementById('baselineResults').classList.add('hidden');
        document.getElementById('protocolResults').classList.add('hidden');
        document.getElementById('progressResults').classList.add('hidden');
        document.getElementById('progressForm').classList.add('hidden');
        
        // Reset upload area
        document.getElementById('uploadArea').innerHTML = `
            <div class="upload-icon">📊</div>
            <div class="upload-text">Upload CGM Data</div>
            <div class="upload-subtext">Drop JSON file here or click to browse</div>
        `;

        // Reset sliders to default values
        document.getElementById('programDuration').value = 12;
        document.getElementById('durationValue').textContent = '12 weeks';
        document.getElementById('calorieDeficit').value = 600;
        document.getElementById('deficitValue').textContent = '-600 kcal';
    }

    showMessage(message, type = 'info') {
        // Remove existing messages
        const existingMessages = document.querySelectorAll('.message');
        existingMessages.forEach(msg => msg.remove());
        
        const messageDiv = document.createElement('div');
        messageDiv.className = `message ${type}`;
        messageDiv.textContent = message;
        
        // Insert at top of container
        const container = document.querySelector('.container');
        container.insertBefore(messageDiv, container.firstChild);
        
        // Auto-remove after 5 seconds
        setTimeout(() => {
            if (messageDiv.parentNode) {
                messageDiv.parentNode.removeChild(messageDiv);
            }
        }, 5000);
    }

    showLoading(formId) {
        const form = document.getElementById(formId);
        const submitBtn = form.querySelector('button[type="submit"]');
        const btnText = submitBtn.querySelector('.btn-text');
        
        submitBtn.disabled = true;
        btnText.innerHTML = '<span class="loading"></span>Processing...';
    }

    hideLoading(formId) {
        const form = document.getElementById(formId);
        const submitBtn = form.querySelector('button[type="submit"]');
        const btnText = submitBtn.querySelector('.btn-text');
        
        submitBtn.disabled = false;
        
        // Restore original text based on form
        if (formId === 'enhancedBaselineForm') {
            btnText.textContent = 'Generate Enhanced Baseline Profile';
        } else if (formId === 'protocolForm') {
            btnText.textContent = 'Generate Complete Protocol';
        } else if (formId === 'progressForm') {
            btnText.textContent = 'Assess Progress & Update Protocol';
        }
    }

    // Utility methods for form handling
    setFormValue(fieldId, value) {
        const field = document.getElementById(fieldId);
        if (field && value !== null && value !== undefined) {
            field.value = value;
        }
    }

    getFormValue(fieldId) {
        const field = document.getElementById(fieldId);
        return field ? field.value : null;
    }

    setCheckboxValue(fieldId, checked) {
        const field = document.getElementById(fieldId);
        if (field) {
            field.checked = checked;
        }
    }

    // Validation helpers
    validateRequired(fields) {
        const errors = [];
        
        fields.forEach(field => {
            const element = document.getElementById(field.id);
            if (!element || !element.value || element.value.trim() === '') {
                errors.push(`${field.label} is required`);
                this.highlightError(element);
            } else {
                this.clearError(element);
            }
        });
        
        return errors;
    }

    validateNumericRange(fieldId, min, max, label) {
        const element = document.getElementById(fieldId);
        const value = parseFloat(element.value);
        
        if (isNaN(value)) {
            this.highlightError(element);
            return [`${label} must be a valid number`];
        }
        
        if (value < min || value > max) {
            this.highlightError(element);
            return [`${label} must be between ${min} and ${max}`];
        }
        
        this.clearError(element);
        return [];
    }

    highlightError(element) {
        if (element) {
            element.style.borderColor = '#e74c3c';
            element.style.boxShadow = '0 0 5px rgba(231, 76, 60, 0.3)';
        }
    }

    clearError(element) {
        if (element) {
            element.style.borderColor = '';
            element.style.boxShadow = '';
        }
    }

    // Progress tracking helpers
    createProgressBar(percentage, className = '') {
        return `
            <div class="progress-bar ${className}">
                <div class="progress-fill" style="width: ${Math.min(100, Math.max(0, percentage))}%"></div>
            </div>
        `;
    }

    formatMetricCard(label, value, unit, className = '') {
        return `
            <div class="metric-card ${className}">
                <div class="metric-label">${label}</div>
                <div class="metric-value">${value} <span class="metric-unit">${unit}</span></div>
            </div>
        `;
    }

    // Animation helpers
    fadeIn(element, duration = 300) {
        element.style.opacity = '0';
        element.style.display = 'block';
        
        let start = performance.now();
        
        const animate = (time) => {
            const elapsed = time - start;
            const progress = Math.min(elapsed / duration, 1);
            
            element.style.opacity = progress;
            
            if (progress < 1) {
                requestAnimationFrame(animate);
            }
        };
        
        requestAnimationFrame(animate);
    }

    fadeOut(element, duration = 300) {
        let start = performance.now();
        const startOpacity = parseFloat(getComputedStyle(element).opacity);
        
        const animate = (time) => {
            const elapsed = time - start;
            const progress = Math.min(elapsed / duration, 1);
            
            element.style.opacity = startOpacity * (1 - progress);
            
            if (progress >= 1) {
                element.style.display = 'none';
            } else {
                requestAnimationFrame(animate);
            }
        };
        
        requestAnimationFrame(animate);
    }

    // Data export helpers
    exportProtocolData() {
        if (!this.app.completeProtocol || !this.app.currentPatient) {
            this.showMessage('No protocol data to export', 'error');
            return;
        }

        const exportData = {
            patient: this.app.currentPatient,
            baseline: this.app.enhancedBaseline,
            protocol: this.app.completeProtocol,
            weeklyProgression: this.app.weeklyProgression,
            exportDate: new Date().toISOString()
        };

        const dataStr = JSON.stringify(exportData, null, 2);
        const dataBlob = new Blob([dataStr], { type: 'application/json' });
        
        const link = document.createElement('a');
        link.href = URL.createObjectURL(dataBlob);
        link.download = `${this.app.currentPatient.name}_protocol_${new Date().toISOString().split('T')[0]}.json`;
        link.click();

        this.showMessage('Protocol data exported successfully', 'success');
    }

    async publishProtocol() {
        if (!this.app.completeProtocol || !this.app.weeklyProgression) {
            this.showMessage('No protocol data to publish', 'error');
            return;
        }

        if (!this.app.currentPatient || !this.app.currentPatient.patient_id) {
            this.showMessage('No patient selected', 'error');
            return;
        }

        const publishBtn = document.getElementById('step5-publish');
        const originalText = publishBtn.textContent;
        publishBtn.disabled = true;
        publishBtn.textContent = 'Publishing...';

        try {
            const patientId = this.app.currentPatient.patient_id;

            // Save protocol to main server (which will proxy to external API)
            const protocolResponse = await fetch(`/api/patients/${patientId}/protocol/save`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    protocol: this.app.completeProtocol
                })
            });

            if (!protocolResponse.ok) {
                throw new Error('Failed to save protocol');
            }

            // Save weekly targets to main server (which will proxy to external API)
            const weeklyResponse = await fetch(`/api/patient/${patientId}/weekly-targets/save`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    weekly_targets: this.app.weeklyProgression
                })
            });

            if (!weeklyResponse.ok) {
                throw new Error('Failed to save weekly targets');
            }

            const protocolResult = await protocolResponse.json();
            const weeklyResult = await weeklyResponse.json();

            console.log('Protocol published:', {
                protocol: protocolResult,
                weeklyTargets: weeklyResult
            });

            // Show success message
            this.showMessage('Protocol published successfully! Redirecting to patient selection...', 'success');

            // Mark button as completed (disable to prevent duplicate publish)
            publishBtn.disabled = true;
            publishBtn.textContent = '✓ Published';
            publishBtn.style.backgroundColor = '#27ae60';

            // Redirect to main screen after 2 seconds
            setTimeout(() => {
                // Reset app state
                this.app.currentPatient = null;
                this.app.enhancedBaseline = null;
                this.app.completeProtocol = null;
                this.app.weeklyProgression = null;
                this.app.medications = [];

                // Reset forms
                document.getElementById('enhancedBaselineForm').reset();
                document.getElementById('protocolForm').reset();

                // Reset button style for next use
                publishBtn.style.backgroundColor = '';
                publishBtn.textContent = 'Publish Protocol';
                publishBtn.disabled = false;

                // Navigate to step 1
                this.app.wizardGoToStep(1);

                // Update patient display
                this.displayCurrentPatient(null);
            }, 2000);

        } catch (error) {
            console.error('Error publishing protocol:', error);
            this.showMessage(`Failed to publish protocol: ${error.message}`, 'error');
            // Re-enable button on error
            publishBtn.disabled = false;
            publishBtn.textContent = originalText;
        }
    }
}

// Additional CSS classes that should be added to styles.css
const additionalUIStyles = `
/* Additional UI styles for enhanced functionality */

.loading {
    display: inline-block;
    width: 20px;
    height: 20px;
    border: 3px solid rgba(255, 255, 255, 0.3);
    border-radius: 50%;
    border-top-color: #fff;
    animation: spin 1s ease-in-out infinite;
    margin-right: 10px;
}

@keyframes spin {
    to { transform: rotate(360deg); }
}

.message {
    padding: 15px;
    border-radius: 6px;
    margin: 10px 0;
    font-weight: 500;
    position: relative;
    z-index: 1000;
}

.message.error {
    background: #ffebee;
    color: #c62828;
    border: 1px solid #e57373;
}

.message.success {
    background: #e8f5e8;
    color: #2e7d32;
    border: 1px solid #81c784;
}

.message.warning {
    background: #fff3e0;
    color: #ef6c00;
    border: 1px solid #ffb74d;
}

.status-badge {
    background: #3498db;
    color: white;
    padding: 2px 8px;
    border-radius: 12px;
    font-size: 0.8em;
    margin-left: 10px;
}

.status-completed { background: #27ae60; }
.status-current { background: #f39c12; }
.status-upcoming { background: #95a5a6; }

.meal-example, .activity-example, .medication-schedule-item {
    display: flex;
    align-items: center;
    gap: 10px;
    margin: 8px 0;
    padding: 8px;
    background: white;
    border-radius: 6px;
    border: 1px solid #ecf0f1;
}

.meal-emoji, .activity-emoji, .med-emoji {
    font-size: 1.5em;
    min-width: 30px;
}

.meal-description, .activity-description {
    font-size: 0.9em;
    color: #7f8c8d;
    margin-top: 4px;
}

.emergency {
    color: #e74c3c;
    font-weight: bold;
}

.emergency-contact {
    background: #e74c3c;
    color: white;
    padding: 15px;
    border-radius: 6px;
    text-align: center;
    font-size: 1.1em;
    font-weight: bold;
}

.safety-list, .caution-symptoms, .contraindications, .emergency-symptoms {
    list-style: none;
    padding: 0;
}

.safety-list li, .caution-symptoms li, .contraindications li, .emergency-symptoms li {
    padding: 8px 0;
    border-bottom: 1px solid #ecf0f1;
}

.score-excellent { border-left-color: #27ae60; }
.score-good { border-left-color: #f39c12; }
.score-fair { border-left-color: #e67e22; }
.score-poor { border-left-color: #e74c3c; }

.progress-bar {
    width: 100%;
    height: 20px;
    background: #ecf0f1;
    border-radius: 10px;
    overflow: hidden;
    margin: 5px 0;
}

.progress-fill {
    height: 100%;
    background: #27ae60;
    transition: width 0.3s ease;
}

.progress-fill.good { background: #27ae60; }
.progress-fill.fair { background: #f39c12; }
.progress-fill.needs-improvement { background: #e74c3c; }

.milestone-alert {
    padding: 12px;
    margin: 8px 0;
    border-radius: 6px;
    border-left: 4px solid;
}

.milestone-alert.high {
    background: #ffebee;
    border-left-color: #e74c3c;
}

.milestone-alert.medium {
    background: #fff3e0;
    border-left-color: #ff9800;
}

.milestone-alert.low {
    background: #e8f5e8;
    border-left-color: #4caf50;
}

.recommendation {
    background: #e3f2fd;
    border: 1px solid #2196f3;
    border-radius: 6px;
    padding: 12px;
    margin: 8px 0;
}

.recommendation-action {
    font-size: 0.9em;
    color: #666;
    margin-top: 5px;
    font-style: italic;
}

.current-metrics {
    margin-top: 20px;
    padding-top: 20px;
    border-top: 2px solid #ecf0f1;
}

.metrics-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 15px;
    margin-top: 15px;
}

.metric-display {
    font-size: 1.2em;
    font-weight: bold;
    padding: 10px;
    border-radius: 6px;
    text-align: center;
}

.metric-display.good {
    background: #e8f5e8;
    color: #2e7d32;
}

.metric-display.fair {
    background: #fff3e0;
    color: #ef6c00;
}

.metric-display.poor {
    background: #ffebee;
    color: #c62828;
}

.supplement-item {
    background: #f8f9fa;
    border-radius: 8px;
    padding: 15px;
    margin: 10px 0;
    border-left: 4px solid #3498db;
}

.supplement-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 10px;
}

.supplement-dose {
    background: #3498db;
    color: white;
    padding: 4px 8px;
    border-radius: 4px;
    font-size: 0.9em;
}

.supplement-details {
    display: grid;
    gap: 5px;
}

.supplement-details > div {
    font-size: 0.9em;
    color: #666;
}

.progression-summary {
    background: #f8f9fa;
    border-radius: 8px;
    padding: 20px;
    margin-top: 20px;
}

.projection-metrics {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 15px;
    margin-top: 15px;
}

.projection-item {
    background: white;
    padding: 15px;
    border-radius: 6px;
    border-left: 4px solid #3498db;
}
`;

# Convenience launcher so you can run:  python run_server.py
# (Internally it behaves like: python -m app.server)
import runpy
runpy.run_module("app.server", run_name="__main__")

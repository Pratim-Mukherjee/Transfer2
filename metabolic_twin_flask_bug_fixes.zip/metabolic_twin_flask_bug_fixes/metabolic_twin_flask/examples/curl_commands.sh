
#!/usr/bin/env bash
set -e
BASE="http://localhost:5000"

echo "1) /profiles/seed"
curl -s -X POST "$BASE/profiles/seed" -H "Content-Type: application/json" -d '{
  "user_id":"u123",
  "model_ref":"default.sa.1.0.0",
  "baseline":{
    "hba1c_pct":7.8,
    "lipids":{"tg_mg_dl":180,"hdl_mg_dl":35},
    "body":{"bodyfat_pct":32,"weight_kg":86}
  }
}' | jq .

echo "2) /current_state/build"
python - <<'PY' > /tmp/cgm.json
import json, datetime, random
ts0 = datetime.datetime(2025,9,22,0,0,0)
samples = [{"ts": (ts0 + datetime.timedelta(minutes=5*i)).isoformat(), "mgdl": 120 + 10*random.random()} for i in range(60)]
print(json.dumps(samples))
PY
CGM=$(cat /tmp/cgm.json)
curl -s -X POST "$BASE/current_state/build" -H "Content-Type: application/json" -d "{
  \"user_id\": \"u123\",
  \"model_ref\": \"default.sa.1.0.0\",
  \"cgm_samples\": $CGM,
  \"labs_optional\": {\"hba1c_pct\": 7.8, \"tg_mg_dl\":180, \"hdl_mg_dl\":35},
  \"body_optional\": {\"bodyfat_pct\":32,\"weight_kg\":86}
}" | jq .

echo "3) /targets/interim/project"
curl -s -X POST "$BASE/targets/interim/project" -H "Content-Type: application/json" -d '{
  "user_id":"u123",
  "model_ref":"default.sa.1.0.0",
  "phase":"liver_clearance",
  "horizon_weeks":12,
  "plan":{"daily_deficit_kcal": -600},
  "baseline":{"bodyfat_pct":32,"weight_kg":86,"hba1c_pct":7.8,"ttb_min":295,"fbg_mgdl":135,"cv_pct":29,"tir_pct":62,"lc_z":-0.2}
}' | jq .

echo "4) /targets/final"
curl -s "$BASE/targets/final" | jq .

echo "5) /scores/compute"
NOW=$(curl -s -X POST "$BASE/current_state/build" -H "Content-Type: application/json" -d "{
  \"user_id\": \"u123\", \"model_ref\": \"default.sa.1.0.0\",
  \"cgm_samples\": $CGM, \"labs_optional\": {\"hba1c_pct\": 7.8}, \"body_optional\": {\"bodyfat_pct\":32,\"weight_kg\":86}
}")
INTERIM=$(curl -s -X POST "$BASE/targets/interim/project" -H "Content-Type: application/json" -d '{
  "user_id":"u123", "model_ref":"default.sa.1.0.0", "phase":"liver_clearance", "horizon_weeks":12,
  "plan":{"daily_deficit_kcal": -600}, "baseline":{"bodyfat_pct":32,"weight_kg":86,"hba1c_pct":7.8,"ttb_min":295,"fbg_mgdl":135,"cv_pct":29,"tir_pct":62,"lc_z":-0.2}
}')
FINAL=$(curl -s "$BASE/targets/final")
SCORING=$(cat <<'JSON'
{
  "metrics": {
    "fbg_mgdl": {"direction":"down","target_band":{"lo":85,"hi":99},"scale":"prp_mad","weight":0.25},
    "ttb_min":  {"direction":"down","target_band":{"hi":180},"scale":"prp_mad","weight":0.25},
    "cv_pct":   {"direction":"down","target_band":{"hi":28},"scale":"prp_mad","weight":0.20},
    "tir_pct":  {"direction":"up",  "target_band":{"lo":80},"scale":"prp_mad","weight":0.20},
    "lc_z":     {"direction":"down","target_band":{"hi":-0.5},"scale":"abs1","weight":0.10}
  },
  "aggregation": {"method":"logistic","clip":6.0}
}
JSON
)
curl -s -X POST "$BASE/scores/compute" -H "Content-Type: application/json" -d "{
  \"now\": $NOW, \"interim\": $INTERIM, \"final\": $FINAL, \"prp\": { \"metrics\": { \"fbg_mgdl\":{\"mad\":10}, \"ttb_min\":{\"mad\":25}, \"cv_pct\":{\"mad\":4}, \"tir_pct\":{\"mad\":6}, \"lc_z\":{\"mad\":0.2}} }, \"scoring_policy\": $SCORING
}" | jq .

echo "6) /snapshot/upsert"
SCORES=$(curl -s -X POST "$BASE/scores/compute" -H "Content-Type: application/json" -d "{
  \"now\": $NOW, \"interim\": $INTERIM, \"final\": $FINAL, \"prp\": { \"metrics\": { \"fbg_mgdl\":{\"mad\":10}, \"ttb_min\":{\"mad\":25}, \"cv_pct\":{\"mad\":4}, \"tir_pct\":{\"mad\":6}, \"lc_z\":{\"mad\":0.2}} }, \"scoring_policy\": $SCORING
}")
curl -s -X POST "$BASE/snapshot/upsert" -H "Content-Type: application/json" -d "{
  \"date\": \"2025-09-22\", \"user_id\": \"u123\",
  \"now\": $NOW, \"interim\": $INTERIM, \"final\": $FINAL,
  \"scores\": $(echo $SCORES | jq .scores),
  \"energy\": {\"intake_kcal\": 1900, \"expend_kcal\": 2550, \"deficit_kcal\": -650, \"ced_kcal_cum\": -8450}
}" | jq .

echo "Done."

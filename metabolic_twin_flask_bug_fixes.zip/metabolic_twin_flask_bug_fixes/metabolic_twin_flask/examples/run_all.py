
import requests, json, datetime, random
BASE = "http://localhost:5000"

def pretty(res): print(json.dumps(res.json(), indent=2))

print("1) /profiles/seed")
r = requests.post(f"{BASE}/profiles/seed", json={
  "user_id":"u123","model_ref":"default.sa.1.0.0",
  "baseline":{"hba1c_pct":7.8,"lipids":{"tg_mg_dl":180,"hdl_mg_dl":35},"body":{"bodyfat_pct":32,"weight_kg":86}}
})
pretty(r)

print("2) /current_state/build")
ts0 = datetime.datetime(2025,9,22,0,0,0)
samples = [{"ts": (ts0 + datetime.timedelta(minutes=5*i)).isoformat(), "mgdl": 120 + 10*random.random()} for i in range(60)]
r = requests.post(f"{BASE}/current_state/build", json={
  "user_id":"u123","model_ref":"default.sa.1.0.0","cgm_samples": samples,
  "labs_optional":{"hba1c_pct":7.8,"tg_mg_dl":180,"hdl_mg_dl":35},
  "body_optional":{"bodyfat_pct":32,"weight_kg":86}
})
NOW = r.json(); pretty(r)

print("3) /targets/interim/project")
r = requests.post(f"{BASE}/targets/interim/project", json={
  "user_id":"u123","model_ref":"default.sa.1.0.0","phase":"liver_clearance","horizon_weeks":12,
  "plan":{"daily_deficit_kcal": -600},
  "baseline":{"bodyfat_pct":32,"weight_kg":86,"hba1c_pct":7.8,"ttb_min":295,"fbg_mgdl":135,"cv_pct":29,"tir_pct":62,"lc_z":-0.2}
})
INTERIM = r.json(); pretty(r)

print("4) /targets/final")
r = requests.get(f"{BASE}/targets/final"); FINAL = r.json(); pretty(r)

print("5) /scores/compute")
SCORING = {
  "metrics": {
    "fbg_mgdl": {"direction":"down","target_band":{"lo":85,"hi":99},"scale":"prp_mad","weight":0.25},
    "ttb_min":  {"direction":"down","target_band":{"hi":180},"scale":"prp_mad","weight":0.25},
    "cv_pct":   {"direction":"down","target_band":{"hi":28},"scale":"prp_mad","weight":0.20},
    "tir_pct":  {"direction":"up",  "target_band":{"lo":80},"scale":"prp_mad","weight":0.20},
    "lc_z":     {"direction":"down","target_band":{"hi":-0.5},"scale":"abs1","weight":0.10}
  },
  "aggregation": {"method":"logistic","clip":6.0}
}
r = requests.post(f"{BASE}/scores/compute", json={
  "now": NOW, "interim": INTERIM, "final": FINAL,
  "prp": { "metrics": { "fbg_mgdl":{"mad":10}, "ttb_min":{"mad":25}, "cv_pct":{"mad":4}, "tir_pct":{"mad":6}, "lc_z":{"mad":0.2}} },
  "scoring_policy": SCORING
})
SCORES = r.json(); pretty(r)

print("6) /snapshot/upsert")
r = requests.post(f"{BASE}/snapshot/upsert", json={
  "date":"2025-09-22","user_id":"u123","now": NOW,"interim": INTERIM,"final": FINAL,
  "scores": SCORES["scores"],
  "energy": {"intake_kcal":1900,"expend_kcal":2550,"deficit_kcal":-650,"ced_kcal_cum":-8450}
})
pretty(r); print("Done.")

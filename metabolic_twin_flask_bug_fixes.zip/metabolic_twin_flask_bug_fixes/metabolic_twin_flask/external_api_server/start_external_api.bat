@echo off
echo ============================================================
echo Starting External Patient API Server on port 9000
echo ============================================================
echo.
python api_server.py
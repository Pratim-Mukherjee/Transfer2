"""
External API Server - Mock Implementation
This server simulates the external patient management system API.
Replace the mock data and logic with actual database/system integration.

Run this server on port 9000:
    python api_server.py

The main metabolic twin app will connect to this server.
"""

from flask import Flask, jsonify, request
from flask_cors import CORS
import json
from typing import Dict, List, Optional
import os
from datetime import datetime

app = Flask(__name__)
CORS(app)

# ===========================================
# MOCK DATA - Replace with actual database
# ===========================================

MOCK_PATIENTS = [
    {
        "patient_id": "P001",
        "name": "Rajesh Kumar",
        "age": 45,
        "has_protocol": True,
        "last_visit": "2025-09-15"
    },
    {
        "patient_id": "P002",
        "name": "Priya Sharma",
        "age": 52,
        "has_protocol": False,
        "last_visit": "2025-09-28"
    },
    {
        "patient_id": "P003",
        "name": "Amit Patel",
        "age": 58,
        "has_protocol": True,
        "last_visit": "2025-09-20"
    }
]

MOCK_PATIENT_REPORTS = {
    "P001": {
        "patient_id": "P001",
        "name": "Rajesh Kumar",
        "demographics": {
            "age": 45,
            "gender": "male",
            "height_cm": 175,
            "weight_kg": 92
        },
        "lab_reports": {
            "hba1c_pct": 8.2,
            "fbg_mgdl": 152,
            "triglycerides_mgdl": 210,
            "hdl_mgdl": 38,
            "ldl_mgdl": 145,
            "bodyfat_pct": 34,
            "bodyfat_method": "dexa_scan",
            "egfr": 82,
            "creatinine_mgdl": 1.1,
            "vitamin_b12_pg_ml": 350,
            "vitamin_d_ng_ml": 22,
            "body_measurements": {
                "waist_cm": 98,
                "neck_cm": 40,
                "hip_cm": None
            }
        },
        "lifestyle": {
            "wake_time": "06:00",
            "sleep_time": "22:30",
            "work_start": "09:00",
            "work_end": "18:00",
            "cultural_food_preference": "north_indian_non_vegetarian",
            "activity_level": "sedentary"
        },
        "current_medications": [
            {
                "name": "Metformin",
                "dose": "1000mg",
                "frequency": "twice_daily",
                "times": ["08:00", "20:00"]
            },
            {
                "name": "Glimepiride",
                "dose": "2mg",
                "frequency": "once_daily",
                "times": ["08:00"]
            }
        ],
        "current_supplements": [
            {
                "name": "Vitamin D3",
                "dose": "2000 IU",
                "frequency": "once_daily",
                "times": ["08:00"]
            },
            {
                "name": "Omega-3",
                "dose": "1000mg",
                "frequency": "twice_daily",
                "times": ["08:00", "20:00"]
            }
        ],
        "contraindications": []
    },
    "P002": {
        "patient_id": "P002",
        "name": "Priya Sharma",
        "demographics": {
            "age": 52,
            "gender": "female",
            "height_cm": 162,
            "weight_kg": 78
        },
        "lab_reports": {
            "hba1c_pct": 7.8,
            "fbg_mgdl": 145,
            "triglycerides_mgdl": 195,
            "hdl_mgdl": 42,
            "ldl_mgdl": 130,
            "bodyfat_pct": None,
            "bodyfat_method": None,
            "egfr": 88,
            "creatinine_mgdl": 0.9,
            "vitamin_b12_pg_ml": 180,
            "vitamin_d_ng_ml": 18,
            "body_measurements": {
                "waist_cm": 88,
                "neck_cm": 34,
                "hip_cm": 105
            }
        },
        "lifestyle": {
            "wake_time": "06:30",
            "sleep_time": "22:00",
            "work_start": "09:30",
            "work_end": "17:30",
            "cultural_food_preference": "south_indian_vegetarian",
            "activity_level": "light"
        },
        "current_medications": [
            {
                "name": "Metformin",
                "dose": "500mg",
                "frequency": "twice_daily",
                "times": ["09:00", "21:00"]
            }
        ],
        "current_supplements": [
            {
                "name": "Vitamin B12",
                "dose": "1000 mcg",
                "frequency": "once_daily",
                "times": ["09:00"]
            }
        ],
        "contraindications": []
    },
    "P003": {
        "patient_id": "P003",
        "name": "Amit Patel",
        "demographics": {
            "age": 58,
            "gender": "male",
            "height_cm": 168,
            "weight_kg": 85
        },
        "lab_reports": {
            "hba1c_pct": 9.1,
            "fbg_mgdl": 168,
            "triglycerides_mgdl": 245,
            "hdl_mgdl": 35,
            "ldl_mgdl": 155,
            "bodyfat_pct": None,
            "bodyfat_method": None,
            "egfr": 75,
            "creatinine_mgdl": 1.3,
            "vitamin_b12_pg_ml": 425,
            "vitamin_d_ng_ml": 35,
            "body_measurements": {
                "waist_cm": 102,
                "neck_cm": 42,
                "hip_cm": None
            }
        },
        "lifestyle": {
            "wake_time": "05:30",
            "sleep_time": "22:00",
            "work_start": "08:30",
            "work_end": "17:00",
            "cultural_food_preference": "indian_continental",
            "activity_level": "moderate"
        },
        "current_medications": [
            {
                "name": "Metformin",
                "dose": "1000mg",
                "frequency": "twice_daily",
                "times": ["07:30", "19:30"]
            },
            {
                "name": "Sitagliptin",
                "dose": "100mg",
                "frequency": "once_daily",
                "times": ["07:30"]
            }
        ],
        "current_supplements": [],
        "contraindications": ["kidney_disease"]
    }
}

# In-memory storage for protocols (replace with database)
STORED_PROTOCOLS = {}
STORED_WEEKLY_TARGETS = {}

# ===========================================
# API ENDPOINTS
# ===========================================

@app.route('/api/patients', methods=['GET'])
def get_patients():
    """
    Get list of all patients

    TODO: Replace with actual database query
    Example: patients = db.query("SELECT * FROM patients WHERE doctor_id = ?", doctor_id)
    """
    print("[API] Fetching patient list")

    # Optional: Add authentication check
    # auth_token = request.headers.get('Authorization')
    # if not validate_token(auth_token):
    #     return jsonify({"error": "Unauthorized"}), 401

    return jsonify({
        "success": True,
        "patients": MOCK_PATIENTS
    })


@app.route('/api/patient/<patient_id>/reports', methods=['GET'])
def get_patient_reports(patient_id: str):
    """
    Get patient medical reports, demographics, medications

    TODO: Replace with actual database query
    Example: reports = db.query("SELECT * FROM patient_reports WHERE patient_id = ?", patient_id)
    """
    print(f"[API] Fetching reports for patient: {patient_id}")

    if patient_id not in MOCK_PATIENT_REPORTS:
        return jsonify({
            "success": False,
            "error": "Patient not found"
        }), 404

    return jsonify({
        "success": True,
        "reports": MOCK_PATIENT_REPORTS[patient_id]
    })


@app.route('/api/patient/<patient_id>/protocol', methods=['GET'])
def get_patient_protocol(patient_id: str):
    """
    Check if protocol exists and return it

    TODO: Replace with actual database query
    Example: protocol = db.query("SELECT * FROM protocols WHERE patient_id = ? ORDER BY created_at DESC LIMIT 1", patient_id)
    """
    print(f"[API] Checking protocol for patient: {patient_id}")

    # Check in-memory storage (replace with database)
    if patient_id in STORED_PROTOCOLS:
        return jsonify({
            "success": True,
            "exists": True,
            "protocol": STORED_PROTOCOLS[patient_id],
            "weekly_targets": STORED_WEEKLY_TARGETS.get(patient_id),
            "timestamp": datetime.now().strftime("%Y%m%d_%H%M%S")
        })

    return jsonify({
        "success": True,
        "exists": False
    })


@app.route('/api/patient/<patient_id>/protocol', methods=['POST'])
@app.route('/api/patients/<patient_id>/protocol/save', methods=['POST'])
def save_patient_protocol(patient_id: str):
    """
    Save patient protocol

    Supports both endpoints:
    - /api/patient/{id}/protocol (legacy)
    - /api/patients/{id}/protocol/save (new)

    TODO: Replace with actual database insert
    Example: db.execute("INSERT INTO protocols (patient_id, data, created_at) VALUES (?, ?, ?)",
                        patient_id, json.dumps(protocol_data), datetime.now())
    """
    print(f"[API] Saving protocol for patient: {patient_id}")

    data = request.json
    protocol_data = data.get('protocol')

    if not protocol_data:
        return jsonify({
            "success": False,
            "error": "Protocol data is required"
        }), 400

    # Store in memory (replace with database)
    STORED_PROTOCOLS[patient_id] = protocol_data

    # Optional: Save to file for persistence during development
    os.makedirs('stored_protocols', exist_ok=True)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"stored_protocols/{patient_id}_protocol_{timestamp}.json"
    with open(filename, 'w', encoding='utf-8') as f:
        json.dump(protocol_data, f, indent=2, ensure_ascii=False)

    print(f"[API] Protocol saved: {filename}")

    return jsonify({
        "success": True,
        "message": "Protocol saved successfully",
        "timestamp": timestamp
    })


@app.route('/api/patient/<patient_id>/weekly-targets', methods=['POST'])
@app.route('/api/patient/<patient_id>/weekly-targets/save', methods=['POST'])
def save_weekly_targets(patient_id: str):
    """
    Save weekly targets for patient

    Supports both endpoints:
    - /api/patient/{id}/weekly-targets (legacy)
    - /api/patient/{id}/weekly-targets/save (new)

    TODO: Replace with actual database insert
    Example: db.execute("INSERT INTO weekly_targets (patient_id, data, created_at) VALUES (?, ?, ?)",
                        patient_id, json.dumps(weekly_data), datetime.now())
    """
    print(f"[API] Saving weekly targets for patient: {patient_id}")

    data = request.json
    weekly_data = data.get('weekly_targets')

    if not weekly_data:
        return jsonify({
            "success": False,
            "error": "Weekly targets data is required"
        }), 400

    # Store in memory (replace with database)
    STORED_WEEKLY_TARGETS[patient_id] = weekly_data

    # Optional: Save to file for persistence during development
    os.makedirs('stored_weekly_targets', exist_ok=True)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"stored_weekly_targets/{patient_id}_weekly_targets_{timestamp}.json"
    with open(filename, 'w', encoding='utf-8') as f:
        json.dump(weekly_data, f, indent=2, ensure_ascii=False)

    print(f"[API] Weekly targets saved: {filename}")

    return jsonify({
        "success": True,
        "message": "Weekly targets saved successfully",
        "timestamp": timestamp
    })


@app.route('/health', methods=['GET'])
def health_check():
    """Health check endpoint"""
    return jsonify({
        "status": "healthy",
        "service": "External Patient API",
        "version": "1.0.0"
    })


# ===========================================
# HELPER FUNCTIONS (for future use)
# ===========================================

def validate_token(token: str) -> bool:
    """
    Validate authentication token

    TODO: Implement actual token validation
    Example: return jwt.verify(token, SECRET_KEY)
    """
    # For now, accept any token
    return True


# ===========================================
# MAIN
# ===========================================

if __name__ == '__main__':
    print("=" * 60)
    print("External Patient API Server")
    print("=" * 60)
    print("Running on: http://localhost:9000")
    print("\nAvailable endpoints:")
    print("  GET  /api/patients")
    print("  GET  /api/patient/<patient_id>/reports")
    print("  GET  /api/patient/<patient_id>/protocol")
    print("  POST /api/patient/<patient_id>/protocol")
    print("  POST /api/patient/<patient_id>/weekly-targets")
    print("  GET  /health")
    print("=" * 60)

    app.run(host='0.0.0.0', port=9000, debug=True)
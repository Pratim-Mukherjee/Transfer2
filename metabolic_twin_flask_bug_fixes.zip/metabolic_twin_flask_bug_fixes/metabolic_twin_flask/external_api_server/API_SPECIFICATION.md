# External Patient API Specification

This document provides the complete API specification for the External Patient Management System that the Metabolic Twin Flask application connects to.

---

## Base URL
```
http://localhost:9000
```

For production, update to: `https://your-production-domain.com`

---

## Authentication

All endpoints (except `/health`) should include authentication header when implemented:

```http
Authorization: Bearer {API_KEY}
```

Currently authentication is optional in the mock implementation.

---

## API Endpoints

### 1. Get Patient List

Retrieve list of all patients for the authenticated doctor/DHA.

**Endpoint:** `GET /api/patients`

**Request Headers:**
```http
Authorization: Bearer {API_KEY}
```

**Response (200 OK):**
```json
{
  "success": true,
  "patients": [
    {
      "patient_id": "P001",
      "name": "Rajesh Kumar",
      "age": 45,
      "has_protocol": true,
      "last_visit": "2025-09-15"
    },
    {
      "patient_id": "P002",
      "name": "Priya Sharma",
      "age": 52,
      "has_protocol": false,
      "last_visit": "2025-09-28"
    }
  ]
}
```

**Response (401 Unauthorized):**
```json
{
  "error": "Unauthorized"
}
```

---

### 2. Get Patient Reports

Retrieve comprehensive medical reports, demographics, medications, and lifestyle data for a specific patient.

**Endpoint:** `GET /api/patient/{patient_id}/reports`

**URL Parameters:**
- `patient_id` (string, required): Unique patient identifier

**Request Headers:**
```http
Authorization: Bearer {API_KEY}
```

**Response (200 OK):**
```json
{
  "success": true,
  "reports": {
    "patient_id": "P001",
    "name": "Rajesh Kumar",
    "demographics": {
      "age": 45,
      "gender": "male",
      "height_cm": 175,
      "weight_kg": 92
    },
    "lab_reports": {
      "hba1c_pct": 8.2,
      "fbg_mgdl": 152,
      "triglycerides_mgdl": 210,
      "hdl_mgdl": 38,
      "ldl_mgdl": 145,
      "bodyfat_pct": 34,
      "egfr": 82,
      "creatinine_mgdl": 1.1
    },
    "lifestyle": {
      "wake_time": "06:00",
      "sleep_time": "22:30",
      "work_start": "09:00",
      "work_end": "18:00",
      "cultural_food_preference": "north_indian_non_vegetarian",
      "activity_level": "sedentary"
    },
    "current_medications": [
      {
        "name": "Metformin",
        "dose": "1000mg",
        "frequency": "twice_daily"
      }
    ],
    "contraindications": ["kidney_disease"]
  }
}
```

**Response (404 Not Found):**
```json
{
  "success": false,
  "error": "Patient not found"
}
```

---

### 3. Check Existing Protocol

Check if a metabolic protocol already exists for the patient.

**Endpoint:** `GET /api/patient/{patient_id}/protocol`

**URL Parameters:**
- `patient_id` (string, required): Unique patient identifier

**Request Headers:**
```http
Authorization: Bearer {API_KEY}
```

**Response (200 OK - Protocol Exists):**
```json
{
  "success": true,
  "exists": true,
  "protocol": {
    "patient_id": "P001",
    "patient_name": "Rajesh Kumar",
    "baseline": { /* baseline data */ },
    "macroTargets": { /* macro targets */ },
    "meal_plan": { /* meal plan */ },
    "medication_schedule": { /* medication schedule */ },
    "supplement_recommendations": { /* supplements */ }
  },
  "weekly_targets": {
    "weeks": [ /* weekly progression data */ ]
  },
  "timestamp": "20250930_143022"
}
```

**Response (200 OK - No Protocol):**
```json
{
  "success": true,
  "exists": false
}
```

---

### 4. Save Patient Protocol

Save a generated metabolic protocol for a patient.

**Endpoint:** `POST /api/patient/{patient_id}/protocol`

**URL Parameters:**
- `patient_id` (string, required): Unique patient identifier

**Request Headers:**
```http
Authorization: Bearer {API_KEY}
Content-Type: application/json
```

**Request Body:**
```json
{
  "protocol": {
    "patient_id": "P001",
    "patient_name": "Rajesh Kumar",
    "generated_at": "2025-09-30T14:30:22",
    "baseline": {
      "patient_profile": { /* full patient profile */ }
    },
    "macroTargets": {
      "targetCalories": 1800,
      "targetProteinGrams": 120,
      "targetCarbsGrams": 180,
      "targetFatGrams": 60
    },
    "meal_plan": { /* complete meal plan */ },
    "medication_schedule": { /* medication schedule */ },
    "supplement_recommendations": { /* supplement recommendations */ }
  }
}
```

**Response (200 OK):**
```json
{
  "success": true,
  "message": "Protocol saved successfully",
  "timestamp": "20250930_143022"
}
```

**Response (400 Bad Request):**
```json
{
  "success": false,
  "error": "Protocol data is required"
}
```

---

### 5. Save Weekly Targets

Save weekly progression targets for a patient protocol.

**Endpoint:** `POST /api/patient/{patient_id}/weekly-targets`

**URL Parameters:**
- `patient_id` (string, required): Unique patient identifier

**Request Headers:**
```http
Authorization: Bearer {API_KEY}
Content-Type: application/json
```

**Request Body:**
```json
{
  "weekly_targets": {
    "program_duration_weeks": 12,
    "weeks": [
      {
        "week": 1,
        "targets": {
          "target_weight_kg": 91.5,
          "target_calories": 1850,
          "target_hba1c_pct": 8.0,
          "exercise_minutes": 150
        },
        "milestones": ["Start baseline measurements"],
        "adjustments": {
          "medication_changes": [],
          "supplement_changes": []
        }
      }
    ]
  }
}
```

**Response (200 OK):**
```json
{
  "success": true,
  "message": "Weekly targets saved successfully",
  "timestamp": "20250930_143022"
}
```

**Response (400 Bad Request):**
```json
{
  "success": false,
  "error": "Weekly targets data is required"
}
```

---

### 6. Health Check

Check if the API server is running and healthy.

**Endpoint:** `GET /health`

**Authentication:** Not required

**Response (200 OK):**
```json
{
  "status": "healthy",
  "service": "External Patient API",
  "version": "1.0.0"
}
```

---

## Data Models

### Patient List Item
```json
{
  "patient_id": "string",
  "name": "string",
  "age": "integer",
  "has_protocol": "boolean",
  "last_visit": "string (ISO date)"
}
```

### Patient Reports
```json
{
  "patient_id": "string",
  "name": "string",
  "demographics": {
    "age": "integer",
    "gender": "string (male/female)",
    "height_cm": "number",
    "weight_kg": "number"
  },
  "lab_reports": {
    "hba1c_pct": "number",
    "fbg_mgdl": "number",
    "triglycerides_mgdl": "number",
    "hdl_mgdl": "number",
    "ldl_mgdl": "number",
    "bodyfat_pct": "number",
    "egfr": "number",
    "creatinine_mgdl": "number"
  },
  "lifestyle": {
    "wake_time": "string (HH:MM)",
    "sleep_time": "string (HH:MM)",
    "work_start": "string (HH:MM)",
    "work_end": "string (HH:MM)",
    "cultural_food_preference": "string",
    "activity_level": "string (sedentary/light/moderate/active)"
  },
  "current_medications": [
    {
      "name": "string",
      "dose": "string",
      "frequency": "string"
    }
  ],
  "contraindications": ["string"]
}
```

---

## Error Handling

All error responses follow this format:

```json
{
  "success": false,
  "error": "Error message description"
}
```

**Common HTTP Status Codes:**
- `200 OK` - Request successful
- `400 Bad Request` - Invalid request parameters or body
- `401 Unauthorized` - Missing or invalid authentication
- `404 Not Found` - Resource not found
- `500 Internal Server Error` - Server error

---

## Implementation Notes

### Current Mock Implementation

The current implementation uses:
- In-memory dictionaries for data storage
- Optional file-based persistence for development
- No real authentication (validation stub exists)

### Production Implementation Requirements

For production deployment, implement:

1. **Database Integration**
   - Replace in-memory storage with PostgreSQL/MySQL
   - Implement proper connection pooling
   - Add database migrations

2. **Authentication & Authorization**
   - Implement JWT token validation
   - Add role-based access control (doctor, admin, etc.)
   - Implement token refresh mechanism

3. **Security**
   - Add rate limiting
   - Implement HTTPS only
   - Add input validation and sanitization
   - Implement CORS restrictions

4. **Logging & Monitoring**
   - Add comprehensive logging
   - Implement error tracking (Sentry, etc.)
   - Add performance monitoring

5. **Scalability**
   - Add caching (Redis)
   - Implement database read replicas
   - Add load balancing support

---

## Testing the API

### Using cURL

**Get patient list:**
```bash
curl http://localhost:9000/api/patients
```

**Get patient reports:**
```bash
curl http://localhost:9000/api/patient/P001/reports
```

**Check protocol:**
```bash
curl http://localhost:9000/api/patient/P001/protocol
```

**Save protocol:**
```bash
curl -X POST http://localhost:9000/api/patient/P001/protocol \
  -H "Content-Type: application/json" \
  -d '{"protocol": {...}}'
```

### Using Python requests

```python
import requests

# Get patient list
response = requests.get('http://localhost:9000/api/patients')
patients = response.json()['patients']

# Get patient reports
response = requests.get('http://localhost:9000/api/patient/P001/reports')
reports = response.json()['reports']
```

---

## Support

For issues or questions about this API:
1. Check the README.md in the external_api_server folder
2. Review the mock implementation in api_server.py
3. Contact the development team
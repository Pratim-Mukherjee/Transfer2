# External Patient API Server

This is a mock API server that simulates the external patient management system. The main metabolic twin Flask application connects to this server to fetch patient data and save protocols.

## Purpose

- Provides a realistic API interface for development and testing
- Separates mock data from the main application
- Can be easily replaced with the actual production API implementation

## Running the Server

1. Install dependencies:
```bash
pip install -r requirements.txt
```

2. Run the server:
```bash
python api_server.py
```

The server will start on `http://localhost:9000`

## API Endpoints

### 1. GET /api/patients
Get list of all patients

**Response:**
```json
{
  "success": true,
  "patients": [
    {
      "patient_id": "P001",
      "name": "Rajesh Kumar",
      "age": 45,
      "has_protocol": true,
      "last_visit": "2025-09-15"
    }
  ]
}
```

### 2. GET /api/patient/{patient_id}/reports
Get patient medical reports, demographics, and current medications

**Response:**
```json
{
  "success": true,
  "reports": {
    "patient_id": "P001",
    "name": "Rajesh Kumar",
    "demographics": { ... },
    "lab_reports": { ... },
    "lifestyle": { ... },
    "current_medications": [ ... ],
    "contraindications": [ ... ]
  }
}
```

### 3. GET /api/patient/{patient_id}/protocol
Check if protocol exists for patient

**Response (exists):**
```json
{
  "success": true,
  "exists": true,
  "protocol": { ... },
  "weekly_targets": { ... },
  "timestamp": "20250930_143022"
}
```

**Response (doesn't exist):**
```json
{
  "success": true,
  "exists": false
}
```

### 4. POST /api/patient/{patient_id}/protocol
Save patient protocol

**Request Body:**
```json
{
  "protocol": { ... }
}
```

**Response:**
```json
{
  "success": true,
  "message": "Protocol saved successfully",
  "timestamp": "20250930_143022"
}
```

### 5. POST /api/patient/{patient_id}/weekly-targets
Save weekly targets for patient

**Request Body:**
```json
{
  "weekly_targets": { ... }
}
```

**Response:**
```json
{
  "success": true,
  "message": "Weekly targets saved successfully",
  "timestamp": "20250930_143022"
}
```

### 6. GET /health
Health check endpoint

**Response:**
```json
{
  "status": "healthy",
  "service": "External Patient API",
  "version": "1.0.0"
}
```

## Mock Data

The server includes mock data for 3 patients:
- **P001**: Rajesh Kumar (45, male, has existing protocol)
- **P002**: Priya Sharma (52, female, no protocol)
- **P003**: Amit Patel (58, male, has existing protocol)

## Replacing with Production API

To implement the real API:

1. Replace `MOCK_PATIENTS` and `MOCK_PATIENT_REPORTS` with actual database queries
2. Replace `STORED_PROTOCOLS` and `STORED_WEEKLY_TARGETS` dictionaries with database storage
3. Implement proper authentication in `validate_token()`
4. Add proper error handling and logging
5. Deploy to production server

The main application doesn't need to change - just point it to the production API URL.

## Development Storage

During development, the server saves protocols and weekly targets to files:
- `stored_protocols/{patient_id}_protocol_{timestamp}.json`
- `stored_weekly_targets/{patient_id}_weekly_targets_{timestamp}.json`

This provides persistence between server restarts during testing.
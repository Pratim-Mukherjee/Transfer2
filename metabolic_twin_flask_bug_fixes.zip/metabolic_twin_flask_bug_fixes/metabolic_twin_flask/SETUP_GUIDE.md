# Metabolic Twin Flask - Setup Guide

This guide explains how to run the complete system with the external API server.

## Architecture Overview

The system now consists of two separate Flask servers:

```
┌─────────────────────────────────────────────────────────────┐
│                    External API Server                       │
│                    (Port 9000)                              │
│                                                             │
│  • Manages patient data                                    │
│  • Stores protocols and weekly targets                     │
│  • Provides patient list and medical reports               │
│  • Can be replaced with production API                     │
└─────────────────────────────────────────────────────────────┘
                            ▲
                            │ HTTP Requests
                            │
┌─────────────────────────────────────────────────────────────┐
│              Metabolic Twin Flask App                       │
│                    (Port 5000)                              │
│                                                             │
│  • Doctor-facing UI                                        │
│  • Protocol generation engine                              │
│  • Fetches patient data from External API                 │
│  • Posts protocols back to External API                    │
└─────────────────────────────────────────────────────────────┘
```

## Quick Start

### Step 1: Start External API Server

Open a terminal and run:

```bash
cd external_api_server
python api_server.py
```

You should see:
```
============================================================
External Patient API Server
============================================================
Running on: http://localhost:9000

Available endpoints:
  GET  /api/patients
  GET  /api/patient/<patient_id>/reports
  GET  /api/patient/<patient_id>/protocol
  POST /api/patient/<patient_id>/protocol
  POST /api/patient/<patient_id>/weekly-targets
  GET  /health
============================================================
```

**Alternative (Windows):**
```bash
cd external_api_server
start_external_api.bat
```

### Step 2: Start Main Application

Open another terminal and run:

```bash
python app/server.py
```

The main app will start on `http://localhost:5000`

### Step 3: Access the Application

Open your browser and go to:
```
http://localhost:5000
```

## Mock Data

The external API server comes with 3 mock patients:

1. **P001 - Rajesh Kumar**
   - 45 years old, male
   - HbA1c: 8.2%
   - Has existing protocol

2. **P002 - Priya Sharma**
   - 52 years old, female
   - HbA1c: 7.8%
   - No existing protocol

3. **P003 - Amit Patel**
   - 58 years old, male
   - HbA1c: 9.1%
   - Has existing protocol

## Workflow

### For New Patient (No Existing Protocol)

1. Select patient from dropdown (e.g., Priya Sharma)
2. Click "Load Patient"
3. System fetches medical reports from External API
4. Form is auto-populated with patient data
5. Review and adjust baseline data if needed
6. Click "Submit Baseline"
7. Adjust protocol parameters
8. Click "Generate Protocol"
9. Protocol and weekly targets are:
   - Displayed in UI
   - Saved locally in `protocols/` and `weekly_targets/`
   - Posted to External API server

### For Existing Patient (Has Protocol)

1. Select patient from dropdown (e.g., Rajesh Kumar)
2. Click "Load Patient"
3. System checks External API for existing protocol
4. Existing protocol is loaded and displayed
5. Make modifications if needed
6. Click "Regenerate Protocol" to update

## Configuration

### Changing API URL

The main app connects to `http://localhost:9000` by default.

To change this, set environment variable:

```bash
# Linux/Mac
export EXTERNAL_API_URL=https://your-production-api.com

# Windows
set EXTERNAL_API_URL=https://your-production-api.com
```

Or modify in `app/external_api_helper.py`:
```python
API_BASE_URL = os.getenv("EXTERNAL_API_URL", "http://localhost:9000")
```

### Adding Authentication

When implementing authentication, set:

```bash
export EXTERNAL_API_KEY=your-api-key-here
```

The helper will automatically add it to request headers:
```python
Authorization: Bearer {API_KEY}
```

## File Structure

```
metabolic_twin_flask/
│
├── external_api_server/          # NEW: Separate API server
│   ├── api_server.py             # Flask API server on port 9000
│   ├── requirements.txt          # Dependencies (Flask, flask-cors)
│   ├── README.md                 # External API documentation
│   ├── API_SPECIFICATION.md      # Complete API spec
│   ├── start_external_api.bat    # Windows startup script
│   ├── .env.example              # Configuration template
│   ├── stored_protocols/         # Development storage (auto-created)
│   └── stored_weekly_targets/    # Development storage (auto-created)
│
├── app/
│   ├── server.py                 # Main Flask app (updated)
│   ├── external_api_helper.py    # API client (updated)
│   ├── engines/                  # Protocol generation engines
│   └── relationships/            # Policy configurations
│
├── static/
│   ├── PatientManager.js         # Handles external patient workflow
│   ├── BaselineProcessor.js      # Form population and baseline
│   ├── ProtocolGenerator.js      # Protocol generation
│   └── UIManager.js              # UI controls
│
├── templates/
│   └── index.html                # Main UI (updated)
│
├── protocols/                    # Local protocol storage
└── weekly_targets/               # Local weekly targets storage
```

## API Endpoints

### External API Server (Port 9000)

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/patients` | GET | Get patient list |
| `/api/patient/{id}/reports` | GET | Get patient medical reports |
| `/api/patient/{id}/protocol` | GET | Check existing protocol |
| `/api/patient/{id}/protocol` | POST | Save protocol |
| `/api/patient/{id}/weekly-targets` | POST | Save weekly targets |
| `/health` | GET | Health check |

### Main App Server (Port 5000)

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/external/patients` | GET | Proxy to external API |
| `/api/external/patient/{id}/reports` | GET | Fetch and transform reports |
| `/api/external/patient/{id}/protocol/check` | GET | Check protocol existence |
| `/protocol/generate_complete` | POST | Generate complete protocol |

## Testing

### Test External API Directly

```bash
# Check if server is running
curl http://localhost:9000/health

# Get patient list
curl http://localhost:9000/api/patients

# Get patient reports
curl http://localhost:9000/api/patient/P001/reports

# Check protocol
curl http://localhost:9000/api/patient/P001/protocol
```

### Test Through Main App

```bash
# Get patient list through main app
curl http://localhost:5000/api/external/patients

# Get patient reports (transformed)
curl http://localhost:5000/api/external/patient/P001/reports
```

## Troubleshooting

### Error: "Cannot connect to external API server"

**Solution:**
- Make sure external API server is running on port 9000
- Check terminal for error messages
- Verify port 9000 is not blocked by firewall

### Error: Port 9000 already in use

**Solution:**
```bash
# Windows
netstat -ano | findstr :9000
taskkill /PID <PID> /F

# Linux/Mac
lsof -ti:9000 | xargs kill
```

### External API not responding

**Solution:**
- Restart external API server
- Check logs in terminal
- Verify API_BASE_URL in external_api_helper.py

### Protocol not saving

**Solution:**
- Check external API server logs
- Verify directories exist (protocols/, weekly_targets/)
- Check file permissions

## Production Deployment

### Replacing External API with Production

1. Deploy your production API server
2. Update API URL:
   ```bash
   export EXTERNAL_API_URL=https://api.production.com
   export EXTERNAL_API_KEY=your-production-key
   ```
3. No code changes needed in main app!

### What to Implement in Production API

See `external_api_server/api_server.py` for TODO comments:

1. **Database Integration**
   - Replace `MOCK_PATIENTS` with database queries
   - Replace `STORED_PROTOCOLS` with database storage

2. **Authentication**
   - Implement JWT validation in `validate_token()`
   - Add role-based access control

3. **Security**
   - Add rate limiting
   - Enable HTTPS only
   - Implement input validation

4. **Monitoring**
   - Add logging framework
   - Implement error tracking
   - Add performance monitoring

## Development Tips

### Modifying Mock Data

Edit `external_api_server/api_server.py`:

```python
MOCK_PATIENTS = [
    {
        "patient_id": "P004",
        "name": "New Patient",
        "age": 40,
        "has_protocol": False,
        "last_visit": "2025-09-30"
    }
]

MOCK_PATIENT_REPORTS["P004"] = {
    # Add patient data
}
```

### Testing API Changes

1. Stop external API server (Ctrl+C)
2. Make changes to `api_server.py`
3. Restart: `python api_server.py`
4. Test with curl or through main app

### Viewing Saved Data

During development, protocols are saved to files:

```
external_api_server/
  stored_protocols/
    P001_protocol_20250930_143022.json
  stored_weekly_targets/
    P001_weekly_targets_20250930_143022.json
```

## Support

For issues:
1. Check external API server terminal for errors
2. Check main app terminal for errors
3. Review API specification: `external_api_server/API_SPECIFICATION.md`
4. Check browser console (F12) for frontend errors

# Metabolic Twin — Flask JSON Bundle (MVP)

This is a minimal, JSON-first implementation with **Flask** endpoints and clean separation:
- **/app/engines/**: Python modules that compute values
- **/app/relationships/**: One JSON per curve/formula/policy/target (swappable)
- **/contracts/**: JSON Schemas (add more as needed)
- **/examples/**: cURL script and Python client to exercise the API

## Install
```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
```

## Run the Flask server
```bash
python -m app.server
```
Server listens on **http://localhost:5000**.

Windows tip: if you use the Windows launcher, `py -m app.server` also works.

## Try the endpoints

### Option A: bash (cURL)
```bash
bash examples/curl_commands.sh
```

### Option B: Python client
```bash
python examples/run_all.py
```

## Endpoints

### POST /profiles/seed
Cold-start: derive values from baseline labs/biometrics via relationships.

### POST /current_state/build
Compute the Now profile from CGM (+ optional labs/body).

### POST /targets/interim/project
From plan (daily deficit, horizon), project Interim targets (phase end + weekly series).

### GET /targets/final
Return remission targets and filled expectations.

### POST /scores/compute
Compute scores vs Interim & Final using policy weights and PRP MAD scaling.

### POST /snapshot/upsert
Save a Day Snapshot (for dashboards). Here it returns an ack; wire to DB later.

## Notes
- Numbers/curves are placeholders; tune via JSON under `app/relationships/`.
- Engines are intentionally simple to keep the MVP portable.
- Add schema validation middleware if you want to enforce `/contracts` at runtime.

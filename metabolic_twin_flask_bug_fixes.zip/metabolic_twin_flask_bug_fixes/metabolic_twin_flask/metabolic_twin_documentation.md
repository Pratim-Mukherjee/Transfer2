# Metabolic Twin System Documentation

## Overview

The Metabolic Twin system is a comprehensive diabetes reversal platform that combines stateless computational engines with an intuitive provider interface. It enables healthcare providers to assess patient baselines, create personalized treatment plans, and monitor progress toward clinical remission through data-driven metabolic optimization.

## System Architecture

### Core Principles

**Stateless Engine Design**
- All computational engines are pure functions with no state persistence
- External systems handle all data storage, patient management, and workflow orchestration
- Engines provide consistent, reproducible calculations given identical inputs
- Clear separation of concerns between computation and data management

**Clinical Workflow Integration**
- Provider-controlled setup ensures clinical oversight and safety
- Patient receives view-only progress dashboard for engagement
- All treatment decisions remain under healthcare provider supervision
- Evidence-based targets align with diabetes remission research

**Data-Driven Personalization**
- Personal Reference Point (PRP) system accounts for individual metabolic variation
- Dynamic plan adjustments based on progress analysis
- Multi-metric scoring provides comprehensive progress assessment
- Biomarker relationships enable predictive modeling

## Engine Endpoints

### 1. Baseline Profile Generation
**Endpoint:** `POST /profiles/seed`

**Purpose:** Generate initial metabolic profile from baseline clinical measurements

**Input Schema:**
```json
{
  "baseline": {
    "hba1c_pct": 7.8,
    "lipids": {
      "tg_mg_dl": 180,
      "hdl_mg_dl": 45
    },
    "body": {
      "bodyfat_pct": 32.0,
      "weight_kg": 78.5
    }
  }
}
```

**Output Schema:**
```json
{
  "values": {
    "eag_mgdl": 177.9,
    "tg_hdl_ratio": 4.0,
    "insulin_sensitivity_band": "High Insulin Resistance",
    "tir_pct": 52,
    "sd_mg_dl": 50,
    "mage_mg_dl": 72,
    "liver_chatter": "High",
    "ttb_min": 270
  },
  "sources": {
    "eag_mgdl": "formula:adag",
    "insulin_sensitivity_band": "band:tg_hdl_bands",
    "tir_pct": "curve:hba1c_to_gv_band",
    "ttb_min": "curve:hba1c_to_ttb_min"
  }
}
```

**Clinical Application:**
- Establishes metabolic phenotype from standard clinical measurements
- Estimates glucose variability patterns from HbA1c levels
- Determines insulin sensitivity from TG/HDL ratio
- Creates comprehensive baseline for treatment planning

### 2. Current State Assessment
**Endpoint:** `POST /current_state/build`

**Purpose:** Compute real-time metabolic metrics from CGM data and optional current measurements

**Input Schema:**
```json
{
  "cgm_samples": [
    {"mgdl": 120, "timestamp": "2025-01-15T10:30:00Z"},
    {"mgdl": 135, "timestamp": "2025-01-15T10:35:00Z"}
  ],
  "meals": [],
  "activities": [],
  "labs_optional": {
    "hba1c_pct": 7.4,
    "tg_mg_dl": 170,
    "hdl_mg_dl": 48
  },
  "body_optional": {
    "bodyfat_pct": 30.5,
    "weight_kg": 76.2
  }
}
```

**Output Schema:**
```json
{
  "as_of": "2025-01-15T12:00:00Z",
  "values": {
    "fbg_mgdl": 125,
    "mean_glucose_mgdl": 142.3,
    "sd_mg_dl": 32.1,
    "cv_pct": 22.6,
    "tir_pct": 68.4,
    "ttb_min": 285,
    "delta_peak_med_mgdl": 48,
    "auc_med": 5000,
    "lc_energy": 0.74,
    "lc_z": -0.2,
    "eag_mgdl": 165.9,
    "hba1c_pct": 7.4,
    "tg_hdl_ratio": 3.54,
    "insulin_sensitivity_band": "Borderline",
    "bodyfat_pct": 30.5,
    "weight_kg": 76.2
  },
  "sources": {
    "fbg_mgdl": "observed",
    "mean_glucose_mgdl": "observed",
    "cv_pct": "observed",
    "tir_pct": "observed",
    "eag_mgdl": "formula:adag",
    "insulin_sensitivity_band": "band:tg_hdl_bands"
  },
  "quality": {
    "coverage_pct": 95.2,
    "gaps": 0,
    "flags": []
  }
}
```

**Clinical Application:**
- Processes continuous glucose monitoring data for comprehensive analysis
- Calculates key glycemic metrics (TIR, CV, mean glucose)
- Integrates optional lab updates and body composition changes
- Provides data quality assessment for clinical decision-making

### 3. Treatment Plan Generation
**Endpoint:** `POST /targets/interim/project`

**Purpose:** Generate personalized treatment projections based on intervention parameters

**Input Schema:**
```json
{
  "phase": "intensive",
  "horizon_weeks": 12,
  "plan": {
    "daily_deficit_kcal": -600
  },
  "baseline": {
    "bodyfat_pct": 32.0,
    "weight_kg": 78.5,
    "hba1c_pct": 7.8,
    "ttb_min": 295,
    "fbg_mgdl": 135,
    "cv_pct": 29,
    "tir_pct": 62,
    "lc_z": -0.2
  }
}
```

**Output Schema:**
```json
{
  "phase": "intensive",
  "horizon_weeks": 12,
  "plan": {
    "daily_deficit_kcal": -600
  },
  "baseline": {...},
  "projected": {
    "delta_fat_kg": -3.2,
    "delta_bodyfat_pct": -4.1,
    "ttb_min": 235,
    "fbg_mgdl": 117,
    "cv_pct": 26.9,
    "tir_pct": 70,
    "lc_z": -0.35,
    "hba1c_pct": 7.3,
    "notes": ["Adaptation 0.85; bounds [-300,-900] kcal/day applied"]
  },
  "series_weekly": [
    {
      "week": 1,
      "bodyfat_pct": 31.7,
      "ttb_min": 290,
      "fbg_mgdl": 133,
      "cv_pct": 28.8,
      "tir_pct": 63,
      "hba1c_pct": 7.75
    }
  ],
  "sources": {
    "energy": "policies/energy.json",
    "fatpct_to_ttb_delta": "curves/fatpct_to_ttb_delta.json"
  }
}
```

**Clinical Application:**
- Projects metabolic improvements based on weight loss interventions
- Accounts for metabolic adaptation and safety boundaries
- Generates weekly milestone targets for progress tracking
- Uses evidence-based relationships between body composition and metabolic markers

### 4. Final Target Definition
**Endpoint:** `GET /targets/final`

**Purpose:** Retrieve evidence-based clinical remission targets

**Output Schema:**
```json
{
  "name": "clinical_remission_default",
  "targets": {
    "hba1c_pct": {"hi": 6.5},
    "fbg_mgdl": {"lo": 85, "hi": 99},
    "tir_pct": {"lo": 80},
    "cv_pct": {"hi": 28},
    "ttb_min": {"hi": 180}
  },
  "filled": {
    "expected_mean_glucose_mgdl": 105,
    "expected_sd_mg_dl": 25,
    "expected_lc_z": -1.0
  }
}
```

**Clinical Application:**
- Defines diabetes remission criteria based on clinical research
- Establishes target ranges for all key metabolic metrics
- Provides benchmark values for long-term treatment success

### 5. Progress Scoring
**Endpoint:** `POST /scores/compute`

**Purpose:** Evaluate patient progress against interim and final targets

**Input Schema:**
```json
{
  "now": { /* current_state output */ },
  "interim": { /* interim targets */ },
  "final": { /* final targets */ },
  "prp": {
    "metrics": {
      "fbg_mgdl": {"mad": 12},
      "cv_pct": {"mad": 5.2}
    }
  },
  "scoring_policy": {
    "metrics": {
      "fbg_mgdl": {
        "direction": "down",
        "target_band": {"lo": 85, "hi": 99},
        "scale": "prp_mad",
        "weight": 0.25
      }
    },
    "aggregation": {
      "method": "logistic",
      "clip": 6.0
    }
  }
}
```

**Output Schema:**
```json
{
  "scores": {
    "interim": 73.2,
    "final": 45.8,
    "overall": 62.1,
    "components": [
      {
        "metric": "fbg_mgdl",
        "closeness": 0.82,
        "weight": 0.25,
        "confidence": 1.0
      }
    ]
  }
}
```

**Clinical Application:**
- Provides quantitative assessment of treatment progress
- Uses personalized reference points for individual variation
- Weights metrics by clinical importance
- Enables data-driven treatment adjustments

### 6. Data Snapshot Storage
**Endpoint:** `POST /snapshot/upsert`

**Purpose:** Create checkpoint records for dashboard and historical analysis

**Input Schema:**
```json
{
  "user_id": "patient_123",
  "date": "2025-01-15",
  "current_state": { /* current_state output */ },
  "scores": { /* scores output */ },
  "week_number": 4,
  "target_milestone": { /* weekly target */ }
}
```

**Output Schema:**
```json
{
  "ok": true,
  "snapshot_id": "patient_123-2025-01-15"
}
```

**Clinical Application:**
- Creates time-stamped records for longitudinal analysis
- Enables dashboard visualization and trend analysis
- Supports historical comparison and outcome tracking

## User Interface Design Principles

### 1. Provider-Centric Workflow Design

**Clinical Authority Model**
- Healthcare providers control all treatment decisions and plan modifications
- Patients receive view-only progress dashboards for engagement and motivation
- All setup, goal-setting, and adjustments require provider oversight
- Safety boundaries and clinical protocols embedded throughout workflow

**Professional Medical Aesthetic**
- Clean, modern interface with medical-grade credibility
- Glassmorphism and gradient effects for contemporary appeal
- Consistent color scheme emphasizing trust and professionalism
- Typography and spacing designed for clinical environments

### 2. Progressive Workflow Architecture

**Three-Phase Treatment Journey**
1. **Baseline Setup**: Comprehensive metabolic assessment and phenotyping
2. **Treatment Planning**: Evidence-based goal setting with predictive modeling
3. **Progress Assessment**: Continuous monitoring with dynamic adjustments

**Linear Task Completion**
- Submit-based interactions ensure data integrity and clinical review points
- Each phase builds upon previous data with clear dependencies
- Auto-save functionality prevents data loss during multi-step processes
- Visual progress indicators guide providers through complex workflows

### 3. Data Visualization Philosophy

**Multi-Modal Information Display**
- **Metabolic Fingerprint**: Radar charts for holistic baseline assessment
- **Projection Curves**: Time-series visualizations for treatment planning
- **Progress Dashboards**: Comparative displays for outcome evaluation
- **Interactive Charts**: D3.js implementations with hover tooltips and zoom capabilities

**Clinical Decision Support**
- Color-coded indicators for at-risk metrics and achievement status
- Milestone markers on timeline charts for progress tracking
- Target lines and ranges overlaid on patient data for context
- Confidence intervals and data quality indicators for clinical judgment

### 4. Responsive Interface Design

**Cross-Platform Compatibility**
- Mobile-first design principles for bedside and clinic use
- Desktop optimization for comprehensive analysis and documentation
- Tablet interface for patient consultation and shared decision-making
- Consistent user experience across all device categories

**Accessibility Standards**
- High contrast ratios for clinical lighting conditions
- Large touch targets for mobile interaction
- Keyboard navigation support for accessibility compliance
- Screen reader compatibility for inclusive design

### 5. Error Handling and User Feedback

**Graceful Failure Management**
- Clear error messaging with actionable resolution steps
- Loading states and progress indicators for long-running operations
- Validation feedback before engine submission to prevent errors
- Success confirmations with next-step guidance

**Data Quality Assurance**
- CGM upload validation with format checking and sample counting
- Input range validation based on clinical plausibility
- Missing data handling with clear indication of optional vs required fields
- Data completeness indicators for clinical confidence assessment

## Integration Patterns

### 1. Stateless Engine Orchestration

**External System Responsibilities**
- Patient identity management and data persistence
- Clinical workflow orchestration and safety monitoring
- Treatment plan versioning and adjustment history
- Provider authentication and authorization

**Engine Integration Pattern**
```javascript
// 1. Collect and validate input data
const inputData = gatherPatientData(patientId);

// 2. Call appropriate engine endpoint
const response = await callEngine('/endpoint', inputData);

// 3. Store results and update patient record
await storeResults(patientId, response.data);

// 4. Trigger next workflow step or notifications
await processWorkflowTransition(patientId, response.data);
```

### 2. Data Flow Architecture

**Baseline → Planning → Monitoring Loop**
```
1. Baseline Assessment
   ↓ (seed results stored)
2. Treatment Planning
   ↓ (plan and targets stored)
3. Weekly Monitoring
   ↓ (progress data accumulated)
4. Plan Adjustment (if needed)
   ↓ (new plan version created)
5. Continue Monitoring
```

**State Management Requirements**
- Patient profiles with baseline metabolic fingerprints
- Treatment plan versions with adjustment history
- Weekly assessment snapshots for trend analysis
- CGM data aggregation and quality monitoring

### 3. Clinical Decision Support Integration

**Automated Alert Generation**
- Progress deviation detection based on scoring thresholds
- Data quality warnings for missing or inconsistent measurements
- Safety alerts for rapid changes or concerning trends
- Milestone achievement notifications for patient engagement

**Provider Dashboard Integration**
- Population-level outcome tracking and quality metrics
- Individual patient risk stratification and priority queuing
- Treatment protocol adherence monitoring and reporting
- Research and quality improvement data extraction

## Configuration and Customization

### 1. Relationship Data Structure

**JSON-Based Configuration System**
- **Formulas**: Mathematical relationships (e.g., ADAG equation for eAG calculation)
- **Curves**: Lookup tables for biomarker projections (e.g., body fat to HbA1c delta)
- **Bands**: Classification systems (e.g., insulin sensitivity categories)
- **Policies**: Treatment parameters and safety boundaries
- **Targets**: Clinical goals and remission criteria

**Hot-Swappable Components**
- Relationship files can be updated without code changes
- Version control and rollback capabilities for configuration management
- A/B testing support for protocol optimization
- Regional customization for different clinical guidelines

### 2. Personalization Framework

**Personal Reference Point (PRP) System**
- Individual baseline establishment for metric normalization
- Median Absolute Deviation (MAD) scaling for personalized scoring
- Historical trend analysis for adaptive target adjustment
- Population benchmarking with individual variation accounting

**Adaptive Treatment Protocols**
- Progress-based plan modification algorithms
- Safety boundary enforcement with provider override capabilities
- Multi-phase treatment progression with automatic transitions
- Risk-stratified monitoring frequency adjustment

## Technical Implementation

### 1. Frontend Architecture

**Technology Stack**
- Pure HTML5/CSS3/JavaScript for maximum compatibility
- D3.js for interactive data visualizations
- Responsive CSS Grid and Flexbox for layout management
- Progressive Web App (PWA) capabilities for offline access

**Performance Optimization**
- Lazy loading for chart components and large datasets
- Efficient D3 rendering with data binding and transitions
- Minimal external dependencies for fast loading
- Client-side caching for frequently accessed configuration data

### 2. Backend Requirements

**Stateless Engine Design**
- RESTful API endpoints with consistent JSON interfaces
- Horizontal scaling capability through stateless architecture
- Container-ready deployment for cloud environments
- Health check endpoints for monitoring and load balancing

**Data Storage Patterns**
```sql
-- Core patient data schema
patients (id, demographics, enrollment_date, status)
baselines (patient_id, assessment_date, computed_values, raw_inputs)
treatment_plans (id, patient_id, version, parameters, targets, created_date)
assessments (id, patient_id, plan_id, week_number, metrics, scores)
cgm_data (patient_id, timestamp, mgdl, quality_flags)
```

### 3. Security and Compliance

**Healthcare Data Protection**
- HIPAA compliance for patient data handling
- End-to-end encryption for data transmission
- Audit logging for all patient data access and modifications
- Role-based access control for provider permissions

**Clinical Safety Features**
- Treatment parameter boundary enforcement
- Provider approval workflows for significant plan changes
- Emergency contact protocols for concerning metric trends
- Medication interaction warnings and contraindication checking

## Deployment and Scaling

### 1. Development Environment Setup

**Local Development Stack**
```bash
# Engine development
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
python -m app.server  # Flask server on localhost:5000

# Frontend development
# Open metabolic_twin_ui.html in browser
# Ensure CORS headers for local development
```

**Docker Containerization**
```dockerfile
FROM python:3.9-slim
WORKDIR /app
COPY requirements.txt .
RUN pip install -r requirements.txt
COPY . .
EXPOSE 5000
CMD ["python", "-m", "app.server"]
```

### 2. Production Deployment Patterns

**Microservices Architecture**
- Engine endpoints deployed as independent services
- API Gateway for request routing and rate limiting
- Database layer for patient data persistence
- Message queue for asynchronous processing

**Cloud Infrastructure**
- Kubernetes orchestration for auto-scaling and health management
- Redis caching for frequently accessed relationship data
- PostgreSQL with time-series extensions for CGM data storage
- CDN deployment for static frontend assets

### 3. Monitoring and Observability

**Application Performance Monitoring**
- Engine response time and error rate tracking
- Database query performance and connection pooling
- Frontend loading times and user interaction metrics
- Real-time alerting for system health issues

**Clinical Quality Metrics**
- Patient engagement rates and dashboard usage patterns
- Treatment protocol adherence and outcome tracking
- Provider satisfaction and workflow efficiency measures
- Population health outcomes and remission rate analysis

## Future Enhancements

### 1. Advanced Analytics

**Machine Learning Integration**
- Predictive models for treatment response and outcome probability
- Anomaly detection for unusual glucose patterns or rapid changes
- Natural language processing for provider notes and patient feedback
- Recommendation engines for treatment protocol optimization

**Population Health Analytics**
- Cohort analysis for treatment effectiveness across demographics
- Real-world evidence generation for protocol refinement
- Comparative effectiveness research between intervention strategies
- Health economic outcomes and cost-effectiveness analysis

### 2. Extended Integration

**Electronic Health Record (EHR) Connectivity**
- HL7 FHIR integration for seamless clinical workflow
- Lab result auto-import and medication reconciliation
- Clinical decision support rule integration
- Quality measure reporting and meaningful use compliance

**Patient Engagement Platform**
- Mobile app for patient progress viewing and education
- Telemedicine integration for remote consultations
- Automated coaching and behavioral intervention delivery
- Peer support community and gamification features

### 3. Research and Development Platform

**Clinical Trial Management**
- Randomized controlled trial support and outcome tracking
- Protocol deviation detection and compliance monitoring
- Adverse event reporting and safety signal detection
- Regulatory submission support and data extraction

**Precision Medicine Development**
- Genetic data integration for personalized treatment selection
- Biomarker discovery and validation pipelines
- Pharmacogenomic analysis for medication optimization
- Multi-omics data integration and pathway analysis

---

## Conclusion

The Metabolic Twin system represents a comprehensive approach to diabetes reversal through data-driven precision medicine. By combining stateless computational engines with intuitive clinical workflows, the platform enables healthcare providers to deliver personalized treatment plans while maintaining clinical oversight and safety standards.

The modular architecture ensures scalability and adaptability, while the evidence-based approach to target setting and progress monitoring provides clinical confidence in treatment decisions. The system's focus on provider-controlled workflows with patient engagement dashboards creates an optimal balance between clinical authority and patient empowerment.

Through continuous monitoring, adaptive treatment protocols, and comprehensive progress tracking, the Metabolic Twin system supports the achievement of diabetes remission while generating valuable real-world evidence for protocol refinement and population health improvement.
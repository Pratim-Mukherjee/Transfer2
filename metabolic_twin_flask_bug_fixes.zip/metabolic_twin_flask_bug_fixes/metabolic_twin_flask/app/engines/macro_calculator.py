# app/engines/macro_calculator.py

from .delegate import get_policy
import math

def calculate_safe_deficit_range(patient_profile):
    """
    Calculate safe calorie deficit range based on patient factors
    Returns: (min_deficit, max_deficit) in kcal/day (negative values)
    """
    config = get_policy("macro_calculation_rules")
    
    age = patient_profile["demographics"]["age"]
    weight_kg = patient_profile["demographics"]["weight_kg"]
    egfr = patient_profile["metabolic_baseline"].get("egfr", 90)
    
    # Base deficit limits from configuration
    base_limits = config["deficit_limits"]["base"]
    min_deficit = base_limits["min_deficit"]
    max_deficit = base_limits["max_deficit"]
    
    # Age adjustments
    age_adjustments = config["deficit_limits"]["age_adjustments"]
    for age_bracket in age_adjustments:
        if age >= age_bracket["min_age"]:
            min_deficit = max(min_deficit, age_bracket["min_deficit"])
            max_deficit = min(max_deficit, age_bracket["max_deficit"])
    
    # Weight-based adjustments (lower limits for lower weights)
    if weight_kg < config["deficit_limits"]["low_weight_threshold"]:
        weight_factor = config["deficit_limits"]["low_weight_factor"]
        min_deficit = int(min_deficit * weight_factor)
        max_deficit = int(max_deficit * weight_factor)
    
    # Medical condition adjustments
    if egfr < config["deficit_limits"]["kidney_function_threshold"]:
        kidney_factor = config["deficit_limits"]["kidney_adjustment_factor"]
        min_deficit = int(min_deficit * kidney_factor)
        max_deficit = int(max_deficit * kidney_factor)
    
    return (min_deficit, max_deficit)

def assess_insulin_resistance_level(metabolic_baseline):
    """
    Assess insulin resistance level for carb restriction determination
    Returns: 'low', 'moderate', 'high'
    """
    config = get_policy("macro_calculation_rules")
    ir_thresholds = config["insulin_resistance_assessment"]
    
    hba1c = metabolic_baseline["hba1c_pct"]
    tg_hdl_ratio = metabolic_baseline["tg_mg_dl"] / max(metabolic_baseline["hdl_mg_dl"], 1)
    
    # Score based on HbA1c
    hba1c_score = 0
    if hba1c >= ir_thresholds["hba1c_high_threshold"]:
        hba1c_score = 2
    elif hba1c >= ir_thresholds["hba1c_moderate_threshold"]:
        hba1c_score = 1
    
    # Score based on TG/HDL ratio
    ratio_score = 0
    if tg_hdl_ratio >= ir_thresholds["tg_hdl_high_threshold"]:
        ratio_score = 2
    elif tg_hdl_ratio >= ir_thresholds["tg_hdl_moderate_threshold"]:
        ratio_score = 1
    
    # Combine scores
    total_score = hba1c_score + ratio_score
    
    if total_score >= 3:
        return "high"
    elif total_score >= 2:
        return "moderate"
    else:
        return "low"

def calculate_bmr(demographics):
    """
    Calculate Basal Metabolic Rate using Mifflin-St Jeor equation
    """
    weight_kg = demographics["weight_kg"]
    height_cm = demographics["height_cm"]
    age = demographics["age"]
    gender = demographics.get("gender", "male")
    
    # Mifflin-St Jeor equation
    bmr = 10 * weight_kg + 6.25 * height_cm - 5 * age
    
    if gender.lower() == "female":
        bmr -= 161
    else:
        bmr += 5
    
    return bmr

def calculate_tdee(demographics, activity_level, physical_activities=None):
    """
    Calculate Total Daily Energy Expenditure
    Includes baseline activity level + planned physical activities
    """
    config = get_policy("macro_calculation_rules")
    activity_multipliers = config["activity_multipliers"]

    bmr = calculate_bmr(demographics)

    # Base TDEE from activity level (sedentary baseline for most)
    multiplier = activity_multipliers.get(activity_level, activity_multipliers["sedentary"])
    base_tdee = bmr * multiplier

    # Add calories from planned physical activities
    activity_calories = 0
    if physical_activities and len(physical_activities) > 0:
        for activity in physical_activities:
            # Weekly calories divided by 7 for daily average
            activity_calories += activity.get('weekly_calories', 0) / 7

    total_tdee = base_tdee + activity_calories

    return total_tdee

def calculate_protein_target(demographics, program_intensity):
    """
    Calculate protein target based on weight and program intensity
    """
    config = get_policy("macro_calculation_rules")
    protein_targets = config["protein_targets"]
    
    weight_kg = demographics["weight_kg"]
    protein_per_kg = protein_targets.get(program_intensity, protein_targets["moderate"])
    
    protein_g = weight_kg * protein_per_kg
    protein_calories = protein_g * 4
    
    return protein_g, protein_calories

def calculate_carb_target(insulin_resistance_level):
    """
    Calculate carb target based on insulin resistance level
    """
    config = get_policy("macro_calculation_rules")
    carb_targets = config["carb_targets"]
    
    carb_g = carb_targets.get(insulin_resistance_level, carb_targets["moderate"])
    carb_calories = carb_g * 4
    
    return carb_g, carb_calories

def validate_deficit_safety(deficit_kcal, patient_profile):
    """
    Validate that the chosen deficit is within safe range
    """
    min_deficit, max_deficit = calculate_safe_deficit_range(patient_profile)
    
    return min_deficit <= deficit_kcal <= max_deficit

def calculate_protocol_macros(enhanced_baseline, doctor_deficit_kcal, program_intensity="intensive"):
    """
    Main function to calculate macro targets using simplified hierarchy:
    1. Protein (fixed for muscle preservation)
    2. Carbs (minimized for glucose control)
    3. Fat (fills remainder)
    4. Calories (determined by deficit)
    """
    demographics = enhanced_baseline["patient_profile"]["demographics"]
    metabolic_baseline = enhanced_baseline["patient_profile"]["metabolic_baseline"]
    lifestyle = enhanced_baseline["patient_profile"]["lifestyle_constraints"]
    
    # Validate deficit safety
    if not validate_deficit_safety(doctor_deficit_kcal, enhanced_baseline["patient_profile"]):
        min_def, max_def = calculate_safe_deficit_range(enhanced_baseline["patient_profile"])
        raise ValueError(f"Deficit {doctor_deficit_kcal} outside safe range [{min_def}, {max_def}]")

    # Calculate total daily calories including physical activities
    activity_level = lifestyle.get("activity_level", "sedentary")
    physical_activities = lifestyle.get("physical_activities", [])
    tdee = calculate_tdee(demographics, activity_level, physical_activities)
    total_calories = max(800, tdee + doctor_deficit_kcal)  # Safety minimum
    
    # Step 1: Protein (muscle preservation priority)
    protein_g, protein_calories = calculate_protein_target(demographics, program_intensity)
    
    # Step 2: Carbs (glucose control priority)
    ir_level = assess_insulin_resistance_level(metabolic_baseline)
    carb_g, carb_calories = calculate_carb_target(ir_level)
    
    # Step 3: Fat (fills remainder)
    config = get_policy("macro_calculation_rules")
    min_fat_pct = config["fat_limits"]["minimum_percent"] / 100.0
    
    remaining_calories = total_calories - protein_calories - carb_calories
    min_fat_calories = total_calories * min_fat_pct
    
    # Ensure minimum fat requirements are met
    fat_calories = max(remaining_calories, min_fat_calories)
    fat_g = fat_calories / 9
    
    # Recalculate total if fat minimum was applied
    actual_total_calories = protein_calories + carb_calories + fat_calories
    
    # Calculate percentages
    protein_pct = round(100 * protein_calories / actual_total_calories, 1)
    carb_pct = round(100 * carb_calories / actual_total_calories, 1)
    fat_pct = round(100 * fat_calories / actual_total_calories, 1)
    
    return {
        "total_calories": round(actual_total_calories),
        "protein_g": round(protein_g, 1),
        "carb_g": round(carb_g, 1),
        "fat_g": round(fat_g, 1),
        "protein_pct": protein_pct,
        "carb_pct": carb_pct,
        "fat_pct": fat_pct,
        "tdee": round(tdee),
        "deficit_kcal": doctor_deficit_kcal,
        "insulin_resistance_level": ir_level,
        "program_intensity": program_intensity,
        "validation": {
            "deficit_safe": True,
            "min_fat_applied": fat_calories > remaining_calories,
            "total_check": round(protein_calories + carb_calories + fat_calories)
        }
    }

def get_recommended_deficit(patient_profile, program_duration_weeks):
    """
    Calculate recommended deficit based on patient profile and program duration
    """
    config = get_policy("macro_calculation_rules")
    
    # Get safe range
    min_deficit, max_deficit = calculate_safe_deficit_range(patient_profile)
    
    # Calculate target weight loss based on metabolic state
    current_weight = patient_profile["demographics"]["weight_kg"]
    target_weight_loss_pct = config["recommended_targets"]["weight_loss_percent"]
    target_weight_loss_kg = current_weight * (target_weight_loss_pct / 100.0)
    
    # Calculate weekly target
    weekly_target_kg = target_weight_loss_kg / program_duration_weeks
    
    # Convert to daily calorie deficit (assuming 7700 kcal per kg fat)
    energy_config = get_policy("energy")
    kcal_per_kg = energy_config["kcal_per_kg_fat"]
    adaptation_factor = energy_config["adaptation_factor"]
    
    recommended_deficit = int(-(weekly_target_kg * kcal_per_kg * 7) / (7 * adaptation_factor))
    
    # Clamp to safe range
    recommended_deficit = max(min_deficit, min(max_deficit, recommended_deficit))
    
    return {
        "recommended_deficit": recommended_deficit,
        "safe_range": (min_deficit, max_deficit),
        "target_weight_loss_kg": round(target_weight_loss_kg, 1),
        "weekly_target_kg": round(weekly_target_kg, 2)
    }
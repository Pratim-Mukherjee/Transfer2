
import os, json
from functools import lru_cache

REL_ROOT = os.path.join(os.path.dirname(__file__), "..", "relationships")

def _load(path):
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)

@lru_cache(maxsize=128)
def get_formula(name):
    return _load(os.path.join(REL_ROOT, "formulas", f"{name}.json"))

@lru_cache(maxsize=128)
def get_band(name):
    return _load(os.path.join(REL_ROOT, "bands", f"{name}.json"))

@lru_cache(maxsize=128)
def get_curve(name):
    return _load(os.path.join(REL_ROOT, "curves", f"{name}.json"))

@lru_cache(maxsize=128)
def get_policy(name):
    return _load(os.path.join(REL_ROOT, "policies", f"{name}.json"))

@lru_cache(maxsize=128)
def get_target(name):
    return _load(os.path.join(REL_ROOT, "targets", f"{name}.json"))

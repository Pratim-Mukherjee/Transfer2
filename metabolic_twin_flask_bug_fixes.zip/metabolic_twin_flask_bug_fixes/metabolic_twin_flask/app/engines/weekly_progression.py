# app/engines/weekly_progression.py

from .delegate import get_curve, get_policy
from .interim import _interp_table
import datetime

def calculate_weekly_progression(enhanced_baseline, doctor_decisions, program_config, protocol_macros):
    """
    Generate complete weekly progression using existing curves and milestone detection
    Includes both actual targets and ideal trajectories for comparison
    """
    patient_profile = enhanced_baseline["patient_profile"]
    duration_weeks = program_config.get("duration_weeks", 12)
    daily_deficit = doctor_decisions.get("calorie_deficit_kcal", -600)

    # Calculate baseline metrics
    baseline_metrics = extract_baseline_metrics(patient_profile)

    # Calculate total expected changes using existing curves
    total_projections = calculate_total_projections(baseline_metrics, daily_deficit, duration_weeks)

    # Calculate ideal trajectory (optimal targets for comparison)
    ideal_projections = calculate_ideal_trajectory(baseline_metrics, duration_weeks)

    # Generate week-by-week progression
    weekly_targets = []
    for week in range(1, duration_weeks + 1):
        week_targets = calculate_week_targets(week, duration_weeks, baseline_metrics, total_projections)
        week_ideal_targets = calculate_week_ideal_targets(week, duration_weeks, baseline_metrics, ideal_projections)
        week_milestones = detect_weekly_milestones(week, week_targets, baseline_metrics, patient_profile, duration_weeks)
        week_monitoring = determine_monitoring_requirements(week, week_targets, patient_profile)

        weekly_entry = {
            "week": week,
            "targets": week_targets,
            "ideal_targets": week_ideal_targets,
            "milestones": week_milestones,
            "monitoring": week_monitoring
        }
        weekly_targets.append(weekly_entry)

    # Calculate overall projections
    overall_projections = calculate_overall_projections(baseline_metrics, total_projections, duration_weeks)

    # Generate complete weekly progression JSON
    progression_json = {
        "patient_id": f"{patient_profile['demographics']['name'].lower().replace(' ', '_')}_001",
        "program_duration": duration_weeks,
        "generated_date": datetime.datetime.utcnow().isoformat() + "Z",
        "weekly_targets": weekly_targets,
        "overall_projections": overall_projections
    }

    return progression_json

def extract_baseline_metrics(patient_profile):
    """
    Extract baseline metrics from patient profile
    """
    demographics = patient_profile["demographics"]
    metabolic = patient_profile["metabolic_baseline"]
    
    # Use default values if metrics not available (common in real clinical settings)
    baseline = {
        "weight_kg": demographics["weight_kg"],
        "bodyfat_pct": metabolic.get("bodyfat_pct", 32),  # Estimated if not measured
        "hba1c_pct": metabolic.get("hba1c_pct", 7.8),
        "fbg_mgdl": metabolic.get("fbg_mgdl", 135),  # Estimated from HbA1c if not available
        "tir_pct": 62,  # Typical baseline for diabetes patients
        "cv_pct": 29,   # Typical baseline variability
        "ttb_min": 295, # Typical baseline time to baseline
        "lc_z": -0.2    # Typical baseline liver chatter
    }
    
    return baseline

def calculate_total_projections(baseline_metrics, daily_deficit, duration_weeks):
    """
    Calculate total expected changes using existing curve relationships
    """
    energy = get_policy("energy")
    
    # Calculate total weight and body fat loss using existing energy model
    # Note: daily_deficit is already negative (e.g., -600), so gross_deficit will be negative
    days = duration_weeks * 7
    gross_deficit = daily_deficit * days
    fat_kg_loss = gross_deficit / energy["kcal_per_kg_fat"] * energy["adaptation_factor"]
    delta_bodyfat_pct = (fat_kg_loss / max(1e-6, baseline_metrics["weight_kg"])) * 100.0
    
    # Use existing curves to project metabolic improvements
    projections = {}
    projections["delta_weight_kg"] = fat_kg_loss
    projections["delta_bodyfat_pct"] = delta_bodyfat_pct
    
    # Use existing curve interpolation from interim.py
    projections["delta_ttb_min"] = _interp_table(
        get_curve("fatpct_to_ttb_delta"), "delta_bodyfat_pct", "delta_ttb_min", delta_bodyfat_pct
    )
    projections["delta_fbg_mgdl"] = _interp_table(
        get_curve("fatpct_to_fbg_delta"), "delta_bodyfat_pct", "delta_fbg_mgdl", delta_bodyfat_pct
    )
    projections["delta_cv_pct"] = _interp_table(
        get_curve("fatpct_to_cv_delta"), "delta_bodyfat_pct", "delta_cv_pct", delta_bodyfat_pct
    )
    projections["delta_tir_pct"] = _interp_table(
        get_curve("fatpct_to_tir_delta"), "delta_bodyfat_pct", "delta_tir_pct", delta_bodyfat_pct
    )
    projections["delta_lc_z"] = _interp_table(
        get_curve("fatpct_to_lc_delta"), "delta_bodyfat_pct", "delta_lc_z", delta_bodyfat_pct
    )
    projections["delta_hba1c_pct"] = _interp_table(
        get_curve("fatpct_to_hba1c_delta"), "delta_bodyfat_pct", "delta_hba1c_pct", delta_bodyfat_pct
    )

    # Store daily deficit for display (convert back to positive for UI)
    projections["daily_deficit"] = abs(daily_deficit)

    return projections


def calculate_ideal_trajectory(baseline_metrics, duration_weeks):
    """
    Calculate ideal trajectory targets (optimal path for comparison)
    This represents the "best case scenario" with perfect adherence
    Uses slightly more aggressive but still safe improvements
    """
    energy = get_policy("energy")

    # Ideal deficit: -800 kcal/day (more aggressive than typical)
    ideal_daily_deficit = -800
    days = duration_weeks * 7
    gross_deficit = ideal_daily_deficit * days
    fat_kg_loss = gross_deficit / energy["kcal_per_kg_fat"] * energy["adaptation_factor"]
    delta_bodyfat_pct = (fat_kg_loss / max(1e-6, baseline_metrics["weight_kg"])) * 100.0

    # Calculate ideal projections using curves (slightly more optimistic)
    projections = {}
    projections["delta_weight_kg"] = fat_kg_loss
    projections["delta_bodyfat_pct"] = delta_bodyfat_pct

    # Use curves for ideal projections (10% more improvement than actual)
    projections["delta_ttb_min"] = _interp_table(
        get_curve("fatpct_to_ttb_delta"), "delta_bodyfat_pct", "delta_ttb_min", delta_bodyfat_pct
    ) * 1.1

    projections["delta_fbg_mgdl"] = _interp_table(
        get_curve("fatpct_to_fbg_delta"), "delta_bodyfat_pct", "delta_fbg_mgdl", delta_bodyfat_pct
    ) * 1.1

    projections["delta_cv_pct"] = _interp_table(
        get_curve("fatpct_to_cv_delta"), "delta_bodyfat_pct", "delta_cv_pct", delta_bodyfat_pct
    ) * 1.1

    projections["delta_tir_pct"] = _interp_table(
        get_curve("fatpct_to_tir_delta"), "delta_bodyfat_pct", "delta_tir_pct", delta_bodyfat_pct
    ) * 1.1

    projections["delta_lc_z"] = _interp_table(
        get_curve("fatpct_to_lc_delta"), "delta_bodyfat_pct", "delta_lc_z", delta_bodyfat_pct
    ) * 1.1

    projections["delta_hba1c_pct"] = _interp_table(
        get_curve("fatpct_to_hba1c_delta"), "delta_bodyfat_pct", "delta_hba1c_pct", delta_bodyfat_pct
    ) * 1.1

    projections["daily_deficit"] = abs(ideal_daily_deficit)

    return projections


def calculate_week_ideal_targets(week, total_weeks, baseline_metrics, ideal_projections):
    """
    Calculate ideal targets for a specific week (for comparison with actual)
    """
    # Calculate progression fraction
    progress_fraction = week / total_weeks

    # Apply progression to each metric
    ideal_targets = {}

    ideal_targets["weight_kg"] = round(
        baseline_metrics["weight_kg"] + (progress_fraction * ideal_projections["delta_weight_kg"]), 1
    )
    ideal_targets["bodyfat_pct"] = round(
        baseline_metrics["bodyfat_pct"] + (progress_fraction * ideal_projections["delta_bodyfat_pct"]), 1
    )
    ideal_targets["hba1c_pct"] = round(
        baseline_metrics["hba1c_pct"] + (progress_fraction * ideal_projections["delta_hba1c_pct"]), 2
    )
    ideal_targets["fbg_mgdl"] = round(
        baseline_metrics["fbg_mgdl"] + (progress_fraction * ideal_projections["delta_fbg_mgdl"]), 0
    )
    ideal_targets["tir_pct"] = round(
        baseline_metrics["tir_pct"] + (progress_fraction * ideal_projections["delta_tir_pct"]), 1
    )
    ideal_targets["cv_pct"] = round(
        baseline_metrics["cv_pct"] + (progress_fraction * ideal_projections["delta_cv_pct"]), 1
    )
    ideal_targets["ttb_min"] = round(
        baseline_metrics["ttb_min"] + (progress_fraction * ideal_projections["delta_ttb_min"]), 0
    )

    # Calculate ideal pillar scores (slightly higher than actual targets)
    ideal_targets["safety_score"] = min(100, calculate_safety_score(week, ideal_targets, baseline_metrics, total_weeks) + 2)
    ideal_targets["glycemic_score"] = min(100, calculate_glycemic_score(ideal_targets) + 3)
    ideal_targets["metabolic_score"] = min(100, calculate_metabolic_score(ideal_targets, baseline_metrics) + 2)
    ideal_targets["stability_score"] = min(100, calculate_stability_score(ideal_targets) + 2)
    ideal_targets["liver_score"] = min(100, calculate_liver_score(ideal_targets, baseline_metrics) + 5)
    ideal_targets["pancreatic_score"] = min(100, calculate_pancreatic_score(ideal_targets, baseline_metrics) + 3)
    ideal_targets["overall_score"] = calculate_overall_score(ideal_targets)

    ideal_targets["energy_deficit_kcal"] = ideal_projections.get("daily_deficit", 0)

    return ideal_targets


def calculate_week_targets(week, total_weeks, baseline_metrics, total_projections):
    """
    Calculate targets for specific week using linear progression
    Includes all metrics: weight, HbA1c, metabolic markers, and pillar scores
    """
    # Calculate progression fraction (non-linear could be added later)
    progress_fraction = week / total_weeks

    # Apply progression to each metric
    week_targets = {}

    week_targets["weight_kg"] = round(
        baseline_metrics["weight_kg"] + (progress_fraction * total_projections["delta_weight_kg"]), 1
    )
    week_targets["bodyfat_pct"] = round(
        baseline_metrics["bodyfat_pct"] + (progress_fraction * total_projections["delta_bodyfat_pct"]), 1
    )
    week_targets["hba1c_pct"] = round(
        baseline_metrics["hba1c_pct"] + (progress_fraction * total_projections["delta_hba1c_pct"]), 2
    )
    week_targets["fbg_mgdl"] = round(
        baseline_metrics["fbg_mgdl"] + (progress_fraction * total_projections["delta_fbg_mgdl"]), 0
    )
    week_targets["tir_pct"] = round(
        baseline_metrics["tir_pct"] + (progress_fraction * total_projections["delta_tir_pct"]), 1
    )
    week_targets["cv_pct"] = round(
        baseline_metrics["cv_pct"] + (progress_fraction * total_projections["delta_cv_pct"]), 1
    )
    week_targets["ttb_min"] = round(
        baseline_metrics["ttb_min"] + (progress_fraction * total_projections["delta_ttb_min"]), 0
    )

    # Calculate pillar scores based on current metrics
    # These scores represent progress towards optimal metabolic health (0-100 scale)

    # Safety Score: Based on hypoglycemia risk, weight loss rate, and metabolic stability
    week_targets["safety_score"] = calculate_safety_score(week, week_targets, baseline_metrics, total_weeks)

    # Glycemic Score: Based on HbA1c, TIR, and glucose variability
    week_targets["glycemic_score"] = calculate_glycemic_score(week_targets)

    # Metabolic Score: Based on weight loss, body fat, and overall metabolic improvement
    week_targets["metabolic_score"] = calculate_metabolic_score(week_targets, baseline_metrics)

    # Stability Score: Based on glucose stability (CV) and TTB
    week_targets["stability_score"] = calculate_stability_score(week_targets)

    # Liver Score: Based on liver fat reduction (estimated from body fat loss)
    week_targets["liver_score"] = calculate_liver_score(week_targets, baseline_metrics)

    # Pancreatic Score: Based on beta cell recovery (estimated from HbA1c and FBG improvement)
    week_targets["pancreatic_score"] = calculate_pancreatic_score(week_targets, baseline_metrics)

    # Overall Score: Weighted average of all pillar scores
    week_targets["overall_score"] = calculate_overall_score(week_targets)

    # Energy Deficit (for display purposes)
    week_targets["energy_deficit_kcal"] = total_projections.get("daily_deficit", 0)

    return week_targets

def detect_weekly_milestones(week, week_targets, baseline_metrics, patient_profile, duration_weeks):
    """
    Detect milestones and clinical decision points for specific week
    """
    config = get_policy("milestone_triggers")
    milestones = []
    
    # Medication review milestones
    if week % 4 == 0:  # Every 4 weeks
        hba1c_improvement = baseline_metrics["hba1c_pct"] - week_targets["hba1c_pct"]
        fbg_improvement = baseline_metrics["fbg_mgdl"] - week_targets["fbg_mgdl"]
        
        if hba1c_improvement >= 0.5 or fbg_improvement >= 20:
            milestones.append({
                "type": "medication_review",
                "description": "Consider medication dose reduction due to glucose improvement",
                "trigger": f"HbA1c improved by {hba1c_improvement:.1f}% or FBG improved by {fbg_improvement:.0f} mg/dL"
            })
    
    # Phase transition milestones
    if week == 8:
        if week_targets["hba1c_pct"] < 7.0:
            milestones.append({
                "type": "phase_transition",
                "description": "Consider transition from intensive to moderate phase",
                "trigger": "HbA1c below 7.0% at week 8"
            })
    
    # Remission assessment milestone
    if week == duration_weeks:
        remission_criteria = get_policy("remission")
        if (week_targets["hba1c_pct"] <= remission_criteria["hba1c_pct"]["hi"] and
            week_targets["fbg_mgdl"] >= remission_criteria["fbg_mgdl"]["lo"] and
            week_targets["fbg_mgdl"] <= remission_criteria["fbg_mgdl"]["hi"]):
            milestones.append({
                "type": "remission_assessment",
                "description": "Patient meets criteria for diabetes remission evaluation",
                "trigger": "HbA1c and fasting glucose in remission range"
            })
    
    # Weight loss rate milestones
    weeks_elapsed = week
    if weeks_elapsed >= 4:
        expected_weight_loss = (baseline_metrics["weight_kg"] - week_targets["weight_kg"])
        weekly_rate = expected_weight_loss / weeks_elapsed
        
        if weekly_rate > 1.2:  # > 1.2 kg/week average
            milestones.append({
                "type": "safety_review",
                "description": "Weight loss rate above target - consider calorie increase",
                "trigger": f"Average weight loss {weekly_rate:.1f} kg/week"
            })
    
    return milestones

def determine_monitoring_requirements(week, week_targets, patient_profile):
    """
    Determine monitoring requirements for specific week
    """
    base_monitoring = {
        "glucose_frequency": "daily_cgm",
        "weight_check": "weekly",
        "medication_review": False
    }
    
    # Enhanced monitoring at key weeks
    if week % 4 == 0:  # Every 4 weeks
        base_monitoring["lab_tests"] = ["hba1c", "basic_metabolic_panel"]
        base_monitoring["medication_review"] = True
    
    # Additional monitoring based on risk factors
    egfr = patient_profile["metabolic_baseline"].get("egfr", 90)
    if egfr < 60:
        base_monitoring["kidney_monitoring"] = "monthly_creatinine_egfr"
    
    age = patient_profile["demographics"]["age"]
    if age > 65:
        base_monitoring["safety_check"] = "enhanced_symptom_monitoring"
    
    return base_monitoring

def calculate_overall_projections(baseline_metrics, total_projections, duration_weeks):
    """
    Calculate overall program projections and success probability
    """
    # Calculate final expected values
    final_weight = baseline_metrics["weight_kg"] + total_projections["delta_weight_kg"]
    final_hba1c = baseline_metrics["hba1c_pct"] + total_projections["delta_hba1c_pct"]

    # Estimate probability of remission based on expected improvements
    remission_probability = estimate_remission_probability(baseline_metrics, total_projections)

    # Calculate safety score based on patient factors and program intensity
    safety_score = calculate_program_safety_score(baseline_metrics, total_projections, duration_weeks)

    overall_projections = {
        "expected_weight_loss_kg": round(-total_projections["delta_weight_kg"], 1),
        "expected_hba1c_reduction": round(-total_projections["delta_hba1c_pct"], 2),
        "probability_remission": round(remission_probability, 2),
        "safety_score": round(safety_score, 2),
        "final_projected_weight_kg": round(final_weight, 1),
        "final_projected_hba1c_pct": round(final_hba1c, 2)
    }

    return overall_projections

def estimate_remission_probability(baseline_metrics, total_projections):
    """
    Estimate probability of achieving diabetes remission
    """
    # Simple model based on expected HbA1c improvement
    final_hba1c = baseline_metrics["hba1c_pct"] + total_projections["delta_hba1c_pct"]
    hba1c_improvement = -total_projections["delta_hba1c_pct"]
    
    # Probability increases with greater HbA1c improvement and lower final HbA1c
    if final_hba1c <= 6.0:
        probability = 0.9
    elif final_hba1c <= 6.5:
        probability = 0.75
    elif final_hba1c <= 7.0:
        probability = 0.5
    else:
        probability = 0.25
    
    # Adjust based on magnitude of improvement
    if hba1c_improvement >= 2.0:
        probability = min(0.95, probability + 0.1)
    elif hba1c_improvement >= 1.5:
        probability = min(0.9, probability + 0.05)
    
    return probability

def calculate_program_safety_score(baseline_metrics, total_projections, duration_weeks):
    """
    Calculate overall program safety score based on program parameters (0-1 scale)
    This is different from the weekly safety pillar score
    """
    safety_score = 1.0  # Start with perfect safety score

    # Reduce score for aggressive weight loss
    weekly_weight_loss = -total_projections["delta_weight_kg"] / duration_weeks
    if weekly_weight_loss > 1.0:
        safety_score -= 0.1
    if weekly_weight_loss > 1.5:
        safety_score -= 0.2

    # Reduce score for very low final HbA1c (hypoglycemia risk)
    final_hba1c = baseline_metrics["hba1c_pct"] + total_projections["delta_hba1c_pct"]
    if final_hba1c < 6.0:
        safety_score -= 0.1

    # Ensure score stays within valid range
    return max(0.5, min(1.0, safety_score))

def generate_milestone_configuration():
    """
    Generate milestone trigger configuration if not exists
    """
    milestone_config = {
        "medication_review_triggers": {
            "hba1c_improvement_threshold": 0.5,
            "fbg_improvement_threshold": 20,
            "review_frequency_weeks": 4
        },
        "phase_transition_triggers": {
            "intensive_to_moderate": {
                "week_minimum": 8,
                "hba1c_threshold": 7.0,
                "weight_loss_minimum_kg": 5
            }
        },
        "safety_triggers": {
            "excessive_weight_loss": {
                "weekly_rate_threshold": 1.2,
                "action": "increase_calories"
            }
        }
    }

    return milestone_config


# ===========================================
# PILLAR SCORE CALCULATION FUNCTIONS
# ===========================================

def calculate_safety_score(week, week_targets, baseline_metrics, total_weeks):
    """
    Calculate safety score based on hypoglycemia risk, weight loss rate, and metabolic stability
    Score: 0-100, higher is safer
    """
    score = 100.0

    # Check weight loss rate
    weeks_elapsed = week
    if weeks_elapsed > 0:
        weight_loss = baseline_metrics["weight_kg"] - week_targets["weight_kg"]
        weekly_rate = weight_loss / weeks_elapsed

        # Penalize if weight loss is too fast (>1.2 kg/week is risky)
        if weekly_rate > 1.5:
            score -= 25
        elif weekly_rate > 1.2:
            score -= 15

    # Check glucose variability (CV) - high CV indicates instability
    cv = week_targets.get("cv_pct", 29)
    if cv > 35:
        score -= 15
    elif cv > 30:
        score -= 10

    # Check HbA1c for hypo risk - very low HbA1c increases hypo risk
    hba1c = week_targets["hba1c_pct"]
    if hba1c < 5.5:
        score -= 10

    # Reward good time in range
    tir = week_targets.get("tir_pct", 62)
    if tir >= 70:
        score = min(100, score + 5)

    return max(0, min(100, round(score)))


def calculate_glycemic_score(week_targets):
    """
    Calculate glycemic control score based on HbA1c, TIR, and glucose variability
    Score: 0-100, higher is better glycemic control
    """
    score = 0.0

    # HbA1c component (50% weight)
    hba1c = week_targets["hba1c_pct"]
    if hba1c <= 5.7:
        hba1c_score = 100
    elif hba1c <= 6.5:
        hba1c_score = 85
    elif hba1c <= 7.0:
        hba1c_score = 70
    elif hba1c <= 8.0:
        hba1c_score = 50
    else:
        hba1c_score = max(0, 50 - (hba1c - 8.0) * 10)

    # Time in Range component (30% weight)
    tir = week_targets.get("tir_pct", 62)
    tir_score = min(100, tir * 1.2)  # TIR of 85% = 100 score

    # Coefficient of Variation component (20% weight) - lower is better
    cv = week_targets.get("cv_pct", 29)
    if cv <= 20:
        cv_score = 100
    elif cv <= 30:
        cv_score = 70
    elif cv <= 36:
        cv_score = 50
    else:
        cv_score = max(0, 50 - (cv - 36) * 5)

    score = 0.5 * hba1c_score + 0.3 * tir_score + 0.2 * cv_score

    return max(0, min(100, round(score)))


def calculate_metabolic_score(week_targets, baseline_metrics):
    """
    Calculate metabolic improvement score based on weight loss, body fat, and metabolic markers
    Score: 0-100, higher indicates better metabolic health
    """
    score = 0.0

    # Weight loss progress (40% weight)
    weight_loss_pct = ((baseline_metrics["weight_kg"] - week_targets["weight_kg"]) /
                       baseline_metrics["weight_kg"]) * 100
    if weight_loss_pct >= 15:
        weight_score = 100
    elif weight_loss_pct >= 10:
        weight_score = 85
    elif weight_loss_pct >= 7:
        weight_score = 70
    elif weight_loss_pct >= 5:
        weight_score = 55
    else:
        weight_score = min(50, weight_loss_pct * 10)

    # Body fat reduction (30% weight)
    bodyfat = week_targets.get("bodyfat_pct", 32)
    if bodyfat <= 20:
        bodyfat_score = 100
    elif bodyfat <= 25:
        bodyfat_score = 80
    elif bodyfat <= 30:
        bodyfat_score = 60
    else:
        bodyfat_score = max(0, 60 - (bodyfat - 30) * 5)

    # Fasting blood glucose (30% weight)
    fbg = week_targets.get("fbg_mgdl", 135)
    if fbg <= 100:
        fbg_score = 100
    elif fbg <= 110:
        fbg_score = 85
    elif fbg <= 126:
        fbg_score = 70
    else:
        fbg_score = max(0, 70 - (fbg - 126) * 2)

    score = 0.4 * weight_score + 0.3 * bodyfat_score + 0.3 * fbg_score

    return max(0, min(100, round(score)))


def calculate_stability_score(week_targets):
    """
    Calculate glucose stability score based on CV and TTB
    Score: 0-100, higher indicates better stability
    """
    score = 0.0

    # CV component (60% weight) - lower is better
    cv = week_targets.get("cv_pct", 29)
    if cv <= 20:
        cv_score = 100
    elif cv <= 30:
        cv_score = 75
    elif cv <= 36:
        cv_score = 50
    else:
        cv_score = max(0, 50 - (cv - 36) * 3)

    # TTB component (40% weight) - lower is better (faster return to baseline)
    ttb = week_targets.get("ttb_min", 295)
    if ttb <= 180:
        ttb_score = 100
    elif ttb <= 240:
        ttb_score = 80
    elif ttb <= 300:
        ttb_score = 60
    else:
        ttb_score = max(0, 60 - (ttb - 300) * 0.5)

    score = 0.6 * cv_score + 0.4 * ttb_score

    return max(0, min(100, round(score)))


def calculate_liver_score(week_targets, baseline_metrics):
    """
    Calculate liver recovery score based on body fat reduction (proxy for liver fat)
    Score: 0-100, higher indicates better liver health
    """
    # Liver fat is highly correlated with body fat reduction
    # Significant improvement in liver fat typically occurs with 5%+ body weight loss

    weight_loss_pct = ((baseline_metrics["weight_kg"] - week_targets["weight_kg"]) /
                       baseline_metrics["weight_kg"]) * 100

    bodyfat = week_targets.get("bodyfat_pct", 32)

    # Weight loss component (50% weight)
    if weight_loss_pct >= 10:
        weight_component = 100
    elif weight_loss_pct >= 7:
        weight_component = 85
    elif weight_loss_pct >= 5:
        weight_component = 70
    else:
        weight_component = min(70, weight_loss_pct * 14)

    # Body fat component (50% weight)
    if bodyfat <= 20:
        bodyfat_component = 100
    elif bodyfat <= 25:
        bodyfat_component = 85
    elif bodyfat <= 30:
        bodyfat_component = 65
    else:
        bodyfat_component = max(0, 65 - (bodyfat - 30) * 5)

    score = 0.5 * weight_component + 0.5 * bodyfat_component

    return max(0, min(100, round(score)))


def calculate_pancreatic_score(week_targets, baseline_metrics):
    """
    Calculate pancreatic beta cell recovery score based on HbA1c and FBG improvement
    Score: 0-100, higher indicates better beta cell function
    """
    # Beta cell recovery is indicated by improved glucose control and reduced glucose variability

    hba1c = week_targets["hba1c_pct"]
    hba1c_improvement = baseline_metrics["hba1c_pct"] - hba1c

    fbg = week_targets.get("fbg_mgdl", 135)
    fbg_improvement = baseline_metrics["fbg_mgdl"] - fbg

    # HbA1c improvement component (50% weight)
    if hba1c <= 5.7:
        hba1c_component = 100
    elif hba1c <= 6.5:
        hba1c_component = 80
    elif hba1c <= 7.0:
        hba1c_component = 60
    else:
        # Give credit for improvement even if not at target yet
        hba1c_component = min(60, 30 + hba1c_improvement * 15)

    # FBG improvement component (30% weight)
    if fbg <= 100:
        fbg_component = 100
    elif fbg <= 110:
        fbg_component = 80
    else:
        # Give credit for improvement
        fbg_component = min(80, 40 + fbg_improvement * 2)

    # Time to baseline component (20% weight) - faster TTB indicates better insulin response
    ttb = week_targets.get("ttb_min", 295)
    if ttb <= 180:
        ttb_component = 100
    elif ttb <= 240:
        ttb_component = 70
    else:
        ttb_component = max(0, 70 - (ttb - 240) * 0.5)

    score = 0.5 * hba1c_component + 0.3 * fbg_component + 0.2 * ttb_component

    return max(0, min(100, round(score)))


def calculate_overall_score(week_targets):
    """
    Calculate overall progress score as weighted average of all pillar scores
    Score: 0-100
    """
    weights = {
        "safety_score": 0.20,
        "glycemic_score": 0.25,
        "metabolic_score": 0.20,
        "stability_score": 0.10,
        "liver_score": 0.15,
        "pancreatic_score": 0.10
    }

    total_score = 0.0
    for metric, weight in weights.items():
        total_score += week_targets.get(metric, 0) * weight

    return round(total_score)
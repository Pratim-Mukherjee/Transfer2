# app/engines/protocol_generator.py

from .macro_calculator import calculate_protocol_macros, get_recommended_deficit
from .supplement_optimizer import analyze_supplement_needs, generate_supplement_schedule
from .medication_timing import optimize_daily_schedule
from .meal_distributor import calculate_meal_distribution, generate_meal_examples, validate_meal_distribution
from .delegate import get_policy
import datetime

def generate_complete_protocol(enhanced_baseline, doctor_decisions, program_config):
    """
    Main function to generate complete patient protocol
    Returns: Complete protocol JSON in the specified format
    """
    
    # Extract key components
    patient_profile = enhanced_baseline["patient_profile"]
    medications = doctor_decisions.get("medications", [])
    deficit_kcal = doctor_decisions.get("calorie_deficit_kcal", -600)
    
    # Determine program phase and intensity
    phase_info = determine_program_phase(patient_profile["metabolic_baseline"], program_config)
    
    # Calculate macro targets
    macro_targets = calculate_protocol_macros(
        enhanced_baseline, 
        deficit_kcal, 
        phase_info["intensity"]
    )
    
    # Generate supplement recommendations
    supplement_recommendations = analyze_supplement_needs(enhanced_baseline)

    # Generate meal plan using new meal distributor
    # This must be done BEFORE medication optimization so we have actual meal times
    meal_planning_config = program_config.get("meal_planning", {
        "meal_count": 3,
        "carb_strategy": "distributed",
        "selected_meal_for_carbs": 1,
        "meal_names": ["Breakfast", "Lunch", "Dinner"]
    })

    meal_distribution = calculate_meal_distribution(
        macros=macro_targets,
        meal_planning_config=meal_planning_config,
        lifestyle_constraints=patient_profile["lifestyle_constraints"]
    )

    # Optimize medication and supplement timing
    # Pass meal distribution so medications can be aligned with actual meal times
    medication_schedule = optimize_daily_schedule(
        medications,
        supplement_recommendations,
        patient_profile["lifestyle_constraints"],
        meal_distribution  # Pass meal distribution with actual meal times
    )

    # Validate meal distribution
    validation = validate_meal_distribution(meal_distribution)
    if not validation["valid"]:
        # Critical errors - cannot proceed
        raise ValueError(f"Meal distribution validation failed: {validation['errors']}")
    elif validation["warnings"]:
        # Log warnings but continue
        import logging
        logging.warning(f"Meal distribution warnings: {validation['warnings']}")

    # Generate meal examples
    # Support both old single preference and new multiple preferences
    cultural_preferences = patient_profile["lifestyle_constraints"].get("cultural_food_preferences")
    if not cultural_preferences:
        # Fallback to old single preference field for backward compatibility
        cultural_preferences = patient_profile["lifestyle_constraints"].get("cultural_food_preference", "western")
    meal_examples = generate_meal_examples(meal_distribution["meals"], cultural_preferences)

    # Format meal plan for protocol
    meal_plan = format_meal_plan_for_protocol(meal_distribution, meal_examples)
    
    # Generate activity plan from user's actual activities ONLY
    # Do not auto-generate activities - only use what user explicitly planned
    user_activities = patient_profile["lifestyle_constraints"].get("physical_activities", [])
    if user_activities and len(user_activities) > 0:
        # Use user's actual planned activities
        activity_plan = format_user_activities(user_activities)
    else:
        # No activities planned by user - return empty schedule
        activity_plan = {"dailySchedule": []}
    
    # Generate safety protocol
    safety_protocol = assess_safety_requirements(
        patient_profile,
        medications,
        supplement_recommendations,
        macro_targets
    )
    
    # Calculate initial progress percentage
    progress_percentage = calculate_initial_progress_percentage(
        patient_profile["metabolic_baseline"],
        program_config
    )
    
    # Assemble complete protocol
    complete_protocol = {
        "patient": {
            "age": patient_profile["demographics"]["age"],
            "name": patient_profile["demographics"]["name"],
            "phaseGoal": phase_info["description"],
            "currentWeek": 1,
            "currentPhase": phase_info["name"],
            "weeklyTarget": phase_info["weekly_target"],
            "progressPercentage": progress_percentage,
            "culturalPreferences": cultural_preferences  # Store cultural preferences (can be string or array)
        },
        "mealPlan": meal_plan,
        "mealPlanningConfig": meal_planning_config,  # Store meal planning configuration
        "activityPlan": activity_plan,
        "safetyProtocol": safety_protocol,
        "medicationSchedule": medication_schedule,
        "protocolOverview": create_protocol_overview(phase_info, program_config),
        "macroTargets": macro_targets
    }

    return complete_protocol

def determine_program_phase(metabolic_baseline, program_config):
    """
    Determine the appropriate program phase based on metabolic state
    Now uses user-selected duration instead of hardcoded phase duration
    """
    config = get_policy("phase_definitions")

    hba1c = metabolic_baseline.get("hba1c_pct", 7.0)
    bodyfat_pct = metabolic_baseline.get("bodyfat_pct", 25)
    program_duration = program_config.get("duration_weeks", 12)

    # Determine phase based on metabolic severity
    if hba1c >= 8.0 or bodyfat_pct >= 30:
        phase_key = "intensive"
    elif hba1c >= 7.0 or bodyfat_pct >= 27:
        phase_key = "moderate"
    else:
        phase_key = "maintenance"

    phase_config = config["phases"][phase_key]

    return {
        "name": f"Phase 1: {phase_config['name']}",
        "intensity": phase_key,
        "description": phase_config["description"],
        "weekly_target": phase_config["weekly_target"],
        "duration": program_duration,  # Use user-selected duration instead of hardcoded
        "expected_outcome": phase_config["expected_outcome"]
    }

def create_meal_schedule(macro_targets, cultural_preference):
    """
    Create meal schedule with macro distribution
    """
    config = get_policy("meal_templates")
    
    # Standard meal distribution
    meal_distribution = {
        "breakfast": 0.35,
        "lunch": 0.40,
        "dinner": 0.25
    }
    
    daily_schedule = []
    
    for meal_type, ratio in meal_distribution.items():
        # Calculate meal-specific macros
        meal_macros = {
            "calories": round(macro_targets["total_calories"] * ratio),
            "protein": round(macro_targets["protein_g"] * ratio, 1),
            "carbs": round(macro_targets["carb_g"] * ratio, 1),
            "fat": round(macro_targets["fat_g"] * ratio, 1)
        }
        
        # Get meal templates for this cultural preference
        meal_options = get_meal_templates(meal_type, meal_macros, cultural_preference)
        
        # Determine meal status (for UI display)
        status = "upcoming"
        if meal_type == "breakfast":
            status = "completed"
        elif meal_type == "lunch":
            status = "current"
        
        # Create meal schedule entry
        meal_entry = {
            "status": status,
            "mealType": meal_type,
            "timeWindow": get_meal_time_window(meal_type),
            "exampleMeals": meal_options,
            "nutritionalTargets": {
                "fat": f"{meal_macros['fat']-5}-{meal_macros['fat']+5}g",
                "carbs": f"{meal_macros['carbs']-5}-{meal_macros['carbs']+5}g", 
                "protein": f"{meal_macros['protein']-5}-{meal_macros['protein']+5}g",
                "calories": f"{meal_macros['calories']-50}-{meal_macros['calories']+50}"
            }
        }
        
        daily_schedule.append(meal_entry)
    
    return {"dailySchedule": daily_schedule}

def get_meal_templates(meal_type, target_macros, cultural_preference):
    """
    Get appropriate meal templates based on macro targets and cultural preference
    """
    config = get_policy("meal_templates")
    
    # Get templates for this cultural preference and meal type
    cultural_templates = config.get(cultural_preference, {})
    meal_templates = cultural_templates.get(meal_type, [])
    
    # Filter templates that approximately match macro targets (within 20% tolerance)
    suitable_templates = []
    
    for template in meal_templates:
        protein_match = abs(template["protein"] - target_macros["protein"]) <= target_macros["protein"] * 0.2
        calorie_match = abs(template["calories"] - target_macros["calories"]) <= target_macros["calories"] * 0.2
        
        if protein_match and calorie_match:
            # Format template for protocol output
            formatted_template = {
                "name": template["name"],
                "emoji": template.get("emoji", "🍽️"),
                "description": template["description"],
                "culturalName": template.get("cultural_name", cultural_preference.replace("_", " ").title()),
                "nutritionalContent": {
                    "fat": template["fat"],
                    "carbs": template["carbs"],
                    "protein": template["protein"],
                    "calories": template["calories"]
                }
            }
            suitable_templates.append(formatted_template)
    
    # Return top 3 options or create generic option if none found
    if suitable_templates:
        return suitable_templates[:3]
    else:
        return create_generic_meal_option(meal_type, target_macros, cultural_preference)

def create_generic_meal_option(meal_type, target_macros, cultural_preference):
    """
    Create generic meal option when no templates match
    """
    generic_option = {
        "name": f"Custom {meal_type.title()} ({cultural_preference.replace('_', ' ').title()})",
        "emoji": "🍽️",
        "description": f"Balanced {meal_type} meeting your macro targets with {cultural_preference.replace('_', ' ')} preferences",
        "culturalName": cultural_preference.replace("_", " ").title(),
        "nutritionalContent": {
            "fat": target_macros["fat"],
            "carbs": target_macros["carbs"],
            "protein": target_macros["protein"],
            "calories": target_macros["calories"]
        }
    }
    
    return [generic_option]

def format_meal_plan_for_protocol(meal_distribution, meal_examples):
    """
    Format meal distribution and examples into protocol-compatible format
    """
    daily_schedule = []

    for i, meal in enumerate(meal_distribution["meals"]):
        macros = meal["macros"]
        meal_example = meal_examples[i] if i < len(meal_examples) else {}

        # Format time window
        timing_24h = meal["timing"]  # e.g., "08:00"
        hour = int(timing_24h.split(":")[0])
        am_pm = "AM" if hour < 12 else "PM"
        hour_12 = hour if hour <= 12 else hour - 12
        hour_12 = 12 if hour_12 == 0 else hour_12
        time_window = f"{hour_12}:00 {am_pm} - {hour_12 + 1}:00 {am_pm}"

        # Create example meal entry
        if meal["meal_type"] == "carb_containing":
            # Get protein and carb sources from the meal example
            protein_sources = meal_example.get("protein_sources", [])
            carb_sources = meal_example.get("carb_sources", [])

            # Create single meal option - rotate through different options for variety
            # Use meal index to pick different combinations
            if protein_sources and carb_sources:
                protein_idx = i % len(protein_sources)
                carb_idx = i % len(carb_sources)

                example_meals = [{
                    "name": f"{protein_sources[protein_idx]} with {carb_sources[carb_idx]}",
                    "emoji": "🍽️",
                    "description": f"{meal_example.get('protein_amount', '')} + {carb_sources[carb_idx]} ({meal_example.get('carb_amount', '')}) + vegetables",
                    "culturalName": meal_example.get("meal_name", meal["meal_name"]),
                    "nutritionalContent": {
                        "fat": round(macros["fat_g"], 1),
                        "carbs": round(macros["carb_g"], 1),
                        "protein": round(macros["protein_g"], 1),
                        "calories": round(macros["calories"])
                    }
                }]
            else:
                # Fallback to old format
                example_meals = [{
                    "name": meal_example.get("protein_source", "Protein source"),
                    "emoji": "🍖",
                    "description": f"{meal_example.get('protein_amount', '')} + {meal_example.get('carb_source', 'Complex carbs')} ({meal_example.get('carb_amount', '')}) + vegetables",
                    "culturalName": meal_example.get("meal_name", meal["meal_name"]),
                    "nutritionalContent": {
                        "fat": round(macros["fat_g"], 1),
                        "carbs": round(macros["carb_g"], 1),
                        "protein": round(macros["protein_g"], 1),
                        "calories": round(macros["calories"])
                    }
                }]
        else:
            # Zero-carb meal - show single example from first available option
            zero_carb_examples = meal_example.get("examples", [])

            if zero_carb_examples:
                example_meals = [{
                    "name": "Zero-Carb Meal",
                    "emoji": "",
                    "description": zero_carb_examples[0],  # Use first example only
                    "culturalName": meal_example.get("meal_name", meal["meal_name"]),
                    "nutritionalContent": {
                        "fat": round(macros["fat_g"], 1),
                        "carbs": round(macros["carb_g"], 1),
                        "protein": round(macros["protein_g"], 1),
                        "calories": round(macros["calories"])
                    }
                }]
            else:
                # Fallback
                example_meals = [{
                    "name": "Zero-Carb Meal",
                    "emoji": "",
                    "description": meal_example.get("example", "High-protein, high-fat, zero-carb meal"),
                    "culturalName": meal_example.get("meal_name", meal["meal_name"]),
                    "nutritionalContent": {
                        "fat": round(macros["fat_g"], 1),
                        "carbs": round(macros["carb_g"], 1),
                        "protein": round(macros["protein_g"], 1),
                        "calories": round(macros["calories"])
                    }
                }]

        meal_entry = {
            "status": "completed",  # Default status
            "mealType": meal["meal_name"].lower().replace(" ", "_"),
            "timeWindow": time_window,
            "exampleMeals": example_meals,
            "nutritionalTargets": {
                "fat": f"{round(max(0, macros['fat_g']-5), 1)}-{round(macros['fat_g']+5, 1)}g",
                "carbs": f"{round(max(0, macros['carb_g']-5), 1)}-{round(macros['carb_g']+5, 1)}g",
                "protein": f"{round(max(0, macros['protein_g']-5), 1)}-{round(macros['protein_g']+5, 1)}g",
                "calories": f"{round(max(0, macros['calories']-50))}-{round(macros['calories']+50)}"
            },
            "meal_metadata": {
                "is_zero_carb": meal["meal_type"] == "zero_carb",
                "is_primary_carb_meal": meal.get("is_primary_carb_meal", False)
            }
        }

        daily_schedule.append(meal_entry)

    return {
        "dailySchedule": daily_schedule,
        "meal_planning_strategy": {
            "meal_count": meal_distribution["meal_count"],
            "carb_strategy": meal_distribution["carb_strategy"],
            "fasting_hours": meal_distribution["meal_planning_metadata"]["fasting_hours"],
            "eating_window_hours": meal_distribution["meal_planning_metadata"]["eating_window_hours"],
            "strategy_description": meal_distribution["meal_planning_metadata"]["strategy_description"]
        }
    }


def get_meal_time_window(meal_type):
    """
    Get appropriate time window for meal type
    """
    time_windows = {
        "breakfast": "7:00 AM - 9:00 AM",
        "lunch": "2:00 PM - 3:00 PM",
        "dinner": "7:00 PM - 9:00 PM"
    }

    return time_windows.get(meal_type, "12:00 PM - 1:00 PM")

def format_user_activities(activities):
    """
    Format user's planned activities for protocol display
    IMPORTANT: Uses actual user activities, NOT templates

    Activities structure from frontend:
    {
        type: "walking",
        name: "Walking",
        time: "07:00",
        duration: 30,
        frequency: "daily",
        met_value: 3.5,
        intensity: "moderate",
        calories_per_session: 150,
        weekly_calories: 1050
    }
    """
    if not activities or len(activities) == 0:
        return {"dailySchedule": []}

    # Create schedule entries for each activity
    daily_schedule = []

    for idx, activity in enumerate(activities):
        # Determine time window based on activity time
        time_24h = activity.get("time", "07:00")
        hour = int(time_24h.split(":")[0])
        minute = int(time_24h.split(":")[1]) if ":" in time_24h else 0

        # Categorize by time of day
        if hour < 10:
            time_slot = "morning"
            am_pm = "AM"
            hour_12 = hour if hour > 0 else 12
            time_window = f"{hour_12}:{minute:02d} {am_pm} - {hour_12 + 1}:{minute:02d} {am_pm}"
        elif hour < 14:
            time_slot = "midday"
            am_pm = "PM"
            hour_12 = hour if hour == 12 else hour - 12
            time_window = f"{hour_12}:{minute:02d} {am_pm} - {hour_12 + 1}:{minute:02d} {am_pm}"
        elif hour < 18:
            time_slot = "afternoon"
            am_pm = "PM"
            hour_12 = hour - 12
            time_window = f"{hour_12}:{minute:02d} {am_pm} - {hour_12 + 1}:{minute:02d} {am_pm}"
        else:
            time_slot = "evening"
            am_pm = "PM"
            hour_12 = hour - 12
            time_window = f"{hour_12}:{minute:02d} {am_pm} - {hour_12 + 1}:{minute:02d} {am_pm}"

        # Get activity details
        activity_name = activity.get("name", "Physical Activity")
        duration_min = activity.get("duration", 30)
        calories = activity.get("calories_per_session", 0)
        intensity = activity.get("intensity", "moderate").capitalize()

        # Create schedule entry matching the expected format
        schedule_entry = {
            "status": "completed" if idx == 0 else ("current" if idx == 1 else "upcoming"),
            "targets": {
                "duration": f"{duration_min} minutes",
                "intensity": intensity,
                "caloriesBurn": str(calories)
            },
            "timeSlot": time_slot,
            "timeWindow": time_window,
            "exampleRoutines": [{
                "name": activity_name,
                "emoji": get_activity_emoji(activity.get("type", "walking")),
                "details": {
                    "calories": calories,
                    "duration": f"{duration_min} minutes"
                },
                "description": activity.get("description", f"{intensity} intensity {activity_name.lower()}")
            }]
        }

        daily_schedule.append(schedule_entry)

    # Sort by scheduled time
    daily_schedule.sort(key=lambda x: x.get("timeSlot", "morning"))

    return {"dailySchedule": daily_schedule}

def get_activity_emoji(activity_type):
    """
    Get appropriate emoji for activity type
    """
    emoji_map = {
        "walking": "🚶",
        "jogging": "🏃",
        "running": "🏃‍♂️",
        "cycling": "🚴",
        "swimming": "🏊",
        "yoga": "🧘",
        "weights": "🏋️",
        "aerobics": "💃",
        "sports": "⚽",
        "dancing": "💃",
        "hiking": "🥾",
        "stairs": "🪜",
        "elliptical": "🏃",
        "rowing": "🚣"
    }
    return emoji_map.get(activity_type, "🏃")

def create_activity_schedule(lifestyle_constraints, program_intensity):
    """
    Create activity schedule based on lifestyle and program intensity
    FALLBACK FUNCTION: Only used when user has not planned specific activities
    """
    config = get_policy("activity_templates")

    # Get activity templates for program intensity
    intensity_activities = config.get(program_intensity, config["moderate"])

    daily_schedule = []

    # Morning activity slot
    morning_activities = intensity_activities.get("morning", [])
    if morning_activities:
        morning_schedule = {
            "status": "completed",
            "targets": morning_activities[0]["targets"],
            "timeSlot": "morning",
            "timeWindow": "7:00 AM - 9:00 AM",
            "exampleRoutines": format_activity_routines(morning_activities)
        }
        daily_schedule.append(morning_schedule)

    # Midday activity slot
    midday_activities = intensity_activities.get("midday", [])
    if midday_activities:
        midday_schedule = {
            "status": "current",
            "targets": midday_activities[0]["targets"],
            "timeSlot": "midday",
            "timeWindow": "12:00 PM - 3:00 PM",
            "exampleRoutines": format_activity_routines(midday_activities)
        }
        daily_schedule.append(midday_schedule)

    return {"dailySchedule": daily_schedule}

def format_activity_routines(activities):
    """
    Format activity routines for protocol output
    """
    formatted_routines = []
    
    for activity in activities:
        formatted_routine = {
            "name": activity["name"],
            "emoji": activity.get("emoji", "🏃"),
            "details": {
                "calories": activity.get("calories", 150),
                "duration": activity.get("duration", "30 minutes")
            },
            "description": activity.get("description", "Physical activity for health")
        }
        formatted_routines.append(formatted_routine)
    
    return formatted_routines

def assess_safety_requirements(patient_profile, medications, supplements, macro_targets):
    """
    Generate comprehensive safety protocol
    """
    config = get_policy("safety_protocols")
    
    # Calculate safety limits based on patient profile
    safety_limits = calculate_safety_limits(patient_profile, macro_targets)
    
    # Identify caution symptoms
    caution_symptoms = get_caution_symptoms(patient_profile, medications)
    
    # Check for contraindications
    contraindications = assess_contraindications(patient_profile, medications)
    
    # Identify emergency symptoms
    emergency_symptoms = get_emergency_symptoms(patient_profile)
    
    safety_protocol = {
        "protocolLimits": safety_limits,
        "cautionSymptoms": caution_symptoms,
        "emergencyContact": "+91-XXX-XXXX",  # Should be configurable
        "contraindications": contraindications,
        "emergencySymptoms": emergency_symptoms
    }
    
    return safety_protocol

def calculate_safety_limits(patient_profile, macro_targets):
    """
    Calculate safety limits based on patient profile
    """
    weight_kg = patient_profile["demographics"]["weight_kg"]
    
    # Minimum protein (0.8g/kg absolute minimum)
    min_protein = max(60, weight_kg * 0.8)
    
    # Minimum calories (never below 800)
    min_calories = max(800, macro_targets["total_calories"] * 0.9)
    
    # Maximum fasting period
    max_fasting = 16  # Conservative limit
    
    return {
        "minProtein": f"{round(min_protein)}g/day",
        "minCalories": f"{round(min_calories)}/day",
        "maxFastingPeriod": f"{max_fasting} hours"
    }

def get_caution_symptoms(patient_profile, medications):
    """
    Get caution symptoms based on patient profile and medications
    """
    base_symptoms = [
        "Unusual fatigue or weakness",
        "Persistent nausea", 
        "Dizziness when standing",
        "Severe headaches"
    ]
    
    # Add medication-specific symptoms
    for med in medications:
        if "metformin" in med.get("name", "").lower():
            base_symptoms.extend([
                "Persistent metallic taste",
                "Unusual muscle pain"
            ])
    
    return list(set(base_symptoms))  # Remove duplicates

def assess_contraindications(patient_profile, medications):
    """
    Assess contraindications based on patient profile
    """
    contraindications = []
    
    egfr = patient_profile["metabolic_baseline"].get("egfr", 90)
    creatinine = patient_profile["metabolic_baseline"].get("creatinine_mg_dl", 1.0)
    
    # Kidney function contraindications
    if egfr < 60 or creatinine > 1.4:
        contraindications.append("eGFR < 60 mL/min or Creatinine > 1.4")
    
    # Standard contraindications
    contraindications.extend([
        "History of gallstones or pancreatitis",
        "Severe cardiovascular disease"
    ])
    
    return contraindications

def get_emergency_symptoms(patient_profile):
    """
    Get emergency symptoms that require immediate attention
    """
    return [
        "Severe abdominal pain lasting >2 hours",
        "Jaundice (yellow skin or eyes)",
        "Pain radiating to back or shoulder", 
        "Persistent vomiting"
    ]

def create_protocol_overview(phase_info, program_config):
    """
    Create protocol overview section
    Now uses program_type to set appropriate objectives
    """
    program_type = program_config.get("program_type", "intensive_remission")

    # Define objectives based on program type
    objectives_map = {
        "intensive_remission": {
            "primaryObjective": "Achieve Type 2 Diabetes remission by significantly reducing liver and visceral fat, restoring natural blood sugar management",
            "remissionDefinition": "HbA1c below 6.5% for at least 3 months after stopping all glucose-lowering medications"
        },
        "moderate_improvement": {
            "primaryObjective": "Achieve significant improvement in metabolic health markers through gradual lifestyle changes and metabolic optimization",
            "remissionDefinition": "Target HbA1c reduction of 1-2% with improved insulin sensitivity and reduced medication dependence"
        },
        "maintenance": {
            "primaryObjective": "Maintain current metabolic health status and prevent progression through sustainable lifestyle interventions",
            "remissionDefinition": "Maintain HbA1c below 7% with stable or reduced medication requirements"
        }
    }

    objectives = objectives_map.get(program_type, objectives_map["intensive_remission"])

    return {
        "currentStage": {
            "name": phase_info["name"],
            "duration": f"{phase_info['duration']} weeks",
            "description": phase_info["description"],
            "expectedOutcome": phase_info["expected_outcome"]
        },
        "upcomingStages": [
            {
                "name": "Stage 2: Pancreatic Reset & Transition",
                "description": "Gradual calorie increase while pancreas heals and adapts"
            },
            {
                "name": "Stage 3: Long-Term Maintenance",
                "description": "Sustainable lifestyle to ensure lifelong remission"
            }
        ],
        "primaryObjective": objectives["primaryObjective"],
        "remissionDefinition": objectives["remissionDefinition"]
    }

def calculate_initial_progress_percentage(metabolic_baseline, program_config):
    """
    Calculate initial progress percentage (typically low at start)
    """
    # Simple initial calculation - can be enhanced
    hba1c = metabolic_baseline.get("hba1c_pct", 7.0)
    
    # Higher HbA1c means more room for improvement, lower starting percentage
    if hba1c >= 9.0:
        return 10
    elif hba1c >= 8.0:
        return 15
    elif hba1c >= 7.0:
        return 25
    else:
        return 35

from .delegate import get_target
def get_final_target():
    t = get_target("remission")
    filled = {"expected_mean_glucose_mgdl": 105, "expected_sd_mg_dl": 25, "expected_lc_z": -1.0}
    return {"name":"clinical_remission_default","targets": t, "filled": filled}


from .delegate import get_policy, get_curve

def _interp_table(table, x_key, y_key, x):
    t = sorted(table, key=lambda r: r[x_key])
    if x <= t[0][x_key]: return t[0][y_key]
    if x >= t[-1][x_key]: return t[-1][y_key]
    for i in range(len(t)-1):
        x0, y0 = t[i][x_key], t[i][y_key]
        x1, y1 = t[i+1][x_key], t[i+1][y_key]
        if x0 <= x <= x1:
            if x1 == x0: return y0
            alpha = (x - x0) / (x1 - x0)
            return y0 + alpha*(y1 - y0)
    return t[-1][y_key]

def project_interim(phase: str, horizon_weeks: int, plan_daily_deficit_kcal: float, baseline: dict):
    energy = get_policy("energy")
    d = max(energy["min_daily_deficit"], min(energy["max_daily_deficit"], plan_daily_deficit_kcal))
    days = horizon_weeks * 7
    gross_def = d * days
    fat_kg = - gross_def / energy["kcal_per_kg_fat"] * energy["adaptation_factor"]
    delta_bf_pct = - (fat_kg / max(1e-6, baseline["weight_kg"])) * 100.0

    dfp = delta_bf_pct
    proj = {}
    proj["delta_fat_kg"] = round(fat_kg,2)
    proj["delta_bodyfat_pct"] = round(dfp,2)

    proj["ttb_min"] = round(baseline.get("ttb_min", 295) + _interp_table(get_curve("fatpct_to_ttb_delta"), "delta_bodyfat_pct","delta_ttb_min", dfp),0)
    proj["fbg_mgdl"] = round(baseline.get("fbg_mgdl", 135) + _interp_table(get_curve("fatpct_to_fbg_delta"), "delta_bodyfat_pct","delta_fbg_mgdl", dfp),0)
    proj["cv_pct"] = round(baseline.get("cv_pct", 29) + _interp_table(get_curve("fatpct_to_cv_delta"), "delta_bodyfat_pct","delta_cv_pct", dfp),1)
    proj["tir_pct"] = round(baseline.get("tir_pct", 62) + _interp_table(get_curve("fatpct_to_tir_delta"), "delta_bodyfat_pct","delta_tir_pct", dfp),1)
    proj["lc_z"] = round(baseline.get("lc_z", -0.2) + _interp_table(get_curve("fatpct_to_lc_delta"), "delta_bodyfat_pct","delta_lc_z", dfp),2)
    if "hba1c_pct" in baseline and baseline["hba1c_pct"] is not None:
        proj["hba1c_pct"] = round(baseline["hba1c_pct"] + _interp_table(get_curve("fatpct_to_hba1c_delta"), "delta_bodyfat_pct","delta_hba1c_pct", dfp),2)

    series = []
    for w in range(1, horizon_weeks+1):
        frac = w / horizon_weeks
        series.append({
            "week": w,
            "bodyfat_pct": round(baseline["bodyfat_pct"] + frac * proj["delta_bodyfat_pct"],2),
            "ttb_min": round(baseline.get("ttb_min",295) + frac * (proj["ttb_min"] - baseline.get("ttb_min",295)),0),
            "fbg_mgdl": round(baseline.get("fbg_mgdl",135) + frac * (proj["fbg_mgdl"] - baseline.get("fbg_mgdl",135)),0),
            "cv_pct": round(baseline.get("cv_pct",29) + frac * (proj["cv_pct"] - baseline.get("cv_pct",29)),1),
            "tir_pct": round(baseline.get("tir_pct",62) + frac * (proj["tir_pct"] - baseline.get("tir_pct",62)),1),
            "hba1c_pct": round(baseline.get("hba1c_pct",7.8) + frac * ((proj.get("hba1c_pct",7.8)) - baseline.get("hba1c_pct",7.8)),2)
        })
    notes = [f"Adaptation {energy['adaptation_factor']}; bounds [{energy['min_daily_deficit']},{energy['max_daily_deficit']}] kcal/day applied"]
    return {
        "phase": phase,
        "horizon_weeks": horizon_weeks,
        "plan": {"daily_deficit_kcal": d},
        "baseline": {"bodyfat_pct": baseline["bodyfat_pct"], "weight_kg": baseline["weight_kg"], "hba1c_pct": baseline.get("hba1c_pct"),
                     "ttb_min": baseline.get("ttb_min"), "fbg_mgdl": baseline.get("fbg_mgdl"), "cv_pct": baseline.get("cv_pct"),
                     "tir_pct": baseline.get("tir_pct"), "lc_z": baseline.get("lc_z")},
        "projected": {**proj, "notes": notes},
        "series_weekly": series,
        "sources": {"energy":"policies/energy.json","fatpct_to_ttb_delta":"curves/fatpct_to_ttb_delta.json"}
    }


import math
def logistic(x, clip=6.0):
    x = max(-clip, min(clip, x))
    return 1.0 / (1.0 + math.exp(x))

def compute_scores(now, interim, final, prp, scoring_policy):
    metrics = scoring_policy["metrics"]
    clip = scoring_policy.get("aggregation", {}).get("clip", 6.0)

    def closeness(metric, current_val, target_band, direction, scale_name):
        if current_val is None:
            return 0.0, 0.0
        if direction == "down":
            hi = target_band.get("hi", float("inf"))
            d_raw = max(0.0, current_val - hi)
        elif direction == "up":
            lo = target_band.get("lo", -float("inf"))
            d_raw = max(0.0, lo - current_val)
        else:
            lo = target_band.get("lo", -float("inf")); hi = target_band.get("hi", float("inf"))
            if lo <= current_val <= hi: d_raw = 0.0
            else: d_raw = min(abs(current_val - lo), abs(current_val - hi))
        if scale_name == "prp_mad":
            mad = prp.get("metrics", {}).get(metric, {}).get("mad", 10) or 10
            z = d_raw / max(1e-6, mad)
        elif scale_name == "abs1":
            z = abs(d_raw)
        else:
            z = d_raw
        return logistic(z-1.0, clip), 1.0

    def score_against(targets):
        comps = []; total_w = 0.0; total = 0.0
        for m, cfg in metrics.items():
            cur = now["values"].get(m) if m in now["values"] else None
            clos, conf = closeness(m, cur, targets.get(m, {}), cfg["direction"], cfg["scale"])
            w = cfg["weight"] * conf
            comps.append({"metric": m, "closeness": round(clos,3), "weight": cfg["weight"], "confidence": conf})
            total += w * clos; total_w += w
        goal = 100.0 * (total / total_w) if total_w>0 else 0.0
        return round(goal,1), comps

    s_interim, comps_i = score_against(interim["targets"] if "targets" in interim else _interim_targets_from(interim))
    s_final, comps_f = score_against(final["targets"])
    overall = round(0.5*s_interim + 0.3*s_final + 0.2*(0.5*0.5 + 0.5*0.8), 1)  # placeholder
    return {"interim": s_interim, "final": s_final, "overall": overall, "components": comps_i}

def _interim_targets_from(interim):
    t = {}
    for key in ["fbg_mgdl","ttb_min","cv_pct","tir_pct","lc_z","hba1c_pct"]:
        if key in interim.get("projected", {}):
            val = interim["projected"][key]
            if key in ["tir_pct"]:
                t[key] = {"lo": val}
            else:
                t[key] = {"hi": val}
    return t

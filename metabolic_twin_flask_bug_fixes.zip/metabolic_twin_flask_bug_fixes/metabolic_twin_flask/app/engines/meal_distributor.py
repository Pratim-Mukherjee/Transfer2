# app/engines/meal_distributor.py
# Meal planning and macro distribution across meals

from .delegate import get_policy
import logging

logger = logging.getLogger(__name__)

def calculate_meal_distribution(macros, meal_planning_config, lifestyle_constraints):
    """
    Calculate per-meal macro distribution based on meal count and carb strategy

    Args:
        macros: Dict with total_calories, protein_g, carb_g, fat_g
        meal_planning_config: Dict with meal_count, carb_strategy, selected_meal_for_carbs
        lifestyle_constraints: Dict with wake_time, sleep_time, work_schedule

    Returns:
        Dict with meals array containing per-meal macros and timing
    """
    meal_count = meal_planning_config["meal_count"]
    carb_strategy = meal_planning_config["carb_strategy"]
    selected_meal = meal_planning_config.get("selected_meal_for_carbs", 1)

    # Get meal planning rules
    config = get_policy("meal_planning_rules")
    meal_config = config["meal_count_options"][str(meal_count)]

    # Calculate per-meal protein (always distributed equally)
    protein_per_meal = macros["protein_g"] / meal_count

    # Calculate meal timings
    meal_timings = calculate_meal_timings(meal_count, lifestyle_constraints, config)

    # Distribute carbs based on strategy
    carb_distribution = distribute_carbs(
        total_carbs=macros["carb_g"],
        meal_count=meal_count,
        carb_strategy=carb_strategy,
        selected_meal=selected_meal
    )

    # Calculate fat distribution (fills remaining calories)
    fat_distribution = distribute_fat(
        total_fat=macros["fat_g"],
        total_calories=macros["total_calories"],
        protein_per_meal=protein_per_meal,
        carb_distribution=carb_distribution,
        meal_count=meal_count
    )

    # Build meal array
    meals = []
    meal_names = meal_planning_config.get("meal_names", [f"Meal {i+1}" for i in range(meal_count)])

    for i in range(meal_count):
        meal_number = i + 1
        protein_g = round(protein_per_meal, 1)
        carb_g = round(carb_distribution[i], 1)
        fat_g = round(fat_distribution[i], 1)

        meal_calories = (protein_g * 4) + (carb_g * 4) + (fat_g * 9)

        meal = {
            "meal_number": meal_number,
            "meal_name": meal_names[i],
            "timing": meal_timings[i],
            "macros": {
                "calories": round(meal_calories),
                "protein_g": protein_g,
                "carb_g": carb_g,
                "fat_g": fat_g
            },
            "meal_type": "carb_containing" if carb_g >= 10 else "zero_carb",
            "is_primary_carb_meal": (meal_number == selected_meal and carb_strategy in ["aggressive"])
        }

        meals.append(meal)

    return {
        "meal_count": meal_count,
        "carb_strategy": carb_strategy,
        "meals": meals,
        "meal_planning_metadata": {
            "fasting_hours": meal_config["fasting_hours"],
            "eating_window_hours": meal_config["eating_window_hours"],
            "strategy_description": config["carb_distribution_strategies"][carb_strategy]["description"]
        }
    }


def calculate_meal_timings(meal_count, lifestyle_constraints, config):
    """
    Calculate meal timings based on meal count and user's lifestyle timing
    Now uses user's actual wake/sleep times instead of static defaults
    """
    wake_time = lifestyle_constraints.get("wake_time", "07:00")
    sleep_time = lifestyle_constraints.get("sleep_time", "23:00")

    # Parse times to calculate eating window
    wake_hour = int(wake_time.split(':')[0]) if wake_time else 7
    wake_min = int(wake_time.split(':')[1]) if wake_time and ':' in wake_time else 0
    sleep_hour = int(sleep_time.split(':')[0]) if sleep_time else 23
    sleep_min = int(sleep_time.split(':')[1]) if sleep_time and ':' in sleep_time else 0

    # Convert to minutes from midnight for easier calculation
    wake_minutes = wake_hour * 60 + wake_min
    sleep_minutes = sleep_hour * 60 + sleep_min

    # Calculate awake duration (eating window available)
    if sleep_minutes > wake_minutes:
        awake_minutes = sleep_minutes - wake_minutes
    else:
        # Sleep time is after midnight
        awake_minutes = (24 * 60 - wake_minutes) + sleep_minutes

    def minutes_to_time(minutes):
        """Convert minutes from midnight to HH:MM format"""
        h = (minutes // 60) % 24
        m = minutes % 60
        return f"{h:02d}:{m:02d}"

    if meal_count == 1:
        # OMAD - place meal 3-4 hours before sleep for digestion
        # Default to 3 hours before sleep
        meal_time_minutes = sleep_minutes - (3 * 60)
        if meal_time_minutes < wake_minutes:
            # If that's before wake time, place it at wake + 10 hours (mid-day)
            meal_time_minutes = wake_minutes + (10 * 60)
        return [minutes_to_time(meal_time_minutes)]

    elif meal_count == 2:
        # 2 meals - place them strategically in eating window
        # First meal: 2-3 hours after waking
        # Second meal: 3-4 hours before sleep
        first_meal_minutes = wake_minutes + (2 * 60 + 30)  # 2.5 hours after wake
        second_meal_minutes = sleep_minutes - (3 * 60 + 30)  # 3.5 hours before sleep

        # Ensure minimum 4 hour gap between meals
        if second_meal_minutes - first_meal_minutes < 4 * 60:
            # Distribute evenly
            gap = awake_minutes // 3
            first_meal_minutes = wake_minutes + gap
            second_meal_minutes = wake_minutes + (2 * gap)

        return [minutes_to_time(first_meal_minutes), minutes_to_time(second_meal_minutes)]

    elif meal_count == 3:
        # 3 meals - breakfast, lunch, dinner
        # Breakfast: 1 hour after wake
        # Lunch: midpoint of eating window
        # Dinner: 3 hours before sleep
        breakfast_minutes = wake_minutes + 60
        dinner_minutes = sleep_minutes - (3 * 60)
        lunch_minutes = (breakfast_minutes + dinner_minutes) // 2

        return [
            minutes_to_time(breakfast_minutes),
            minutes_to_time(lunch_minutes),
            minutes_to_time(dinner_minutes)
        ]

    elif meal_count == 4:
        # 4 meals - evenly spaced throughout eating window
        # Leave 1 hour after wake and 3 hours before sleep
        eating_start = wake_minutes + 60
        eating_end = sleep_minutes - (3 * 60)
        eating_duration = eating_end - eating_start

        # Divide into 3 equal gaps (for 4 meals)
        gap = eating_duration // 3

        return [
            minutes_to_time(eating_start),
            minutes_to_time(eating_start + gap),
            minutes_to_time(eating_start + 2 * gap),
            minutes_to_time(eating_end)
        ]

    return []


def distribute_carbs(total_carbs, meal_count, carb_strategy, selected_meal):
    """
    Distribute carbs across meals based on strategy

    Returns: Array of carb amounts per meal
    """
    carb_distribution = [0] * meal_count

    # Default selected_meal to 1 if None (for OMAD or when not specified)
    if selected_meal is None:
        selected_meal = 1

    if carb_strategy == "all_in_one" or carb_strategy == "aggressive":
        # ALL carbs in the selected meal only
        carb_distribution[selected_meal - 1] = total_carbs

    elif carb_strategy == "moderate":
        # Skip carbs in selected meal, distribute evenly across others
        # For OMAD (meal_count=1), this strategy doesn't make sense, fall back to distributed
        if meal_count <= 1:
            carb_distribution[0] = total_carbs
        else:
            carbs_per_meal = total_carbs / (meal_count - 1)
            for i in range(meal_count):
                if (i + 1) != selected_meal:
                    carb_distribution[i] = carbs_per_meal

    elif carb_strategy == "distributed":
        # Distribute evenly across all meals
        carbs_per_meal = total_carbs / meal_count
        carb_distribution = [carbs_per_meal] * meal_count

    return carb_distribution


def distribute_fat(total_fat, total_calories, protein_per_meal, carb_distribution, meal_count):
    """
    Distribute fat to fill remaining calories per meal

    Fat fills the gap after protein and carbs are allocated
    """
    fat_distribution = []

    # Calculate total calories per meal proportionally
    total_carb_calories = sum([c * 4 for c in carb_distribution])
    total_protein_calories = protein_per_meal * 4 * meal_count
    total_fat_calories = total_calories - total_carb_calories - total_protein_calories

    for i in range(meal_count):
        protein_calories = protein_per_meal * 4
        carb_calories = carb_distribution[i] * 4

        # Calculate target calories for this meal
        if carb_distribution[i] > 0:
            # Carb-containing meal - allocate proportionally
            carb_ratio = (carb_distribution[i] * 4) / total_carb_calories if total_carb_calories > 0 else (1 / meal_count)
            meal_target_calories = total_calories * carb_ratio
        else:
            # Zero-carb meal - gets equal share of remaining calories
            zero_carb_meal_count = sum([1 for c in carb_distribution if c == 0])
            if zero_carb_meal_count > 0:
                remaining_calories = total_calories - (total_carb_calories + total_protein_calories)
                meal_target_calories = protein_calories + (remaining_calories / zero_carb_meal_count)
            else:
                meal_target_calories = total_calories / meal_count

        # Fat fills the gap
        remaining_calories_for_fat = max(0, meal_target_calories - protein_calories - carb_calories)
        fat_g = remaining_calories_for_fat / 9
        fat_distribution.append(fat_g)

    # Adjust to match total fat (rounding compensation)
    total_distributed_fat = sum(fat_distribution)
    if total_distributed_fat > 0:
        adjustment_factor = total_fat / total_distributed_fat
        fat_distribution = [f * adjustment_factor for f in fat_distribution]

    return fat_distribution


def generate_meal_examples(meals, cultural_preferences):
    """
    Generate example meal compositions based on cultural preferences
    Now supports multiple cuisine preferences - combines options from all selected cuisines
    """
    config = get_policy("meal_planning_rules")

    # Handle both single preference (string) and multiple preferences (list) for backward compatibility
    if isinstance(cultural_preferences, str):
        cultural_preferences = [cultural_preferences]

    # If no preferences selected, default to western
    if not cultural_preferences or len(cultural_preferences) == 0:
        cultural_preferences = ["western"]

    # Collect food options from all selected cuisines
    all_protein_sources = []
    all_carb_sources = []
    all_zero_carb_examples = []

    for preference in cultural_preferences:
        cultural_config = config["cultural_food_integration"].get(preference, config["cultural_food_integration"]["western"])
        all_protein_sources.extend(cultural_config.get("protein_sources", []))
        all_carb_sources.extend(cultural_config.get("carb_sources", []))
        zero_carb_example = cultural_config.get("zero_carb_meal_example")
        if zero_carb_example:
            all_zero_carb_examples.append(zero_carb_example)

    # Remove duplicates while preserving order
    all_protein_sources = list(dict.fromkeys(all_protein_sources))
    all_carb_sources = list(dict.fromkeys(all_carb_sources))

    meal_examples = []

    for meal in meals:
        meal_type = meal["meal_type"]
        macros = meal["macros"]

        if meal_type == "carb_containing":
            # Use first protein and carb source from combined list
            example = {
                "meal_name": meal["meal_name"],
                "protein_sources": all_protein_sources,  # Provide all options
                "carb_sources": all_carb_sources,  # Provide all options
                "protein_amount": f"{macros['protein_g']}g protein",
                "carb_amount": f"{macros['carb_g']}g carbs",
                "fat_amount": f"{macros['fat_g']}g fat",
                "vegetables": "Non-starchy vegetables (unlimited)",
                "total_calories": f"{macros['calories']} kcal"
            }
        else:
            # Zero-carb meal - provide all zero-carb examples from selected cuisines
            example = {
                "meal_name": meal["meal_name"],
                "examples": all_zero_carb_examples if all_zero_carb_examples else ["High-protein, high-fat, zero-carb meal"],
                "protein_amount": f"{macros['protein_g']}g protein",
                "carb_amount": f"{macros['carb_g']}g carbs (trace only)",
                "fat_amount": f"{macros['fat_g']}g fat",
                "total_calories": f"{macros['calories']} kcal"
            }

        meal_examples.append(example)

    return meal_examples


def validate_meal_distribution(meal_distribution):
    """
    Validate the meal distribution meets safety requirements
    IMPROVED: Uses adaptive minimums based on total calories, warnings instead of hard errors
    """
    config = get_policy("meal_planning_rules")
    validation_rules = config["validation_rules"]

    errors = []
    warnings = []

    # Calculate total daily calories and meal count for adaptive validation
    total_calories = sum(meal["macros"]["calories"] for meal in meal_distribution["meals"])
    meal_count = len(meal_distribution["meals"])

    # Adaptive minimum calories per meal based on total calories
    # If total is low, we need to be more flexible
    standard_min = validation_rules["minimum_calories_per_meal"]
    adaptive_min = max(100, total_calories / meal_count * 0.5)  # At least 50% of average, minimum 100 kcal
    actual_min = min(standard_min, adaptive_min)

    for meal in meal_distribution["meals"]:
        macros = meal["macros"]

        # Check CRITICAL minimum calories (only error if dangerously low)
        if macros["calories"] < 100:
            errors.append(f"{meal['meal_name']}: {macros['calories']} kcal is dangerously low (minimum 100 kcal for safety)")
        # Check adaptive minimum (warning only)
        elif macros["calories"] < actual_min:
            warnings.append(f"{meal['meal_name']}: {macros['calories']} kcal is below recommended minimum {int(actual_min)} kcal")

        # Check maximum calories per meal
        if macros["calories"] > validation_rules["maximum_calories_per_meal"]:
            warnings.append(f"{meal['meal_name']}: {macros['calories']} kcal exceeds recommended maximum {validation_rules['maximum_calories_per_meal']} kcal")

        # Check minimum protein per meal (warning only, not error)
        if macros["protein_g"] < validation_rules["minimum_protein_per_meal"]:
            warnings.append(f"{meal['meal_name']}: {macros['protein_g']}g protein is below recommended minimum {validation_rules['minimum_protein_per_meal']}g")

        # Check carb meal minimum (warning only)
        if meal["meal_type"] == "carb_containing" and macros["carb_g"] < validation_rules["carb_meal_minimum_carbs"]:
            warnings.append(f"{meal['meal_name']}: Carb-containing meal has only {macros['carb_g']}g carbs")

        # Check zero-carb meal maximum (warning only)
        if meal["meal_type"] == "zero_carb" and macros["carb_g"] > validation_rules["zero_carb_meal_maximum_carbs"]:
            warnings.append(f"{meal['meal_name']}: Zero-carb meal exceeds {validation_rules['zero_carb_meal_maximum_carbs']}g carbs")

    # Additional validation: Check if total calories seem too low for meal count
    if total_calories < 800:
        errors.append(f"Total daily calories ({total_calories} kcal) is below absolute minimum (800 kcal) - unsafe")
    elif total_calories < meal_count * 200 and meal_count > 2:
        warnings.append(f"Total calories ({total_calories} kcal) may be too low for {meal_count} meals. Consider reducing to {meal_count - 1} meals.")

    return {
        "valid": len(errors) == 0,
        "errors": errors,
        "warnings": warnings
    }

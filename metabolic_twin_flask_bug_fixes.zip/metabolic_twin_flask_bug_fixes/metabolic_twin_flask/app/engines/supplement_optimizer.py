# app/engines/supplement_optimizer.py
# Deficiency-based supplement recommendations ONLY

from .delegate import get_policy
import logging

def analyze_supplement_needs(enhanced_baseline):
    """
    Analyze and recommend supplements based STRICTLY on:
    1. Laboratory-confirmed deficiencies
    2. Medication interactions (Metformin → B12 only)
    3. User-entered supplements (preserved)

    NO auto-supplementation based on metabolic state!
    """
    patient_profile = enhanced_baseline["patient_profile"]

    # Get user's current supplements (preserve these!)
    user_supplements = patient_profile.get("medical_history", {}).get("current_supplements", [])

    # Get current medications for interaction check
    medications = patient_profile.get("medical_history", {}).get("current_medications", [])

    # Get lab results (if available)
    lab_results = patient_profile.get("lab_results", {})

    supplement_recommendations = {}

    # 1. PRESERVE USER-ENTERED SUPPLEMENTS
    for supp in user_supplements:
        supplement_recommendations[f"user_{supp['name']}"] = {
            "name": supp['name'],
            "dose": supp['dose'],
            "timing": supp.get('timing', 'as_directed'),
            "duration": "ongoing",
            "rationale": "Patient-reported supplement (preserved from baseline)",
            "category": "user_entered",
            "source": "patient"
        }

    # 2. LAB-BASED DEFICIENCY SUPPLEMENTS (only if labs provided)
    deficiency_supplements = get_lab_based_supplements(lab_results, user_supplements)
    supplement_recommendations.update(deficiency_supplements)

    # 3. METABOLIC-BASED SUPPLEMENTS (Omega-3 from triglycerides > 150)
    metabolic_baseline = patient_profile.get("metabolic_baseline", {})
    metabolic_supplements = get_metabolic_based_supplements(metabolic_baseline, user_supplements)
    supplement_recommendations.update(metabolic_supplements)

    # 4. MEDICATION-TRIGGERED (ONLY Metformin → B12)
    med_supplements = get_medication_triggered_supplements(medications, user_supplements)
    supplement_recommendations.update(med_supplements)

    # Apply safety checks
    final_recommendations = apply_safety_checks(
        supplement_recommendations,
        patient_profile,
        medications
    )

    return final_recommendations


def get_lab_based_supplements(lab_results, existing_supplements):
    """
    Recommend supplements ONLY based on laboratory-confirmed deficiencies
    """
    if not lab_results:
        return {}

    config = get_policy("supplement_thresholds")
    lab_based = config["lab_based_supplements"]

    recommendations = {}

    # Check Vitamin B12
    if lab_results.get("vitamin_b12"):
        b12_level = lab_results["vitamin_b12"]
        b12_config = lab_based["vitamin_b12"]

        # Check if already taking B12
        if not _already_supplementing("b12", existing_supplements):
            if b12_level < b12_config["ranges"]["deficient"]["max"]:
                # Deficient
                rec = b12_config["supplement_recommendations"]["deficient"]
                recommendations["b12_deficiency"] = {
                    "name": rec["supplement_name"],
                    "dose": rec["dose"],
                    "timing": rec["timing"],
                    "duration": rec["duration"],
                    "rationale": f"B12 level {b12_level} pg/mL - {rec['rationale']}",
                    "category": "lab_deficiency",
                    "lab_value": b12_level,
                    "retest_after": "8 weeks"
                }
            elif b12_level < b12_config["ranges"]["insufficient"]["max"]:
                # Insufficient
                rec = b12_config["supplement_recommendations"]["insufficient"]
                recommendations["b12_insufficient"] = {
                    "name": rec["supplement_name"],
                    "dose": rec["dose"],
                    "timing": rec["timing"],
                    "duration": rec["duration"],
                    "rationale": f"B12 level {b12_level} pg/mL - {rec['rationale']}",
                    "category": "lab_deficiency",
                    "lab_value": b12_level,
                    "retest_after": "8 weeks"
                }

    # Check Vitamin D
    if lab_results.get("vitamin_d"):
        vit_d_level = lab_results["vitamin_d"]
        vit_d_config = lab_based["vitamin_d"]

        if not _already_supplementing("vitamin d", existing_supplements):
            if vit_d_level < vit_d_config["ranges"]["deficient"]["max"]:
                # Deficient
                rec = vit_d_config["supplement_recommendations"]["deficient"]
                recommendations["vitd_deficiency"] = {
                    "name": rec["supplement_name"],
                    "dose": rec["dose"],
                    "timing": rec["timing"],
                    "duration": rec["duration"],
                    "rationale": f"Vitamin D level {vit_d_level} ng/mL - {rec['rationale']}",
                    "category": "lab_deficiency",
                    "lab_value": vit_d_level,
                    "retest_after": "12 weeks"
                }
            elif vit_d_level < vit_d_config["ranges"]["insufficient"]["max"]:
                # Insufficient
                rec = vit_d_config["supplement_recommendations"]["insufficient"]
                recommendations["vitd_insufficient"] = {
                    "name": rec["supplement_name"],
                    "dose": rec["dose"],
                    "timing": rec["timing"],
                    "duration": rec["duration"],
                    "rationale": f"Vitamin D level {vit_d_level} ng/mL - {rec['rationale']}",
                    "category": "lab_deficiency",
                    "lab_value": vit_d_level,
                    "retest_after": "12 weeks"
                }

    return recommendations


def get_metabolic_based_supplements(metabolic_baseline, existing_supplements):
    """
    Supplements based on metabolic parameters (NOT lab deficiency tests)
    Currently: Omega-3 triggered by triglycerides > 150 mg/dL
    """
    config = get_policy("supplement_thresholds")
    metabolic_based = config.get("metabolic_based_supplements", {})
    recommendations = {}

    # Check Triglycerides for Omega-3
    triglycerides = metabolic_baseline.get("tg_mg_dl")
    if triglycerides and triglycerides >= 150:
        if not _already_supplementing("omega", existing_supplements):
            omega3_config = metabolic_based.get("triglycerides_omega3", {})
            rec = omega3_config.get("supplement_recommendation", {})

            if rec:
                recommendations["omega3_triglycerides"] = {
                    "name": rec["supplement_name"],
                    "dose": rec["dose"],
                    "timing": rec["timing"],
                    "duration": rec["duration"],
                    "rationale": f"Triglycerides {triglycerides} mg/dL - {rec['rationale']}",
                    "category": "metabolic_optimization",
                    "metabolic_value": triglycerides,
                    "target": rec.get("target", "Reduce triglycerides to <150 mg/dL"),
                    "retest_after": "12 weeks"
                }

    return recommendations


def get_medication_triggered_supplements(medications, existing_supplements):
    """
    ONLY Metformin → B12
    All other medication interactions removed per requirements
    """
    config = get_policy("supplement_thresholds")
    med_triggers = config["medication_triggered_supplements"]

    recommendations = {}

    # Check for Metformin
    for medication in medications:
        med_name = medication.get("name", "").lower()

        if "metformin" in med_name:
            if not _already_supplementing("b12", existing_supplements):
                rec = med_triggers["metformin"]
                recommendations["b12_metformin"] = {
                    "name": rec["supplement_name"],
                    "dose": rec["dose"],
                    "timing": rec["timing"],
                    "duration": rec["duration"],
                    "rationale": rec["rationale"],
                    "category": "medication_interaction",
                    "evidence": rec["evidence"],
                    "monitoring": rec["monitoring"]
                }

    return recommendations


def _already_supplementing(supplement_keyword, existing_supplements):
    """
    Check if patient is already taking a supplement containing the keyword
    """
    for supp in existing_supplements:
        if supplement_keyword.lower() in supp.get('name', '').lower():
            return True
    return False


def apply_safety_checks(recommendations, patient_profile, medications):
    """
    Apply contraindication checks and safety limits
    """
    config = get_policy("supplement_thresholds")
    contraindications = config.get("contraindications", {})

    final_recommendations = {}
    warnings = []

    for key, supplement in recommendations.items():
        supp_name_lower = supplement.get('name', '').lower()

        # Check contraindications
        is_safe = True

        # Check for Omega-3 contraindications
        if 'omega' in supp_name_lower:
            patient_contraindications = patient_profile.get("medical_history", {}).get("contraindications", [])

            # Check bleeding disorders
            if any('bleeding' in c.lower() for c in patient_contraindications):
                warnings.append(f"⚠️ Omega-3 contraindicated due to bleeding disorder")
                is_safe = False

            # Check for warfarin
            for med in medications:
                if 'warfarin' in med.get('name', '').lower():
                    warnings.append(f"⚠️ Omega-3 with Warfarin: Monitor INR closely")

        # Check for Vitamin D contraindications
        if 'vitamin d' in supp_name_lower:
            patient_contraindications = patient_profile.get("medical_history", {}).get("contraindications", [])

            if any('hypercalcemia' in c.lower() for c in patient_contraindications):
                warnings.append(f"⚠️ Vitamin D contraindicated due to hypercalcemia")
                is_safe = False

        if is_safe:
            final_recommendations[key] = supplement
            if warnings:
                final_recommendations[key]['warnings'] = warnings
                warnings = []  # Reset for next supplement

    return final_recommendations


def generate_supplement_schedule(supplement_recommendations, meal_schedule):
    """
    Generate a daily schedule for supplement intake
    """
    schedule = {
        "morning_fasting": [],
        "with_breakfast": [],
        "with_lunch": [],
        "with_dinner": [],
        "evening": []
    }

    for key, supplement in supplement_recommendations.items():
        timing = supplement.get("timing", "with_breakfast")

        schedule_entry = {
            "name": supplement.get("name"),
            "dose": supplement.get("dose"),
            "rationale": supplement.get("rationale", ""),
            "category": supplement.get("category", "")
        }

        # Map timing to schedule slots
        if timing == "morning_fasting":
            schedule["morning_fasting"].append(schedule_entry)
        elif timing in ["with_breakfast", "morning"]:
            schedule["with_breakfast"].append(schedule_entry)
        elif timing == "with_lunch":
            schedule["with_lunch"].append(schedule_entry)
        elif timing in ["with_dinner", "evening"]:
            schedule["with_dinner"].append(schedule_entry)
        else:
            schedule["with_breakfast"].append(schedule_entry)  # Default

    return schedule

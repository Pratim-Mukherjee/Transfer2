
from .delegate import get_formula, get_curve, get_band
def seed_from_baseline(hba1c_pct: float, tg_mg_dl: float, hdl_mg_dl: float, bodyfat_pct: float, weight_kg: float):
    # eAG from ADAG
    _ = get_formula("adag")  # load to assert present
    eag = 28.7 * hba1c_pct - 46.7

    # TG/HDL band
    ratio = tg_mg_dl / hdl_mg_dl if hdl_mg_dl else float("inf")
    band = None
    for row in get_band("tg_hdl_bands"):
        if ratio <= row["max_ratio"]:
            band = row["label"]; break

    # GV band by HbA1c
    gv = None
    for row in get_curve("hba1c_to_gv_band"):
        if hba1c_pct <= row["max_hba1c"]:
            gv = row; break
    if gv is None: gv = get_curve("hba1c_to_gv_band")[-1]

    # TTB tier
    ttb = None
    for row in get_curve("hba1c_to_ttb_min"):
        if hba1c_pct <= row["max_hba1c"]:
            ttb = row["ttb_min"]; break
    if ttb is None: ttb = get_curve("hba1c_to_ttb_min")[-1]["ttb_min"]

    values = {
        "eag_mgdl": round(eag,1),
        "tg_hdl_ratio": round(ratio,2),
        "insulin_sensitivity_band": band,
        "tir_pct": gv["TIR_pct"],
        "sd_mg_dl": gv["SD_mg_dl"],
        "mage_mg_dl": gv["MAGE_mg_dl"],
        "liver_chatter": gv["liver_chatter"],
        "ttb_min": ttb
    }
    sources = {
        "eag_mgdl":"formula:adag",
        "insulin_sensitivity_band":"band:tg_hdl_bands",
        "tir_pct":"curve:hba1c_to_gv_band",
        "ttb_min":"curve:hba1c_to_ttb_min"
    }
    return {"values": values, "sources": sources}

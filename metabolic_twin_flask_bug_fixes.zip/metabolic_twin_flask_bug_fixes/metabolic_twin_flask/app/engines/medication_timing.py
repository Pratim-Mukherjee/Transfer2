# app/engines/medication_timing.py

from .delegate import get_policy
from datetime import datetime, timedelta
import logging

def optimize_daily_schedule(medications, supplements, lifestyle_constraints, meal_distribution=None):
    """
    Main function to create optimized daily medication and supplement schedule
    Now accepts meal_distribution to align medications with actual meal times
    """
    config = get_policy("medication_timing")

    # Combine medications and supplements into unified list
    all_items = prepare_medication_list(medications, supplements)

    # Create initial schedule based on optimal timing
    initial_schedule = create_initial_schedule(all_items, config)

    # Resolve timing conflicts
    conflict_free_schedule = resolve_timing_conflicts(initial_schedule, config)

    # Apply lifestyle constraints
    final_schedule = apply_lifestyle_constraints(conflict_free_schedule, lifestyle_constraints)

    # Generate formatted output for protocol
    # Pass meal_distribution so we can use actual meal times and names
    # Pass lifestyle_constraints for time-of-day categorization based on user's wake/sleep times
    formatted_schedule = format_medication_schedule(final_schedule, meal_distribution, lifestyle_constraints)

    return formatted_schedule

def prepare_medication_list(medications, supplements):
    """
    Combine medications and supplements into unified list with timing metadata
    IMPORTANT: Preserves user-entered medication times, does NOT override them
    """
    config = get_policy("medication_timing")
    timing_rules = config["timing_rules"]

    all_items = []

    # Process prescription medications - PRESERVE USER TIMES and FREQUENCY PATTERNS
    for med in medications:
        # Check if medication has user-specified times
        user_times = med.get("times", [])
        has_user_times = user_times and len(user_times) > 0

        # Check if medication has frequency pattern (e.g., "0-0-1")
        frequency_pattern = med.get("frequency_pattern", None)

        med_info = {
            "name": med["name"],
            "dose": med["dose"],
            "frequency": med.get("frequency", "once_daily"),
            "category": "prescription",
            "user_times": user_times if has_user_times else None,  # Preserve user times
            "frequency_pattern": frequency_pattern,  # NEW: Store frequency pattern
            "timing_preference": med.get("timing", ["with_meals"]),
            "spacing_hours": get_medication_spacing(med["name"], timing_rules),
            "food_requirement": get_food_requirement(med["name"], timing_rules)
        }
        all_items.append(med_info)

    # Process supplements
    for supp_name, supp_details in supplements.items():
        if supp_name.startswith("_"):  # Skip meta information
            continue

        supp_info = {
            "name": supp_name,
            "dose": supp_details["dose"],
            "frequency": "once_daily",
            "category": "supplement",
            "user_times": None,  # Supplements don't have user times
            "timing_preference": [supp_details.get("timing", "with_breakfast")],
            "spacing_hours": get_supplement_spacing(supp_name, timing_rules),
            "food_requirement": get_food_requirement(supp_name, timing_rules)
        }
        all_items.append(supp_info)

    return all_items

def create_initial_schedule(all_items, config):
    """
    Create initial schedule based on optimal timing for each item
    """
    time_slots = config["time_slots"]
    initial_schedule = {slot: [] for slot in time_slots.keys()}
    
    for item in all_items:
        # Get preferred timing
        timing_preferences = item["timing_preference"]
        
        # Find best time slot
        best_slot = find_best_time_slot(timing_preferences, time_slots)
        
        # Add to schedule
        initial_schedule[best_slot].append(item)
    
    return initial_schedule

def find_best_time_slot(timing_preferences, time_slots):
    """
    Find the best time slot based on preferences
    """
    # Priority mapping for timing preferences
    timing_mapping = {
        "morning_fasting": "morning_fasting",
        "with_breakfast": "with_breakfast", 
        "morning": "with_breakfast",
        "afternoon": "afternoon",
        "with_dinner": "with_dinner",
        "evening": "with_dinner",
        "bedtime": "bedtime",
        "with_meals": "with_breakfast"  # Default to breakfast
    }
    
    # Find first matching preference
    for preference in timing_preferences:
        if preference in timing_mapping:
            return timing_mapping[preference]
    
    # Default to with_breakfast
    return "with_breakfast"

def resolve_timing_conflicts(schedule, config):
    """
    Resolve conflicts between medications/supplements that can't be taken together
    """
    interaction_rules = config["interaction_spacing"]
    conflict_free_schedule = {}
    
    for time_slot, items in schedule.items():
        if len(items) <= 1:
            conflict_free_schedule[time_slot] = items
            continue
        
        # Check for interactions between items in same time slot
        conflicts = find_interactions(items, interaction_rules)
        
        if not conflicts:
            conflict_free_schedule[time_slot] = items
        else:
            # Move conflicting items to different time slots
            resolved_items, moved_items = resolve_conflicts(items, conflicts, config)
            conflict_free_schedule[time_slot] = resolved_items
            
            # Place moved items in alternative slots
            for moved_item, alternative_slot in moved_items:
                if alternative_slot not in conflict_free_schedule:
                    conflict_free_schedule[alternative_slot] = []
                conflict_free_schedule[alternative_slot].append(moved_item)
    
    return conflict_free_schedule

def find_interactions(items, interaction_rules):
    """
    Find interaction conflicts between items in the same time slot
    """
    conflicts = []
    
    for i, item1 in enumerate(items):
        for j, item2 in enumerate(items[i+1:], i+1):
            # Check if these items have spacing requirements
            for rule_name, rule_details in interaction_rules.items():
                if (item1["name"] in rule_details["medications"] and 
                    item2["name"] in rule_details["medications"]):
                    conflicts.append({
                        "item1": item1,
                        "item2": item2,
                        "rule": rule_details,
                        "spacing_hours": rule_details["spacing_hours"]
                    })
    
    return conflicts

def resolve_conflicts(items, conflicts, config):
    """
    Resolve conflicts by moving items to alternative time slots
    """
    resolved_items = items.copy()
    moved_items = []
    
    for conflict in conflicts:
        # Move the less critical item (supplements over prescriptions)
        if conflict["item1"]["category"] == "supplement":
            item_to_move = conflict["item1"]
        elif conflict["item2"]["category"] == "supplement":
            item_to_move = conflict["item2"]
        else:
            # Both prescriptions - move the one with more flexible timing
            item_to_move = conflict["item2"]  # Arbitrary choice
        
        # Find alternative time slot
        alternative_slot = find_alternative_slot(item_to_move, config)
        
        # Remove from current slot and mark for moving
        if item_to_move in resolved_items:
            resolved_items.remove(item_to_move)
            moved_items.append((item_to_move, alternative_slot))
    
    return resolved_items, moved_items

def find_alternative_slot(item, config):
    """
    Find alternative time slot for moved item
    """
    time_slots = list(config["time_slots"].keys())
    current_preferences = item["timing_preference"]
    
    # Try to find next best slot based on item characteristics
    if item["food_requirement"] == "with_food":
        meal_slots = ["with_breakfast", "with_dinner"]
        for slot in meal_slots:
            if slot not in current_preferences:
                return slot
    
    if item["food_requirement"] == "fasting":
        return "morning_fasting"
    
    # Default alternative
    return "afternoon"



def apply_lifestyle_constraints(schedule, lifestyle_constraints):
    """
    Adjust schedule timing based on patient lifestyle
    """
    config = get_policy("medication_timing")

    # Get lifestyle timing preferences
    wake_time = lifestyle_constraints.get("wake_time", "06:00")
    work_schedule = lifestyle_constraints.get("work_schedule", "09:00-17:00")
    sleep_time = lifestyle_constraints.get("sleep_time", "22:00")



    # Extract work start time from work_schedule
    work_start = work_schedule.split("-")[0] if "-" in work_schedule else work_schedule

    # Calculate actual times for each slot
    time_mappings = calculate_actual_times(wake_time, work_start, sleep_time, config)
    
    # Adjust schedule if any times conflict with constraints
    adjusted_schedule = {}
    
    for time_slot, items in schedule.items():
        if not items:  # Skip empty slots
            continue
            
        actual_time = time_mappings.get(time_slot)
        if actual_time and is_time_feasible(actual_time, lifestyle_constraints):
            adjusted_schedule[time_slot] = {
                "items": items,
                "time": actual_time,
                "feasible": True
            }
        else:
            # Find alternative timing
            alternative_time = find_feasible_time(time_slot, lifestyle_constraints, config)
            adjusted_schedule[time_slot] = {
                "items": items,
                "time": alternative_time,
                "feasible": False,
                "note": f"Adjusted from optimal timing due to schedule constraints"
            }
    
    return adjusted_schedule
def parse_time_str(time_str):
    for fmt in ("%H:%M", "%H:%M:%S"):
        try:
            return datetime.strptime(time_str, fmt)
        except ValueError:
            continue
    raise ValueError(f"Invalid time format: {time_str}")

def calculate_actual_times(wake_time, work_start, sleep_time, config):
    """
    Calculate actual clock times for each time slot based on patient schedule
    """
    # Convert times to datetime objects for calculation
    wake_dt = parse_time_str(wake_time)
    work_dt = parse_time_str(work_start)
    sleep_dt = parse_time_str(sleep_time)
    
    time_mappings = {}
    
    # Morning fasting: 30-60 minutes after wake up
    time_mappings["morning_fasting"] = (wake_dt + timedelta(minutes=30)).strftime("%H:%M")
    
    # With breakfast: 60-90 minutes after wake up
    time_mappings["with_breakfast"] = (wake_dt + timedelta(minutes=75)).strftime("%H:%M")
    
    # Afternoon: Mid-afternoon, avoiding work conflicts
    afternoon_time = max(work_dt + timedelta(hours=4), datetime.strptime("13:00", "%H:%M"))
    time_mappings["afternoon"] = afternoon_time.strftime("%H:%M")
    
    # With dinner: 2-3 hours before sleep
    time_mappings["with_dinner"] = (sleep_dt - timedelta(hours=2.5)).strftime("%H:%M")
    
    # Bedtime: 30-60 minutes before sleep
    time_mappings["bedtime"] = (sleep_dt - timedelta(minutes=45)).strftime("%H:%M")
    
    return time_mappings

def is_time_feasible(time_str, lifestyle_constraints):
    """
    Check if a given time is feasible based on lifestyle constraints
    """
    # Simple feasibility check - can be enhanced
    work_schedule = lifestyle_constraints.get("work_schedule", "09:00-17:00")
    
    if "-" in work_schedule:
        work_start, work_end = work_schedule.split("-")
        work_start_dt = datetime.strptime(work_start, "%H:%M")
        work_end_dt = datetime.strptime(work_end, "%H:%M")
        time_dt = datetime.strptime(time_str, "%H:%M")
        
        # Check if time falls during work hours
        if work_start_dt <= time_dt <= work_end_dt:
            return False
    
    return True

def find_feasible_time(time_slot, lifestyle_constraints, config):
    """
    Find feasible alternative time when optimal timing conflicts with schedule
    """
    # Simple logic - can be enhanced
    work_schedule = lifestyle_constraints.get("work_schedule", "09:00-17:00")
    
    if time_slot == "afternoon" and "-" in work_schedule:
        work_end = work_schedule.split("-")[1]
        # Schedule after work
        work_end_dt = datetime.strptime(work_end, "%H:%M")
        alternative_dt = work_end_dt + timedelta(minutes=30)
        return alternative_dt.strftime("%H:%M")
    
    # Default return original mapping
    return config["default_times"].get(time_slot, "12:00")

def create_time_window(time_str, window_minutes=60):
    """
    Create a time window string from a base time
    Default window is ±30 minutes (total 60 minutes)

    Example: "08:00" -> "7:30 AM - 8:30 AM"
    """
    try:
        # Parse the time
        time_parts = time_str.split(':')
        hour = int(time_parts[0])
        minute = int(time_parts[1]) if len(time_parts) > 1 else 0

        # Calculate start time (30 min before)
        start_minutes = hour * 60 + minute - (window_minutes // 2)
        end_minutes = hour * 60 + minute + (window_minutes // 2)

        # Handle day boundaries
        if start_minutes < 0:
            start_minutes += 24 * 60
        if end_minutes >= 24 * 60:
            end_minutes -= 24 * 60

        # Convert back to hours and minutes
        def format_12hr(total_minutes):
            h = (total_minutes // 60) % 24
            m = total_minutes % 60
            period = "AM" if h < 12 else "PM"
            hour_12 = h % 12
            if hour_12 == 0:
                hour_12 = 12
            return f"{hour_12}:{m:02d} {period}"

        start_time = format_12hr(start_minutes)
        end_time = format_12hr(end_minutes)

        return f"{start_time} - {end_time}"
    except:
        return "12:00 PM - 1:00 PM"  # Default fallback

def get_time_of_day_category(time_str, wake_time=None, sleep_time=None):
    """
    Categorize time into morning/afternoon/night based on user's actual wake/sleep times
    If wake/sleep times not provided, uses default ranges

    Logic:
    - Morning: wake_time to wake_time + 6 hours
    - Afternoon: wake_time + 6 hours to wake_time + 10 hours
    - Night: wake_time + 10 hours to sleep_time (and sleep to wake)
    """
    try:
        # Parse the time to check
        time_parts = time_str.split(':')
        check_hour = int(time_parts[0])
        check_min = int(time_parts[1]) if len(time_parts) > 1 else 0
        check_minutes = check_hour * 60 + check_min

        # If no wake/sleep times provided, use default fixed ranges
        if not wake_time or not sleep_time:
            if 5 <= check_hour < 12:
                return "morning"
            elif 12 <= check_hour < 18:
                return "afternoon"
            else:
                return "night"

        # Parse wake and sleep times
        wake_parts = wake_time.split(':')
        wake_hour = int(wake_parts[0])
        wake_min = int(wake_parts[1]) if len(wake_parts) > 1 else 0
        wake_minutes = wake_hour * 60 + wake_min

        sleep_parts = sleep_time.split(':')
        sleep_hour = int(sleep_parts[0])
        sleep_min = int(sleep_parts[1]) if len(sleep_parts) > 1 else 0
        sleep_minutes = sleep_hour * 60 + sleep_min

        # Calculate boundaries based on wake time
        # Morning: wake to wake+6hrs
        morning_end = wake_minutes + (6 * 60)
        # Afternoon: wake+6hrs to wake+10hrs
        afternoon_end = wake_minutes + (10 * 60)

        # Handle times that cross midnight
        def normalize_time(minutes):
            """Normalize minutes to 0-1440 range, handling day boundaries"""
            if minutes >= 24 * 60:
                return minutes - (24 * 60)
            elif minutes < 0:
                return minutes + (24 * 60)
            return minutes

        morning_end = normalize_time(morning_end)
        afternoon_end = normalize_time(afternoon_end)

        # Determine category
        # Check if time falls in morning window
        if wake_minutes <= morning_end:
            # Normal case: morning period doesn't cross midnight
            if wake_minutes <= check_minutes < morning_end:
                return "morning"
        else:
            # Morning period crosses midnight
            if check_minutes >= wake_minutes or check_minutes < morning_end:
                return "morning"

        # Check if time falls in afternoon window
        if morning_end <= afternoon_end:
            # Normal case: afternoon period doesn't cross midnight
            if morning_end <= check_minutes < afternoon_end:
                return "afternoon"
        else:
            # Afternoon period crosses midnight
            if check_minutes >= morning_end or check_minutes < afternoon_end:
                return "afternoon"

        # Everything else is night
        return "night"

    except Exception as e:
        return "morning"  # Default fallback

def format_medication_schedule(optimized_schedule, meal_distribution=None, lifestyle_constraints=None):
    """
    Format the optimized schedule for protocol output
    IMPORTANT: Uses user-specified times for medications when available
    NOW: Uses actual meal times and names from meal distribution
    NOW: Uses user's wake/sleep times for time-of-day categorization
    """
    formatted_schedule = {
        "dailySchedule": []
    }

    # Get wake/sleep times for time-of-day categorization
    wake_time = None
    sleep_time = None
    if lifestyle_constraints:
        wake_time = lifestyle_constraints.get("wake_time")
        sleep_time = lifestyle_constraints.get("sleep_time")

    # Build meal timing map from meal_distribution if provided
    meal_map = {}
    if meal_distribution and "meals" in meal_distribution:
        for i, meal in enumerate(meal_distribution["meals"]):
            meal_map[i] = {
                "name": meal.get("meal_name", f"Meal {i+1}"),
                "time": meal.get("timing", "12:00"),
                "number": i + 1
            }

    # First, handle medications with user-specified times OR frequency patterns
    user_timed_medications = []
    for slot_key, slot_data in optimized_schedule.items():
        if "items" in slot_data:
            for item in slot_data["items"]:
                # Handle medications with specific times
                if item.get("user_times") and item["category"] == "prescription":
                    # This medication has user-specified times
                    for time_str in item["user_times"]:
                        time_category = get_time_of_day_category(time_str, wake_time, sleep_time)
                        time_window = create_time_window(time_str)
                        user_timed_medications.append({
                            "status": "upcoming",
                            "timeSlot": time_category,  # Add timeSlot for UI compatibility
                            "timeWindow": time_window,
                            "timeOfDay": time_category,
                            "medications": [{
                                "name": item["name"],
                                "dose": item["dose"],
                                "type": item["category"],  # "prescription" or "supplement"
                                "emoji": get_medication_emoji(item["name"], item["category"]),
                                "reason": "Medication" if item["category"] == "prescription" else "Supplement",
                                "instructions": f"Take as prescribed"
                            }]
                        })

                # Handle medications with frequency patterns (e.g., "0-0-1", "1-2-1")
                elif item.get("frequency_pattern") and item["category"] == "prescription" and meal_map:
                    pattern = item["frequency_pattern"]
                    parts = pattern.split('-')
                    if len(parts) == 3:
                        # Map pattern to meal times
                        # Pattern format: breakfast-lunch-dinner (e.g., "1-2-1" = 1 at breakfast, 2 at lunch, 1 at dinner)
                        for meal_idx, count_str in enumerate(parts):
                            count = int(count_str)
                            if count > 0 and meal_idx in meal_map:
                                meal_info = meal_map[meal_idx]
                                time_category = get_time_of_day_category(meal_info['time'], wake_time, sleep_time)
                                time_window = create_time_window(meal_info['time'])

                                # Create dose instruction based on count
                                dose_instruction = item["dose"]
                                if count > 1:
                                    dose_instruction = f"{count} × {item['dose']}"

                                user_timed_medications.append({
                                    "status": "upcoming",
                                    "timeSlot": time_category,  # Add timeSlot for UI compatibility
                                    "timeWindow": time_window,
                                    "timeOfDay": time_category,
                                    "medications": [{
                                        "name": item["name"],
                                        "dose": dose_instruction,
                                        "type": item["category"],  # "prescription" or "supplement"
                                        "emoji": get_medication_emoji(item["name"], item["category"]),
                                        "reason": "Medication" if item["category"] == "prescription" else "Supplement",
                                        "instructions": f"Take {count} tablet{'s' if count > 1 else ''} with {meal_info['name'].lower()}"
                                    }]
                                })

    # Then, handle supplements and medications without user times (optimized times)
    # Map timing slots to actual meals if meal_distribution is available
    slot_order = []
    if meal_map:
        # Use actual meal times from meal distribution
        if len(meal_map) == 1:
            # OMAD - single meal
            slot_order = [
                ("with_breakfast", f"WITH {meal_map[0]['name'].upper()}", meal_map[0]['time'])
            ]
        elif len(meal_map) == 2:
            # 2 meals
            slot_order = [
                ("with_breakfast", f"WITH {meal_map[0]['name'].upper()}", meal_map[0]['time']),
                ("with_dinner", f"WITH {meal_map[1]['name'].upper()}", meal_map[1]['time'])
            ]
        elif len(meal_map) >= 3:
            # 3+ meals
            slot_order = [
                ("with_breakfast", f"WITH {meal_map[0]['name'].upper()}", meal_map[0]['time']),
                ("afternoon", f"WITH {meal_map[1]['name'].upper()}", meal_map[1]['time']),
                ("with_dinner", f"WITH {meal_map[2]['name'].upper()}", meal_map[2]['time'])
            ]
    else:
        # Fallback to generic slot names if no meal distribution
        slot_order = [
            ("morning_fasting", "Morning (Fasting)", "07:00"),
            ("with_breakfast", "With Breakfast", "08:00"),
            ("afternoon", "Afternoon", "14:00"),
            ("with_dinner", "With Dinner", "19:00"),
            ("bedtime", "Bedtime", "22:00")
        ]

    for slot_key, _, slot_time in slot_order:
        if slot_key in optimized_schedule and optimized_schedule[slot_key]["items"]:
            slot_data = optimized_schedule[slot_key]

            medications_list = []
            for item in slot_data["items"]:
                # Skip prescription medications with user times (already added above)
                if item.get("user_times") and item["category"] == "prescription":
                    continue

                # Skip prescription medications with frequency patterns (already added above)
                if item.get("frequency_pattern") and item["category"] == "prescription":
                    continue

                # Clean up medication name - remove "User " prefix if present
                clean_name = item["name"].replace("_", " ").title()
                if clean_name.startswith("User "):
                    clean_name = clean_name.replace("User ", "", 1)

                med_entry = {
                    "name": clean_name,
                    "dose": item["dose"],
                    "type": item["category"],  # "prescription" or "supplement"
                    "emoji": get_medication_emoji(item["name"], item["category"]),
                    "reason": "Medication" if item["category"] == "prescription" else "Supplement",
                    "instructions": get_timing_instructions(slot_key, item)
                }
                medications_list.append(med_entry)

            # Only add this time slot if it has items
            if medications_list:
                time_category = get_time_of_day_category(slot_time, wake_time, sleep_time)
                time_window = create_time_window(slot_time)
                schedule_entry = {
                    "status": "upcoming",
                    "timeSlot": time_category,  # Add timeSlot for UI compatibility
                    "timeWindow": time_window,
                    "timeOfDay": time_category,
                    "medications": medications_list
                }

                if not slot_data.get("feasible", True):
                    schedule_entry["note"] = slot_data.get("note", "")

                formatted_schedule["dailySchedule"].append(schedule_entry)

    # Add user-timed medications first, then sort all by time
    all_schedules = user_timed_medications + formatted_schedule["dailySchedule"]

    # Sort by timeWindow - extract the start time from "HH:MM AM/PM - HH:MM AM/PM" format
    def extract_sort_time(entry):
        """Extract start time from time window for sorting"""
        try:
            time_window = entry.get("timeWindow", "12:00 PM - 1:00 PM")
            start_time = time_window.split(" - ")[0].strip()
            # Parse 12-hour format to 24-hour for sorting
            time_part, period = start_time.rsplit(" ", 1)
            hour, minute = map(int, time_part.split(":"))
            if period == "PM" and hour != 12:
                hour += 12
            elif period == "AM" and hour == 12:
                hour = 0
            return hour * 60 + minute
        except:
            return 0

    all_schedules.sort(key=extract_sort_time)

    formatted_schedule["dailySchedule"] = all_schedules

    return formatted_schedule

def get_medication_emoji(med_name, category):
    """
    Get appropriate emoji for medication/supplement
    """
    emoji_map = {
        "metformin": "💊",
        "r_ala": "💊", 
        "omega3": "🐟",
        "vitamin_d3_k2": "☀",
        "magnesium_glycinate": "🌙",
        "b12_methylcobalamin": "💊",
        "coq10": "⚡"
    }
    
    return emoji_map.get(med_name, "💊" if category == "prescription" else "🟡")

def get_medication_reason(med_name):
    """
    Get brief reason for medication/supplement
    """
    reasons = {
        "metformin": "Blood sugar control",
        "r_ala": "Antioxidant, insulin sensitivity, relieves neuropathy",
        "omega3": "Anti-inflammatory, reduces triglycerides, improves cardiovascular health", 
        "vitamin_d3_k2": "Supports vascular health, reduces calcification, improves insulin sensitivity",
        "magnesium_glycinate": "Relaxes vascular smooth muscle, improves endothelial function, insulin cofactor",
        "b12_methylcobalamin": "Energy metabolism, prevents metformin-induced deficiency",
        "coq10": "Mitochondrial support, glucose uptake, statin-related muscle protection"
    }
    
    return reasons.get(med_name, "Health optimization")

def get_timing_instructions(time_slot, item):
    """
    Get specific timing instructions for medication/supplement
    """
    instructions = {
        "morning_fasting": f"Take on empty stomach, 45 min before breakfast",
        "with_breakfast": f"Take with breakfast",
        "afternoon": f"Take with or without food", 
        "with_dinner": f"Take with dinner",
        "bedtime": f"Take before bedtime"
    }
    
    base_instruction = instructions.get(time_slot, "Take as directed")
    
    # Add specific notes for certain medications
    if item["name"] == "magnesium_glycinate":
        return "Take before bedtime"
    elif item["name"] == "r_ala":
        return "Take on empty stomach, 45 min before breakfast"
    elif "omega3" in item["name"]:
        return "Take after breakfast"
    
    return base_instruction

def get_medication_spacing(med_name, timing_rules):
    """
    Get spacing requirements for medications
    """
    spacing_rules = timing_rules.get("medication_spacing", {})
    return spacing_rules.get(med_name, {}).get("spacing_hours", 0)

def get_supplement_spacing(supp_name, timing_rules):
    """
    Get spacing requirements for supplements
    """
    spacing_rules = timing_rules.get("supplement_spacing", {})
    return spacing_rules.get(supp_name, {}).get("spacing_hours", 0)

def get_food_requirement(item_name, timing_rules):
    """
    Get food requirement for medication/supplement
    """
    food_rules = timing_rules.get("food_requirements", {})
    return food_rules.get(item_name, {}).get("requirement", "flexible")

import numpy as np
from .delegate import get_policy, get_band

def compute_now(cgm_samples, meals=None, activities=None, labs=None, body=None):
    vals = np.array([p["mgdl"] for p in cgm_samples], dtype=float)
    if vals.size == 0:
        raise ValueError("No CGM values")
    mean = float(np.mean(vals))
    sd = float(np.std(vals, ddof=0))
    cv = float(100 * sd / mean) if mean else 0.0
    tir_low = get_policy("gv")["range_tir"]["low"]
    tir_high = get_policy("gv")["range_tir"]["high"]
    tir = float(100 * np.mean((vals>=tir_low) & (vals<=tir_high)))
    fbg = float(np.mean(vals[:12])) if vals.size>=12 else float(vals[0])  # naive

    # placeholders (swap with real event engine later)
    ttb_min = 280.0; delta_peak_med = 48.0; auc_med = 5000.0
    lc_energy = 0.74; lc_z = -0.2

    hba1c = labs.get("hba1c_pct") if labs else None
    eag = 28.7 * hba1c - 46.7 if hba1c is not None else None
    tg = labs.get("tg_mg_dl") if labs else None
    hdl = labs.get("hdl_mg_dl") if labs else None
    ratio = (tg/hdl) if (tg and hdl) else None
    ir_band = None
    if ratio is not None:
        for row in get_band("tg_hdl_bands"):
            if ratio <= row["max_ratio"]:
                ir_band = row["label"]; break

    out_vals = {
        "fbg_mgdl": round(fbg,0),
        "mean_glucose_mgdl": round(mean,1),
        "sd_mg_dl": round(sd,1),
        "cv_pct": round(cv,1),
        "tir_pct": round(tir,1),
        "ttb_min": round(ttb_min,0),
        "delta_peak_med_mgdl": round(delta_peak_med,0),
        "auc_med": round(auc_med,0),
        "lc_energy": round(lc_energy,2),
        "lc_z": round(lc_z,2),
        "eag_mgdl": round(eag,1) if eag is not None else None,
        "hba1c_pct": hba1c,
        "tg_hdl_ratio": round(ratio,2) if ratio is not None else None,
        "insulin_sensitivity_band": ir_band,
        "bodyfat_pct": body.get("bodyfat_pct") if body else None,
        "weight_kg": body.get("weight_kg") if body else None
    }
    sources = {"fbg_mgdl":"observed","mean_glucose_mgdl":"observed","cv_pct":"observed","tir_pct":"observed",
               "ttb_min":"observed","delta_peak_med_mgdl":"observed","auc_med":"observed",
               "lc_energy":"observed","lc_z":"observed"}
    if hba1c is not None: sources["eag_mgdl"] = "formula:adag"
    if ratio is not None: sources["insulin_sensitivity_band"] = "band:tg_hdl_bands"

    quality = {"coverage_pct": round(100*len(vals)/288,1), "gaps": 0, "flags": []}
    return {"as_of": None, "values": out_vals, "sources": sources, "quality": quality}

"""
External API Helper
Makes HTTP requests to external patient management API server
"""

import json
import requests
from typing import Dict, List, Optional
import os
import sys

# Add parent directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.utils.body_fat_calculator import get_body_fat_with_fallback, validate_body_measurements

# ===========================================
# API CONFIGURATION
# ===========================================

# External API server configuration
# Change this to production URL when deploying
API_BASE_URL = os.getenv("EXTERNAL_API_URL", "http://localhost:9000")
API_KEY = os.getenv("EXTERNAL_API_KEY", "")  # Add authentication token when available

# Request timeout in seconds
REQUEST_TIMEOUT = 40

# ===========================================
# API HELPER METHODS
# ===========================================

def fetch_patient_list() -> List[Dict]:
    """
    Fetch list of patients from external API

    Returns:
        List of patient dictionaries with patient_id, name, age, has_protocol, last_visit
    """
    try:
        print(f"[API] Fetching patient list from {API_BASE_URL}")

        headers = {}
        if API_KEY:
            headers["Authorization"] = f"Bearer {API_KEY}"

        response = requests.get(
            f"{API_BASE_URL}/api/patients",
            headers=headers,
            timeout=REQUEST_TIMEOUT
        )
        response.raise_for_status()

        data = response.json()
        if data.get("success"):
            print(f"[API] Successfully fetched {len(data['patients'])} patients")
            return data["patients"]
        else:
            print(f"[API] Error in response: {data.get('error', 'Unknown error')}")
            return []

    except requests.exceptions.ConnectionError:
        print(f"[API ERROR] Cannot connect to external API server at {API_BASE_URL}")
        print("[API ERROR] Make sure the external API server is running (python external_api_server/api_server.py)")
        return []
    except requests.exceptions.Timeout:
        print(f"[API ERROR] Request timeout after {REQUEST_TIMEOUT} seconds")
        return []
    except Exception as e:
        print(f"[API ERROR] Failed to fetch patient list: {str(e)}")
        return []


def fetch_patient_reports(patient_id: str) -> Optional[Dict]:
    """
    Fetch patient medical reports from external API

    Args:
        patient_id: Patient identifier

    Returns:
        Dictionary containing patient demographics, lab reports, lifestyle, medications, contraindications
    """
    try:
        print(f"[API] Fetching reports for patient: {patient_id}")

        headers = {}
        if API_KEY:
            headers["Authorization"] = f"Bearer {API_KEY}"

        response = requests.get(
            f"{API_BASE_URL}/api/patient/{patient_id}/reports",
            headers=headers,
            timeout=REQUEST_TIMEOUT
        )
        response.raise_for_status()

        data = response.json()
        if data.get("success"):
            print(f"[API] Successfully fetched reports for patient: {patient_id}")
            return data["reports"]
        else:
            print(f"[API] Error fetching reports: {data.get('error', 'Unknown error')}")
            return None

    except requests.exceptions.ConnectionError:
        print(f"[API ERROR] Cannot connect to external API server at {API_BASE_URL}")
        return None
    except requests.exceptions.Timeout:
        print(f"[API ERROR] Request timeout after {REQUEST_TIMEOUT} seconds")
        return None
    except Exception as e:
        print(f"[API ERROR] Failed to fetch patient reports: {str(e)}")
        return None


def check_existing_protocol(patient_id: str) -> Dict:
    """
    Check if protocol exists for patient via external API

    Args:
        patient_id: Patient identifier

    Returns:
        Dictionary with 'exists' boolean and optional 'protocol', 'weekly_targets' data
    """
    try:
        print(f"[API] Checking for existing protocol: {patient_id}")

        headers = {}
        if API_KEY:
            headers["Authorization"] = f"Bearer {API_KEY}"

        response = requests.get(
            f"{API_BASE_URL}/api/patient/{patient_id}/protocol",
            headers=headers,
            timeout=REQUEST_TIMEOUT
        )
        response.raise_for_status()

        data = response.json()
        if data.get("success"):
            if data.get("exists"):
                print(f"[API] Found existing protocol for patient: {patient_id}")
                return {
                    "exists": True,
                    "protocol": data.get("protocol"),
                    "weekly_targets": data.get("weekly_targets"),
                    "timestamp": data.get("timestamp")
                }
            else:
                print(f"[API] No existing protocol found for: {patient_id}")
                return {"exists": False}
        else:
            print(f"[API] Error checking protocol: {data.get('error', 'Unknown error')}")
            return {"exists": False}

    except requests.exceptions.ConnectionError:
        print(f"[API ERROR] Cannot connect to external API server at {API_BASE_URL}")
        return {"exists": False}
    except requests.exceptions.Timeout:
        print(f"[API ERROR] Request timeout after {REQUEST_TIMEOUT} seconds")
        return {"exists": False}
    except Exception as e:
        print(f"[API ERROR] Failed to check existing protocol: {str(e)}")
        return {"exists": False}


def post_protocol_to_external_api(patient_id: str, protocol_data: Dict) -> bool:
    """
    Post generated protocol to external API

    Args:
        patient_id: Patient identifier
        protocol_data: Complete protocol JSON

    Returns:
        True if successful, False otherwise
    """
    try:
        print(f"[API] Posting protocol to external API for patient: {patient_id}")

        headers = {"Content-Type": "application/json"}
        if API_KEY:
            headers["Authorization"] = f"Bearer {API_KEY}"

        response = requests.post(
            f"{API_BASE_URL}/api/patient/{patient_id}/protocol",
            json={"protocol": protocol_data},
            headers=headers,
            timeout=REQUEST_TIMEOUT
        )
        response.raise_for_status()

        data = response.json()
        if data.get("success"):
            print(f"[API] Successfully posted protocol for patient: {patient_id}")
            return True
        else:
            print(f"[API] Error posting protocol: {data.get('error', 'Unknown error')}")
            return False

    except requests.exceptions.ConnectionError:
        print(f"[API ERROR] Cannot connect to external API server at {API_BASE_URL}")
        return False
    except requests.exceptions.Timeout:
        print(f"[API ERROR] Request timeout after {REQUEST_TIMEOUT} seconds")
        return False
    except Exception as e:
        print(f"[API ERROR] Failed to post protocol: {str(e)}")
        return False


def post_weekly_targets_to_external_api(patient_id: str, weekly_targets: Dict) -> bool:
    """
    Post weekly targets to external API

    Args:
        patient_id: Patient identifier
        weekly_targets: Weekly targets JSON

    Returns:
        True if successful, False otherwise
    """
    try:
        print(f"[API] Posting weekly targets to external API for patient: {patient_id}")

        headers = {"Content-Type": "application/json"}
        if API_KEY:
            headers["Authorization"] = f"Bearer {API_KEY}"

        response = requests.post(
            f"{API_BASE_URL}/api/patient/{patient_id}/weekly-targets",
            json={"weekly_targets": weekly_targets},
            headers=headers,
            timeout=REQUEST_TIMEOUT
        )
        response.raise_for_status()

        data = response.json()
        if data.get("success"):
            print(f"[API] Successfully posted weekly targets for patient: {patient_id}")
            return True
        else:
            print(f"[API] Error posting weekly targets: {data.get('error', 'Unknown error')}")
            return False

    except requests.exceptions.ConnectionError:
        print(f"[API ERROR] Cannot connect to external API server at {API_BASE_URL}")
        return False
    except requests.exceptions.Timeout:
        print(f"[API ERROR] Request timeout after {REQUEST_TIMEOUT} seconds")
        return False
    except Exception as e:
        print(f"[API ERROR] Failed to post weekly targets: {str(e)}")
        return False


# ===========================================
# DATA TRANSFORMATION HELPERS
# ===========================================

def transform_reports_to_baseline(reports: Dict) -> Dict:
    """
    Transform external medical reports format to internal baseline format
    This acts as the mapping layer between external API and internal format
    Calculates body fat using Navy method if not provided
    """

    if not reports:
        return None

    # Get body fat with fallback to Navy method calculation
    body_fat_result = get_body_fat_with_fallback(
        lab_reports=reports["lab_reports"],
        demographics=reports["demographics"]
    )

    # Transform to enhanced baseline format expected by the system
    enhanced_baseline = {
        "patient_profile": {
            "demographics": {
                "name": reports["name"],
                "age": reports["demographics"]["age"],
                "gender": reports["demographics"]["gender"],
                "height_cm": reports["demographics"]["height_cm"],
                "weight_kg": reports["demographics"]["weight_kg"]
            },
            "metabolic_baseline": {
                "hba1c_pct": reports["lab_reports"]["hba1c_pct"],
                "fbg_mgdl": reports["lab_reports"]["fbg_mgdl"],
                "tg_mg_dl": reports["lab_reports"].get("triglycerides_mgdl"),
                "hdl_mg_dl": reports["lab_reports"].get("hdl_mgdl"),
                "ldl_mg_dl": reports["lab_reports"].get("ldl_mgdl"),
                "bodyfat_pct": body_fat_result["bodyfat_pct"],
                "bodyfat_method": body_fat_result["bodyfat_method"],
                "bodyfat_is_calculated": body_fat_result["is_calculated"],
                "body_measurements": body_fat_result["body_measurements"],
                "egfr": reports["lab_reports"].get("egfr"),
                "creatinine_mg_dl": reports["lab_reports"].get("creatinine_mgdl")
            },
            "lab_results": {
                "vitamin_b12": reports["lab_reports"].get("vitamin_b12_pg_ml"),
                "vitamin_d": reports["lab_reports"].get("vitamin_d_ng_ml")
            },
            "lifestyle_constraints": {
                "wake_time": reports["lifestyle"]["wake_time"],
                "sleep_time": reports["lifestyle"]["sleep_time"],
                "work_schedule": f"{reports['lifestyle']['work_start']}-{reports['lifestyle']['work_end']}",
                "cultural_food_preference": reports["lifestyle"]["cultural_food_preference"],
                "activity_level": reports["lifestyle"]["activity_level"]
            },
            "medical_history": {
                "current_medications": reports["current_medications"],
                "current_supplements": reports.get("current_supplements", []),
                "contraindications": reports["contraindications"]
            }
        }
    }

    return enhanced_baseline


def transform_baseline_to_form_data(enhanced_baseline: Dict) -> Dict:
    """
    Transform enhanced baseline to form data for UI population
    Includes body measurements and medication times
    """

    if not enhanced_baseline:
        return {}

    profile = enhanced_baseline["patient_profile"]
    metabolic = profile["metabolic_baseline"]

    # Extract work schedule
    work_schedule = profile["lifestyle_constraints"]["work_schedule"]
    work_start, work_end = work_schedule.split("-") if "-" in work_schedule else ("09:00", "17:00")

    form_data = {
        "demographics": profile["demographics"],
        "metabolic": {
            "hba1c_pct": metabolic.get("hba1c_pct"),
            "fbg_mgdl": metabolic.get("fbg_mgdl"),
            "tg_mg_dl": metabolic.get("tg_mg_dl"),
            "hdl_mg_dl": metabolic.get("hdl_mg_dl"),
            "ldl_mg_dl": metabolic.get("ldl_mg_dl"),
            "bodyfat_pct": metabolic.get("bodyfat_pct"),
            "bodyfat_method": metabolic.get("bodyfat_method"),
            "bodyfat_is_calculated": metabolic.get("bodyfat_is_calculated", False),
            "egfr": metabolic.get("egfr"),
            "creatinine_mg_dl": metabolic.get("creatinine_mg_dl")
        },
        "body_measurements": metabolic.get("body_measurements", {}),
        "lab_results": {
            "vitamin_b12": profile.get("lab_results", {}).get("vitamin_b12"),
            "vitamin_d": profile.get("lab_results", {}).get("vitamin_d")
        },
        "lifestyle": {
            "wake_time": profile["lifestyle_constraints"]["wake_time"],
            "sleep_time": profile["lifestyle_constraints"]["sleep_time"],
            "work_start": work_start,
            "work_end": work_end,
            "cultural_food_preference": profile["lifestyle_constraints"]["cultural_food_preference"],
            "activity_level": profile["lifestyle_constraints"]["activity_level"]
        },
        "medications": profile["medical_history"]["current_medications"],
        "supplements": profile["medical_history"].get("current_supplements", []),
        "contraindications": profile["medical_history"]["contraindications"]
    }

    return form_data
"""
Body Fat Percentage Calculator
Implements US Navy body fat estimation method
"""

import math
from typing import Optional, Dict


def calculate_body_fat_navy_method(
    gender: str,
    height_cm: float,
    waist_cm: float,
    neck_cm: float,
    hip_cm: Optional[float] = None
) -> Optional[float]:
    """
    Calculate body fat percentage using US Navy method

    Formulas:
    Male: Body Fat % = 495 / (1.0324 - 0.19077 × log10(waist - neck) + 0.15456 × log10(height)) - 450
    Female: Body Fat % = 495 / (1.29579 - 0.35004 × log10(waist + hip - neck) + 0.22100 × log10(height)) - 450

    Args:
        gender: "male" or "female"
        height_cm: Height in centimeters
        waist_cm: Waist circumference in centimeters (at navel for men, at narrowest point for women)
        neck_cm: Neck circumference in centimeters (below larynx)
        hip_cm: Hip circumference in centimeters (required for females, at widest point)

    Returns:
        Body fat percentage as float, or None if calculation not possible
    """

    # Validate inputs
    if not all([gender, height_cm, waist_cm, neck_cm]):
        return None

    if height_cm <= 0 or waist_cm <= 0 or neck_cm <= 0:
        return None

    if waist_cm <= neck_cm:
        return None  # Invalid measurement

    gender = gender.lower()

    try:
        if gender == "male":
            # Male formula
            log_waist_minus_neck = math.log10(waist_cm - neck_cm)
            log_height = math.log10(height_cm)

            body_fat_pct = 495 / (1.0324 - 0.19077 * log_waist_minus_neck + 0.15456 * log_height) - 450

        elif gender == "female":
            # Female formula requires hip measurement
            if not hip_cm or hip_cm <= 0:
                return None

            if (waist_cm + hip_cm) <= neck_cm:
                return None  # Invalid measurement

            log_waist_hip_minus_neck = math.log10(waist_cm + hip_cm - neck_cm)
            log_height = math.log10(height_cm)

            body_fat_pct = 495 / (1.29579 - 0.35004 * log_waist_hip_minus_neck + 0.22100 * log_height) - 450

        else:
            return None  # Invalid gender

        # Validate result is within reasonable range
        if body_fat_pct < 3 or body_fat_pct > 60:
            return None  # Unrealistic value, likely measurement error

        return round(body_fat_pct, 1)

    except (ValueError, ZeroDivisionError):
        return None


def get_body_fat_with_fallback(
    lab_reports: Dict,
    demographics: Dict
) -> Dict:
    """
    Get body fat percentage from lab reports, or calculate using Navy method if missing

    Args:
        lab_reports: Dictionary containing bodyfat_pct and body_measurements
        demographics: Dictionary containing gender and height_cm

    Returns:
        Dictionary with:
        - bodyfat_pct: The body fat percentage (from lab or calculated)
        - bodyfat_method: How it was determined
        - is_calculated: Boolean indicating if it was calculated
        - body_measurements: The measurements used (if any)
    """

    result = {
        "bodyfat_pct": None,
        "bodyfat_method": None,
        "is_calculated": False,
        "body_measurements": None
    }

    # Check if body fat percentage already exists
    if lab_reports.get("bodyfat_pct") is not None:
        result["bodyfat_pct"] = lab_reports["bodyfat_pct"]
        result["bodyfat_method"] = lab_reports.get("bodyfat_method", "provided")
        result["is_calculated"] = False
        result["body_measurements"] = lab_reports.get("body_measurements")
        return result

    # Try to calculate using Navy method
    body_measurements = lab_reports.get("body_measurements", {})

    if not body_measurements:
        return result

    waist_cm = body_measurements.get("waist_cm")
    neck_cm = body_measurements.get("neck_cm")
    hip_cm = body_measurements.get("hip_cm")

    gender = demographics.get("gender")
    height_cm = demographics.get("height_cm")

    if not all([gender, height_cm, waist_cm, neck_cm]):
        return result

    calculated_bodyfat = calculate_body_fat_navy_method(
        gender=gender,
        height_cm=height_cm,
        waist_cm=waist_cm,
        neck_cm=neck_cm,
        hip_cm=hip_cm
    )

    if calculated_bodyfat is not None:
        result["bodyfat_pct"] = calculated_bodyfat
        result["bodyfat_method"] = "navy_formula"
        result["is_calculated"] = True
        result["body_measurements"] = body_measurements

    return result


def get_required_measurements_for_gender(gender: str) -> list:
    """
    Get list of required body measurements for Navy method based on gender

    Args:
        gender: "male" or "female"

    Returns:
        List of required measurement field names
    """
    base_measurements = ["waist_cm", "neck_cm"]

    if gender and gender.lower() == "female":
        return base_measurements + ["hip_cm"]

    return base_measurements


def validate_body_measurements(
    gender: str,
    height_cm: float,
    body_measurements: Dict
) -> Dict:
    """
    Validate body measurements for Navy method calculation

    Returns:
        Dictionary with:
        - valid: Boolean
        - missing_fields: List of missing required fields
        - invalid_fields: List of fields with invalid values
        - can_calculate: Boolean indicating if Navy method can be used
    """

    result = {
        "valid": True,
        "missing_fields": [],
        "invalid_fields": [],
        "can_calculate": False
    }

    required_fields = get_required_measurements_for_gender(gender)

    # Check for missing fields
    for field in required_fields:
        if field not in body_measurements or body_measurements[field] is None:
            result["missing_fields"].append(field)
            result["valid"] = False

    if result["missing_fields"]:
        return result

    # Validate values
    waist_cm = body_measurements.get("waist_cm", 0)
    neck_cm = body_measurements.get("neck_cm", 0)
    hip_cm = body_measurements.get("hip_cm")

    if waist_cm <= 0 or waist_cm > 200:
        result["invalid_fields"].append("waist_cm")
        result["valid"] = False

    if neck_cm <= 0 or neck_cm > 60:
        result["invalid_fields"].append("neck_cm")
        result["valid"] = False

    if waist_cm <= neck_cm:
        result["invalid_fields"].append("waist_cm")
        result["invalid_fields"].append("neck_cm")
        result["valid"] = False

    if gender and gender.lower() == "female":
        if hip_cm is None or hip_cm <= 0 or hip_cm > 200:
            result["invalid_fields"].append("hip_cm")
            result["valid"] = False

    if height_cm <= 0 or height_cm > 250:
        result["invalid_fields"].append("height_cm")
        result["valid"] = False

    result["can_calculate"] = result["valid"]

    return result
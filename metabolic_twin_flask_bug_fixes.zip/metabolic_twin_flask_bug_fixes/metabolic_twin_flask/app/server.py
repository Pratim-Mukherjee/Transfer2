# Complete Flask Server for Metabolic Twin Diabetes Management System
# Drop-in replacement server.py file

from flask import Flask, render_template, request, jsonify
from flask_cors import CORS
import json
import os
import datetime
import traceback

# Import all the engines
try:
    from app.engines.protocol_generator import generate_complete_protocol
    from app.engines.weekly_progression import calculate_weekly_progression
    from app.engines.macro_calculator import get_recommended_deficit, calculate_safe_deficit_range
    from app.engines.supplement_optimizer import analyze_supplement_needs
    from app.engines.current_state import compute_now
    from app.engines.scoring import compute_scores
    from app.engines.delegate import get_policy
    from app.external_api_helper import (
        fetch_patient_list,
        fetch_patient_reports,
        check_existing_protocol,
        post_protocol_to_external_api,
        post_weekly_targets_to_external_api,
        transform_reports_to_baseline,
        transform_baseline_to_form_data
    )
except ImportError as e:
    print(f"Warning: Could not import engine modules: {e}")
    print("Some endpoints may not work until engine modules are properly configured")

# Initialize Flask app
app = Flask(__name__)
CORS(app)

# In-memory patient database (replace with real database in production)
patient_database = {}

# ===========================================
# DATABASE MANAGEMENT
# ===========================================

def load_patient_database():
    """Load patient database from file"""
    global patient_database
    try:
        if os.path.exists('patient_data.json'):
            with open('patient_data.json', 'r') as f:
                patient_database = json.load(f)
            print(f"Loaded {len(patient_database)} patients from database")
        else:
            patient_database = {}
            print("No existing patient database found, starting fresh")
    except Exception as e:
        print(f"Error loading patient database: {e}")
        patient_database = {}

def save_patient_database():
    """Save patient database to file"""
    try:
        with open('patient_data.json', 'w') as f:
            json.dump(patient_database, f, indent=2, default=str)
        print(f"Saved {len(patient_database)} patients to database")
    except Exception as e:
        print(f"Error saving patient database: {e}")

# ===========================================
# BASIC ROUTES
# ===========================================

@app.route('/')
def index():
    """Serve the main application page"""
    return render_template('index.html')

@app.route('/list_patients')
def list_patients():
    """Get list of all patients - DEPRECATED, use /api/external/patients"""
    try:
        patients = []
        for name, data in patient_database.items():
            patients.append({
                'name': name,
                'last_updated': data.get('last_updated', datetime.datetime.now().isoformat()),
                'protocol_count': len(data.get('protocols', [])),
                'created_at': data.get('created_at', datetime.datetime.now().isoformat())
            })
        return jsonify(patients)
    except Exception as e:
        return jsonify({"error": f"Failed to list patients: {str(e)}"}), 500

# ===========================================
# EXTERNAL API INTEGRATION ENDPOINTS
# ===========================================

@app.route('/api/external/patients')
def get_external_patients():
    """Fetch patient list from external API"""
    try:
        patients = fetch_patient_list()
        return jsonify({
            "success": True,
            "patients": patients
        })
    except Exception as e:
        print(f"Error fetching external patients: {str(e)}")
        return jsonify({
            "error": f"Failed to fetch patients: {str(e)}"
        }), 500

@app.route('/api/policy/<policy_name>')
def get_policy_json(policy_name):
    """Serve policy JSON files"""
    try:
        policy_path = os.path.join('app', 'relationships', 'policies', f'{policy_name}.json')
        if not os.path.exists(policy_path):
            return jsonify({"error": "Policy not found"}), 404

        with open(policy_path, 'r', encoding='utf-8') as f:
            policy_data = json.load(f)

        return jsonify(policy_data)
    except Exception as e:
        print(f"Error loading policy {policy_name}: {str(e)}")
        return jsonify({"error": str(e)}), 500

@app.route('/api/external/patient/<patient_id>/reports')
def get_patient_reports(patient_id):
    """Fetch patient medical reports from external API"""
    try:
        reports = fetch_patient_reports(patient_id)

        if not reports:
            return jsonify({
                "error": "Patient not found"
            }), 404

        # Transform to baseline format
        enhanced_baseline = transform_reports_to_baseline(reports)

        # Transform to form data for UI
        form_data = transform_baseline_to_form_data(enhanced_baseline)

        return jsonify({
            "success": True,
            "patient_id": patient_id,
            "enhanced_baseline": enhanced_baseline,
            "form_data": form_data,
            "raw_reports": reports
        })

    except Exception as e:
        print(f"Error fetching patient reports: {str(e)}")
        traceback.print_exc()
        return jsonify({
            "error": f"Failed to fetch patient reports: {str(e)}"
        }), 500

@app.route('/api/external/patient/<patient_id>/protocol/check')
def check_patient_protocol(patient_id):
    """Check if protocol exists for patient"""
    try:
        result = check_existing_protocol(patient_id)

        return jsonify({
            "success": True,
            "patient_id": patient_id,
            **result
        })

    except Exception as e:
        print(f"Error checking protocol: {str(e)}")
        traceback.print_exc()
        return jsonify({
            "error": f"Failed to check protocol: {str(e)}"
        }), 500

# ===========================================
# CORE ENGINE ENDPOINTS
# ===========================================

@app.route("/compute_now", methods=['POST'])
def compute_now_endpoint():
    """Process CGM data to get current metabolic state"""
    try:
        data = request.get_json(force=True)
        
        # Validate required CGM data
        if 'cgm_samples' not in data or not data['cgm_samples']:
            return jsonify({"error": "CGM samples are required"}), 400
        
        result = compute_now(
            cgm_samples=data['cgm_samples'],
            meals=data.get('meals'),
            activities=data.get('activities'),
            labs=data.get('labs', {}),
            body=data.get('body', {})
        )
        
        return jsonify(result)
        
    except Exception as e:
        print(f"Error in compute_now: {str(e)}")
        print(traceback.format_exc())
        return jsonify({
            "error": "Failed to process current state",
            "details": str(e)
        }), 500

@app.route("/score", methods=['POST'])
def score_endpoint():
    """Calculate progress scores against targets"""
    try:
        data = request.get_json(force=True)
        
        # Validate required fields
        required_fields = ['now', 'interim', 'final', 'prp']
        for field in required_fields:
            if field not in data:
                return jsonify({"error": f"Missing required field: {field}"}), 400
        
        scoring_policy = get_policy("scoring")
        
        result = compute_scores(
            now=data['now'],
            interim=data['interim'], 
            final=data['final'],
            prp=data['prp'],
            scoring_policy=scoring_policy
        )
        
        return jsonify(result)
        
    except Exception as e:
        print(f"Error in scoring: {str(e)}")
        print(traceback.format_exc())
        return jsonify({
            "error": "Failed to calculate scores",
            "details": str(e)
        }), 500

# ===========================================
# PROTOCOL GENERATION ENDPOINTS
# ===========================================

@app.route("/protocol/generate_complete", methods=['POST'])
def generate_complete_protocol_endpoint():
    """Generate complete patient protocol from enhanced baseline and doctor decisions"""
    try:
        data = request.get_json(force=True)
        
        # Validate required input data
        required_fields = ["enhanced_baseline", "doctor_decisions", "program_config"]
        for field in required_fields:
            if field not in data:
                return jsonify({"error": f"Missing required field: {field}"}), 400
        
        enhanced_baseline = data["enhanced_baseline"]
        doctor_decisions = data["doctor_decisions"]
        program_config = data["program_config"]
        
        patient_name = enhanced_baseline["patient_profile"]["demographics"]["name"]
        patient_id = data.get("patient_id", patient_name.lower().replace(' ', '_'))
        print(f"Generating protocol for: {patient_name} (ID: {patient_id})")
        
        # Generate complete protocol
        complete_protocol = generate_complete_protocol(
            enhanced_baseline, 
            doctor_decisions, 
            program_config
        )
        
        # Generate weekly progression
        weekly_progression = calculate_weekly_progression(
            enhanced_baseline,
            doctor_decisions, 
            program_config,
            complete_protocol.get("macroTargets", {})
        )
        
        # Save to patient database
        if patient_name not in patient_database:
            patient_database[patient_name] = {
                'name': patient_name,
                'created_at': datetime.datetime.now().isoformat(),
                'protocols': [],
                'progress_updates': []
            }
        
        # Save protocol to patient record
        protocol_entry = {
            'generated_at': datetime.datetime.now().isoformat(),
            'enhanced_baseline': enhanced_baseline,
            'protocol': complete_protocol,
            'weekly_progression': weekly_progression,
            'doctor_decisions': doctor_decisions,
            'program_config': program_config
        }
        
        patient_database[patient_name]['protocols'].append(protocol_entry)
        patient_database[patient_name]['last_updated'] = datetime.datetime.now().isoformat()
        save_patient_database()

        # Save individual protocol and weekly targets JSON files
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")

        # Create output directories if they don't exist
        os.makedirs('protocols', exist_ok=True)
        os.makedirs('weekly_targets', exist_ok=True)

        # Save protocol JSON
        protocol_filename = f"protocols/{patient_id}_protocol_{timestamp}.json"
        with open(protocol_filename, 'w', encoding='utf-8') as f:
            json.dump(complete_protocol, f, indent=2, ensure_ascii=False)
        print(f"Protocol JSON saved to: {protocol_filename}")

        # Print entire protocol JSON to terminal
        print("\n" + "="*80)
        print("COMPLETE PROTOCOL JSON")
        print("="*80)
        print(json.dumps(complete_protocol, indent=2, ensure_ascii=False))
        print("="*80 + "\n")

        # Save weekly targets JSON
        weekly_filename = f"weekly_targets/{patient_id}_weekly_targets_{timestamp}.json"
        with open(weekly_filename, 'w', encoding='utf-8') as f:
            json.dump(weekly_progression, f, indent=2, ensure_ascii=False)
        print(f"Weekly targets JSON saved to: {weekly_filename}")

        # POST to external API (two separate calls as per best practice)
        try:
            # Post protocol
            protocol_success = post_protocol_to_external_api(patient_id, complete_protocol)
            if protocol_success:
                print(f"Successfully posted protocol to external API")

            # Post weekly targets
            weekly_success = post_weekly_targets_to_external_api(patient_id, weekly_progression)
            if weekly_success:
                print(f"Successfully posted weekly targets to external API")

        except Exception as e:
            print(f"Warning: Failed to post to external API: {e}")
            # Don't fail the request if external POST fails

        print(f"Protocol saved for patient: {patient_name}")
        
        return jsonify({
            "success": True,
            "protocol": complete_protocol,
            "weekly_progression": weekly_progression,
            "generated_at": datetime.datetime.now().isoformat()
        })
        
    except Exception as e:
        print(f"Error generating complete protocol: {str(e)}")
        print(traceback.format_exc())
        return jsonify({
            "error": "Failed to generate protocol",
            "details": str(e)
        }), 500

@app.route("/protocol/calculate_deficit_recommendations", methods=['POST'])
def calculate_deficit_recommendations():
    """Calculate recommended calorie deficit range for patient"""
    try:
        data = request.get_json(force=True)
        
        if "patient_profile" not in data:
            return jsonify({"error": "Missing patient_profile"}), 400
        
        patient_profile = data["patient_profile"]
        program_duration = data.get("program_duration_weeks", 12)
        
        # Calculate safe deficit range
        min_deficit, max_deficit = calculate_safe_deficit_range(patient_profile)
        
        # Get recommended deficit
        recommendations = get_recommended_deficit(patient_profile, program_duration)
        
        return jsonify({
            "safe_range": {
                "min_deficit": min_deficit,
                "max_deficit": max_deficit
            },
            "recommended": recommendations,
            "calculated_at": datetime.datetime.now().isoformat()
        })
        
    except Exception as e:
        print(f"Error calculating deficit recommendations: {str(e)}")
        return jsonify({
            "error": "Failed to calculate recommendations", 
            "details": str(e)
        }), 500

@app.route("/protocol/analyze_supplements", methods=['POST'])
def analyze_supplements_endpoint():
    """Analyze supplement needs based on patient profile"""
    try:
        data = request.get_json(force=True)
        
        if "enhanced_baseline" not in data:
            return jsonify({"error": "Missing enhanced_baseline"}), 400
        
        enhanced_baseline = data["enhanced_baseline"]
        
        # Analyze supplement needs
        supplement_recommendations = analyze_supplement_needs(enhanced_baseline)
        
        return jsonify({
            "supplement_recommendations": supplement_recommendations,
            "analyzed_at": datetime.datetime.now().isoformat()
        })
        
    except Exception as e:
        print(f"Error analyzing supplements: {str(e)}")
        return jsonify({
            "error": "Failed to analyze supplements",
            "details": str(e)
        }), 500

@app.route("/protocol/validate_baseline", methods=['POST'])
def validate_enhanced_baseline():
    """Validate enhanced baseline data before protocol generation"""
    try:
        data = request.get_json(force=True)
        
        if "enhanced_baseline" not in data:
            return jsonify({"error": "Missing enhanced_baseline"}), 400
        
        enhanced_baseline = data["enhanced_baseline"]
        validation_results = validate_baseline_data(enhanced_baseline)
        
        return jsonify({
            "valid": validation_results["valid"],
            "errors": validation_results.get("errors", []),
            "warnings": validation_results.get("warnings", []),
            "suggestions": validation_results.get("suggestions", [])
        })
        
    except Exception as e:
        print(f"Error validating baseline: {str(e)}")
        return jsonify({
            "error": "Validation failed",
            "details": str(e)
        }), 500

# ===========================================
# PATIENT MANAGEMENT ENDPOINTS
# ===========================================

@app.route("/protocol/patient_protocols/<patient_name>", methods=['GET'])
def get_patient_protocols(patient_name):
    """Get all protocols for a specific patient"""
    try:
        if patient_name not in patient_database:
            return jsonify({"error": "Patient not found"}), 404
        
        patient_data = patient_database[patient_name]
        protocols = patient_data.get('protocols', [])
        progress_updates = patient_data.get('progress_updates', [])
        
        return jsonify({
            "patient_name": patient_name,
            "protocols": protocols,
            "progress_updates": progress_updates,
            "protocol_count": len(protocols),
            "last_update": protocols[-1]['generated_at'] if protocols else None
        })
        
    except Exception as e:
        print(f"Error retrieving patient protocols: {str(e)}")
        return jsonify({
            "error": "Failed to retrieve protocols",
            "details": str(e)
        }), 500

@app.route("/protocol/update_progression", methods=['POST'])
def update_protocol_progression():
    """Update protocol based on current progress and generate new weekly targets"""
    try:
        data = request.get_json(force=True)
        
        required_fields = ["patient_name", "current_week", "current_metrics", "adjustments"]
        for field in required_fields:
            if field not in data:
                return jsonify({"error": f"Missing required field: {field}"}), 400
        
        patient_name = data["patient_name"]
        current_week = data["current_week"]
        current_metrics = data["current_metrics"]
        adjustments = data["adjustments"]
        
        # Check if patient exists
        if patient_name not in patient_database:
            return jsonify({"error": "Patient not found"}), 404
        
        # Get latest protocol
        patient_data = patient_database[patient_name]
        if 'protocols' not in patient_data or not patient_data['protocols']:
            return jsonify({"error": "No protocols found for patient"}), 404
        
        latest_protocol = patient_data['protocols'][-1]
        
        # Apply adjustments to create updated baseline
        updated_baseline = apply_progress_adjustments(
            latest_protocol, 
            current_metrics, 
            adjustments
        )
        
        # Recalculate remaining weeks progression
        remaining_weeks = latest_protocol['program_config']['duration_weeks'] - current_week
        if remaining_weeks > 0:
            updated_progression = calculate_weekly_progression(
                updated_baseline,
                latest_protocol['doctor_decisions'],
                {'duration_weeks': remaining_weeks},
                latest_protocol['protocol'].get('macroTargets', {})
            )
        else:
            updated_progression = None
        
        # Save progress update
        progress_entry = {
            'week': current_week,
            'metrics': current_metrics,
            'adjustments': adjustments,
            'updated_progression': updated_progression,
            'updated_at': datetime.datetime.now().isoformat()
        }
        
        if 'progress_updates' not in patient_data:
            patient_data['progress_updates'] = []
        
        patient_data['progress_updates'].append(progress_entry)
        patient_data['last_updated'] = datetime.datetime.now().isoformat()
        save_patient_database()
        
        return jsonify({
            "success": True,
            "current_week": current_week,
            "updated_progression": updated_progression,
            "next_milestones": get_upcoming_milestones(updated_progression, current_week) if updated_progression else [],
            "updated_at": datetime.datetime.now().isoformat()
        })
        
    except Exception as e:
        print(f"Error updating protocol progression: {str(e)}")
        return jsonify({
            "error": "Failed to update progression",
            "details": str(e)
        }), 500

# ===========================================
# PROTOCOL SAVE/PUBLISH ENDPOINTS
# ===========================================

@app.route("/api/patients/<patient_id>/protocol/save", methods=['POST'])
def save_patient_protocol(patient_id):
    """
    Publish protocol for a patient to external API
    External API handles all storage
    """
    try:
        data = request.get_json(force=True)
        protocol_data = data.get('protocol')

        if not protocol_data:
            return jsonify({
                "success": False,
                "error": "Protocol data is required"
            }), 400

        # Post to external API (external API handles storage)
        success = post_protocol_to_external_api(patient_id, protocol_data)

        if not success:
            return jsonify({
                "success": False,
                "error": "Failed to publish protocol to external API"
            }), 500

        print(f"Protocol published to external API for patient: {patient_id}")

        return jsonify({
            "success": True,
            "message": "Protocol published successfully"
        })

    except Exception as e:
        print(f"Error publishing protocol: {str(e)}")
        traceback.print_exc()
        return jsonify({
            "success": False,
            "error": "Failed to publish protocol",
            "details": str(e)
        }), 500

@app.route("/api/patient/<patient_id>/weekly-targets/save", methods=['POST'])
def save_patient_weekly_targets(patient_id):
    """
    Publish weekly targets for a patient to external API
    External API handles all storage
    """
    try:
        data = request.get_json(force=True)
        weekly_data = data.get('weekly_targets')

        if not weekly_data:
            return jsonify({
                "success": False,
                "error": "Weekly targets data is required"
            }), 400

        # Post to external API (external API handles storage)
        success = post_weekly_targets_to_external_api(patient_id, weekly_data)

        if not success:
            return jsonify({
                "success": False,
                "error": "Failed to publish weekly targets to external API"
            }), 500

        print(f"Weekly targets published to external API for patient: {patient_id}")

        return jsonify({
            "success": True,
            "message": "Weekly targets published successfully"
        })

    except Exception as e:
        print(f"Error publishing weekly targets: {str(e)}")
        traceback.print_exc()
        return jsonify({
            "success": False,
            "error": "Failed to publish weekly targets",
            "details": str(e)
        }), 500

# ===========================================
# STATISTICS AND MONITORING
# ===========================================

@app.route("/protocol/statistics", methods=['GET'])
def get_protocol_statistics():
    """Get statistics about protocol generation and patient progress"""
    try:
        total_patients = len(patient_database)
        patients_with_protocols = sum(1 for p in patient_database.values() if p.get('protocols'))
        total_protocols = sum(len(p.get('protocols', [])) for p in patient_database.values())
        
        # Calculate average progress metrics if available
        recent_protocols = []
        for patient_data in patient_database.values():
            if patient_data.get('protocols'):
                recent_protocols.extend(patient_data['protocols'][-3:])  # Last 3 protocols per patient
        
        stats = {
            'total_patients': total_patients,
            'patients_with_protocols': patients_with_protocols,
            'total_protocols_generated': total_protocols,
            'protocol_generation_rate': f"{patients_with_protocols}/{total_patients}" if total_patients > 0 else "0/0",
            'recent_protocol_count': len(recent_protocols),
            'server_status': 'operational',
            'last_updated': datetime.datetime.now().isoformat()
        }
        
        return jsonify(stats)
        
    except Exception as e:
        return jsonify({
            'error': 'Failed to generate statistics',
            'details': str(e)
        }), 500

# ===========================================
# HELPER FUNCTIONS
# ===========================================

def apply_progress_adjustments(latest_protocol, current_metrics, adjustments):
    """Apply progress adjustments to create updated baseline"""
    import copy
    
    # Start with original baseline (deep copy to avoid modifying original)
    updated_baseline = copy.deepcopy(latest_protocol['enhanced_baseline'])
    
    # Update demographics with current metrics
    if 'weight_kg' in current_metrics and current_metrics['weight_kg']:
        updated_baseline['patient_profile']['demographics']['weight_kg'] = current_metrics['weight_kg']
    
    # Update metabolic baseline with current metrics
    metabolic_updates = ['hba1c_pct', 'fbg_mgdl', 'bodyfat_pct']
    for metric in metabolic_updates:
        if metric in current_metrics and current_metrics[metric]:
            updated_baseline['patient_profile']['metabolic_baseline'][metric] = current_metrics[metric]
    
    # Apply any doctor adjustments
    if 'calorie_deficit_adjustment' in adjustments:
        if 'doctor_decisions' not in updated_baseline:
            updated_baseline['doctor_decisions'] = latest_protocol['doctor_decisions'].copy()
        updated_baseline['doctor_decisions']['calorie_deficit_kcal'] += adjustments['calorie_deficit_adjustment']
    
    return updated_baseline

def get_upcoming_milestones(progression_data, current_week):
    """Get upcoming milestones from progression data"""
    if not progression_data or 'weekly_targets' not in progression_data:
        return []
    
    upcoming_milestones = []
    
    for week_data in progression_data['weekly_targets']:
        if week_data['week'] > current_week:
            if week_data.get('milestones'):
                for milestone in week_data['milestones']:
                    upcoming_milestones.append({
                        'week': week_data['week'],
                        'milestone': milestone
                    })
    
    return upcoming_milestones[:3]  # Return next 3 milestones

def validate_baseline_data(enhanced_baseline):
    """Validate enhanced baseline data structure and values"""
    validation_results = {"valid": True, "errors": [], "warnings": [], "suggestions": []}
    
    try:
        # Check required structure
        required_sections = ['patient_profile']
        for section in required_sections:
            if section not in enhanced_baseline:
                validation_results["errors"].append(f"Missing required section: {section}")
                validation_results["valid"] = False
        
        if not validation_results["valid"]:
            return validation_results
        
        patient_profile = enhanced_baseline['patient_profile']
        
        # Check demographics
        if 'demographics' not in patient_profile:
            validation_results["errors"].append("Missing demographics section")
            validation_results["valid"] = False
        else:
            demographics = patient_profile['demographics']
            required_demo_fields = ['name', 'age', 'weight_kg']
            for field in required_demo_fields:
                if field not in demographics:
                    validation_results["errors"].append(f"Missing demographic field: {field}")
                    validation_results["valid"] = False
        
        # Check metabolic baseline
        if 'metabolic_baseline' not in patient_profile:
            validation_results["errors"].append("Missing metabolic_baseline section")
            validation_results["valid"] = False
        else:
            metabolic = patient_profile['metabolic_baseline']
            required_metabolic_fields = ['hba1c_pct']
            for field in required_metabolic_fields:
                if field not in metabolic:
                    validation_results["errors"].append(f"Missing metabolic field: {field}")
                    validation_results["valid"] = False
            
            # Validate HbA1c range
            if 'hba1c_pct' in metabolic:
                hba1c = metabolic['hba1c_pct']
                if hba1c < 4.0 or hba1c > 15.0:
                    validation_results["warnings"].append(f"HbA1c {hba1c}% is outside typical range (4-15%)")
        
        # Check lifestyle constraints
        if 'lifestyle_constraints' not in patient_profile:
            validation_results["warnings"].append("Missing lifestyle_constraints - using defaults")
        
        # Add suggestions for missing optional fields
        if 'bodyfat_pct' not in patient_profile.get('metabolic_baseline', {}):
            validation_results["suggestions"].append("Body fat percentage not provided - will use estimated value")
        
        if 'cultural_food_preference' not in patient_profile.get('lifestyle_constraints', {}):
            validation_results["suggestions"].append("Cultural food preference not specified - using default options")
        
    except Exception as e:
        validation_results["errors"].append(f"Validation error: {str(e)}")
        validation_results["valid"] = False
    
    return validation_results

# ===========================================
# ERROR HANDLERS
# ===========================================

@app.errorhandler(404)
def handle_404(e):
    return jsonify({
        "error": "Endpoint not found", 
        "available_endpoints": [
            "GET /",
            "GET /list_patients",
            "POST /compute_now",
            "POST /score",
            "POST /protocol/generate_complete",
            "POST /protocol/calculate_deficit_recommendations", 
            "POST /protocol/analyze_supplements",
            "POST /protocol/validate_baseline",
            "POST /protocol/update_progression",
            "GET /protocol/patient_protocols/<patient_name>",
            "GET /protocol/statistics"
        ]
    }), 404

@app.errorhandler(500)
def handle_500(e):
    return jsonify({
        "error": "Internal server error", 
        "message": "Please check server logs for details"
    }), 500

@app.errorhandler(Exception)
def handle_exception(e):
    print(f"Unhandled exception: {str(e)}")
    print(traceback.format_exc())
    return jsonify({
        "error": "Unexpected error occurred",
        "details": str(e)
    }), 500

# ===========================================
# APPLICATION STARTUP
# ===========================================

def initialize_app():
    """Initialize the application with necessary setup"""
    print("Initializing Metabolic Twin Server...")
    
    # Load existing patient data
    load_patient_database()
    
    # Verify critical directories exist
    critical_dirs = [
        'app/engines',
        'app/relationships/bands',
        'app/relationships/curves', 
        'app/relationships/formulas',
        'app/relationships/policies',
        'app/relationships/targets',
        'static',
        'templates'
    ]
    
    for dir_path in critical_dirs:
        if not os.path.exists(dir_path):
            print(f"Warning: Directory {dir_path} does not exist")
    
    print("Server initialization complete")

if __name__ == '__main__':
    initialize_app()
    print("Starting Metabolic Twin Server on http://localhost:5000")
    app.run(debug=True, host='0.0.0.0', port=5000)
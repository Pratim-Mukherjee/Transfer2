// =============================================================================
// Main Application Logic
// =============================================================================

document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('stagingForm');
    const calculateBtn = document.getElementById('calculateBtn');
    const emptyState = document.getElementById('emptyState');
    const resultsContent = document.getElementById('resultsContent');
    const profileSelect = document.getElementById('profileSelect');

    // Load profiles
    loadProfiles();

    form.addEventListener('submit', async (e) => {
        e.preventDefault();
        await calculateStaging();
    });

    profileSelect.addEventListener('change', (e) => {
        if (e.target.value) {
            loadProfileData(e.target.value);
        }
    });
});

let loadedProfiles = {};

async function loadProfiles() {
    try {
        const response = await fetch('/profiles');
        const profiles = await response.json();
        loadedProfiles = profiles;

        const select = document.getElementById('profileSelect');
        for (const [key, profile] of Object.entries(profiles)) {
            const option = document.createElement('option');
            option.value = key;
            option.textContent = profile.name;
            select.appendChild(option);
        }
    } catch (error) {
        console.error('Error loading profiles:', error);
    }
}

function loadProfileData(profileKey) {
    const profile = loadedProfiles[profileKey];
    if (!profile) return;

    // Update description
    document.getElementById('profileDesc').textContent = profile.description;

    // Fill form
    const data = profile.data;
    for (const [key, value] of Object.entries(data)) {
        const input = document.getElementById(key);
        if (input) {
            input.value = value;
        }
    }

    // Auto calculate
    calculateStaging();
}

async function calculateStaging() {
    const calculateBtn = document.getElementById('calculateBtn');
    const emptyState = document.getElementById('emptyState');
    const resultsContent = document.getElementById('resultsContent');

    // Show loading state
    calculateBtn.textContent = 'Calculating...';
    calculateBtn.classList.add('loading');
    calculateBtn.disabled = true;

    try {
        // Gather form data
        const formData = gatherFormData();

        // Call API
        const response = await fetch('/calculate-staging', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(formData)
        });

        if (!response.ok) {
            throw new Error(`API error: ${response.status}`);
        }

        const result = await response.json();

        // Display results
        displayResults(result);

        // Show results panel
        emptyState.style.display = 'none';
        resultsContent.style.display = 'block';

    } catch (error) {
        console.error('Error calculating staging:', error);
        alert('Error calculating staging. Please check the console for details.');
    } finally {
        // Reset button
        calculateBtn.textContent = 'Calculate Staging';
        calculateBtn.classList.remove('loading');
        calculateBtn.disabled = false;
    }
}

function gatherFormData() {
    const form = document.getElementById('stagingForm');
    const formData = new FormData(form);
    const data = {};

    for (const [key, value] of formData.entries()) {
        if (value === '' || value === null) {
            data[key] = null;
        } else if (key === 'sex') {
            data[key] = value;
        } else if (key === 'urine_glucose_grade') {
            data[key] = parseInt(value, 10);
        } else {
            data[key] = parseFloat(value);
        }
    }

    // Add any missing optional fields as null
    const allFields = [
        'sex', 'fasting_glucose_mgdl', 'hba1c_pct', 'fasting_insulin_microU',
        'c_peptide_ngml', 'lipase_u', 'lipase_uln', 'amylase_u', 'amylase_uln',
        'magnesium_mgdl', 'vitamin_b12_pgml', 'homocysteine_umoll', 'vitamin_d_ngml',
        'ferritin_ngml', 'triglycerides_mgdl', 'hdl_mgdl', 'ldl_mgdl',
        'creatinine_mgdl', 'egfr_ml_min_173', 'alt_u', 'ast_u', 'ggt_u',
        'uacr_mg_per_g', 'urine_glucose_grade', 'tsh_miul', 'cortisol_am_ugdl',
        'waist_cm', 'height_cm'
    ];

    allFields.forEach(field => {
        if (!(field in data)) {
            data[field] = null;
        }
    });

    return data;
}

function displayResults(result) {
    const { scores, derived, modifiers, ambiguity } = result;

    // Hero Metric - Reversibility Class
    displayHeroMetric(scores.reversibility_class.final_after_modifiers);

    // IR Layer
    displayIRLayer(scores.ir_score, scores.ir_grade, derived.homa_ir, derived.whtr);

    // Chronicity Band
    displayChronicity(derived.chronicity_band);

    // Beta Cell Layer
    displayBetaLayer(scores.beta_grade, result.beta_cell_pattern, scores.mismatch_score);

    // PSS Layer
    displayPSSLayer(scores.pss);

    // Modifiers
    displayModifiers(modifiers);

    // Prognosis
    displayPrognosis(result.prognosis);

    // Ambiguity
    displayAmbiguity(ambiguity);
}

function displayPrognosis(prognosis) {
    const windowEl = document.getElementById('prognosisWindow');
    const textEl = document.getElementById('prognosisText');
    const warningsContainer = document.getElementById('warningsContainer');
    const warningsList = document.getElementById('prognosisWarnings');

    // 1. Window Badge
    const windowVal = prognosis.window || 'UNKNOWN';
    windowEl.textContent = `${windowVal} WINDOW`;

    // Style based on window
    if (windowVal === 'URGENT') {
        windowEl.style.background = '#FEE2E2';
        windowEl.style.color = '#DC2626';
        windowEl.style.border = '1px solid #FECACA';
    } else if (windowVal === 'MODERATE') {
        windowEl.style.background = '#FEF3C7';
        windowEl.style.color = '#D97706';
        windowEl.style.border = '1px solid #FDE68A';
    } else if (windowVal === 'STABLE') {
        windowEl.style.background = '#D1FAE5';
        windowEl.style.color = '#059669';
        windowEl.style.border = '1px solid #A7F3D0';
    } else {
        windowEl.style.background = '#F3F4F6';
        windowEl.style.color = '#6B7280';
        windowEl.style.border = '1px solid #E5E7EB';
    }

    // 2. Primary Reason
    textEl.textContent = prognosis.primary_reason;

    // 3. Warnings
    if (prognosis.warnings && prognosis.warnings.length > 0) {
        warningsContainer.style.display = 'block';
        warningsList.innerHTML = '';
        prognosis.warnings.forEach(warning => {
            const li = document.createElement('li');
            li.textContent = warning;
            li.style.marginBottom = '6px';
            warningsList.appendChild(li);
        });
    } else {
        warningsContainer.style.display = 'none';
    }
}

function displayHeroMetric(finalClass) {
    const heroValue = document.getElementById('heroValue');
    const heroInterpretation = document.getElementById('heroInterpretation');

    const interpretations = {
        1: 'High Reversal Potential',
        2: 'Good Potential with Effort',
        3: 'Possible but More Difficult',
        4: 'Focus on Control & Protection'
    };

    heroValue.textContent = `Class ${finalClass}`;
    heroInterpretation.textContent = interpretations[finalClass] || 'Unknown';

    // Draw hero gauge
    drawHeroGauge(finalClass);
}

function displayIRLayer(irScore, irGrade, homaIR, whtr) {
    // Generate contextual message based on IR score and grade
    const contextualMessage = generateIRContextualMessage(irScore, irGrade, homaIR, whtr);

    // Get or create contextual message element
    let layerContent = document.querySelector('.layer-card .layer-content');
    if (layerContent) {
        // Remove existing contextual message if any
        const existingMsg = layerContent.querySelector('.contextual-message');
        if (existingMsg) existingMsg.remove();

        // Add new contextual message at the top
        const msgDiv = document.createElement('div');
        msgDiv.className = `contextual-message ${contextualMessage.severity}`;
        msgDiv.textContent = contextualMessage.text;
        layerContent.insertBefore(msgDiv, layerContent.firstChild);
    }

    document.getElementById('irScore').textContent = `${irScore} / 10`;

    const gradeLabels = ['None', 'Early IR', 'Moderate IR', 'Marked IR', 'Severe IR'];
    const gradeBadge = document.getElementById('irGrade');
    gradeBadge.textContent = `Grade ${irGrade} - ${gradeLabels[irGrade]}`;

    // Color code the badge
    if (irGrade <= 1) gradeBadge.style.background = '#D1FAE5';
    else if (irGrade === 2) gradeBadge.style.background = '#FEF3C7';
    else if (irGrade === 3) gradeBadge.style.background = '#FFEDD5';
    else gradeBadge.style.background = '#FEE2E2';

    // Replace progress bar with horizontal scale gauge
    const progressBarContainer = document.querySelector('#irProgressFill').parentElement;
    if (progressBarContainer) {
        progressBarContainer.innerHTML = '';
        const scaleGauge = createHorizontalScaleGauge(irScore, 10);
        progressBarContainer.appendChild(scaleGauge);
    }

    // Derived metrics
    document.getElementById('homaIR').textContent = homaIR !== null ? homaIR.toFixed(2) : 'N/A';
    document.getElementById('whtr').textContent = whtr !== null ? whtr.toFixed(3) : 'N/A';
}

function generateIRContextualMessage(irScore, irGrade, homaIR, whtr) {
    const gradeLabels = ['None', 'Early IR', 'Moderate IR', 'Marked IR', 'Severe IR'];
    const gradeName = gradeLabels[irGrade];

    let message = `Your IR score of ${irScore}/10 indicates `;
    let severity = 'severity-low';

    if (irScore < 2) {
        message += "excellent insulin sensitivity. Your cells respond well to insulin's signals.";
        severity = 'severity-low';
    } else if (irScore < 4) {
        message += `${gradeName} - you're showing early signs of insulin resistance. This is the ideal time to intervene with lifestyle changes.`;
        severity = 'severity-low';
    } else if (irScore < 6) {
        message += `${gradeName} - your cells require significantly higher insulin levels to process glucose. Dietary changes and metabolic interventions are important now.`;
        severity = 'severity-moderate';
    } else if (irScore < 8) {
        message += `${gradeName} - you have substantial insulin resistance. Your pancreas is working hard to compensate, but metabolic stress is high.`;
        severity = 'severity-high';
    } else {
        message += `${gradeName} - you have severe insulin resistance. Your cells are highly resistant to insulin's effects, placing extreme strain on your metabolic system.`;
        severity = 'severity-high';
    }

    // Add context about HOMA-IR or WHR if available
    if (homaIR !== null && homaIR > 5) {
        message += ` Your HOMA-IR of ${homaIR.toFixed(1)} confirms significant metabolic dysfunction`;
    }

    return { text: message, severity };
}

function createHorizontalScaleGauge(value, maxValue) {
    const container = document.createElement('div');
    container.className = 'scale-gauge-container';

    // Create the gauge bar
    const gauge = document.createElement('div');
    gauge.className = 'scale-gauge';

    // Create the marker showing current position
    const marker = document.createElement('div');
    marker.className = 'scale-marker';
    const percentage = (value / maxValue) * 100;
    marker.style.left = `${percentage}%`;
    gauge.appendChild(marker);

    // Create labels
    const labels = document.createElement('div');
    labels.className = 'scale-labels';
    labels.innerHTML = `
        <span class="scale-label ${value < 2 ? 'active' : ''}">0-2<br>Healthy</span>
        <span class="scale-label ${value >= 2 && value < 4 ? 'active' : ''}">2-4<br>Early</span>
        <span class="scale-label ${value >= 4 && value < 6 ? 'active' : ''}">4-6<br>Moderate</span>
        <span class="scale-label ${value >= 6 && value < 8 ? 'active' : ''}">6-8<br>Marked</span>
        <span class="scale-label ${value >= 8 ? 'active' : ''}">8-10<br>Severe</span>
    `;

    // Create value display
    const valueDisplay = document.createElement('div');
    valueDisplay.className = 'scale-value-display';
    valueDisplay.textContent = `Current: ${value.toFixed(1)}`;

    container.appendChild(gauge);
    container.appendChild(labels);
    container.appendChild(valueDisplay);

    return container;
}

function displayChronicity(band) {
    const el = document.getElementById('chronicityBand');
    if (el) {
        el.textContent = band ? band.charAt(0).toUpperCase() + band.slice(1) : 'Unknown';
        // Optional: Color coding
        if (band === 'long') el.style.color = '#FF3B30';
        else if (band === 'medium') el.style.color = '#FF9500';
        else if (band === 'short') el.style.color = '#34C759';
    }
}

function displayBetaLayer(betaGrade, betaPattern, mismatchScore) {
    // Generate contextual message
    const contextualMessage = generateBetaContextualMessage(betaGrade, betaPattern, mismatchScore);

    // Get or create contextual message element
    let layerContent = document.querySelectorAll('.layer-card .layer-content')[1]; // Beta is second layer
    if (layerContent) {
        const existingMsg = layerContent.querySelector('.contextual-message');
        if (existingMsg) existingMsg.remove();

        const msgDiv = document.createElement('div');
        msgDiv.className = `contextual-message ${contextualMessage.severity}`;
        msgDiv.textContent = contextualMessage.text;
        layerContent.insertBefore(msgDiv, layerContent.firstChild);
    }

    const betaBadge = document.getElementById('betaBadge');
    const betaLabel = document.getElementById('betaLabel');
    const betaPatternEl = document.getElementById('betaPattern');
    const mismatchScoreEl = document.getElementById('mismatchScore');
    const mismatchFill = document.getElementById('mismatchFill');

    const gradeInfo = {
        'A': { label: 'Excellent Reserve', color: '#34C759' },
        'B1': { label: 'Good Reserve', color: '#30D158' },
        'B2': { label: 'Moderate Reserve', color: '#FF9500' },
        'C': { label: 'Low Reserve', color: '#FF9500' },
        'D': { label: 'Very Low Reserve', color: '#FF3B30' },
        'UNKNOWN': { label: 'Unknown', color: '#9CA3AF' }
    };

    const info = gradeInfo[betaGrade] || gradeInfo['UNKNOWN'];
    betaBadge.textContent = betaGrade;
    betaBadge.style.background = info.color;
    betaLabel.textContent = info.label;

    // Add horizontal beta grade scale
    const betaBadgeContainer = betaBadge.parentElement;
    let gradeScale = betaBadgeContainer.querySelector('.beta-grade-scale');
    if (!gradeScale) {
        gradeScale = createBetaGradeScale(betaGrade);
        betaBadgeContainer.appendChild(gradeScale);
    } else {
        // Update existing scale
        gradeScale.replaceWith(createBetaGradeScale(betaGrade));
    }

    // Pattern
    if (betaPatternEl && betaPattern) {
        const mode = betaPattern.mode;
        const modeLabels = {
            'hypersecretion': 'Hypersecretion (Overdrive)',
            'compensated': 'Compensated',
            'dedifferentiation': 'Dedifferentiation (Declining)',
            'failure': 'Beta Cell Failure',
            'indeterminate': 'Indeterminate'
        };
        betaPatternEl.textContent = modeLabels[mode] || mode;

        // Color for pattern
        if (mode === 'failure') betaPatternEl.style.color = '#FF3B30';
        else if (mode === 'dedifferentiation') betaPatternEl.style.color = '#FF9500';
        else if (mode === 'hypersecretion') betaPatternEl.style.color = '#AF52DE';
        else betaPatternEl.style.color = 'var(--primary)';
    }

    // Mismatch
    if (mismatchScoreEl && mismatchFill) {
        mismatchScoreEl.textContent = `${mismatchScore} / 4`;
        const pct = (mismatchScore / 4) * 100;
        mismatchFill.style.width = `${pct}%`;

        if (mismatchScore >= 3) mismatchFill.style.background = '#FF3B30';
        else if (mismatchScore >= 2) mismatchFill.style.background = '#FF9500';
        else mismatchFill.style.background = '#34C759';
    }
}

function generateBetaContextualMessage(betaGrade, betaPattern, mismatchScore) {
    let message = '';
    let severity = 'severity-low';

    if (betaGrade === 'A') {
        message = 'Grade A - Excellent pancreatic insulin reserve. Your beta cells are healthy and producing insulin effectively. You have strong metabolic resilience.';
        severity = 'severity-low';
    } else if (betaGrade === 'B1') {
        message = 'Grade B1 - Good pancreatic reserve. Your beta cells are functioning well under current demands, though showing some signs of stress.';
        severity = 'severity-low';
    } else if (betaGrade === 'B2') {
        message = 'Grade B2 - Moderate reserve. Your pancreas is under strain and struggling to meet demands. Early intervention is important to prevent further decline.';
        severity = 'severity-moderate';
    } else if (betaGrade === 'C') {
        message = 'Grade C - Low reserve. Your pancreatic function is significantly compromised. You have limited ability to tolerate carbohydrates safely.';
        severity = 'severity-high';
    } else if (betaGrade === 'D') {
        message = 'Grade D - Very low reserve. Critical beta cell depletion. Your pancreas has minimal insulin-producing capacity remaining. Strict glycemic control is essential.';
        severity = 'severity-high';
    } else {
        message = 'Beta cell reserve cannot be fully assessed with available data.';
        severity = 'severity-moderate';
    }

    // Add pattern context if available
    if (betaPattern && betaPattern.mode === 'failure') {
        message += ' Pattern indicates beta cell failure - your pancreas can no longer compensate for high glucose.';
    } else if (betaPattern && betaPattern.mode === 'hypersecretion') {
        message += ' Your pancreas is in overdrive mode, pumping out excess insulin to overcome resistance.';
    }

    return { text: message, severity };
}

function createBetaGradeScale(currentGrade) {
    const scale = document.createElement('div');
    scale.className = 'beta-grade-scale';

    const grades = ['A', 'B1', 'B2', 'C', 'D'];
    grades.forEach(grade => {
        const segment = document.createElement('div');
        segment.className = `beta-grade-segment grade-${grade.toLowerCase()}`;
        if (grade === currentGrade) {
            segment.classList.add('active');
        }
        segment.textContent = grade;
        scale.appendChild(segment);
    });

    return scale;
}

function displayPSSLayer(pss) {
    // Generate contextual message
    const contextualMessage = generatePSSContextualMessage(pss);

    let layerContent = document.querySelectorAll('.layer-card .layer-content')[2]; // PSS is third layer
    if (layerContent) {
        const existingMsg = layerContent.querySelector('.contextual-message');
        if (existingMsg) existingMsg.remove();

        const msgDiv = document.createElement('div');
        msgDiv.className = `contextual-message ${contextualMessage.severity}`;
        msgDiv.textContent = contextualMessage.text;
        layerContent.insertBefore(msgDiv, layerContent.firstChild);
    }

    const pssValue = document.getElementById('pssValue');
    const pssLabel = document.getElementById('pssLabel');

    pssValue.textContent = pss;

    const labels = [
        'No Stress',
        'Minimal Stress',
        'Mild Stress',
        'Moderate Stress',
        'Marked Stress',
        'High Stress',
        'Severe Stress'
    ];

    pssLabel.textContent = labels[pss] || 'Unknown';

    // Draw PSS gauge
    drawPSSGauge(pss);
}

function generatePSSContextualMessage(pss) {
    let message = '';
    let severity = 'severity-low';

    if (pss === 0) {
        message = 'PSS 0/6 - No pancreatic stress detected. Your pancreatic enzymes are within normal limits, indicating healthy organ function.';
        severity = 'severity-low';
    } else if (pss === 1) {
        message = 'PSS 1/6 - Minimal stress. Very slight elevation in pancreatic enzymes, likely subclinical and not immediately concerning.';
        severity = 'severity-low';
    } else if (pss === 2) {
        message = 'PSS 2/6 - Mild stress. Your pancreas is experiencing some strain, possibly from dietary factors or metabolic load.';
        severity = 'severity-low';
    } else if (pss === 3) {
        message = 'PSS 3/6 - Moderate stress. Notable pancreatic inflammation or strain is present. Reducing triglycerides and avoiding alcohol is important.';
        severity = 'severity-moderate';
    } else if (pss === 4) {
        message = 'PSS 4/6 - Marked stress. Significant pancreatic strain detected. Your pancreas is actively stressed, which can accelerate beta cell damage.';
        severity = 'severity-high';
    } else if (pss === 5) {
        message = 'PSS 5/6 - High stress. Severe pancreatic enzyme elevation indicates substantial organ inflammation. Immediate lifestyle intervention required.';
        severity = 'severity-high';
    } else if (pss >= 6) {
        message = 'PSS 6/6 - Severe stress. Critical pancreatic dysfunction. This level of stress can lead to permanent organ damage if not addressed urgently.';
        severity = 'severity-high';
    }

    return { text: message, severity };
}

function displayModifiers(modifiers) {
    const container = document.getElementById('modifiersContainer');
    const noModifiers = document.getElementById('noModifiers');

    const modifierDetails = [];

    if (modifiers.thyroid_penalty_applied) {
        modifierDetails.push({
            name: 'Hypothyroid Impact',
            impact: '+1 Class',
            explanation: 'Elevated TSH indicates hypothyroidism, which slows metabolism and makes weight loss and glucose control more difficult.'
        });
    }
    if (modifiers.cortisol_penalty_applied) {
        modifierDetails.push({
            name: 'High Cortisol Impact',
            impact: '+1 Class',
            explanation: 'Elevated morning cortisol drives glucose production and worsens insulin resistance, counteracting treatment efforts.'
        });
    }
    if (modifiers.uacr_penalty_applied) {
        modifierDetails.push({
            name: 'Kidney Stress (UACR)',
            impact: '+1 Class',
            explanation: 'Elevated urinary albumin indicates kidney damage from sustained high glucose, limiting aggressive interventions.'
        });
    }
    if (modifiers.ferritin_cap_applied) {
        modifierDetails.push({
            name: 'Extreme Ferritin Load',
            impact: '+1 Class',
            explanation: 'Very high ferritin suggests iron overload or chronic inflammation, causing oxidative stress to the liver and pancreas.'
        });
    }
    if (modifiers.hyperthyroid_flag) {
        modifierDetails.push({
            name: '⚠️ Hyperthyroid Pattern',
            impact: 'Warning',
            explanation: 'Very low TSH may indicate hyperthyroidism, which accelerates metabolism but can worsen glucose control.'
        });
    }

    if (modifierDetails.length === 0) {
        noModifiers.style.display = 'block';
        container.querySelectorAll('.modifier-detail').forEach(el => el.remove());
        container.querySelectorAll('.modifier-badge').forEach(el => el.remove());
    } else {
        noModifiers.style.display = 'none';
        container.querySelectorAll('.modifier-detail').forEach(el => el.remove());
        container.querySelectorAll('.modifier-badge').forEach(el => el.remove());

        modifierDetails.forEach(mod => {
            const detail = document.createElement('div');
            detail.className = 'modifier-detail';

            detail.innerHTML = `
                <div class="modifier-detail-header">
                    <span class="modifier-name">${mod.name}</span>
                    <span class="modifier-impact">${mod.impact}</span>
                </div>
                <div class="modifier-explanation">${mod.explanation}</div>
            `;

            container.appendChild(detail);
        });
    }
}

function displayAmbiguity(ambiguity) {
    const alert = document.getElementById('ambiguityAlert');
    const level = document.getElementById('ambiguityLevel');
    const missingFields = document.getElementById('missingFields');

    level.textContent = `${ambiguity.level} Ambiguity`;

    // Set color based on level
    alert.className = 'ambiguity-alert';
    if (ambiguity.level === 'HIGH') {
        alert.classList.add('high');
    } else if (ambiguity.level === 'LOW') {
        alert.classList.add('low');
    }

    // Display missing fields
    if (ambiguity.missing_fields_for_low_ambiguity.length > 0) {
        const fieldsList = ambiguity.missing_fields_for_low_ambiguity
            .map(f => formatFieldName(f))
            .join(', ');

        missingFields.innerHTML = `
            <strong>Missing for complete assessment:</strong><br>
            ${fieldsList}
        `;
    } else {
        missingFields.innerHTML = '<strong>All key fields present!</strong>';
    }
}

function formatFieldName(field) {
    // Convert snake_case to readable format
    return field
        .replace(/_/g, ' ')
        .replace(/\b\w/g, l => l.toUpperCase())
        .replace(/Mgdl/gi, '(mg/dL)')
        .replace(/Pgml/gi, '(pg/mL)')
        .replace(/Umoll/gi, '(µmol/L)')
        .replace(/Ngml/gi, '(ng/mL)')
        .replace(/Miul/gi, '(mIU/L)')
        .replace(/Ugdl/gi, '(µg/dL)')
        .replace(/Ml Min 173/gi, '(ml/min/1.73m²)')
        .replace(/Mg Per G/gi, '(mg/g)');
}

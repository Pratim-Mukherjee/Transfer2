// =============================================================================
// Visualizations - SVG Gauges and Charts
// =============================================================================

function drawHeroGauge(value) {
    const svg = document.getElementById('heroGauge');
    svg.innerHTML = ''; // Clear previous

    const width = 200;
    const height = 120;
    const centerX = width / 2;
    const centerY = height - 20;
    const radius = 80;
    const strokeWidth = 16;

    // Create SVG elements
    const svgNS = 'http://www.w3.org/2000/svg';

    // Background arc
    const bgArc = createArc(centerX, centerY, radius, 180, 0, strokeWidth, '#E5E7EB');
    svg.appendChild(bgArc);

    // Colored segments
    const colors = ['#34C759', '#30D158', '#FF9500', '#FF3B30'];
    const segmentAngle = 180 / 4;

    for (let i = 0; i < 4; i++) {
        const startAngle = 180 - (i * segmentAngle);
        const endAngle = 180 - ((i + 1) * segmentAngle);
        const arc = createArc(centerX, centerY, radius, startAngle, endAngle, strokeWidth - 4, colors[i]);
        arc.style.opacity = '0.3';
        svg.appendChild(arc);
    }

    // Highlight active segment
    const activeIndex = value - 1;
    if (activeIndex >= 0 && activeIndex < 4) {
        const startAngle = 180 - (activeIndex * segmentAngle);
        const endAngle = 180 - ((activeIndex + 1) * segmentAngle);
        const activeArc = createArc(centerX, centerY, radius, startAngle, endAngle, strokeWidth - 4, colors[activeIndex]);
        svg.appendChild(activeArc);
    }

    // Add marker needle
    const needleAngle = 180 - (activeIndex * segmentAngle) - (segmentAngle / 2);
    const needle = createNeedle(centerX, centerY, radius - 10, needleAngle);
    svg.appendChild(needle);

    // Add labels
    for (let i = 1; i <= 4; i++) {
        const angle = 180 - ((i - 0.5) * segmentAngle);
        const labelRadius = radius + 20;
        const x = centerX + labelRadius * Math.cos(angle * Math.PI / 180);
        const y = centerY - labelRadius * Math.sin(angle * Math.PI / 180);

        const text = document.createElementNS(svgNS, 'text');
        text.setAttribute('x', x);
        text.setAttribute('y', y);
        text.setAttribute('text-anchor', 'middle');
        text.setAttribute('font-size', '12');
        text.setAttribute('font-weight', '600');
        text.setAttribute('fill', i === value ? colors[i - 1] : '#9CA3AF');
        text.textContent = i;
        svg.appendChild(text);
    }
}

function drawPSSGauge(value) {
    const svg = document.getElementById('pssGauge');
    svg.innerHTML = '';

    const width = 120;
    const height = 120;
    const centerX = width / 2;
    const centerY = height / 2;
    const radius = 50;
    const strokeWidth = 10;

    const svgNS = 'http://www.w3.org/2000/svg';

    // Background circle
    const bgCircle = document.createElementNS(svgNS, 'circle');
    bgCircle.setAttribute('cx', centerX);
    bgCircle.setAttribute('cy', centerY);
    bgCircle.setAttribute('r', radius);
    bgCircle.setAttribute('fill', 'none');
    bgCircle.setAttribute('stroke', '#E5E7EB');
    bgCircle.setAttribute('stroke-width', strokeWidth);
    svg.appendChild(bgCircle);

    // Progress circle
    const percentage = value / 6;
    const circumference = 2 * Math.PI * radius;
    const dashOffset = circumference * (1 - percentage);

    const progressCircle = document.createElementNS(svgNS, 'circle');
    progressCircle.setAttribute('cx', centerX);
    progressCircle.setAttribute('cy', centerY);
    progressCircle.setAttribute('r', radius);
    progressCircle.setAttribute('fill', 'none');
    progressCircle.setAttribute('stroke', getStressColor(value));
    progressCircle.setAttribute('stroke-width', strokeWidth);
    progressCircle.setAttribute('stroke-dasharray', circumference);
    progressCircle.setAttribute('stroke-dashoffset', dashOffset);
    progressCircle.setAttribute('stroke-linecap', 'round');
    progressCircle.style.transform = 'rotate(-90deg)';
    progressCircle.style.transformOrigin = 'center';
    progressCircle.style.transition = 'stroke-dashoffset 1s ease';
    svg.appendChild(progressCircle);
}

function createArc(cx, cy, radius, startAngle, endAngle, strokeWidth, color) {
    const svgNS = 'http://www.w3.org/2000/svg';

    const start = polarToCartesian(cx, cy, radius, startAngle);
    const end = polarToCartesian(cx, cy, radius, endAngle);

    const largeArcFlag = Math.abs(endAngle - startAngle) > 180 ? 1 : 0;

    const pathData = [
        'M', start.x, start.y,
        'A', radius, radius, 0, largeArcFlag, 0, end.x, end.y
    ].join(' ');

    const path = document.createElementNS(svgNS, 'path');
    path.setAttribute('d', pathData);
    path.setAttribute('fill', 'none');
    path.setAttribute('stroke', color);
    path.setAttribute('stroke-width', strokeWidth);
    path.setAttribute('stroke-linecap', 'round');

    return path;
}

function createNeedle(cx, cy, radius, angle) {
    const svgNS = 'http://www.w3.org/2000/svg';

    const point = polarToCartesian(cx, cy, radius, angle);

    const line = document.createElementNS(svgNS, 'line');
    line.setAttribute('x1', cx);
    line.setAttribute('y1', cy);
    line.setAttribute('x2', point.x);
    line.setAttribute('y2', point.y);
    line.setAttribute('stroke', '#374151');
    line.setAttribute('stroke-width', '3');
    line.setAttribute('stroke-linecap', 'round');

    return line;
}

function polarToCartesian(cx, cy, radius, angleInDegrees) {
    const angleInRadians = angleInDegrees * Math.PI / 180;
    return {
        x: cx + radius * Math.cos(angleInRadians),
        y: cy - radius * Math.sin(angleInRadians)
    };
}

function getStressColor(pss) {
    if (pss <= 2) return '#34C759';
    if (pss <= 4) return '#FF9500';
    return '#FF3B30';
}

// =============================================================================
// Tooltip Logic
// =============================================================================

const TOOLTIP_CONTENT = {
    reversibility: {
        title: "Reversibility Class",
        body: `
            <p>Your potential to reverse metabolic dysfunction.</p>
            <ul>
                <li><strong>Class 1:</strong> Highly reversible. Body is responsive.</li>
                <li><strong>Class 2:</strong> Good potential, requires sustained effort.</li>
                <li><strong>Class 3:</strong> Difficult. Significant metabolic headwinds.</li>
                <li><strong>Class 4:</strong> Focus on damage control & organ protection.</li>
            </ul>
            <p><em>Influenced by Beta Pattern and Chronicity.</em></p>
        `
    },
    ir: {
        title: "Insulin Resistance (IR)",
        body: `
            <p>A composite score (0-10) measuring how much your body resists insulin.</p>
            <ul>
                <li><strong>HOMA-IR:</strong> Fasting load.</li>
                <li><strong>HbA1c:</strong> Long-term average.</li>
                <li><strong>Waist/Height:</strong> Visceral fat indicator.</li>
            </ul>
            <p>Higher scores mean your pancreas works harder to keep glucose normal.</p>
        `
    },
    beta: {
        title: "Beta Cell Reserve (v2.1)",
        body: `
            <p>A 4-layer assessment of your insulin factory.</p>
            <ul>
                <li><strong>Grade:</strong> A (Excellent) to D (Failure).</li>
                <li><strong>Pattern:</strong>
                    <ul>
                        <li><em>Hypersecretion:</em> Overdrive (early stage).</li>
                        <li><em>Dedifferentiation:</em> Loss of identity (declining).</li>
                        <li><em>Failure:</em> Structural loss.</li>
                    </ul>
                </li>
                <li><strong>Mismatch:</strong> Gap between demand (IR) and supply (C-Pep).</li>
            </ul>
        `
    },
    pss: {
        title: "Pancreatic Stress Score",
        body: `
            <p>A measure of physical stress on the pancreas (0-6).</p>
            <p>Calculated from Lipase and Amylase enzyme levels relative to their upper limits.</p>
            <p>High stress (≥3) indicates active strain and requires immediate dietary relief (low fat/alcohol).</p>
        `
    },
    modifiers: {
        title: "Clinical Modifiers",
        body: `
            <p>Specific conditions that make reversal harder.</p>
            <ul>
                <li><strong>Thyroid:</strong> High TSH slows metabolism.</li>
                <li><strong>Cortisol:</strong> Stress hormone fights insulin.</li>
                <li><strong>Kidney (UACR):</strong> Protein leakage signals vascular damage.</li>
            </ul>
        `
    }
};

document.addEventListener('DOMContentLoaded', () => {
    const icons = document.querySelectorAll('.info-icon');
    const popover = document.getElementById('tooltipPopover');
    const titleEl = document.getElementById('tooltipTitle');
    const bodyEl = document.getElementById('tooltipBody');

    // Close on click outside
    document.addEventListener('click', (e) => {
        if (!popover.contains(e.target) && !e.target.classList.contains('info-icon')) {
            popover.style.display = 'none';
        }
    });

    icons.forEach(icon => {
        icon.addEventListener('click', (e) => {
            e.stopPropagation();
            const metric = icon.dataset.metric;
            const content = TOOLTIP_CONTENT[metric];

            if (content) {
                titleEl.textContent = content.title;
                bodyEl.innerHTML = content.body;
                popover.style.display = 'block';
            }
        });

        // Optional: Hover support
        icon.addEventListener('mouseenter', () => {
            const metric = icon.dataset.metric;
            const content = TOOLTIP_CONTENT[metric];

            if (content) {
                titleEl.textContent = content.title;
                bodyEl.innerHTML = content.body;
                popover.style.display = 'block';
            }
        });

        icon.addEventListener('mouseleave', () => {
            popover.style.display = 'none';
        });
    });

    // Keep popover open when hovering over it
    popover.addEventListener('mouseenter', () => {
        popover.style.display = 'block';
    });

    popover.addEventListener('mouseleave', () => {
        popover.style.display = 'none';
    });
});

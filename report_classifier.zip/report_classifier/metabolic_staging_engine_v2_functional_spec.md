# Metabolic Staging Engine v2.1 – Functional & Integration Spec

*(Drop-in replacement for v2.0)*

This document explains **what** the staging engine does, **what it needs as input**, **what it returns**, and **how a UI/backend should integrate with it**.

The goal:
Take a set of lab + anthropometry values → produce a **JSON summary** of the patient’s metabolic state:

* Insulin resistance score and grade
* **β-cell reserve grade + β-cell pattern + mismatch score (new)**
* Pancreatic stress level
* Reversibility class (baseline and adjusted)
* Modifiers applied
* Chronicity band (new)
* Ambiguity level and missing inputs

The logic is implemented in:

```python
compute_metabolic_staging(input_data: dict) -> dict
```

---

# **1. High-Level Behaviour**

## **1.1 What the engine does**

Given a JSON-like input dictionary with lab results and clinical data, the engine:

1. Computes derived indices:
   * HOMA-IR
   * Waist-to-height ratio (WHtR)
   * Chronicity band (**new**)
2. Builds a composite **Insulin Resistance Score** (`ir_score`) and grade (`ir_grade` 0–4).
3. **Computes β-cell function using a new 4-layer model**:
   * Raw β-grade from C-peptide
   * **Mismatch score** (how C-peptide output compares to IR + stress + chronicity)
   * **β-cell pattern mode** (hypersecretion / compensated / dedifferentiation / failure / indeterminate)
   * Final β-grade after mismatch adjustments
4. Computes a **Pancreatic Stress Score** (`pss` 0–6).
5. Assigns a baseline **Reversibility Class** (1–4) using v2.1 logic.
6. Applies modifiers:
   * Thyroid function
   * Morning cortisol
   * Microalbuminuria (UACR)
   * Extreme ferritin
7. Assesses **ambiguity level** and missing data.
8. Returns everything as a structured JSON.

The engine is **pure**—no DB, no external calls, no side-effects.

## **1.2 Intended uses**

- As a **CLI tool** for testing.
- As a **backend microservice**: one HTTP endpoint that takes JSON → returns JSON.
- As a **scoring module** inside a larger health platform (direct function call).

---

# **2. Core Function**

```python
def compute_metabolic_staging(input_data: Dict[str, Any]) -> Dict[str, Any]:
    ...
```

* **Input**: `input_data` – a dictionary with typed values (floats/strings/ints or `None`).
* **Output**: a dictionary that can be directly JSON-serialized.

The CLI (`main()`) is just a wrapper. For API integration, use `compute_metabolic_staging` directly.

---

# **3. Input Schema**

All values are optional at the code level (you can pass `None`), but missing critical values will increase **ambiguity**.

### 3.1 Demographics / Anthropometry

| Field       | Type  | Description                        |
| ----------- | ----- | ---------------------------------- |
| `sex`       | str   | `"male"`, `"female"`, or `"other"` |
| `waist_cm`  | float | Waist circumference in cm          |
| `height_cm` | float | Height in cm                       |

### 3.2 Core Glycaemia

| Field                    | Type  | Description                    |
| ------------------------ | ----- | ------------------------------ |
| `fasting_glucose_mgdl`   | float | Fasting plasma glucose (mg/dL) |
| `hba1c_pct`              | float | HbA1c (%)                      |
| `fasting_insulin_microU` | float | Fasting insulin (µU/mL)        |
| `c_peptide_ngml`         | float | Fasting C-peptide (ng/mL)      |

### 3.3 Pancreatic Enzymes

| Field         | Type  | Description                                 |
| ------------- | ----- | ------------------------------------------- |
| `lipase_u`    | float | Serum lipase (U/L)                          |
| `lipase_uln`  | float | Lab upper limit of normal for lipase (U/L)  |
| `amylase_u`   | float | Serum amylase (U/L)                         |
| `amylase_uln` | float | Lab upper limit of normal for amylase (U/L) |

### 3.4 Nutrient / Metabolic Modifiers

| Field                | Type  | Description         |
| -------------------- | ----- | ------------------- |
| `magnesium_mgdl`     | float | Serum magnesium     |
| `vitamin_b12_pgml`   | float | Serum vitamin B12   |
| `homocysteine_umoll` | float | Plasma homocysteine |
| `vitamin_d_ngml`     | float | 25(OH)D vitamin D   |
| `ferritin_ngml`      | float | Serum ferritin      |

### 3.5 Lipids

| Field                | Type  | Description     |
| -------------------- | ----- | --------------- |
| `triglycerides_mgdl` | float | Triglycerides   |
| `hdl_mgdl`           | float | HDL cholesterol |
| `ldl_mgdl`           | float | LDL cholesterol |

### 3.6 Kidney / Liver

| Field             | Type  | Description                           |
| ----------------- | ----- | ------------------------------------- |
| `creatinine_mgdl` | float | Serum creatinine                      |
| `egfr_ml_min_173` | float | eGFR (ml/min/1.73 m²)                 |
| `alt_u`           | float | ALT (U/L)                             |
| `ast_u`           | float | AST (U/L)                             |
| `ggt_u`           | float | GGT (U/L)                             |
| `uacr_mg_per_g`   | float | Urine albumin/creatinine ratio (mg/g) |

### 3.7 Urine Glucose

| Field                 | Type | Description                                   |
| --------------------- | ---- | --------------------------------------------- |
| `urine_glucose_grade` | int  | 0 / 1 / 2 / 3 for 0/trace/1+/2+/3+ glycosuria |

### 3.8 Hormones

| Field              | Type  | Description              |
| ------------------ | ----- | ------------------------ |
| `tsh_miul`         | float | TSH (mIU/L)              |
| `cortisol_am_ugdl` | float | Morning cortisol (µg/dL) |

---

# **4. Output Schema**

**Major update**: The output now includes:
* `mismatch_score`
* `beta_cell_pattern`
* `chronicity_band`
* Interpretation layer
* Engine metadata

### **4.1 Example Output Structure**

```jsonc
{
  "engine": {
    "version": "2.1",
    "build": "2025-11-29",
    "schema_version": "2.1"
  },
  "input": { ... },
  "derived": {
    "homa_ir": 2.8,
    "whtr": 0.56,
    "chronicity_band": "medium"
  },
  "scores": {
    "ir_score": 7,
    "ir_grade": 3,
    "beta_grade": "B2",
    "mismatch_score": 2,
    "pss": 2,
    "reversibility_class": {
      "baseline": 2,
      "final_after_modifiers": 3
    }
  },
  "beta_cell_pattern": {
    "mode": "dedifferentiation",
    "inferred_stage": 2,
    "drivers": ["high_IR_with_mid_C_peptide", "pss_high", "uacr_flag"],
    "reason_summary": "C-peptide output is inadequate relative to insulin resistance; pattern consistent with early β-cell dedifferentiation."
  },
  "modifiers": {
    "thyroid_penalty_applied": false,
    "cortisol_penalty_applied": true,
    "uacr_penalty_applied": true,
    "ferritin_cap_applied": false,
    "hyperthyroid_flag": false,
    "final_class": 3
  },
  "ambiguity": {
    "level": "MEDIUM",
    "missing_fields_for_low_ambiguity": ["vitamin_d_ngml", "cortisol_am_ugdl"],
    "notes": ["Missing cortisol and vitamin D reduce confidence in pattern recognition."]
  },
  "interpretation": {
    "ir_summary": "...",
    "beta_summary": "...",
    "pss_summary": "...",
    "class_summary": "..."
  },
  "notes": {
    "pss_is_not_pancreatitis_diagnosis": true,
    "beta_dedifferentiation_inference_is_heuristic": true,
    "heuristic_components_present": true
  }
}
```

### 4.2 `derived`

| Field             | Type       | Meaning                             |
| ----------------- | ---------- | ----------------------------------- |
| `homa_ir`         | float|None | Calculated insulin resistance index |
| `whtr`            | float|None | Waist-to-height ratio               |
| `chronicity_band` | str        | `"short"`, `"medium"`, `"long"`, or `"unknown"` |

### 4.3 `scores`

| Field                                       | Type | Meaning                                                     |
| ------------------------------------------- | ---- | ----------------------------------------------------------- |
| `ir_score`                                  | int  | 0–10 composite insulin resistance score                     |
| `ir_grade`                                  | int  | 0–4 grade (higher = worse IR)                               |
| `beta_grade`                                | str  | `"A"`, `"B1"`, `"B2"`, `"C"`, `"D"` or `"UNKNOWN"`          |
| `mismatch_score`                            | int  | 0–4 score indicating supply-demand mismatch                 |
| `pss`                                       | int  | Pancreatic Stress Score (0–6)                               |
| `reversibility_class.baseline`              | int  | Class 1–4 before modifiers                                  |
| `reversibility_class.final_after_modifiers` | int  | Final class 1–4 after modifiers                             |
4. Computes a **Pancreatic Stress Score** (`pss` 0–6).
5. Assigns a baseline **Reversibility Class** (1–4) using v2.1 logic.
6. Applies modifiers:
   * Thyroid function
   * Morning cortisol
   * Microalbuminuria (UACR)
   * Extreme ferritin
7. Assesses **ambiguity level** and missing data.
8. Returns everything as a structured JSON.

The engine is **pure**—no DB, no external calls, no side-effects.

## **1.2 Intended uses**

- As a **CLI tool** for testing.
- As a **backend microservice**: one HTTP endpoint that takes JSON → returns JSON.
- As a **scoring module** inside a larger health platform (direct function call).

---

# **2. Core Function**

```python
def compute_metabolic_staging(input_data: Dict[str, Any]) -> Dict[str, Any]:
    ...
```

* **Input**: `input_data` – a dictionary with typed values (floats/strings/ints or `None`).
* **Output**: a dictionary that can be directly JSON-serialized.

The CLI (`main()`) is just a wrapper. For API integration, use `compute_metabolic_staging` directly.

---

# **3. Input Schema**

All values are optional at the code level (you can pass `None`), but missing critical values will increase **ambiguity**.

### 3.1 Demographics / Anthropometry

| Field       | Type  | Description                        |
| ----------- | ----- | ---------------------------------- |
| `sex`       | str   | `"male"`, `"female"`, or `"other"` |
| `waist_cm`  | float | Waist circumference in cm          |
| `height_cm` | float | Height in cm                       |

### 3.2 Core Glycaemia

| Field                    | Type  | Description                    |
| ------------------------ | ----- | ------------------------------ |
| `fasting_glucose_mgdl`   | float | Fasting plasma glucose (mg/dL) |
| `hba1c_pct`              | float | HbA1c (%)                      |
| `fasting_insulin_microU` | float | Fasting insulin (µU/mL)        |
| `c_peptide_ngml`         | float | Fasting C-peptide (ng/mL)      |

### 3.3 Pancreatic Enzymes

| Field         | Type  | Description                                 |
| ------------- | ----- | ------------------------------------------- |
| `lipase_u`    | float | Serum lipase (U/L)                          |
| `lipase_uln`  | float | Lab upper limit of normal for lipase (U/L)  |
| `amylase_u`   | float | Serum amylase (U/L)                         |
| `amylase_uln` | float | Lab upper limit of normal for amylase (U/L) |

### 3.4 Nutrient / Metabolic Modifiers

| Field                | Type  | Description         |
| -------------------- | ----- | ------------------- |
| `magnesium_mgdl`     | float | Serum magnesium     |
| `vitamin_b12_pgml`   | float | Serum vitamin B12   |
| `homocysteine_umoll` | float | Plasma homocysteine |
| `vitamin_d_ngml`     | float | 25(OH)D vitamin D   |
| `ferritin_ngml`      | float | Serum ferritin      |

### 3.5 Lipids

| Field                | Type  | Description     |
| -------------------- | ----- | --------------- |
| `triglycerides_mgdl` | float | Triglycerides   |
| `hdl_mgdl`           | float | HDL cholesterol |
| `ldl_mgdl`           | float | LDL cholesterol |

### 3.6 Kidney / Liver

| Field             | Type  | Description                           |
| ----------------- | ----- | ------------------------------------- |
| `creatinine_mgdl` | float | Serum creatinine                      |
| `egfr_ml_min_173` | float | eGFR (ml/min/1.73 m²)                 |
| `alt_u`           | float | ALT (U/L)                             |
| `ast_u`           | float | AST (U/L)                             |
| `ggt_u`           | float | GGT (U/L)                             |
| `uacr_mg_per_g`   | float | Urine albumin/creatinine ratio (mg/g) |

### 3.7 Urine Glucose

| Field                 | Type | Description                                   |
| --------------------- | ---- | --------------------------------------------- |
| `urine_glucose_grade` | int  | 0 / 1 / 2 / 3 for 0/trace/1+/2+/3+ glycosuria |

### 3.8 Hormones

| Field              | Type  | Description              |
| ------------------ | ----- | ------------------------ |
| `tsh_miul`         | float | TSH (mIU/L)              |
| `cortisol_am_ugdl` | float | Morning cortisol (µg/dL) |

---

# **4. Output Schema**

**Major update**: The output now includes:
* `mismatch_score`
* `beta_cell_pattern`
* `chronicity_band`
* Interpretation layer
* Engine metadata

### **4.1 Example Output Structure**

```jsonc
{
  "engine": {
    "version": "2.1",
    "build": "2025-11-29",
    "schema_version": "2.1"
  },
  "input": { ... },
  "derived": {
    "homa_ir": 2.8,
    "whtr": 0.56,
    "chronicity_band": "medium"
  },
  "scores": {
    "ir_score": 7,
    "ir_grade": 3,
    "beta_grade": "B2",
    "mismatch_score": 2,
    "pss": 2,
    "reversibility_class": {
      "baseline": 2,
      "final_after_modifiers": 3
    }
  },
  "beta_cell_pattern": {
    "mode": "dedifferentiation",
    "inferred_stage": 2,
    "drivers": ["high_IR_with_mid_C_peptide", "pss_high", "uacr_flag"],
    "reason_summary": "C-peptide output is inadequate relative to insulin resistance; pattern consistent with early β-cell dedifferentiation."
  },
  "modifiers": {
    "thyroid_penalty_applied": false,
    "cortisol_penalty_applied": true,
    "uacr_penalty_applied": true,
    "ferritin_cap_applied": false,
    "hyperthyroid_flag": false,
    "final_class": 3
  },
  "ambiguity": {
    "level": "MEDIUM",
    "missing_fields_for_low_ambiguity": ["vitamin_d_ngml", "cortisol_am_ugdl"],
    "notes": ["Missing cortisol and vitamin D reduce confidence in pattern recognition."]
  },
  "interpretation": {
    "ir_summary": "...",
    "beta_summary": "...",
    "pss_summary": "...",
    "class_summary": "..."
  },
  "notes": {
    "pss_is_not_pancreatitis_diagnosis": true,
    "beta_dedifferentiation_inference_is_heuristic": true,
    "heuristic_components_present": true
  }
}
```

### 4.2 `derived`

| Field             | Type       | Meaning                             |
| ----------------- | ---------- | ----------------------------------- |
| `homa_ir`         | float|None | Calculated insulin resistance index |
| `whtr`            | float|None | Waist-to-height ratio               |
| `chronicity_band` | str        | `"short"`, `"medium"`, `"long"`, or `"unknown"` |

### 4.3 `scores`

| Field                                       | Type | Meaning                                                     |
| ------------------------------------------- | ---- | ----------------------------------------------------------- |
| `ir_score`                                  | int  | 0–10 composite insulin resistance score                     |
| `ir_grade`                                  | int  | 0–4 grade (higher = worse IR)                               |
| `beta_grade`                                | str  | `"A"`, `"B1"`, `"B2"`, `"C"`, `"D"` or `"UNKNOWN"`          |
| `mismatch_score`                            | int  | 0–4 score indicating supply-demand mismatch                 |
| `pss`                                       | int  | Pancreatic Stress Score (0–6)                               |
| `reversibility_class.baseline`              | int  | Class 1–4 before modifiers                                  |
| `reversibility_class.final_after_modifiers` | int  | Final class 1–4 after modifiers                             |

### 4.4 `beta_cell_pattern`

| Field            | Type | Meaning                                                                 |
| ---------------- | ---- | ----------------------------------------------------------------------- |
| `mode`          ## 5.4 Reversibility Class (1–4) — **Upgraded Prognosis Logic (v2.1)**

In v2.x, the engine’s “prognosis” is represented as **reversal potential + urgency window**, not a medical prediction of outcomes.

**Reversal potential** is expressed as a **Reversibility Class (1–4)**:
- **Class 1** = high reversal potential (capacity exists; short window risk low)
- **Class 2** = good potential but needs sustained effort and tighter execution
- **Class 3** = reversal is still possible but difficult; damage-risk and constraints are significant
- **Class 4** = low reversal probability; focus is control + complication protection (metabolic improvement still valuable)

### 5.4.1 Baseline Class Inputs

Baseline class is computed from:
- `ir_grade` (0–4)
- **final** `beta_grade` (A/B1/B2/C/D/UNKNOWN)
- `pss` (0–6)
- renal function proxies:
  - `egfr_ml_min_173`
  - `uacr_mg_per_g`
- **β pattern engine outputs (v2.1):**
  - `beta_cell_pattern`
  - `beta_mismatch_score`
  - `beta_confidence`
- `derived.chronicity_proxy` (SHORT/MEDIUM/LONG/UNKNOWN)

> Key v2.1 change: baseline class is now **pattern-aware**.  
> It is not computed only from IR-grade and absolute C-peptide.

### 5.4.2 Baseline Computation (Monotonic Principles)

The baseline class must be monotonic in severity:
- Higher IR-grade → never improves class
- Lower β-grade → never improves class
- Higher PSS → never improves class
- Worse kidney markers (UACR↑, eGFR↓) → never improves class
- Chronicity (MEDIUM/LONG) → tends to worsen or constrain class

A practical implementation can use a weighted internal score mapped to 1–4, but the **explicit v2.1 overrides below must apply**.

### 5.4.3 Pattern-Based Overrides (Critical v2.1 Rules)

These rules embed the “new truth” about hypersecretion vs dedifferentiation vs failure.

#### A) Hypersecretion bias (capacity exists)
If:
- `beta_cell_pattern == "HYPERSECRETION"`
- and `derived.chronicity_proxy != "LONG"`
- and kidneys are not significantly compromised:
  - (`uacr_mg_per_g` is missing or `< 30`) AND (`egfr_ml_min_173` is missing or `>= 60`)

Then:
- **Improve baseline by 1 class** (e.g., 2→1, 3→2), but never below Class 1.

Rationale: hypersecretion implies preserved insulin output but maladaptive overdrive; reversal is often high-potential if acted on.

#### B) Dedifferentiation penalty (output inadequate for demand)
If:
- `beta_cell_pattern == "DEDIFFERENTIATION_SUSPECTED"`
- and (`beta_mismatch_score >= 2` OR `derived.chronicity_proxy in ["MEDIUM","LONG"]`)

Then:
- **Worsen baseline by 1 class** (cap at Class 4).

Rationale: relative insulin output inadequacy under high demand is a “decline pattern”; reversal can still occur but becomes harder and more time-sensitive.

#### C) Failure floor (true low reserve)
If:
- `beta_cell_pattern == "FAILURE"` OR (`beta_grade` in ["C","D"] AND `beta_mismatch_score >= 3`)

Then:
- Baseline must be **at least Class 3**.
- If kidney damage present (`uacr_mg_per_g >= 30` OR `egfr_ml_min_173 < 60`) → baseline tends to **Class 4** unless other signals are strongly contradictory.

Rationale: low reserve + organ stress limits aggressive reversal and increases safety constraints.

#### D) Mismatch override (the big safety catch)
If:
- `beta_mismatch_score >= 3`

Then:
- Baseline must be **at least Class 3** regardless of absolute C-peptide grade.

Rationale: high mismatch means “C-peptide is too low for the IR+glycemic burden”; this is precisely how dedifferentiation and late-stage decline get missed if you use C-peptide alone.

#### E) Confidence handling
If:
- `beta_confidence == "LOW"` OR `beta_cell_pattern == "INDETERMINATE"`

Then:
- Do **not** apply A/B/C pattern overrides.
- Baseline class should rely on IR-grade + PSS + renal markers and mark ambiguity as MEDIUM/HIGH.

### 5.4.4 Modifier Adjustments (unchanged from v2.0)

After baseline is computed, apply modifiers (+1 class; cap at 4):

- Hypothyroid penalty:
  - If `tsh_miul > 10` → class += 1 (`thyroid_penalty_applied = true`)

- Cortisol penalty:
  - If `cortisol_am_ugdl > 18` → class += 1 (`cortisol_penalty_applied = true`)

- UACR penalty:
  - If `uacr_mg_per_g > 30` → class += 1 (`uacr_penalty_applied = true`)

- Ferritin cap:
  - If `ferritin_ngml > 1000` → class = min(class, 3) (`ferritin_cap_applied = true`)

Final class is stored as:
- `scores.reversibility_class.final_after_modifiers`
- `modifiers.final_class`

---

## 5.5 Prognosis Block (NEW OUTPUT SECTION)

To reflect the upgraded truth clearly without overclaiming, the output now includes a `prognosis` block that summarizes:

1) **reversal potential** (final class)
2) **urgency / window** (time-sensitivity)
3) a short reason and warnings

### 5.5.1 Output Schema Addition

```jsonc
"prognosis": {
  "reversibility_class": 3,
  "window": "URGENT|MODERATE|STABLE|UNKNOWN",
  "primary_reason": "Dedifferentiation-suspected: insulin output is inadequate for high insulin resistance burden.",
  "warnings": [
    "Pattern inference is heuristic; confirm with follow-up labs and clinical context."
  ]
}
```

### 5.5.2 Window Mapping Rules

Set `prognosis.window` as:

* `"URGENT"` if:
  * `beta_cell_pattern == "DEDIFFERENTIATION_SUSPECTED"` AND `beta_mismatch_score >= 2`
  * OR `beta_cell_pattern == "FAILURE"`
  * OR (`uacr_mg_per_g >= 30` OR `egfr_ml_min_173 < 60`) with worsening glycemia (HbA1c high or urine glucose >= 2)

* `"MODERATE"` if:
  * `beta_cell_pattern == "HYPERSECRETION"` (capacity exists but overdrive)
  * OR class is 2 with medium chronicity

* `"STABLE"` if:
  * `beta_cell_pattern == "COMPENSATED"` AND chronicity is SHORT and kidneys are okay

* `"UNKNOWN"` if:
  * beta pattern is indeterminate OR supporting fields are missing

### 5.5.3 Primary Reason Generation (examples)

* Hypersecretion:
  * `"High insulin resistance with high C-peptide suggests hypersecretion (overdrive) rather than weak reserve."`

* Dedifferentiation suspected:
  * `"High insulin resistance with inappropriately low C-peptide for demand suggests early decline/dedifferentiation pattern."`

* Failure:
  * `"Low C-peptide with high glycemia indicates low reserve/failure pattern; focus shifts to control and protection."`

### 5.5.4 Warnings (always include at least one)

Always include:
* `"This engine provides staging inference, not a diagnosis. Use clinical judgment and follow-up testing."`

Add extra warnings when:
* `beta_confidence == "LOW"`:
  * `"Low confidence: C-peptide/IR/stress markers incomplete; pattern may change when missing labs are added."`

* Missing kidney markers:
  * `"Renal markers missing; long-term risk constraints may be underestimated."`

---

## 5.6 Updates Required Elsewhere in the Output Schema

Because `prognosis` is now an output section, the top-level output schema becomes:

```jsonc
{
  "input": { ... },
  "derived": { ... },
  "scores": { ... },
  "prognosis": { ... },          // NEW
  "modifiers": { ... },
  "ambiguity": { ... },
  "notes": { ... }
}
```

UI should treat:
* `scores.reversibility_class.final_after_modifiers` as the numeric class
* `prognosis.window` as the urgency message anchor
* `prognosis.primary_reason` as the headline explanation

"""
Metabolic Staging Engine - API

This module exposes the metabolic staging logic as a REST API using FastAPI.
"""

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field
from typing import Optional, List, Dict, Any
from pathlib import Path
from . import metabolic_staging_core as core
from . import metabolic_staging_prognosis as prognosis
from . import metabolic_staging_profiles as profiles

app = FastAPI(
    title="Metabolic Staging Engine API",
    description="API for computing metabolic staging based on lab and anthropometric data.",
    version="2.0.0"
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Allow all origins for development
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Mount static files
BASE_DIR = Path(__file__).resolve().parent.parent
FRONTEND_DIR = BASE_DIR / "frontend"

if FRONTEND_DIR.exists():
    app.mount("/static", StaticFiles(directory=str(FRONTEND_DIR)), name="static")

# =============================================================================
# Input Models
# =============================================================================

class MetabolicInput(BaseModel):
    sex: Optional[str] = Field(None, description="male, female, or other")
    
    fasting_glucose_mgdl: Optional[float] = Field(None, description="Fasting plasma glucose (mg/dL)")
    hba1c_pct: Optional[float] = Field(None, description="HbA1c (%)")
    fasting_insulin_microU: Optional[float] = Field(None, description="Fasting insulin (µU/mL)")
    c_peptide_ngml: Optional[float] = Field(None, description="Fasting C-peptide (ng/mL)")
    
    lipase_u: Optional[float] = Field(None, description="Serum lipase (U/L)")
    lipase_uln: Optional[float] = Field(None, description="Lab upper limit of normal for lipase (U/L)")
    amylase_u: Optional[float] = Field(None, description="Serum amylase (U/L)")
    amylase_uln: Optional[float] = Field(None, description="Lab upper limit of normal for amylase (U/L)")
    
    magnesium_mgdl: Optional[float] = Field(None, description="Serum magnesium (mg/dL)")
    vitamin_b12_pgml: Optional[float] = Field(None, description="Serum vitamin B12 (pg/mL)")
    homocysteine_umoll: Optional[float] = Field(None, description="Plasma homocysteine (µmol/L)")
    vitamin_d_ngml: Optional[float] = Field(None, description="25(OH)D vitamin D (ng/mL)")
    ferritin_ngml: Optional[float] = Field(None, description="Serum ferritin (ng/mL)")
    
    triglycerides_mgdl: Optional[float] = Field(None, description="Triglycerides (mg/dL)")
    hdl_mgdl: Optional[float] = Field(None, description="HDL cholesterol (mg/dL)")
    ldl_mgdl: Optional[float] = Field(None, description="LDL cholesterol (mg/dL)")
    
    creatinine_mgdl: Optional[float] = Field(None, description="Serum creatinine (mg/dL)")
    egfr_ml_min_173: Optional[float] = Field(None, description="eGFR (ml/min/1.73 m²)")
    
    alt_u: Optional[float] = Field(None, description="ALT (U/L)")
    ast_u: Optional[float] = Field(None, description="AST (U/L)")
    ggt_u: Optional[float] = Field(None, description="GGT (U/L)")
    
    uacr_mg_per_g: Optional[float] = Field(None, description="Urine albumin/creatinine ratio (mg/g)")
    urine_glucose_grade: Optional[int] = Field(None, description="0, 1, 2, or 3 for 0/trace/1+/2+/3+")
    
    tsh_miul: Optional[float] = Field(None, description="TSH (mIU/L)")
    cortisol_am_ugdl: Optional[float] = Field(None, description="Morning cortisol (µg/dL)")
    
    waist_cm: Optional[float] = Field(None, description="Waist circumference (cm)")
    height_cm: Optional[float] = Field(None, description="Height (cm)")

    model_config = {
        "json_schema_extra": {
            "example": {
                "sex": "male",
                "fasting_glucose_mgdl": 100,
                "hba1c_pct": 5.7,
                "fasting_insulin_microU": 10,
                "c_peptide_ngml": 1.5,
                "waist_cm": 90,
                "height_cm": 175
            }
        }
    }

# =============================================================================
# Output Models (Optional, for documentation)
# =============================================================================
# For now, we return a generic Dict to match the core output flexibility,
# but strictly typing this would be a good future enhancement.

# =============================================================================
# Endpoints
# =============================================================================

@app.get("/")
def read_root():
    """Serve the main frontend page"""
    index_file = FRONTEND_DIR / "index.html"
    if index_file.exists():
        return FileResponse(str(index_file))
    return {"message": "Metabolic Staging Engine API v2.0.0"}

@app.get("/api")
def api_info():
    return {"message": "Metabolic Staging Engine API v2.0.0", "docs": "/docs"}

@app.get("/profiles")
def get_profiles():
    """Return list of sample clinical profiles"""
    return profiles.get_profiles()

@app.post("/calculate-staging", response_model=Dict[str, Any])
def calculate_staging(input_data: MetabolicInput):
    """
    Compute metabolic staging based on input data.
    """
    # Convert Pydantic model to dict, excluding None values if we wanted to be strict,
    # but our core handles None, so we just dump it.
    data_dict = input_data.model_dump()
    
    try:
        result = core.compute_metabolic_staging(data_dict)
        
        # Add Prognosis & Way Forward
        result["prognosis"] = {
            "outlook": prognosis.generate_prognosis(result),
            "way_forward": prognosis.generate_way_forward(result)
        }
        
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)

"""
Metabolic Staging Engine - Prognosis & Way Forward

This module generates deterministic prognosis and actionable steps based on the
metabolic staging results.
"""

from typing import Dict, List, Any

def generate_prognosis(staging_result: Dict[str, Any]) -> str:
    """
    Generates a deterministic prognosis string based on the staging result.
    """
    scores = staging_result["scores"]
    modifiers = staging_result["modifiers"]
    
    final_class = scores["reversibility_class"]["final_after_modifiers"]
    beta_grade = scores["beta_grade"]
    pss = scores["pss"]
    
    prognosis = ""
    
    # Base prognosis based on class
    if final_class == 1:
        prognosis = "Excellent potential for complete reversal. Your metabolic flexibility is intact, and your body is likely to respond rapidly to lifestyle interventions."
    elif final_class == 2:
        prognosis = "Good potential for reversal, but requires sustained effort. You have significant metabolic resistance, but your organs are resilient."
    elif final_class == 3:
        prognosis = "Reversal is possible but will be difficult and slow. You face significant metabolic headwinds, likely due to organ stress or hormonal barriers."
    else: # Class 4
        prognosis = "Focus should be on damage control and organ protection. Complete reversal is unlikely due to severe beta-cell loss or advanced organ complications, but quality of life can be significantly improved."

    # Nuance based on Beta Grade
    if beta_grade in ["C", "D"]:
        prognosis += " However, your pancreatic insulin reserve is critically low, which limits how much carbohydrate you can ever safely tolerate."
    elif beta_grade == "A":
        prognosis += " Your strong pancreatic reserve is a major asset in your recovery."

    # Nuance based on PSS
    if pss >= 3:
        prognosis += " High pancreatic stress indicates active inflammation or strain; immediate relief of this stress is crucial to prevent permanent damage."

    # Nuance based on Modifiers
    if modifiers["thyroid_penalty_applied"]:
        prognosis += " Untreated hypothyroidism is acting as a metabolic brake, slowing down your progress."
    if modifiers["cortisol_penalty_applied"]:
        prognosis += " High cortisol levels are actively fighting against your efforts to improve insulin sensitivity."
    
    return prognosis


def generate_way_forward(staging_result: Dict[str, Any]) -> List[str]:
    """
    Generates a list of actionable steps ('Way Forward') based on specific deficits.
    """
    scores = staging_result["scores"]
    derived = staging_result["derived"]
    input_data = staging_result["input"]
    modifiers = staging_result["modifiers"]
    
    steps = []
    
    # 1. Insulin Resistance Actions
    ir_score = scores["ir_score"]
    if ir_score >= 5:
        steps.append("Prioritize lowering insulin levels through time-restricted eating and carbohydrate restriction.")
        if derived["whtr"] is not None and derived["whtr"] > 0.6:
            steps.append("Visceral fat reduction is essential; focus on sleep and stress management alongside diet to mobilize abdominal fat.")
    
    # 2. Beta Cell Actions
    beta_grade = scores["beta_grade"]
    if beta_grade in ["C", "D"]:
        steps.append("Strictly limit glycemic load to protect remaining beta cells. Exogenous insulin may be required if glucose remains uncontrolled.")
    elif beta_grade in ["B1", "B2"]:
        steps.append("Avoid glucose spikes to allow beta cells to rest and recover function.")

    # 3. Pancreatic Stress Actions
    pss = scores["pss"]
    if pss >= 2:
        steps.append("Reduce pancreatic stress by avoiding alcohol, heavy meals, and processed fats.")
        if input_data.get("triglycerides_mgdl") and input_data["triglycerides_mgdl"] > 200:
            steps.append("Aggressively lower triglycerides to reduce lipotoxicity on the pancreas.")

    # 4. Micronutrient Actions
    # Magnesium
    if input_data.get("magnesium_mgdl") and input_data["magnesium_mgdl"] < 1.8:
        steps.append("Supplement Magnesium to improve insulin receptor sensitivity.")
    # Vitamin D
    if input_data.get("vitamin_d_ngml") and input_data["vitamin_d_ngml"] < 30:
        steps.append("Correct Vitamin D deficiency to support immune and metabolic function.")
    # B12
    if input_data.get("vitamin_b12_pgml") and input_data["vitamin_b12_pgml"] < 400:
        steps.append("Optimize B12 levels for energy metabolism and nerve health.")
        
    # 5. Modifier Actions
    if modifiers["thyroid_penalty_applied"]:
        steps.append("Consult an endocrinologist to optimize thyroid function; metabolic repair is difficult with high TSH.")
    if modifiers["cortisol_penalty_applied"]:
        steps.append("Implement stress reduction techniques (meditation, sleep hygiene) to lower morning cortisol.")
    if modifiers["uacr_penalty_applied"]:
        steps.append("Kidney protection is paramount. Strict blood pressure and glucose control are non-negotiable.")
    if modifiers["ferritin_cap_applied"]:
        steps.append("Investigate causes of high ferritin (inflammation or iron overload) as it causes oxidative stress to the liver and pancreas.")

    if not steps:
        steps.append("Continue maintaining healthy habits and regular monitoring.")

    return steps

"""
Metabolic Staging Engine - Sample Clinical Profiles

This module contains a dictionary of sample patient profiles to demonstrate
various metabolic scenarios.
"""

from typing import Dict, Any

PROFILES = {
    "healthy_metabolically_flexible": {
        "name": "Healthy & Metabolically Flexible",
        "description": "Ideal metabolic health with no resistance or organ stress.",
        "clinical_reasoning": "All markers are optimal. Low insulin, healthy beta cells, no inflammation.",
        "data": {
            "sex": "male",
            "fasting_glucose_mgdl": 85,
            "hba1c_pct": 5.0,
            "fasting_insulin_microU": 4.0,
            "c_peptide_ngml": 1.5,
            "waist_cm": 80,
            "height_cm": 180,
            "lipase_u": 40,
            "lipase_uln": 60,
            "magnesium_mgdl": 2.2,
            "vitamin_d_ngml": 45,
            "tsh_miul": 1.5,
            "cortisol_am_ugdl": 12,
            "egfr_ml_min_173": 100,
            "uacr_mg_per_g": 5
        }
    },
    "classic_insulin_resistance": {
        "name": "Classic Insulin Resistance (Metabolic Syndrome)",
        "description": "High insulin, central obesity, but beta cells are compensating well.",
        "clinical_reasoning": "High HOMA-IR and WHtR drive the score up, but C-peptide is high (Grade A), showing the pancreas is working hard to compensate.",
        "data": {
            "sex": "female",
            "fasting_glucose_mgdl": 105,
            "hba1c_pct": 5.9,
            "fasting_insulin_microU": 25.0,
            "c_peptide_ngml": 3.5,
            "waist_cm": 105,
            "height_cm": 165,
            "lipase_u": 55,
            "lipase_uln": 60,
            "magnesium_mgdl": 1.9,
            "vitamin_d_ngml": 25,
            "tsh_miul": 2.5,
            "cortisol_am_ugdl": 15,
            "egfr_ml_min_173": 90,
            "triglycerides_mgdl": 180,
            "hdl_mgdl": 40
        }
    },
    "beta_cell_exhaustion": {
        "name": "Beta Cell Exhaustion (Type 2 Progression)",
        "description": "Glucose is rising despite medication, insulin levels are dropping.",
        "clinical_reasoning": "The key here is the 'inappropriately normal' insulin for high glucose. C-peptide is dropping (Grade B2/C), indicating the pancreas is losing the battle.",
        "data": {
            "sex": "male",
            "fasting_glucose_mgdl": 180,
            "hba1c_pct": 8.5,
            "fasting_insulin_microU": 6.0,
            "c_peptide_ngml": 0.9,
            "waist_cm": 95,
            "height_cm": 175,
            "lipase_u": 45,
            "lipase_uln": 60,
            "magnesium_mgdl": 1.6,
            "vitamin_d_ngml": 20,
            "tsh_miul": 1.8,
            "egfr_ml_min_173": 75
        }
    },
    "pancreatic_stress_toxicity": {
        "name": "Pancreatic Stress & Lipotoxicity",
        "description": "High triglycerides and alcohol use stressing the pancreas.",
        "clinical_reasoning": "Elevated Lipase/Amylase ratios (PSS) indicate sub-clinical inflammation, often driven by high triglycerides (lipotoxicity).",
        "data": {
            "sex": "male",
            "fasting_glucose_mgdl": 130,
            "hba1c_pct": 6.8,
            "fasting_insulin_microU": 15.0,
            "c_peptide_ngml": 2.2,
            "waist_cm": 100,
            "height_cm": 178,
            "lipase_u": 110,
            "lipase_uln": 60,
            "amylase_u": 95,
            "amylase_uln": 100,
            "triglycerides_mgdl": 450,
            "magnesium_mgdl": 1.5,
            "tsh_miul": 1.2
        }
    },
    "hypothyroid_blocker": {
        "name": "Hypothyroid Metabolic Brake",
        "description": "Efforts to lose weight fail due to untreated thyroid issues.",
        "clinical_reasoning": "Even if IR is moderate, the high TSH (>10) triggers a penalty modifier, pushing the Reversibility Class up because metabolism is chemically slowed.",
        "data": {
            "sex": "female",
            "fasting_glucose_mgdl": 110,
            "hba1c_pct": 6.1,
            "fasting_insulin_microU": 12.0,
            "c_peptide_ngml": 2.0,
            "waist_cm": 92,
            "height_cm": 160,
            "tsh_miul": 12.5,
            "cortisol_am_ugdl": 14,
            "lipase_u": 30,
            "lipase_uln": 60
        }
    },
    "stress_cortisol_dominance": {
        "name": "Stress/Cortisol Dominance",
        "description": "High stress lifestyle driving glucose up in the mornings.",
        "clinical_reasoning": "High morning cortisol (>18) acts as a gluconeogenic driver, causing 'Dawn Phenomenon' and insulin resistance despite reasonable body weight.",
        "data": {
            "sex": "male",
            "fasting_glucose_mgdl": 125,
            "hba1c_pct": 5.8,
            "fasting_insulin_microU": 8.0,
            "c_peptide_ngml": 1.8,
            "waist_cm": 85,
            "height_cm": 180,
            "tsh_miul": 1.5,
            "cortisol_am_ugdl": 24.0,
            "magnesium_mgdl": 1.7
        }
    },
    "severe_organ_damage": {
        "name": "Severe Organ Damage (Class 4)",
        "description": "Advanced complications limiting reversibility.",
        "clinical_reasoning": "Low eGFR (<60) and high UACR indicate vascular damage. This automatically pushes the case to Class 4 (Protection Focus) regardless of glucose control.",
        "data": {
            "sex": "male",
            "fasting_glucose_mgdl": 150,
            "hba1c_pct": 7.5,
            "fasting_insulin_microU": 18.0,
            "c_peptide_ngml": 2.5,
            "egfr_ml_min_173": 45,
            "uacr_mg_per_g": 150,
            "creatinine_mgdl": 1.8,
            "waist_cm": 110,
            "height_cm": 170
        }
    }
}

def get_profiles() -> Dict[str, Any]:
    return PROFILES

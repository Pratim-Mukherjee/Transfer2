"""Backend package for Metabolic Staging Engine"""

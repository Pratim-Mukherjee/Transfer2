"""
Metabolic Staging Engine - Configuration & Thresholds

This module contains all the clinical thresholds, scoring rules, and constants
used by the metabolic staging engine. These values are derived from the
functional specification and clinical guidelines.
"""

# =============================================================================
# 1. Insulin Resistance (IR) Scoring Thresholds
# =============================================================================

# HOMA-IR: (Glucose * Insulin) / 405
# Points: 0-4
HOMA_IR_THRESHOLDS = [
    {"limit": 1.0,  "score": 0},
    {"limit": 1.8,  "score": 1},
    {"limit": 2.2,  "score": 2},
    {"limit": 3.0,  "score": 3},
    {"limit": float('inf'), "score": 4},
]

# HbA1c (%)
# Points: 0-3
HBA1C_THRESHOLDS = [
    {"limit": 5.7, "score": 0},
    {"limit": 6.4, "score": 1},
    {"limit": 7.9, "score": 2},
    {"limit": float('inf'), "score": 3},
]

# Urine Glucose Grade (0, 1, 2, 3)
# Points: 0-2
URINE_GLUCOSE_SCORES = {
    0: 0,
    1: 1,
    2: 2,
    3: 2  # 2+ and 3+ both get 2 points
}

# Waist-to-Height Ratio (WHtR)
# Points: 0-2
WHTR_THRESHOLDS = [
    {"limit": 0.52, "score": 0},
    {"limit": 0.60, "score": 1},
    {"limit": float('inf'), "score": 2},
]

# Micronutrients & Hormones
# Points are additive, capped at 6 for the micronutrient section in the original code,
# but here we define individual thresholds.

# Magnesium (mg/dL)
MAGNESIUM_THRESHOLDS = [
    {"limit": 1.6, "score": 2},  # < 1.6
    {"limit": 1.79, "score": 1}, # 1.6 - 1.79
]

# Vitamin B12 (pg/mL)
VITAMIN_B12_LOW_THRESHOLD = 200  # < 200 -> +1 point

# Homocysteine (µmol/L)
HOMOCYSTEINE_THRESHOLDS = [
    {"min": 15, "max": 30, "score": 1},
    {"min": 30, "max": float('inf'), "score": 2},
]

# Vitamin D (ng/mL)
VITAMIN_D_THRESHOLDS = [
    {"limit": 10, "score": 2},   # < 10
    {"limit": 20, "score": 1},   # 10 - 20
]

# Thyroid (TSH mIU/L)
TSH_THRESHOLDS = {
    "hypo_mild": {"min": 4.5, "max": 10, "score": 1},
    "hypo_severe": {"min": 10, "score": 2},
    "hyper": {"max": 0.1, "score": 1}
}

# Cortisol (µg/dL)
CORTISOL_THRESHOLDS = [
    {"min": 16, "max": 18, "score": 1},
    {"min": 18, "max": float('inf'), "score": 2},
]

# Ferritin (ng/mL)
# Sex-specific thresholds
FERRITIN_THRESHOLDS = {
    "male": [
        {"min": 300, "max": 500, "score": 1},
        {"min": 500, "max": float('inf'), "score": 2},
    ],
    "female": [
        {"min": 200, "max": 350, "score": 1},
        {"min": 350, "max": float('inf'), "score": 2},
    ]
}

# =============================================================================
# 2. IR Grade Mapping
# =============================================================================

# Total IR Score (0-10) -> IR Grade (0-4)
IR_SCORE_TO_GRADE = [
    {"max_score": 2, "grade": 1}, # 0-2 -> Grade 0-1 (Simplified to 1 in logic or kept as 0/1? Spec says 0-1. Code returns 0 if <=0, 1 if 1-2. Let's align with code.)
    # Code: <=0 -> 0; 1-2 -> 1; 3-4 -> 2; 5-7 -> 3; >=8 -> 4
    # Let's define ranges explicitly
]

def get_ir_grade(score: int) -> int:
    if score <= 0: return 0
    if score <= 2: return 1
    if score <= 4: return 2
    if score <= 7: return 3
    return 4

# =============================================================================
# 3. Beta Cell Reserve (C-Peptide)
# =============================================================================

# Fasting C-Peptide (ng/mL) -> Base Grade
# Fasting C-Peptide (ng/mL) -> Base Grade (v2.1)
C_PEPTIDE_THRESHOLDS = [
    {"min": 3.0, "grade": "A"},
    {"min": 2.0, "grade": "B1"},
    {"min": 1.3, "grade": "B2"},
    {"min": 0.8, "grade": "C"},
    {"min": 0.0, "grade": "D"}, # < 0.8
]

# v2.1 Mismatch Score Constants
MISMATCH_IR_GRADE_THRESHOLD = 3
MISMATCH_CPEP_HIGH_THRESHOLD = 2.5
MISMATCH_FPG_THRESHOLD = 130
MISMATCH_CPEP_LOW_THRESHOLD = 2.0
MISMATCH_PSS_THRESHOLD = 3
MISMATCH_UACR_THRESHOLD = 30.0
MISMATCH_EGFR_THRESHOLD = 60.0

# v2.1 Chronicity Constants
CHRONICITY_A1C_MEDIUM_MIN = 8.0
CHRONICITY_A1C_MEDIUM_MAX = 9.5
CHRONICITY_EGFR_SHORT_MIN = 90.0
CHRONICITY_UACR_SHORT_MAX = 30.0

# =============================================================================
# 4. Pancreatic Stress Score (PSS)
# =============================================================================

# Lipase Ratio (Value / ULN)
LIPASE_RATIO_THRESHOLDS = [
    {"min": 2.0, "score": 3}, # > 2.0
    {"min": 1.5, "score": 2}, # 1.5 - 2.0
    {"min": 1.0, "score": 1}, # 1.0 - 1.5
    # <= 1.0 -> 0
]

# Amylase Ratio (Value / ULN)
AMYLASE_RATIO_THRESHOLDS = [
    {"min": 1.5, "score": 2}, # > 1.5
    {"min": 1.0, "score": 1}, # 1.0 - 1.5
]

# Metabolic Add-on for PSS
# +1 if Glucose >= 200 OR Magnesium < 1.6
PSS_GLUCOSE_THRESHOLD = 200
PSS_MAGNESIUM_THRESHOLD = 1.6

PSS_MAX_SCORE = 6

# =============================================================================
# 5. Reversibility Class Modifiers
# =============================================================================

# Penalties that increase class by +1 (max 4)
MODIFIER_THRESHOLDS = {
    "tsh_penalty": 10.0,       # TSH > 10
    "cortisol_penalty": 18.0,  # Cortisol > 18
    "uacr_penalty": 30.0,      # UACR > 30
}

# Cap that limits class to max 3
FERRITIN_CAP_THRESHOLD = 1000.0

# =============================================================================
# 6. Ambiguity
# =============================================================================

REQUIRED_FIELDS_FOR_LOW_AMBIGUITY = [
    "fasting_glucose_mgdl", "hba1c_pct",
    "fasting_insulin_microU", "c_peptide_ngml",
    "magnesium_mgdl", "vitamin_b12_pgml",
    "homocysteine_umoll", "vitamin_d_ngml",
    "ferritin_ngml", "tsh_miul",
    "uacr_mg_per_g", "waist_cm", "height_cm",
    "lipase_u", "lipase_uln", "amylase_u", "amylase_uln",
    "egfr_ml_min_173"
]

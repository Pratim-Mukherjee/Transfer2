"""
Metabolic Staging Engine - Core Logic

This module contains the pure functions for computing metabolic staging.
It accepts a dictionary of input values and returns a dictionary of results.
It relies on `metabolic_staging_config` for thresholds and constants.
"""

from typing import Any, Dict, Optional, List
from . import metabolic_staging_config as config

# =============================================================================
# Helper Functions
# =============================================================================

def compute_homa_ir(fasting_glucose_mgdl: Optional[float],
                    fasting_insulin_microU: Optional[float]) -> Optional[float]:
    if fasting_glucose_mgdl is None or fasting_insulin_microU is None:
        return None
    return (fasting_glucose_mgdl * fasting_insulin_microU) / 405.0


def score_value_against_thresholds(value: Optional[float], thresholds: List[Dict]) -> int:
    """
    Generic helper to score a value against a list of thresholds.
    Thresholds list should be ordered by limit/min/max.
    """
    if value is None:
        return 0
    
    # Check for "limit" style (value < limit)
    # or "min/max" style (min <= value <= max)
    
    # Simple "limit" style (ascending severity)
    # Example: [{"limit": 1.0, "score": 0}, {"limit": 1.8, "score": 1}, ...]
    # We assume the list is ordered. We find the first bucket that fits.
    # Actually, the original logic often does: if < X return A, elif < Y return B...
    
    for item in thresholds:
        if "limit" in item:
            if value <= item["limit"]: # Using <= to match typical "up to" logic, check specific functions for strictness
                return item["score"]
        elif "min" in item and "max" in item:
            if item["min"] <= value <= item["max"]:
                return item["score"]
        elif "min" in item: # Open ended top
            if value >= item["min"]:
                return item["score"]
        elif "max" in item: # Open ended bottom
            if value <= item["max"]:
                return item["score"]
                
    return 0 # Default if no match found (shouldn't happen if covered)


def score_homa_ir(homa_ir: Optional[float]) -> int:
    if homa_ir is None: return 0
    # Custom logic to match exact original boundaries if generic helper is too risky
    # Original: <1.0 (0), 1.0-1.8 (1), 1.9-2.2 (2), 2.21-3.0 (3), >3.0 (4)
    
    if homa_ir < 1.0: return 0
    if homa_ir <= 1.8: return 1
    if homa_ir <= 2.2: return 2
    if homa_ir <= 3.0: return 3
    return 4


def score_hba1c(hba1c_pct: Optional[float]) -> int:
    if hba1c_pct is None: return 0
    # Original: <5.7 (0), 5.7-6.4 (1), 6.5-7.9 (2), >7.9 (3)
    if hba1c_pct < 5.7: return 0
    if hba1c_pct <= 6.4: return 1
    if hba1c_pct <= 7.9: return 2
    return 3


def score_glycosuria(urine_glucose_grade: Optional[int]) -> int:
    if urine_glucose_grade is None: return 0
    return config.URINE_GLUCOSE_SCORES.get(urine_glucose_grade, 2) # Default to max if unknown high? Or 0? Original code: >=2 -> 2.


def score_micronutrients(magnesium: Optional[float],
                         vitamin_b12: Optional[float],
                         homocysteine: Optional[float],
                         vitamin_d: Optional[float]) -> int:
    score = 0

    # Magnesium
    if magnesium is not None:
        if magnesium < 1.6: score += 2
        elif magnesium <= 1.79: score += 1

    # B12
    if vitamin_b12 is not None and vitamin_b12 < config.VITAMIN_B12_LOW_THRESHOLD:
        score += 1

    # Homocysteine
    if homocysteine is not None:
        if 15 <= homocysteine <= 30: score += 1
        elif homocysteine > 30: score += 2

    # Vitamin D
    if vitamin_d is not None:
        if vitamin_d < 10: score += 2
        elif vitamin_d <= 20: score += 1

    return min(score, 6)


def score_thyroid(tsh: Optional[float]) -> int:
    if tsh is None: return 0
    # 4.5 - 10 -> 1
    # > 10 -> 2
    # < 0.1 -> 1
    if 4.5 <= tsh <= 10: return 1
    if tsh > 10: return 2
    if tsh < 0.1: return 1
    return 0


def score_cortisol(cortisol_am: Optional[float]) -> int:
    if cortisol_am is None: return 0
    # 16-18 -> 1
    # > 18 -> 2
    if 16 <= cortisol_am <= 18: return 1
    if cortisol_am > 18: return 2
    return 0


def score_ferritin(ferritin: Optional[float], sex: Optional[str]) -> int:
    if ferritin is None or sex is None: return 0
    
    s = sex.lower()
    # Use male thresholds for "other" or fallback
    thresholds = config.FERRITIN_THRESHOLDS.get("female") if s == "female" else config.FERRITIN_THRESHOLDS.get("male")
    
    # Manual check to ensure exact match with original logic
    # Male: 300-500 (1), >500 (2)
    # Female: 200-350 (1), >350 (2)
    
    for t in thresholds:
        if "max" in t and t["max"] == float('inf'):
            if ferritin > t["min"]: return t["score"]
        else:
            if t["min"] <= ferritin <= t["max"]: return t["score"]
            
    return 0


def compute_whtr(waist_cm: Optional[float], height_cm: Optional[float]) -> Optional[float]:
    if waist_cm is None or height_cm is None or height_cm == 0:
        return None
    return waist_cm / height_cm


def score_whtr(whtr: Optional[float]) -> int:
    if whtr is None: return 0
    # 0.52 - 0.6 -> 1
    # > 0.6 -> 2
    if 0.52 <= whtr <= 0.6: return 1
    if whtr > 0.6: return 2
    return 0





def compute_pss(lipase: Optional[float],
                lipase_uln: Optional[float],
                amylase: Optional[float],
                amylase_uln: Optional[float],
                fasting_glucose_mgdl: Optional[float],
                magnesium: Optional[float]) -> int:
    score = 0

    # Lipase
    if lipase is not None and lipase_uln is not None and lipase_uln > 0:
        r_lipase = lipase / lipase_uln
        if r_lipase > 2.0: score += 3
        elif r_lipase > 1.5: score += 2
        elif r_lipase > 1.0: score += 1

    # Amylase
    if amylase is not None and amylase_uln is not None and amylase_uln > 0:
        r_amylase = amylase / amylase_uln
        if r_amylase > 1.5: score += 2
        elif r_amylase > 1.0: score += 1

    # Metabolic add-on
    if (fasting_glucose_mgdl is not None and fasting_glucose_mgdl >= config.PSS_GLUCOSE_THRESHOLD) or \
       (magnesium is not None and magnesium < config.PSS_MAGNESIUM_THRESHOLD):
        score += 1

    return min(score, config.PSS_MAX_SCORE)


def compute_chronicity_band(uacr: Optional[float],
                            egfr: Optional[float],
                            hba1c: Optional[float]) -> str:
    """
    Determines the chronicity band (short, medium, long) based on organ damage and A1c.
    """
    # Check for Long
    if (uacr is not None and uacr >= config.MISMATCH_UACR_THRESHOLD) or \
       (egfr is not None and egfr < config.MISMATCH_EGFR_THRESHOLD):
        return "long"
    
    # Check for Medium
    # Mild renal stress (implied by not being long but maybe not perfect? Spec says "mild renal/liver stress")
    # Spec: "medium -> mild renal/liver stress OR A1c 8-9.5"
    # Let's interpret "mild renal stress" as eGFR < 90 but >= 60, or UACR > normal but < 30?
    # Spec for short: UACR < 30, eGFR >= 90, A1c < 8.
    # So if not short and not long, it's medium.
    
    is_short = True
    if uacr is not None and uacr >= config.CHRONICITY_UACR_SHORT_MAX: is_short = False
    if egfr is not None and egfr < config.CHRONICITY_EGFR_SHORT_MIN: is_short = False
    if hba1c is not None and hba1c >= config.CHRONICITY_A1C_MEDIUM_MIN: is_short = False
    
    if is_short:
        return "short"
        
    return "medium"


def compute_mismatch_score(ir_grade: int,
                           c_peptide: Optional[float],
                           fasting_glucose: Optional[float],
                           pss: int,
                           chronicity_band: str,
                           uacr: Optional[float],
                           egfr: Optional[float]) -> int:
    """
    Calculates the mismatch score (0-4) indicating supply-demand mismatch.
    """
    score = 0
    
    if c_peptide is None:
        return 0 # Cannot compute mismatch without C-peptide
        
    # 1. IR-grade >= 3 and C-peptide < 2.5
    if ir_grade >= config.MISMATCH_IR_GRADE_THRESHOLD and c_peptide < config.MISMATCH_CPEP_HIGH_THRESHOLD:
        score += 1
        
    # 2. FPG >= 130 and C-peptide <= 2.0
    if fasting_glucose is not None and fasting_glucose >= config.MISMATCH_FPG_THRESHOLD and c_peptide <= config.MISMATCH_CPEP_LOW_THRESHOLD:
        score += 1
        
    # 3. PSS >= 3 and C-peptide not high (let's say < 2.5 to be consistent with "not high")
    # Spec says "PSS >= 3 and C-peptide not high". Let's assume < 2.5.
    if pss >= config.MISMATCH_PSS_THRESHOLD and c_peptide < config.MISMATCH_CPEP_HIGH_THRESHOLD:
        score += 1
        
    # 4. Chronicity medium/long and C-peptide < 2.0
    if chronicity_band in ["medium", "long"] and c_peptide < config.MISMATCH_CPEP_LOW_THRESHOLD:
        score += 1
        
    # 5. UACR >= 30 or eGFR < 60
    if (uacr is not None and uacr >= config.MISMATCH_UACR_THRESHOLD) or \
       (egfr is not None and egfr < config.MISMATCH_EGFR_THRESHOLD):
        score += 1
        
    return min(score, 4)


def determine_beta_pattern(c_peptide: Optional[float],
                           ir_grade: int,
                           fasting_glucose: Optional[float],
                           pss: int,
                           chronicity_band: str,
                           uacr: Optional[float],
                           egfr: Optional[float]) -> Dict[str, Any]:
    """
    Determines the beta cell pattern mode and reasons.
    """
    if c_peptide is None:
        return {"mode": "indeterminate", "inferred_stage": 0, "drivers": ["missing_c_peptide"], "reason_summary": "Missing C-peptide data."}
        
    drivers = []
    mode = "compensated" # Default
    inferred_stage = 1
    
    has_damage = (pss >= 3) or \
                 (uacr is not None and uacr >= config.MISMATCH_UACR_THRESHOLD) or \
                 (egfr is not None and egfr < config.MISMATCH_EGFR_THRESHOLD) or \
                 (chronicity_band in ["medium", "long"])
                 
    # Hypersecretion
    # High IR, High Glucose, High C-peptide, Low Organ Damage, PSS <= 2
    if ir_grade >= 3 and \
       fasting_glucose is not None and fasting_glucose > 100 and \
       c_peptide >= 2.5 and \
       not has_damage and pss <= 2:
        mode = "hypersecretion"
        inferred_stage = 1
        drivers.append("high_c_peptide_response")
        reason_summary = "Compensating, in overdrive, still structurally intact."
        
    # Failure
    # Low C-peptide, High Glucose
    elif c_peptide < 0.8 and fasting_glucose is not None and fasting_glucose > 126:
        mode = "failure"
        inferred_stage = 4
        drivers.append("low_c_peptide_high_glucose")
        reason_summary = "True β-cell failure; extensive structural loss."
        
    # Dedifferentiation
    # IR high, Glucose elevated, C-peptide mid-range or falling relative to IR, Damage flags
    elif ir_grade >= 3 and \
         fasting_glucose is not None and fasting_glucose > 100 and \
         c_peptide < 2.5 and \
         has_damage:
        mode = "dedifferentiation"
        inferred_stage = 3
        drivers.append("mismatch_with_damage")
        reason_summary = "Inadequate secretion for demand; identity/function loss."
        
    else:
        # Compensated (Default)
        mode = "compensated"
        inferred_stage = 2
        reason_summary = "Adequate output but IR still present."
        
    return {
        "mode": mode,
        "inferred_stage": inferred_stage,
        "drivers": drivers,
        "reason_summary": reason_summary
    }


def grade_beta(c_peptide: Optional[float],
               ir_grade: int,
               fasting_glucose: Optional[float],
               pss: int,
               chronicity_band: str,
               uacr: Optional[float],
               egfr: Optional[float]) -> Dict[str, Any]:
    """
    v2.1 Beta Grade Logic: 4-Layer Model
    """
    
    # Layer 1: Raw Grade
    if c_peptide is None:
        raw_grade = "UNKNOWN"
    else:
        # Check thresholds in descending order (v2.1)
        # > 3.0 -> A
        # 2.0 - 3.0 -> B1
        # 1.3 - 2.0 -> B2
        # 0.8 - 1.3 -> C
        # < 0.8 -> D
        if c_peptide > 3.0: raw_grade = "A"
        elif c_peptide >= 2.0: raw_grade = "B1"
        elif c_peptide >= 1.3: raw_grade = "B2"
        elif c_peptide >= 0.8: raw_grade = "C"
        else: raw_grade = "D"
        
    if raw_grade == "UNKNOWN":
        return {"grade": "UNKNOWN", "mismatch_score": 0, "pattern": {}}

    # Layer 2: Mismatch Score
    mismatch_score = compute_mismatch_score(ir_grade, c_peptide, fasting_glucose, pss, chronicity_band, uacr, egfr)
    
    # Layer 3: Pattern
    pattern = determine_beta_pattern(c_peptide, ir_grade, fasting_glucose, pss, chronicity_band, uacr, egfr)
    
    # Layer 4: Final Adjustment
    final_grade = raw_grade
    
    # Downgrade logic
    mapping_order = ["A", "B1", "B2", "C", "D"]
    try:
        idx = mapping_order.index(raw_grade)
        
        if mismatch_score >= 2:
            idx = min(idx + 1, 4) # Downgrade one level
            
        if mismatch_score >= 3:
            idx = max(idx, 3) # Enforce at least C (index 3)
            
        if mismatch_score == 4:
            # Enforce D (index 4), EXCEPT if Hypersecretion AND Raw=A
            if pattern["mode"] == "hypersecretion" and raw_grade == "A":
                idx = min(idx, 1) # Cap at B1 (index 1)
            else:
                idx = 4 # Enforce D
                
        final_grade = mapping_order[idx]
        
    except ValueError:
        pass # Should not happen
        
    return {
        "grade": final_grade,
        "mismatch_score": mismatch_score,
        "pattern": pattern
    }


def baseline_reversibility_class(ir_grade: int,
                                 beta_grade: str,
                                 pss: int,
                                 egfr: Optional[float],
                                 uacr: Optional[float],
                                 beta_pattern_mode: str,
                                 mismatch_score: int,
                                 chronicity_band: str,
                                 beta_confidence: str = "HIGH") -> int:
    """
    Computes the baseline Reversibility Class (1-4) using v2.1 Monotonic Logic + Overrides.
    """
    
    # --- 1. Monotonic Baseline Calculation ---
    # We use a weighted score to establish a monotonic baseline before overrides.
    # This ensures that worsening inputs generally lead to a worse class.
    
    score = 0
    
    # IR Grade (0-4)
    if ir_grade >= 4: score += 3
    elif ir_grade == 3: score += 2
    elif ir_grade == 2: score += 1
    
    # Beta Grade (A-D)
    if beta_grade in ["C", "D"]: score += 3
    elif beta_grade == "B2": score += 2
    elif beta_grade == "B1": score += 1
    
    # PSS (0-6)
    if pss >= 5: score += 3
    elif pss >= 3: score += 2
    elif pss >= 1: score += 1
    
    # Renal / Organ Damage
    has_renal_damage = (uacr is not None and uacr >= 30) or (egfr is not None and egfr < 60)
    if has_renal_damage:
        score += 2
        
    # Chronicity
    if chronicity_band == "long": score += 2
    elif chronicity_band == "medium": score += 1
    
    # Map Score to Class 1-4
    # These mapping thresholds are heuristic to align with the "feel" of the classes
    if score <= 2: baseline = 1
    elif score <= 5: baseline = 2
    elif score <= 8: baseline = 3
    else: baseline = 4
    
    # --- 2. Pattern-Based Overrides (v2.1) ---
    
    # E) Confidence Handling
    # If confidence is LOW or pattern INDETERMINATE, skip pattern-based overrides A/B/C
    if beta_confidence == "LOW" or beta_pattern_mode == "indeterminate":
        # Still apply D (Mismatch Override) as it's a safety catch? 
        # Spec says: "Baseline class should rely on IR-grade + PSS + renal markers".
        # We'll stick to the monotonic baseline but apply the Mismatch override (D) as it's a "hard" signal.
        if mismatch_score >= 3:
            baseline = max(baseline, 3)
        return baseline

    final_baseline = baseline

    # A) Hypersecretion Bias (Capacity Exists)
    # Improve by 1 class if hypersecretion, not long chronicity, and kidneys ok
    if beta_pattern_mode == "hypersecretion" and \
       chronicity_band != "long" and \
       not has_renal_damage:
        final_baseline = max(1, final_baseline - 1)

    # B) Dedifferentiation Penalty (Output Inadequate)
    # Worsen by 1 class if dediff suspected AND (mismatch >= 2 OR chronicity med/long)
    if beta_pattern_mode == "dedifferentiation" and \
       (mismatch_score >= 2 or chronicity_band in ["medium", "long"]):
        final_baseline = min(4, final_baseline + 1)

    # C) Failure Floor (True Low Reserve)
    # If Failure OR (Grade C/D + Mismatch >= 3) -> At least Class 3
    if beta_pattern_mode == "failure" or \
       (beta_grade in ["C", "D"] and mismatch_score >= 3):
        final_baseline = max(final_baseline, 3)
        
        # If kidney damage present -> tends to Class 4
        if has_renal_damage:
            final_baseline = 4

    # D) Mismatch Override (Safety Catch)
    # Mismatch >= 3 -> At least Class 3
    if mismatch_score >= 3:
        final_baseline = max(final_baseline, 3)

    return final_baseline


def generate_prognosis(reversibility_class: int,
                       beta_pattern_mode: str,
                       mismatch_score: int,
                       uacr: Optional[float],
                       egfr: Optional[float],
                       hba1c: Optional[float],
                       urine_glucose_grade: Optional[int],
                       chronicity_band: str,
                       beta_confidence: str = "HIGH") -> Dict[str, Any]:
    """
    Generates the prognosis block with window, primary reason, and warnings.
    """
    
    # --- 1. Window Mapping ---
    window = "UNKNOWN"
    
    has_renal_damage = (uacr is not None and uacr >= 30) or (egfr is not None and egfr < 60)
    worsening_glycemia = (hba1c is not None and hba1c >= 8.0) or (urine_glucose_grade is not None and urine_glucose_grade >= 2)

    # URGENT
    if (beta_pattern_mode == "dedifferentiation" and mismatch_score >= 2) or \
       (beta_pattern_mode == "failure") or \
       (has_renal_damage and worsening_glycemia):
        window = "URGENT"
        
    # MODERATE
    elif window == "UNKNOWN": # Only check if not already Urgent
        if (beta_pattern_mode == "hypersecretion") or \
           (reversibility_class == 2 and chronicity_band == "medium"):
            window = "MODERATE"
            
    # STABLE
    if window == "UNKNOWN":
        if (beta_pattern_mode == "compensated") and \
           (chronicity_band == "short") and \
           (not has_renal_damage):
            window = "STABLE"
            
    # --- 2. Primary Reason ---
    reason = "Metabolic staging assessment complete." # Default
    
    if beta_pattern_mode == "hypersecretion":
        reason = "High insulin resistance with high C-peptide suggests hypersecretion (overdrive) rather than weak reserve."
    elif beta_pattern_mode == "dedifferentiation":
        reason = "High insulin resistance with inappropriately low C-peptide for demand suggests early decline/dedifferentiation pattern."
    elif beta_pattern_mode == "failure":
        reason = "Low C-peptide with high glycemia indicates low reserve/failure pattern; focus shifts to control and protection."
    elif beta_pattern_mode == "compensated":
        reason = "Insulin output is currently compensating for resistance, but metabolic burden remains."
    elif mismatch_score >= 3:
        reason = "Significant mismatch between insulin output and metabolic demand."
        
    # --- 3. Warnings ---
    warnings = [
        "This engine provides staging inference, not a diagnosis. Use clinical judgment and follow-up testing."
    ]
    
    if beta_confidence == "LOW" or beta_pattern_mode == "indeterminate":
        warnings.append("Low confidence: C-peptide/IR/stress markers incomplete; pattern may change when missing labs are added.")
        
    if uacr is None and egfr is None:
        warnings.append("Renal markers missing; long-term risk constraints may be underestimated.")

    return {
        "reversibility_class": reversibility_class,
        "window": window,
        "primary_reason": reason,
        "warnings": warnings
    }


def apply_modifiers(base_class: int,
                    tsh: Optional[float],
                    cortisol_am: Optional[float],
                    uacr: Optional[float],
                    ferritin: Optional[float]) -> Dict[str, Any]:
    
    c = base_class
    modifiers = {
        "thyroid_penalty_applied": False,
        "cortisol_penalty_applied": False,
        "uacr_penalty_applied": False,
        "ferritin_cap_applied": False,
        "hyperthyroid_flag": False
    }

    # Thyroid penalty
    if tsh is not None:
        if tsh > config.MODIFIER_THRESHOLDS["tsh_penalty"]:
            c = min(4, c + 1)
            modifiers["thyroid_penalty_applied"] = True
        elif tsh < config.TSH_THRESHOLDS["hyper"]["max"]:
            modifiers["hyperthyroid_flag"] = True

    # Cortisol penalty
    if cortisol_am is not None and cortisol_am > config.MODIFIER_THRESHOLDS["cortisol_penalty"]:
        c = min(4, c + 1)
        modifiers["cortisol_penalty_applied"] = True

    # UACR penalty
    if uacr is not None and uacr > config.MODIFIER_THRESHOLDS["uacr_penalty"] and c < 4:
        c = min(4, c + 1)
        modifiers["uacr_penalty_applied"] = True

    # Ferritin cap
    if ferritin is not None and ferritin > config.FERRITIN_CAP_THRESHOLD and c < 3:
        c = 3
        modifiers["ferritin_cap_applied"] = True

    modifiers["final_class"] = c
    return modifiers


def compute_ambiguity(input_data: Dict[str, Any],
                      ir_grade: int,
                      beta_grade: str) -> Dict[str, Any]:
    
    missing = [k for k in config.REQUIRED_FIELDS_FOR_LOW_AMBIGUITY if input_data.get(k) is None]

    # High ambiguity if missing fasting insulin or C-peptide
    if input_data.get("fasting_insulin_microU") is None or \
       input_data.get("c_peptide_ngml") is None:
        level = "HIGH"
    else:
        if len(missing) == 0:
            level = "LOW"
        else:
            level = "MEDIUM"

    notes = []
    if level != "LOW":
        notes.append("Some key parameters are missing; staging may be less precise.")
    if beta_grade == "UNKNOWN":
        notes.append("β-Grade could not be computed because C-peptide is missing.")

    return {
        "level": level,
        "missing_fields_for_low_ambiguity": missing,
        "notes": notes
    }


def compute_metabolic_staging(input_data: Dict[str, Any]) -> Dict[str, Any]:
    """
    Core engine: accepts input_data dict and returns a structured output dict.
    """

    # --- Unpack inputs ---
    sex = input_data.get("sex")
    fasting_glucose = input_data.get("fasting_glucose_mgdl")
    hba1c = input_data.get("hba1c_pct")
    fasting_insulin = input_data.get("fasting_insulin_microU")
    c_peptide = input_data.get("c_peptide_ngml")

    lipase = input_data.get("lipase_u")
    lipase_uln = input_data.get("lipase_uln")
    amylase = input_data.get("amylase_u")
    amylase_uln = input_data.get("amylase_uln")

    magnesium = input_data.get("magnesium_mgdl")
    vitamin_b12 = input_data.get("vitamin_b12_pgml")
    homocysteine = input_data.get("homocysteine_umoll")
    vitamin_d = input_data.get("vitamin_d_ngml")
    ferritin = input_data.get("ferritin_ngml")

    # triglycerides = input_data.get("triglycerides_mgdl")
    # hdl = input_data.get("hdl_mgdl")
    # ldl = input_data.get("ldl_mgdl")

    # creatinine = input_data.get("creatinine_mgdl")
    egfr = input_data.get("egfr_ml_min_173")

    # alt = input_data.get("alt_u")
    # ast = input_data.get("ast_u")
    # ggt = input_data.get("ggt_u")

    uacr = input_data.get("uacr_mg_per_g")
    urine_glucose_grade = input_data.get("urine_glucose_grade")

    tsh = input_data.get("tsh_miul")
    cortisol_am = input_data.get("cortisol_am_ugdl")

    waist_cm = input_data.get("waist_cm")
    height_cm = input_data.get("height_cm")

    # --- Derived indices ---
    homa_ir = compute_homa_ir(fasting_glucose, fasting_insulin)
    whtr = compute_whtr(waist_cm, height_cm)

    # --- Chronicity Band ---
    chronicity_band = compute_chronicity_band(uacr, egfr, hba1c)

    # --- IR-Score ---
    score_homa = score_homa_ir(homa_ir)
    score_a1c = score_hba1c(hba1c)
    score_gly = score_glycosuria(urine_glucose_grade)
    score_micro = score_micronutrients(magnesium, vitamin_b12, homocysteine, vitamin_d)
    score_thy = score_thyroid(tsh)
    score_cort = score_cortisol(cortisol_am)
    score_ferr = score_ferritin(ferritin, sex)
    score_wt = score_whtr(whtr)

    ir_score_raw = (score_homa + score_a1c + score_gly +
                    score_micro + score_thy + score_cort +
                    score_ferr + score_wt)
    ir_score = min(ir_score_raw, 10)
    
    # IR Grade
    ir_grade = config.get_ir_grade(ir_score)

    # --- Pancreatic Stress Score (PSS) ---
    # Computed early as it feeds into Beta logic now
    pss = compute_pss(lipase, lipase_uln, amylase, amylase_uln, fasting_glucose, magnesium)

    # --- β-Grade (v2.1) ---
    beta_info = grade_beta(c_peptide, ir_grade, fasting_glucose, pss, chronicity_band, uacr, egfr)
    beta_grade = beta_info["grade"]
    mismatch_score = beta_info["mismatch_score"]
    beta_pattern = beta_info["pattern"]

    # --- Baseline Reversibility ---
    # Determine confidence (simple heuristic for now)
    beta_confidence = "HIGH"
    if beta_pattern.get("mode") == "indeterminate":
        beta_confidence = "LOW"

    base_class = baseline_reversibility_class(ir_grade, beta_grade, pss, egfr, uacr,
                                              beta_pattern.get("mode", "compensated"), 
                                              mismatch_score, chronicity_band, beta_confidence)

    # --- Modifiers ---
    modifier_info = apply_modifiers(base_class, tsh, cortisol_am, uacr, ferritin)
    final_class = modifier_info["final_class"]

    # --- Ambiguity ---
    ambiguity_info = compute_ambiguity(input_data, ir_grade, beta_grade)

    # --- Prognosis (v2.1) ---
    prognosis = generate_prognosis(final_class, 
                                   beta_pattern.get("mode", "compensated"), 
                                   mismatch_score, 
                                   uacr, egfr, hba1c, urine_glucose_grade, 
                                   chronicity_band, 
                                   beta_confidence)

    # --- Build output ---
    output = {
        "engine": {
            "version": "2.1",
            "build": "2025-11-29",
            "schema_version": "2.1"
        },
        "input": input_data,
        "derived": {
            "homa_ir": homa_ir,
            "whtr": whtr,
            "chronicity_band": chronicity_band
        },
        "scores": {
            "ir_score": ir_score,
            "ir_grade": ir_grade,
            "beta_grade": beta_grade,
            "mismatch_score": mismatch_score,
            "pss": pss,
            "reversibility_class": {
                "baseline": base_class,
                "final_after_modifiers": final_class
            }
        },
        "prognosis": prognosis,
        "beta_cell_pattern": beta_pattern,
        "modifiers": modifier_info,
        "ambiguity": ambiguity_info,
        "notes": {
            "pss_is_not_pancreatitis_diagnosis": True,
            "beta_dedifferentiation_inference_is_heuristic": True,
            "heuristic_components_present": True
        }
    }

    return output

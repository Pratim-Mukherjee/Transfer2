#!/usr/bin/env python3
"""
Metabolic Staging Engine v2 - CLI + JSON

- Prompts user for lab + anthropometry from command line
- Builds an input JSON
- Calls the core engine (metabolic_staging_core)
- Prints JSON output

This is a testing harness; for API usage, import metabolic_staging_core directly.
"""

import json
from typing import Optional, List
from backend import metabolic_staging_core as core

# ---------- Utility input helpers ----------

def prompt_float(label: str) -> Optional[float]:
    s = input(f"{label} (leave blank if unknown): ").strip()
    if not s:
        return None
    try:
        return float(s)
    except ValueError:
        print(f"Invalid number for {label}, treating as missing.")
        return None


def prompt_int(label: str) -> Optional[int]:
    s = input(f"{label} (leave blank if unknown): ").strip()
    if not s:
        return None
    try:
        return int(s)
    except ValueError:
        print(f"Invalid integer for {label}, treating as missing.")
        return None


def prompt_str(label: str, allowed: Optional[List[str]] = None) -> Optional[str]:
    s = input(f"{label} (leave blank if unknown): ").strip()
    if not s:
        return None
    if allowed is not None:
        s_lower = s.lower()
        if s_lower not in allowed:
            print(f"Invalid value for {label}, allowed: {allowed}. Treating as missing.")
            return None
        return s_lower
    return s


# ---------- CLI entrypoint ----------

def main():
    print("=== Metabolic Staging Engine v2 - CLI ===")
    print("Enter patient data. Press Enter to skip any unknown value.\n")

    sex = prompt_str("Sex (male / female / other)", allowed=["male", "female", "other"])

    fasting_glucose = prompt_float("Fasting glucose (mg/dL)")
    hba1c = prompt_float("HbA1c (%)")
    fasting_insulin = prompt_float("Fasting insulin (µU/mL)")
    c_peptide = prompt_float("Fasting C-peptide (ng/mL)")

    lipase = prompt_float("Lipase (U/L)")
    lipase_uln = prompt_float("Lipase ULN (upper limit of normal, U/L)")
    amylase = prompt_float("Amylase (U/L)")
    amylase_uln = prompt_float("Amylase ULN ( U/L)")

    magnesium = prompt_float("Magnesium (mg/dL)")
    vitamin_b12 = prompt_float("Vitamin B12 (pg/mL)")
    homocysteine = prompt_float("Homocysteine (µmol/L)")
    vitamin_d = prompt_float("Vitamin D, 25(OH) (ng/mL)")
    ferritin = prompt_float("Ferritin (ng/mL)")

    triglycerides = prompt_float("Triglycerides (mg/dL)")
    hdl = prompt_float("HDL (mg/dL)")
    ldl = prompt_float("LDL (mg/dL)")

    creatinine = prompt_float("Creatinine (mg/dL)")
    egfr = prompt_float("eGFR (mL/min/1.73 m²)")

    alt = prompt_float("ALT (U/L)")
    ast = prompt_float("AST (U/L)")
    ggt = prompt_float("GGT (U/L)")

    uacr = prompt_float("Urine albumin/creatinine ratio (UACR, mg/g)")

    urine_glucose_grade_str = prompt_str("Urine glucose grade (0, 1, 2, 3)", allowed=["0", "1", "2", "3"])
    urine_glucose_grade = int(urine_glucose_grade_str) if urine_glucose_grade_str is not None else None

    tsh = prompt_float("TSH (mIU/L)")
    cortisol_am = prompt_float("Morning cortisol (µg/dL)")

    waist_cm = prompt_float("Waist circumference (cm)")
    height_cm = prompt_float("Height (cm)")

    # Build input dict
    input_data = {
        "sex": sex,
        "fasting_glucose_mgdl": fasting_glucose,
        "hba1c_pct": hba1c,
        "fasting_insulin_microU": fasting_insulin,
        "c_peptide_ngml": c_peptide,
        "lipase_u": lipase,
        "lipase_uln": lipase_uln,
        "amylase_u": amylase,
        "amylase_uln": amylase_uln,
        "magnesium_mgdl": magnesium,
        "vitamin_b12_pgml": vitamin_b12,
        "homocysteine_umoll": homocysteine,
        "vitamin_d_ngml": vitamin_d,
        "ferritin_ngml": ferritin,
        "triglycerides_mgdl": triglycerides,
        "hdl_mgdl": hdl,
        "ldl_mgdl": ldl,
        "creatinine_mgdl": creatinine,
        "egfr_ml_min_173": egfr,
        "alt_u": alt,
        "ast_u": ast,
        "ggt_u": ggt,
        "uacr_mg_per_g": uacr,
        "urine_glucose_grade": urine_glucose_grade,
        "tsh_miul": tsh,
        "cortisol_am_ugdl": cortisol_am,
        "waist_cm": waist_cm,
        "height_cm": height_cm,
    }

    result = core.compute_metabolic_staging(input_data)
    print("\n=== Output JSON ===")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()

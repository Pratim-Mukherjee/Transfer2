
import sys
import os
import json

# Add project root to path
sys.path.append(os.getcwd())

from backend import metabolic_staging_core as core
from backend import metabolic_staging_config as config

def test_case(name, input_data, expected_derived=None, expected_scores=None):
    print(f"\n--- Testing: {name} ---")
    result = core.compute_metabolic_staging(input_data)
    
    # Verify Derived
    if expected_derived:
        for k, v in expected_derived.items():
            actual = result["derived"].get(k)
            if actual is not None and abs(actual - v) > 0.01:
                print(f"❌ Derived {k}: Expected {v}, got {actual}")
            else:
                print(f"✅ Derived {k}: {actual}")

    # Verify Scores
    if expected_scores:
        for k, v in expected_scores.items():
            actual = result["scores"].get(k)
            # Handle nested dicts if necessary, but here we just check top level scores
            if k == "reversibility_class":
                # Check baseline and final
                if "baseline" in v:
                    if result["scores"]["reversibility_class"]["baseline"] != v["baseline"]:
                        print(f"❌ Class Baseline: Expected {v['baseline']}, got {result['scores']['reversibility_class']['baseline']}")
                    else:
                        print(f"✅ Class Baseline: {result['scores']['reversibility_class']['baseline']}")
                if "final" in v:
                    if result["scores"]["reversibility_class"]["final_after_modifiers"] != v["final"]:
                        print(f"❌ Class Final: Expected {v['final']}, got {result['scores']['reversibility_class']['final_after_modifiers']}")
                    else:
                        print(f"✅ Class Final: {result['scores']['reversibility_class']['final_after_modifiers']}")
            elif actual != v:
                print(f"❌ Score {k}: Expected {v}, got {actual}")
            else:
                print(f"✅ Score {k}: {actual}")

# Case 1: Healthy
case1_input = {
    "sex": "male",
    "fasting_glucose_mgdl": 85,
    "fasting_insulin_microU": 5,
    "hba1c_pct": 5.0,
    "c_peptide_ngml": 2.5,
    "waist_cm": 80,
    "height_cm": 180,
    "lipase_u": 40, "lipase_uln": 60,
    "amylase_u": 50, "amylase_uln": 100,
    "magnesium_mgdl": 2.2,
    "egfr_ml_min_173": 100
}
# HOMA = 85*5/405 = 1.05 -> Score 1 (1.0-1.8)
# HbA1c 5.0 -> Score 0
# WHtR = 80/180 = 0.44 -> Score 0
# IR Score = 1
# Beta: 2.5 -> A
# PSS: Normal -> 0
# Class: 1

test_case("Healthy Male", case1_input, 
          expected_derived={"homa_ir": 1.049}, 
          expected_scores={"ir_score": 1, "beta_grade": "A", "pss": 0, "reversibility_class": {"baseline": 1, "final": 1}})

# Case 2: Severe IR, Beta Dysfunction
case2_input = {
    "sex": "female",
    "fasting_glucose_mgdl": 150,
    "fasting_insulin_microU": 25,
    "hba1c_pct": 8.5,
    "c_peptide_ngml": 0.8, # Grade C
    "waist_cm": 110,
    "height_cm": 160,
    "lipase_u": 150, "lipase_uln": 60, # Ratio 2.5 -> Score 3
    "amylase_u": 100, "amylase_uln": 100,
    "magnesium_mgdl": 1.5, # < 1.6 -> +2 points micronutrients, +1 PSS add-on
    "tsh_miul": 12.0, # > 10 -> +1 Class penalty
    "egfr_ml_min_173": 90
}
# HOMA = 150*25/405 = 9.25 -> Score 4
# HbA1c 8.5 -> Score 3
# WHtR = 110/160 = 0.68 -> Score 2
# Micro: Mg < 1.6 -> 2
# Thyroid: >10 -> 2 (Score)
# IR Score = 4+3+2+2+2 = 13 -> Cap 10
# Beta: 0.8 -> C
# PSS: Lipase > 2.0 (3) + Mg < 1.6 (1) = 4
# Class Baseline: IR 4, Beta C, PSS 4 -> Likely Class 3
# Class Final: Baseline + 1 (Thyroid) -> Class 4 (Max)

test_case("Severe IR + Thyroid", case2_input,
          expected_derived={"homa_ir": 9.26},
          expected_scores={"ir_score": 10, "beta_grade": "C", "pss": 4, "reversibility_class": {"final": 4}})

# Case 3: Beta Downgrade Logic
case3_input = {
    "sex": "male",
    "fasting_glucose_mgdl": 150, # >= 140
    "fasting_insulin_microU": 2.0, # < 3.0
    "c_peptide_ngml": 2.2, # Base A
    "hba1c_pct": 6.0
}
# Beta Base A -> Downgrade to B1

test_case("Beta Downgrade", case3_input,
          expected_scores={"beta_grade": "B1"})

print("\nVerification Complete.")

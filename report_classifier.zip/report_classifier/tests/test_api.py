"""
Test script for Metabolic Staging API
"""

from fastapi.testclient import TestClient
from backend.metabolic_staging_api import app
import json

client = TestClient(app)

def test_calculate_staging():
    payload = {
        "sex": "male",
        "fasting_glucose_mgdl": 100,
        "hba1c_pct": 5.7,
        "fasting_insulin_microU": 10,
        "c_peptide_ngml": 1.5,
        "waist_cm": 90,
        "height_cm": 175,
        # Add some optional fields to verify they pass through
        "lipase_u": 50,
        "tsh_miul": 2.0
    }
    
    response = client.post("/calculate-staging", json=payload)
    
    print("Status Code:", response.status_code)
    if response.status_code == 200:
        print("Response JSON:")
        print(json.dumps(response.json(), indent=2))
    else:
        print("Error:", response.text)

    # Basic assertions
    assert response.status_code == 200
    data = response.json()
    assert "scores" in data
    assert "ir_score" in data["scores"]
    assert data["input"]["sex"] == "male"
    print("\nTest Passed!")

if __name__ == "__main__":
    test_calculate_staging()

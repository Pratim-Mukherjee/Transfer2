import sys
import os
import json

# Add project root to path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from backend.metabolic_staging_core import compute_metabolic_staging

def get_nested_value(data, key_path):
    keys = key_path.split(".")
    val = data
    for k in keys:
        if isinstance(val, dict):
            val = val.get(k)
        else:
            return None
    return val

def run_test(name, input_data, expected_checks):
    print(f"--- Test: {name} ---")
    result = compute_metabolic_staging(input_data)
    
    all_passed = True
    for key, expected_val in expected_checks.items():
        actual_val = get_nested_value(result, key)
            
        if actual_val != expected_val:
            print(f"❌ {key}: Expected {expected_val}, got {actual_val}")
            all_passed = False
        else:
            print(f"✅ {key}: {actual_val}")
            
    if all_passed:
        print(">> PASS\n")
    else:
        print(">> FAIL\n")
        # Print full result for debugging if fail
        # print(json.dumps(result, indent=2))

# 1. Hypersecretion Case
# High IR, High Glucose, High C-Pep (>3.0), Low Stress
# Should be Pattern: Hypersecretion, Grade: A (Raw A, Mismatch 0 -> Stays A)
# Reversibility: Baseline should improve (e.g. 2 -> 1)
test_hyper = {
    "sex": "male",
    "fasting_glucose_mgdl": 110,
    "fasting_insulin_microU": 25, # High IR
    "c_peptide_ngml": 3.5, # High C-Pep (Raw A)
    "lipase_u": 20, "lipase_uln": 60, # Low PSS
    "amylase_u": 20, "amylase_uln": 100,
    "waist_cm": 100, "height_cm": 170,
    "hba1c_pct": 5.5, # Short chronicity
    "uacr_mg_per_g": 10, "egfr_ml_min_173": 100 # Normal Renal
}
checks_hyper = {
    "beta_cell_pattern.mode": "hypersecretion",
    "scores.mismatch_score": 0, 
    "scores.beta_grade": "A", # Raw A, Mismatch 0 -> Stays A
    "scores.reversibility_class.baseline": 1, # Improved by override
    "prognosis.window": "MODERATE" # Hypersecretion -> Moderate
}

# 2. Dedifferentiation Case
# High IR, High Glucose, Mid C-Pep (1.8 -> Raw B2), High Stress
# Should be Pattern: Dedifferentiation, Grade: D (Downgraded from B2 due to Mismatch 4)
# Reversibility: Worsened
test_dediff = {
    "sex": "male",
    "fasting_glucose_mgdl": 140, # Mismatch pt
    "fasting_insulin_microU": 20, # IR High
    "c_peptide_ngml": 1.8, # Raw B2
    "lipase_u": 180, "lipase_uln": 60, # PSS High -> Mismatch pt
    "waist_cm": 100, "height_cm": 170,
    "hba1c_pct": 8.5, # Medium Chronicity
    "uacr_mg_per_g": 40 # Renal Damage
}
checks_dediff = {
    "beta_cell_pattern.mode": "dedifferentiation",
    "scores.beta_grade": "D", # Mismatch 4 -> Enforce D
    "scores.mismatch_score": 4, # High mismatch (IR, FPG, PSS, Chronicity, Renal -> 5 -> Cap 4)
    "scores.reversibility_class.baseline": 4, # Worsened/Floor
    "prognosis.window": "URGENT" # Dediff + Mismatch >= 2 -> Urgent
}

# 3. Failure Case
# Low C-Pep (<0.8), High Glucose
test_failure = {
    "sex": "male",
    "fasting_glucose_mgdl": 200,
    "c_peptide_ngml": 0.5, # Raw D
    "waist_cm": 90, "height_cm": 170,
    "hba1c_pct": 10.0
}
checks_failure = {
    "beta_cell_pattern.mode": "failure",
    "scores.beta_grade": "D",
    "scores.reversibility_class.baseline": 3, # Failure Floor (at least 3)
    "prognosis.window": "URGENT"
}

# 4. Chronicity Long
# Long: eGFR < 60
test_chronic = {
    "sex": "male",
    "egfr_ml_min_173": 50,
    "c_peptide_ngml": 2.0,
    "fasting_glucose_mgdl": 100,
    "fasting_insulin_microU": 10
}
checks_chronic = {
    "derived.chronicity_band": "long",
    "scores.reversibility_class.baseline": 3 # eGFR < 60 -> Score adds up to Class 3 range or close
}

if __name__ == "__main__":
    run_test("Hypersecretion", test_hyper, checks_hyper)
    run_test("Dedifferentiation", test_dediff, checks_dediff)
    run_test("Failure", test_failure, checks_failure)
    run_test("Chronicity Long", test_chronic, checks_chronic)

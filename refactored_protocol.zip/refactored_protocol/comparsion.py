import os
import json
import requests
from datetime import datetime
from analysis_engine import parse_thyrocare_xml, classify_patient, CONFIG

XML_REPORT_URL = "http://192.168.1.20:8084/medicalreport/getxmlreports/{user_id}"

def compare_reports(prev_data, curr_data, category_map):
    def get_marker_value(data, marker):
        marker_data = data.get(marker, {})
        val = marker_data.get("value")
        try:
            return float(val)
        except (TypeError, ValueError):
            return None

    def get_indicator(data, marker):
        return data.get(marker, {}).get("indicator", "WHITE")

    raw_prev = prev_data.get("rawData", {})
    raw_curr = curr_data.get("rawData", {})

    all_markers = sorted(set(raw_prev.keys()) | set(raw_curr.keys()))

    improved, worsened, stable = [], [], []
    categorized_changes = {}
    key_affected_areas_set = set()

    for marker in all_markers:
        prev_val = get_marker_value(raw_prev, marker)
        curr_val = get_marker_value(raw_curr, marker)
        prev_ind = get_indicator(raw_prev, marker)
        curr_ind = get_indicator(raw_curr, marker)

        if prev_val is None or curr_val is None:
            continue

        change = round(curr_val - prev_val, 2)
        unit = raw_curr.get(marker, {}).get("unit", "")
        trend = {
            "marker": marker,
            "previous_value": prev_val,
            "current_value": curr_val,
            "change": change,
            "unit": unit,
            "previous_indicator": prev_ind,
            "current_indicator": curr_ind
        }

        category = category_map.get(marker, "Uncategorized")
        categorized_changes.setdefault(category, {"improved": [], "worsened": [], "stable": []})

        if prev_ind == "RED" and curr_ind in {"WHITE", "BLUE"}:
            trend["change_description"] = "Moved toward normal range"
            improved.append(trend)
            categorized_changes[category]["improved"].append(trend)
        elif prev_ind in {"WHITE", "BLUE"} and curr_ind == "RED":
            trend["change_description"] = "Moved outside normal range"
            worsened.append(trend)
            categorized_changes[category]["worsened"].append(trend)
            key_affected_areas_set.add(category)
        elif abs(change) >= 0.5:
            if change > 0:
                trend["change_description"] = "Increased significantly"
                worsened.append(trend)
                categorized_changes[category]["worsened"].append(trend)
                key_affected_areas_set.add(category)
            else:
                trend["change_description"] = "Decreased significantly"
                improved.append(trend)
                categorized_changes[category]["improved"].append(trend)
        else:
            trend["change_description"] = "Stable"
            stable.append(trend)
            categorized_changes[category]["stable"].append(trend)

    progression = {
        "previousReportDate": prev_data.get("report_date"),
        "currentReportDate": curr_data.get("report_date"),
        "overallTrendStatement": "",
        "overallTrendIcon": "",
        "overallTrendColorClass": "",
        "negativeChanges": {
            "summary_statement": "",
            "key_affected_areas": sorted(list(key_affected_areas_set)),
            "contributing_markers_summary": worsened,
            "potential_root_causes": [],
            "recommended_focus_areas": []
        },
        "positiveChanges": {
            "summary_statement": "",
            "key_affected_areas": [],
            "contributing_markers_summary": improved,
            "potential_root_causes": [],
            "recommended_focus_areas": []
        },
        "markerSummary": {
            "total": len(all_markers),
            "improved": len(improved),
            "worsened": len(worsened),
            "stable": len(stable)
        },
        "stableMarkers": stable,
        "categorizedChanges": categorized_changes
    }

    if worsened:
        progression["overallTrendStatement"] = "Significant Worsening in Metabolic Health"
        progression["overallTrendIcon"] = "trending_down"
        progression["overallTrendColorClass"] = "trend-negative"
        progression["negativeChanges"]["summary_statement"] = (
            "Multiple key health indicators show significant negative progression."
        )
    if improved:
        progression["positiveChanges"]["summary_statement"] = (
            "Some improvements noted in specific markers."
        )

    return progression

def analyze_with_progression():
    user_id = input("Enter user ID to fetch reports: ")
    response = requests.get(XML_REPORT_URL.format(user_id=user_id))
    if response.status_code != 200:
        print("❌ Failed to fetch reports metadata from API.")
        return

    try:
        data = response.json()
        if "content" not in data or len(data["content"]) < 2:
            print("❌ API did not return two report URLs.")
            return

        urls = data["content"][:2]

        xml_files = []
        for i, url in enumerate(urls, start=1):
            xml_response = requests.get(url)
            if xml_response.status_code != 200:
                print(f"❌ Failed to download XML report from {url}")
                return
            filename = f"report{i}.xml"
            with open(filename, "wb") as f:
                f.write(xml_response.content)
            xml_files.append(filename)

    except Exception as e:
        print(f"❌ Error while processing API response or downloading reports: {e}")
        return

    intermediate_files = []
    report_data_list = []
    for i, xml_file in enumerate(xml_files, start=1):
        info, full_results, input_data = parse_thyrocare_xml(xml_file)
        classification = classify_patient(input_data, CONFIG, info)

        intermediate_data = {
            "patientInfo": info,
            "reportDate": info.get("report_date"),
            "rawData": full_results,
            "analysisInput": input_data,
            "analysisResults": classification
        }

        intermediate_filename = f"intermediate_report{i}.json"
        with open(intermediate_filename, "w") as f:
            json.dump(intermediate_data, f, indent=4)
        intermediate_files.append(intermediate_filename)
        report_data_list.append(intermediate_data)

    prev_data, curr_data = report_data_list

    date1 = datetime.strptime(prev_data["reportDate"], "%Y-%m-%d")
    date2 = datetime.strptime(curr_data["reportDate"], "%Y-%m-%d")
    if date1 > date2:
        prev_data, curr_data = curr_data, prev_data

    category_map = {}
    analytic_drivers = curr_data.get("analysisResults", {}).get("analyticDrivers", {})
    for category, block in analytic_drivers.items():
        for marker in block.get("markers", []):
            category_map[marker["marker"]] = category

    progression = compare_reports(
        {"rawData": prev_data["rawData"], "report_date": prev_data["reportDate"]},
        {"rawData": curr_data["rawData"], "report_date": curr_data["reportDate"]},
        category_map
    )

    prev_score = prev_data.get("analysisResults", {}).get("overallRiskScore")
    curr_score = curr_data.get("analysisResults", {}).get("overallRiskScore")
    progression["overallRiskScore"] = {
        "previous": prev_score,
        "current": curr_score,
        "change": round(curr_score - prev_score, 2) if prev_score is not None and curr_score is not None else None,
        "trend_icon": "trending_up" if curr_score and prev_score and curr_score > prev_score else (
            "trending_down" if curr_score and prev_score and curr_score < prev_score else "trending_flat"
        )
    }

    os.makedirs("data", exist_ok=True)
    combined_report = {
        "patientInfo": curr_data["patientInfo"],
        "previousReport": {
            "reportDate": prev_data["reportDate"],
            "analysisResults": {
                "phenotypeResults": prev_data["analysisResults"].get("phenotypeResults", {}),
                "pathwayResults": prev_data["analysisResults"].get("pathwayResults", {})
            }
        },
        "currentReport": {
            "reportDate": curr_data["reportDate"],
            "analysisResults": {
                "phenotypeResults": curr_data["analysisResults"].get("phenotypeResults", {}),
                "pathwayResults": curr_data["analysisResults"].get("pathwayResults", {})
            }
        },
        "progressionAnalysis": progression
    }

    with open("combined_report.json", "w") as f:
        json.dump(combined_report, f, indent=4)

    print("✅ Full report with categorized comparison saved to data/report_data.json")

if __name__ == "__main__":
    analyze_with_progression()


// script.js (Complete and Corrected)

document.addEventListener('DOMContentLoaded', function() {

document.getElementById("printButton").addEventListener("click", function() {
    // Optional: Hide UI elements like buttons before printing
    window.print();
});


    // --- Global variables for charts ---
    let riskGaugeChartInstance = null;
    let pathwayChartInstance = null;
    let complicationRadarChartInstance = null;

    // --- DOM Elements ---
    const dashboardContainer = document.querySelector('.dashboard-container');
    const dashboardMainContentEl = document.getElementById('dashboardMainContent');
    const dashboardStatusMessageEl = document.getElementById('dashboardStatusMessage');
    //const fileInput = document.getElementById('jsonFile');
    const fileLoadErrorEl = document.getElementById('fileLoadError'); // Error message near input

    // --- Helper Functions ---

    function getRiskColor(score, scaleMax = 10) {
        const percentage = (score / scaleMax) * 100;
        if (percentage >= 80) return '#c0392b'; // Darker Red (Very High)
        if (percentage >= 70) return '#e74c3c'; // Red (High)
        if (percentage >= 50) return '#e67e22'; // Orange (Moderate)
        if (percentage >= 30) return '#f1c40f'; // Yellow (Guarded)
        return '#2ecc71'; // Green (Low)
    }

    function getRiskClass(percentage) {
        if (percentage >= 80) return 'risk-very-high';
        if (percentage >= 70) return 'risk-high';
        if (percentage >= 50) return 'risk-moderate';
        if (percentage >= 30) return 'risk-guarded';
        return 'risk-low';
    }

    // Map complication keys to icons and friendly names
    const complicationMeta = {
        "CVD": { icon: "fas fa-heart", name: "Cardiovascular Disease (CVD)" },
        "Retinopathy": { icon: "fas fa-eye", name: "Retinopathy" },
        "Neuropathy": { icon: "fas fa-brain", name: "Neuropathy" },
        "Nephropathy": { icon: "fas fa-kidneys", name: "Nephropathy" },
        "NAFLD/Hepatic complications": { icon: "fas fa-liver", name: "NAFLD/Hepatic" },
        "Endocrine and nutritional metabolic disruption": { icon: "fas fa-prescription-bottle-alt", name: "Endocrine/Metabolic" }
        // Add entries for any other complications defined in config
    };

    // Helper to parse different normal range formats (e.g., "< 100", "70-100", "> 50")
    function parseNormalRange(rangeStr) {
        if (!rangeStr || typeof rangeStr !== 'string') return null;
        rangeStr = rangeStr.trim();

        // Simple number (treat as upper limit, lower is 0 or undefined)
        let match = rangeStr.match(/^(\d+\.?\d*)$/);
        if (match) return { low: 0, high: parseFloat(match[1]) }; // Assuming 0 is lowest possible

        // Less than (< X)
        match = rangeStr.match(/^<\s*(\d+\.?\d*)$/);
        if (match) return { low: null, high: parseFloat(match[1]) };

        // Less than or equal (<= X)
         match = rangeStr.match(/^<=\s*(\d+\.?\d*)$/);
        if (match) return { low: null, high: parseFloat(match[1]) };

        // Greater than (> X)
        match = rangeStr.match(/^>\s*(\d+\.?\d*)$/);
        if (match) return { low: parseFloat(match[1]), high: null };

         // Greater than or equal (>= X)
         match = rangeStr.match(/^>=\s*(\d+\.?\d*)$/);
        if (match) return { low: parseFloat(match[1]), high: null };

        // Range (X - Y) or (X-Y)
        match = rangeStr.match(/^(\d+\.?\d*)\s*-\s*(\d+\.?\d*)$/);
        if (match) return { low: parseFloat(match[1]), high: parseFloat(match[2]) };

        // Range (X to Y) - Added
        match = rangeStr.match(/^(\d+\.?\d*)\s+to\s+(\d+\.?\d*)$/i);
        if (match) return { low: parseFloat(match[1]), high: parseFloat(match[2]) };


        return null; // Unable to parse
    }

    // *** CORRECTED getStatusInfo Function ***
    function getStatusInfo(value, normalRangeStr, indicator) {
        // Check for null/undefined value FIRST
        if (value === null || value === undefined) {
             // ADDED THIS RETURN STATEMENT
             return { class: 'status-unknown', text: ' ', icon: '' };
        }

        // Use indicator first if it's RED (often means out of range)
        // Also check for other potential flag indicators if needed (e.g., 'HIGH', 'LOW' text)
        if (indicator && ['RED', 'HIGH', 'H', 'L', 'LOW'].includes(indicator.toUpperCase())) {
            const range = parseNormalRange(normalRangeStr);
            if (range) {
                if (range.low !== null && value < range.low) return { class: 'status-low', text: 'LOW', icon: '<i class="fas fa-arrow-down"></i>' };
                if (range.high !== null && value > range.high) return { class: 'status-high', text: 'HIGH', icon: '<i class="fas fa-arrow-up"></i>' };
            }
            // If indicator is flagged but value is within parsed range (or range unparsable), still show flagged
             if (indicator.toUpperCase() === 'L' || indicator.toUpperCase() === 'LOW') {
                 return { class: 'status-low', text: 'LOW', icon: '<i class="fas fa-arrow-down"></i>' };
             }
              if (indicator.toUpperCase() === 'H' || indicator.toUpperCase() === 'HIGH' || indicator.toUpperCase() === 'RED') { // Treat RED as high if not low
                 return { class: 'status-high', text: 'HIGH', icon: '<i class="fas fa-arrow-up"></i>' };
             }
            // Generic fallback for other flags
            return { class: 'status-flagged', text: 'FLAGGED', icon: '<i class="fas fa-flag"></i>' };
        }

        // If indicator suggests normal (e.g., WHITE) or is missing, check against range
        const range = parseNormalRange(normalRangeStr);
        if (range) {
            if (range.low !== null && value < range.low) return { class: 'status-low', text: 'LOW', icon: '<i class="fas fa-arrow-down"></i>' };
            if (range.high !== null && value > range.high) return { class: 'status-high', text: 'HIGH', icon: '<i class="fas fa-arrow-up"></i>' };
            return { class: 'status-normal', text: 'NORMAL', icon: '' }; // Within range
        }

        // Fallback if range parsing fails and indicator isn't explicitly flagged
         return { class: 'status-unknown', text: 'Normal', icon: '' }; // Changed fallback to unknown if range fails
    }
    // *** END OF CORRECTED getStatusInfo ***

     // Function to get influence icons
    function getInfluenceIcons(markerName, analysisResults) {
        if (!analysisResults) return '-';
        let icons = '';
        // Normalize the marker name from the data for comparison
        const normMarkerData = markerName.toLowerCase().replace(/[\s-_()]/g, "");

        // Check Phenotypes
        if (analysisResults.phenotypeResults && Object.values(analysisResults.phenotypeResults).some(p =>
            p.matched_markers && p.matched_markers.some(m => {
                 // Normalize marker name from the config rules
                 const normMarkerConfig = m.toLowerCase().replace(/[\s-_()]/g, "");
                 return normMarkerConfig === normMarkerData;
            })
        )) {
            icons += '<i class="fas fa-dna influence-area-icon" title="Phenotype"></i>';
        }
         // Check Pathways
        if (analysisResults.pathwayResults && Object.values(analysisResults.pathwayResults).some(p =>
            p.matched_markers && p.matched_markers.some(m => {
                const normMarkerConfig = m.toLowerCase().replace(/[\s-_()]/g, "");
                return normMarkerConfig === normMarkerData;
            })
        )) {
            icons += '<i class="fas fa-project-diagram influence-area-icon" title="Pathway"></i>';
        }
         // Check Complications
        if (analysisResults.complicationResults && Object.values(analysisResults.complicationResults).some(p =>
            p.matched_markers && p.matched_markers.some(m => {
                const normMarkerConfig = m.toLowerCase().replace(/[\s-_()]/g, "");
                return normMarkerConfig === normMarkerData;
            })
        )) {
             icons += '<i class="fas fa-heartbeat influence-area-icon" title="Complication"></i>';
        }

        return icons || '-'; // Return '-' if no icons were added
    }


    // --- Function to Populate Dashboard from JSON data ---
    function populateDashboard(data) {
        console.log("Populating dashboard with data:", data);
        try {
            const patientInfo = data.patientInfo || {};
            const rawData = data.rawData || {}; // This now includes value, unit, range, indicator
            const analysisResults = data.analysisResults || {};
            const reportDate = data.reportDate || new Date().toLocaleDateString(); // Use formatted date from JSON

            // --- Reset UI State ---
            dashboardStatusMessageEl.style.display = 'none'; // Hide status message
            dashboardMainContentEl.style.display = 'grid'; // Show main content
            fileLoadErrorEl.style.display = 'none'; // Hide file input error

            // Destroy existing charts before creating new ones
            if (riskGaugeChartInstance) riskGaugeChartInstance.destroy();
            if (pathwayChartInstance) pathwayChartInstance.destroy();
            if (complicationRadarChartInstance) complicationRadarChartInstance.destroy();


            // --- Populate Header ---
            document.getElementById('patientName').textContent = patientInfo.name || 'N/A';
            document.getElementById('patientAgeSex').textContent = patientInfo.age_sex || 'N/A';
            document.getElementById('orderNumber').textContent = patientInfo.order_no || 'N/A';
            document.getElementById('reportDate').textContent = reportDate;


            // --- A. Overall Status & Glycemic Control ---
            const overallRiskScore = analysisResults.overallRiskScore !== undefined ? analysisResults.overallRiskScore : 0;
            const riskColor = getRiskColor(overallRiskScore);
            const riskLabel = (overallRiskScore >= 8 ? "VERY HIGH RISK" : overallRiskScore >= 7 ? "HIGH RISK" : overallRiskScore >= 5 ? "MODERATE RISK" : overallRiskScore >= 3 ? "GUARDED RISK" : "LOW RISK");

            document.getElementById('riskGaugeValue').textContent = `${overallRiskScore.toFixed(2)} / 10`;
            document.getElementById('riskGaugeLabel').textContent = riskLabel;
            document.getElementById('riskGaugeLabel').style.color = riskColor;

            const trajectoryMarker = document.getElementById('trajectoryMarker');
            const markerPosition = Math.min(Math.max(overallRiskScore * 10, 0), 100);
            trajectoryMarker.style.left = `${markerPosition}%`;
            trajectoryMarker.style.color = riskColor;

            // Glycemic Info - Safely access potentially missing keys from rawData
            const hba1cData = rawData["HbA1c"];
            const abgData = rawData["Average Blood Glucose (ABG)"];
            // Try multiple keys for fasting glucose robustness
            const fbsKeys = ["Fasting Blood Sugar (Glucose)", "FASTING BLOOD SUGAR(GLUCOSE)"];
            let fastingGlucoseData = null;
            for (const key of fbsKeys) {
                if (rawData[key]) {
                    fastingGlucoseData = rawData[key];
                    break;
                }
            }

            const hba1cValue = hba1cData?.value;
            const avgGlucoseValue = abgData?.value;
            const fastingGlucoseValue = fastingGlucoseData?.value;

            document.getElementById('hba1cValue').textContent = hba1cValue !== undefined && hba1cValue !== null ? hba1cValue.toFixed(1) : '--';
            document.getElementById('eAGValue').textContent = avgGlucoseValue !== undefined && avgGlucoseValue !== null ? avgGlucoseValue.toFixed(1) : '--';
            document.getElementById('fastingGlucoseValue').textContent = fastingGlucoseValue !== undefined && fastingGlucoseValue !== null ? fastingGlucoseValue.toFixed(2) : '--';

            const hba1cStatusEl = document.getElementById('hba1cStatus');
            const fastingGlucoseStatusEl = document.getElementById('fastingGlucoseStatus');

            // Basic status icons for glycemic control (can be enhanced with getStatusInfo if preferred)
            if (hba1cValue !== undefined && hba1cValue !== null) {
                hba1cStatusEl.innerHTML = hba1cValue < 5.7 ? '<i class="fas fa-check-circle status-icon-good"></i>' : (hba1cValue < 6.5 ? '<i class="fas fa-exclamation-triangle status-icon-warning"></i>' : '<i class="fas fa-times-circle status-icon-bad"></i>');
            } else { hba1cStatusEl.innerHTML = ''; }

            if (fastingGlucoseValue !== undefined && fastingGlucoseValue !== null) {
                fastingGlucoseStatusEl.innerHTML = fastingGlucoseValue < 100 ? '<i class="fas fa-check-circle status-icon-good"></i>' : (fastingGlucoseValue < 126 ? '<i class="fas fa-exclamation-triangle status-icon-warning"></i>' : '<i class="fas fa-times-circle status-icon-bad"></i>');
            } else { fastingGlucoseStatusEl.innerHTML = ''; }


            const contrastMessageEl = document.getElementById('contrastMessage');
            if (overallRiskScore >= 7 && hba1cValue !== undefined && hba1cValue < 6.5) {
                 contrastMessageEl.style.display = 'flex';
            } else {
                 contrastMessageEl.style.display = 'none';
            }

             // Risk Gauge Chart
             const gaugeCtx = document.getElementById('riskGaugeChart').getContext('2d');
             riskGaugeChartInstance = new Chart(gaugeCtx, {
                type: 'doughnut',
                data: { datasets: [{ data: [overallRiskScore, Math.max(0, 10 - overallRiskScore)], backgroundColor: [riskColor, '#e9ecef'], borderWidth: 0, circumference: 180, rotation: 270 }] },
                options: { responsive: true, maintainAspectRatio: true, aspectRatio: 2, cutout: '75%', plugins: { tooltip: { enabled: false }, legend: { display: false } } }
            });


            // --- B. Phenotype ---
            const bestPhenotype = analysisResults.bestMatches?.phenotype || { name: "N/A", value: 0 };
            const phenotypeResults = analysisResults.phenotypeResults || {};

            document.getElementById('dominantPhenotypeName').textContent = bestPhenotype.name !== 'N/A' ? bestPhenotype.name.replace(/_/g, ' ') : '--';
            document.getElementById('dominantPhenotypeMatch').textContent = `${bestPhenotype.value.toFixed(2)}%`;

            const secondaryPhenotypes = Object.entries(phenotypeResults)
                .filter(([key]) => key !== bestPhenotype.name)
                .sort(([, a], [, b]) => b.match_percentage - a.match_percentage);

            document.getElementById('secondaryPhenotype1').textContent = secondaryPhenotypes.length > 0 ? `${secondaryPhenotypes[0][0].replace(/_/g, ' ')}: ${secondaryPhenotypes[0][1].match_percentage.toFixed(2)}%` : '--';
            document.getElementById('secondaryPhenotype2').textContent = secondaryPhenotypes.length > 1 ? `${secondaryPhenotypes[1][0].replace(/_/g, ' ')}: ${secondaryPhenotypes[1][1].match_percentage.toFixed(2)}%` : '--';


            const phenotypeDriversList = document.getElementById('phenotypeDriversList');
            phenotypeDriversList.innerHTML = ''; // Clear previous
            const dominantPhenotypeData = phenotypeResults[bestPhenotype.name];
            const matchedMarkersPheno = (dominantPhenotypeData && Array.isArray(dominantPhenotypeData.matched_markers)) ? dominantPhenotypeData.matched_markers : [];

            if (matchedMarkersPheno.length > 0) {
                 matchedMarkersPheno.forEach(marker => {
                     const markerData = rawData[marker]; // Get full data for the marker
                     if (markerData !== undefined && markerData.value !== null && markerData.value !== undefined) {
                         const statusInfo = getStatusInfo(markerData.value, markerData.normal_range, markerData.indicator);
                         const li = document.createElement('li');
                         // Use status-label class for consistent styling
                         li.innerHTML = `<strong>${marker}:</strong> <span class="status-label ${statusInfo.class}">${markerData.value.toFixed(2)} ${statusInfo.icon}</span>`;
                         phenotypeDriversList.appendChild(li);
                     }
                 });
            } else {
                 phenotypeDriversList.innerHTML = '<li>No specific contributing markers identified.</li>';
            }


            // --- C. Pathways (Chart) ---
            const pathwayResults = analysisResults.pathwayResults || {};
            const pathwayCtx = document.getElementById('pathwayChart').getContext('2d');
            // Ensure pathwayResults is an object before calling Object.entries
             const sortedPathways = typeof pathwayResults === 'object' && pathwayResults !== null ? Object.entries(pathwayResults)
                 .filter(([, data]) => data.match_percentage > 0 || (data.matched_markers && data.matched_markers.length > 0))
                 .sort(([, a], [, b]) => b.match_percentage - a.match_percentage) : [];


            if (sortedPathways.length > 0) {
                const pathwayLabels = sortedPathways.map(([name]) => name.replace(/_/g, ' '));
                const pathwayData = sortedPathways.map(([, data]) => data.match_percentage);
                const pathwayColors = pathwayData.map(p => getRiskColor(p, 100));
                const pathwayMarkersTooltips = sortedPathways.map(([, data]) => (Array.isArray(data.matched_markers) ? data.matched_markers.join(', ') : 'N/A'));

                pathwayChartInstance = new Chart(pathwayCtx, {
                    type: 'bar',
                    data: { labels: pathwayLabels, datasets: [{ label: 'Activation %', data: pathwayData, backgroundColor: pathwayColors, borderColor: pathwayColors.map(c => Chart.helpers.color(c).darken(0.2).rgbString()), borderWidth: 1 }] },
                     options: {
                        indexAxis: 'y', responsive: true, maintainAspectRatio: false,
                        scales: { x: { beginAtZero: true, max: 100, ticks: { color: '#333' }, grid: { color: '#eee' } }, y: { ticks: { color: '#333', autoSkip: false, font: {size: 10} }, grid: { display: false } } },
                        plugins: { legend: { display: false }, tooltip: { callbacks: { label: ctx => `${ctx.dataset.label || ''}: ${ctx.parsed.x.toFixed(2)}%`, afterLabel: ctx => `Matched Markers: ${pathwayMarkersTooltips[ctx.dataIndex] || 'None'}` } } }
                    }
                });
            } else {
                 pathwayCtx.clearRect(0, 0, pathwayCtx.canvas.width, pathwayCtx.canvas.height);
                 pathwayCtx.textAlign = 'center'; pathwayCtx.fillStyle = '#888';
                 pathwayCtx.fillText("No pathway activity data available.", pathwayCtx.canvas.width / 2, 50);
            }


            // --- D. Complications (Radar Chart + Details List) ---
             const complicationResults = analysisResults.complicationResults || {};
             const complicationCtx = document.getElementById('complicationRadarChart').getContext('2d');
             // Ensure complicationResults is an object before calling Object.entries
            const complicationEntries = typeof complicationResults === 'object' && complicationResults !== null ? Object.entries(complicationResults) : [];
             const complicationDetailsList = document.getElementById('complicationDetailsList');
             complicationDetailsList.innerHTML = ''; // Clear previous

             if (complicationEntries.length > 0) {
                 const complicationLabels = complicationEntries.map(([key]) => complicationMeta[key]?.name || key.replace(/_/g, ' '));
                 const complicationData = complicationEntries.map(([, data]) => data.match_percentage);
                 const bestCompRiskColor = getRiskColor(analysisResults.bestMatches?.complication?.value || 0, 100);
                 const radarFillColor = Chart.helpers.color(bestCompRiskColor).alpha(0.3).rgbString();

                 complicationRadarChartInstance = new Chart(complicationCtx, {
                    type: 'radar',
                    data: { labels: complicationLabels, datasets: [{ label: 'Risk Match %', data: complicationData, fill: true, backgroundColor: radarFillColor, borderColor: bestCompRiskColor, pointBackgroundColor: bestCompRiskColor, pointBorderColor: '#fff', pointHoverBackgroundColor: '#fff', pointHoverBorderColor: bestCompRiskColor }] },
                     options: {
                         responsive: true, maintainAspectRatio: false,
                         scales: { r: { beginAtZero: true, max: 100, angleLines: { color: '#ccc' }, grid: { color: '#ddd' }, pointLabels: { font: { size: 11 }, color: '#333' }, ticks: { backdropColor: 'rgba(255, 255, 255, 0.7)', color: '#555', stepSize: 20 } } },
                         plugins: { legend: { display: false }, tooltip: { callbacks: { label: ctx => `${ctx.dataset.label}: ${ctx.raw.toFixed(2)}%` } } }
                     }
                 });

                 // Complication Details List
                 complicationEntries
                     .sort(([, a], [, b]) => b.match_percentage - a.match_percentage)
                     .forEach(([key, itemData]) => {
                         const meta = complicationMeta[key] || { icon: "fas fa-question-circle", name: key.replace(/_/g, ' ') };
                         const percentage = itemData.match_percentage;
                         const riskClass = getRiskClass(percentage);
                         const matchedMarkersComp = Array.isArray(itemData.matched_markers) ? itemData.matched_markers : [];
                         const drivers = matchedMarkersComp.slice(0, 4).join(', ') + (matchedMarkersComp.length > 4 ? '...' : '');

                         const li = document.createElement('li');
                         li.innerHTML = `
                             <i class="complication-icon ${meta.icon} ${riskClass}"></i>
                             <div class="complication-info">
                                 <span class="name">${meta.name}</span>
                                 <div class="complication-bar-percent">
                                     <div class="complication-risk-bar-container">
                                         <div class="complication-risk-bar ${riskClass}" style="width: ${percentage.toFixed(2)}%;"></div>
                                     </div>
                                     <span class="complication-percent ${riskClass}">${percentage.toFixed(2)}%</span>
                                 </div>
                                 <span class="complication-drivers"><i class="fas fa-flask"></i> Matched Markers: ${drivers || 'None'}</span>
                             </div>
                         `;
                         complicationDetailsList.appendChild(li);
                     });

             } else {
                  complicationCtx.clearRect(0, 0, complicationCtx.canvas.width, complicationCtx.canvas.height);
                  complicationCtx.textAlign = 'center'; complicationCtx.fillStyle = '#888';
                  complicationCtx.fillText("No complication risk data available.", complicationCtx.canvas.width / 2, 50);
                  complicationDetailsList.innerHTML = '<li>No complication risk data available.</li>';
             }



// --- E. Current Complications (Self-Reported) ---
const currentComplicationsData = data.currentComplications || {};
const currentComplicationsContainer = document.getElementById("currentComplicationsContainer");
currentComplicationsContainer.innerHTML = ''; // Clear previous

const activeComplications = Object.entries(currentComplicationsData)
    .filter(([, details]) => details.is_present === true);

if (activeComplications.length === 0) {
    currentComplicationsContainer.innerHTML = '<p>No reported complications based on questionnaire.</p>';
} else {
    activeComplications.forEach(([compName, compData]) => {
        const compSection = document.createElement("div");
        compSection.classList.add("complication-report-block");

        const title = document.createElement("h3");
        title.textContent = compName.replace(/_/g, ' '); // prettify name
        compSection.appendChild(title);

        if (Array.isArray(compData.contributing_questions) && compData.contributing_questions.length > 0) {
            const ul = document.createElement("ul");
            compData.contributing_questions.forEach(q => {
                const li = document.createElement("li");
                li.innerHTML = `<strong>Q:</strong> ${q.question}<br><strong>A:</strong> ${q.answer}`;
                ul.appendChild(li);
            });
            compSection.appendChild(ul);
        } else {
            compSection.innerHTML += "<p>No specific contributing questions available.</p>";
        }

        currentComplicationsContainer.appendChild(compSection);
    });
}
// --- F. Abnormal Marker Categories ---
const abnormalMarkersSummary = data.abnormalMarkersSummary || {};
const abnormalMarkersContainer = document.getElementById("abnormalMarkersContainer");
abnormalMarkersContainer.innerHTML = ''; // Clear previous

const categories = Object.entries(abnormalMarkersSummary);

if (categories.length === 0) {
    abnormalMarkersContainer.innerHTML = '<p>No abnormal marker categories found.</p>';
} else {
    categories.forEach(([category, details]) => {
        const block = document.createElement("div");
        block.classList.add("abnormal-marker-block");

        const title = document.createElement("h3");
        title.textContent = category;
        block.appendChild(title);

        const desc = document.createElement("p");
        desc.textContent = details.description || 'No description provided.';
        block.appendChild(desc);

        abnormalMarkersContainer.appendChild(block);
    });
}


            // --- E. Key Drivers Table ---
            // --- E. Key Drivers Table ---
const driversTableBody = document.getElementById('driversTable').querySelector('tbody');
driversTableBody.innerHTML = ''; // Clear previous

const analyticDrivers = data.analyticDrivers || {};
let driversFound = false;

for (const category in analyticDrivers) {
    const markersList = analyticDrivers[category].markers;
    if (!markersList || markersList.length === 0) continue;

    // Insert category row
    const categoryRow = document.createElement('tr');
    categoryRow.classList.add('category-row');
    const categoryCell = document.createElement('td');
    categoryCell.colSpan = 6;
    categoryCell.style.fontWeight = 'bold';
    categoryCell.textContent = category;
    categoryRow.appendChild(categoryCell);
    driversTableBody.appendChild(categoryRow);

    // Insert marker rows
    markersList.forEach(marker => {
        const name = marker.marker;
        const value = marker.value;
        const unit = marker.unit || '';
        const normalRange = marker.normal_range || 'N/A';
        const indicator = marker.indicator || 'N/A';

        const statusInfo = getStatusInfo(value, normalRange, indicator);
        const influenceIcons = getInfluenceIcons(name, data.analysisResults);

        driversFound = true;

        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td>${name}</td>
            <td style="text-align: right;">
  ${value !== null && value !== undefined && !isNaN(Number(value)) ? Number(value).toFixed(2) : 'N/A'} ${unit}
</td>

            <td style="text-align: center;"><span class="status-label ${statusInfo.class}">${statusInfo.text} ${statusInfo.icon}</span></td>
            <td style="text-align: center;"><span class="indicator-label indicator-${indicator.toLowerCase().trim()}">${indicator}</span></td>
            <td>${normalRange}</td>
            <td style="text-align: center;"><span class="influence-area-icons">${influenceIcons}</span></td>
        `;
        driversTableBody.appendChild(tr);
    });
}

if (!driversFound) {
    driversTableBody.innerHTML = '<tr><td colspan="6" style="text-align: center;">No specific key drivers identified based on current criteria.</td></tr>';
}


             if (!driversFound) {
                 driversTableBody.innerHTML = '<tr><td colspan="6" style="text-align: center;">No specific key drivers identified based on current criteria.</td></tr>';
             }

        } catch (error) {
            console.error("Error populating dashboard:", error);
            dashboardMainContentEl.style.display = 'none'; // Hide content on error
            dashboardStatusMessageEl.textContent = `Error displaying data: ${error.message}. Please check console for details.`;
            dashboardStatusMessageEl.classList.add('error');
            dashboardStatusMessageEl.style.display = 'flex';
        }

    } // --- End of populateDashboard ---


     // --- Event Listener for JSON File Input ---
     document.getElementById("runButton").addEventListener("click", function () {
    const selectedFile = document.getElementById("patientSelect").value;

    fetch("run_analysis.php", {
        method: "POST",
        headers: {
            "Content-Type": "application/x-www-form-urlencoded",
        },
        body: "xml_file=" + encodeURIComponent(selectedFile),
    })
    .then((response) => response.text())
    .then((data) => {
        try {
            const jsonData = JSON.parse(data);
            document.getElementById("fileLoadError").style.display = "none";
            populateDashboard(jsonData);
        } catch (e) {
            document.getElementById("fileLoadError").textContent = "Error parsing JSON from server.";
            document.getElementById("fileLoadError").style.display = "block";
        }
    })
    .catch((error) => {
    console.error("Error during fetch:", error);
    document.getElementById("fileLoadError").textContent = "Fetch error: " + error.message;
    document.getElementById("fileLoadError").style.display = "block";
});

});


    // --- Initial State Setup ---
    dashboardMainContentEl.style.display = 'none'; // Ensure content is hidden initially
    dashboardStatusMessageEl.textContent = 'Awaiting analysis data file...'; // Set initial message
    dashboardStatusMessageEl.classList.remove('error');
    dashboardStatusMessageEl.style.display = 'flex'; // Show the initial status

}); // End DOMContentLoaded

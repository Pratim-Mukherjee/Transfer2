<?php
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $user_id = $_POST["user_id"] ?? null;

    if (!$user_id) {
        http_response_code(400);
        echo "❌ Error: Missing user_id.";
        exit;
    }

    // Run the protocol generator
    $output = [];
    $return_code = 0;
    exec("python3 generate_protocol.py 2>&1", $output, $return_code);

    if ($return_code === 0) {
 
        echo implode("\n", $output);

        // Append contents of final_display.json
        $final_file = "final_display.json";
        if (file_exists($final_file)) {
            $final_json = file_get_contents($final_file);
 
            echo $final_json;
        } else {
            echo "\n\n⚠️ final_display.json not found.";
        }
    } else {
        echo "❌ Protocol generation failed:\n" . implode("\n", $output);
    }
} else {
    echo "Invalid request method.";
}
?>

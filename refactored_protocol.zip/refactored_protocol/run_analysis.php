<?php
if ($_SERVER["REQUEST_METHOD"] === "POST") {
  
    $xmlFile = isset($_POST["xml_file"]) ? escapeshellarg($_POST["xml_file"]) : null;
 
    $pythonScript = escapeshellarg("analysis_engine.py");

    // Run the Python script with the XML file as an argument
    $command = "python3 $pythonScript --user-id $xmlFile";
    shell_exec($command);

    // Define the fixed JSON output file (adjust path as needed)
    $jsonFile = "analysis_output.json";
    $secondaryFile = "input_data.json";  // 🆕 Additional output file
    // Set header for JSON response
    header("Content-Type: application/json");

    // Read and output the JSON file if it exists
    if (file_exists($jsonFile)) {
        $jsonData = file_get_contents($jsonFile);
        file_put_contents($secondaryFile, $jsonData);
        echo $jsonData;
    } else {
        echo json_encode(["error" => "JSON file not found"]);
    }
}
?>


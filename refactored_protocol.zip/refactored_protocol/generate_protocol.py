import json
import re
import argparse
from datetime import datetime
from datetime import datetime, timedelta

from fetch_all_data import (
    fetch_all_data,
    fetch_bp_summary,
    fetch_hrv_summary,
    fetch_stress_summary,
    fetch_sleep_summary,
    fetch_activity_summary 
)

def load_json(file_path):
    """Load JSON data from a file."""
    try:
        with open(file_path, 'r') as file:
            return json.load(file)
    except Exception as e:
        print(f"Error loading {file_path}: {e}")
        return None

def save_json(data, file_path):
    """Save data to a JSON file."""
    try:
        with open(file_path, 'w', encoding="utf-8") as file:
            json.dump(data, file, indent=4, ensure_ascii=False)
 
    except Exception as e:
        print(f"Error saving to {file_path}: {e}")

def calculate_rmr(gender, weight, height, age, lookups):
    """Calculate Resting Metabolic Rate using Mifflin-St Jeor Equation."""
    formula = lookups["rmr_calculation"].get(gender.lower(), lookups["rmr_calculation"]["male"])["formula"]
    height_cm = height * 30.48  # Convert feet to cm (assuming height in feet)
    return round(eval(formula, {"weight": weight, "height": height_cm, "age": age}))

def get_classification(value, lookup_ranges):
    """Get classification based on value and ranges in lookups."""
    try:
        value = float(value)
        for key, range_data in lookup_ranges.items():
            if range_data["min"] <= value <= range_data["max"]:
                return range_data.get("text", "Unknown")
    except (ValueError, TypeError):
        return "Unknown"
    return "Unknown"

def get_c_peptide_assessment(value, lookups):
    """Assess C-Peptide value and return descriptive text."""
    try:
        value = float(value)
        for key, range_data in lookups["c_peptide_ranges"].items():
            if range_data["min"] <= value <= range_data["max"]:
                return {
                    "function": range_data["text"],
                    "insulin_text": range_data["insulin_text"],
                    "reversal_text": range_data["reversal_text"],
                    "reserve": range_data["reserve"],
                    "functional": range_data["functional"]
                }
    except (ValueError, TypeError):
        pass
    return {"function": "Unknown", "insulin_text": "unknown", "reversal_text": "uncertain", "reserve": "Unknown", "functional": "unknown"}

def get_age_assessment(age, lookups):
    """Assess metabolic flexibility based on age."""
    try:
        age = int(age)
        for key, range_data in lookups["age_metabolic_flexibility"].items():
            if range_data["min"] <= age <= range_data["max"]:
                return {"text": range_data["text"], "potential": range_data["potential"]}
    except (ValueError, TypeError):
        pass
    return {"text": "Unknown", "potential": "unknown"}

def get_hba1c_onset(value, lookups):
    """Assess diabetes onset stage based on HbA1c."""
    try:
        value = float(value)
        for key, range_data in lookups["hba1c_onset"].items():
            if range_data["min"] <= value <= range_data["max"]:
                return {"text": range_data["text"], "description": range_data["description"]}
    except (ValueError, TypeError):
        pass
    return {"text": "Unknown", "description": "unknown"}

def get_liver_marker_assessment(value, marker_key, lookups):
    """Return dict with assessment, threshold (max), and target text from lookups for the given marker_key."""
    try:
        v = float(value)
    except (ValueError, TypeError):
        return {"assessment": "Unknown", "threshold": None, "target": None}

    marker_lookup = lookups.get(marker_key, {})
    # iterate through the named ranges in lookups (order shouldn't matter if ranges don't overlap)
    for label, info in marker_lookup.items():
        try:
            if info["min"] <= v <= info["max"]:
                return {
                    "assessment": info.get("assessment", "Unknown"),
                    "threshold": info.get("max"),
                    "target": info.get("assessment")  # may be None
                }
        except KeyError:
            continue
    return {"assessment": "Unknown", "threshold": None, "target": None}

def get_activity_level(weight, lookups, default="sedentary"):
    """Determine activity level (placeholder logic, can be refined with data)."""
    # Placeholder: Assuming sedentary unless data suggests otherwise
    return lookups["activity_levels"].get(default, lookups["activity_levels"]["sedentary"])

def add_supplement_recommendations(lab_values, lookups):
    supplements = {"morning": [], "evening": []}
    rules = lookups.get("lab_deficiency_supplements", {})

    for marker, value in lab_values.items():
        rule = rules.get(marker)
        try:
            value = float(value)
            if rule and "low" in rule.get("thresholds", {}):
                if value < rule["thresholds"]["low"]:
                    entry = {
                        "supplement": rule["supplement"],
                        "dose": rule["dose"],
                        "reason": rule["reason"],
                        "how_it_helps": rule.get("how_it_helps", "")
                    }
                    supplements[rule["timing"]].append(entry)
        except Exception:
            continue  # skip invalid

   # Omega-3 conditional trigger (based on lipids)
    try:
        tg = float(lab_values.get("triglycerides", 0))
        ldl = float(lab_values.get("ldl", 0))
        ratio = float(lab_values.get("tg_hdl_ratio", 0))

        if tg > 100 or ldl > 120 or ratio > 2.0:
            omega3_rule = rules.get("omega_3")
            if omega3_rule:
                entry = {
                    "supplement": omega3_rule["supplement"],
                    "dose": omega3_rule["dose"],
                    "reason": "Triggered by elevated TG, LDL, or TG/HDL ratio",
                    "how_it_helps": omega3_rule.get("how_it_helps", "")
                }
                supplements[omega3_rule["timing"]].append(entry)
    except Exception:
        pass

    return supplements

def generate_personalized_protocol(input_data, lookups, template, health_data):
    """Generate the personalized protocol by populating the template with data."""
    personalized_data = template.copy()
    patient_info = input_data.get("patientInfo", {})
    raw_data = input_data.get("rawData", {})
    anthropometric = input_data.get("anthropometricMeasures", {})
    # Get user ID
    patient_id = input_data.get("userProfile", {}).get("content", {}).get("id")

    # Fetch health data summaries
    for key in [
    "activity_summary", "blood_pressure_summary",
    "hrv_summary", "stress_summary", "sleep_summary"
    ]:
        if isinstance(health_data.get(key), dict):
            health_data[key].pop("raw_data", None)

    # Use these extracted averages

    activity_summary = health_data.get("activity_summary", {})
    bp_data = health_data.get("blood_pressure_summary", {})
    hrv_data = health_data.get("hrv_summary", {})
    stress_data = health_data.get("stress_summary", {})
    sleep_data = health_data.get("sleep_summary", {})

    personalized_data["activity_summary"] = activity_summary
    personalized_data["hrv_summary"] = hrv_data
    personalized_data["stress_summary"] = stress_data
    personalized_data["sleep_summary"] = sleep_data

    # Set up energy expenditure structure
    if "energy_expenditure_analysis" not in personalized_data["current_metabolic_state"]:
        personalized_data["current_metabolic_state"]["energy_expenditure_analysis"] = {}
    if "active_energy" not in personalized_data["current_metabolic_state"]["energy_expenditure_analysis"]:
        personalized_data["current_metabolic_state"]["energy_expenditure_analysis"]["active_energy"] = {}

    # Extract activity details
    try:
        avg_active_burn = activity_summary.get("average_calrories_burned", 0)
        activity_level_text = activity_summary.get("activityLevel", "Unknown")
        activity_description = activity_summary.get("description", "")
    except Exception as e:
        print(f"⚠️ Could not load activity summary: {e}")
        avg_active_burn = 200
        activity_level_text = "sedentary"
        activity_description = "Minimal movement"

    # Inject activity data
    energy = personalized_data["current_metabolic_state"]["energy_expenditure_analysis"]
    energy["active_energy"]["activity_level"] = f"{activity_level_text} ({activity_description})"
    energy["active_energy"]["daily_burn"] = f"{avg_active_burn:.1f} calories (7-day avg activity)"

    # Populate Profile Section
    personalized_data["profile"]["name"] = patient_info.get("name", "N/A")
    personalized_data["profile"]["age"] = str(patient_info.get("age", "N/A"))
    personalized_data["profile"]["gender"] = patient_info.get("gender", "N/A").capitalize()
    personalized_data["profile"]["start_date"] = datetime.now().strftime("%Y-%m-%d")
    personalized_data["profile"]["physician"] = "[Physician Name, Credentials - To Be Assigned]"
    personalized_data["profile"]["coach"] = "[Coach Name, Credentials - To Be Assigned]"
    personalized_data["profile"]["medical_report"] = f"{patient_info.get('report_date', 'N/A')} from [Lab/Hospital Name - To Be Confirmed]"
    personalized_data["profile"]["emergency_contact"] = "[Phone Number - To Be Provided]"

    # Populate Current Metabolic State - Lab Profile
    # Diabetes Markers
    diabetes_markers = personalized_data["current_metabolic_state"]["lab_profile_targets"]["diabetes_markers"]

    # HbA1c
    hba1c_value = float(raw_data.get('HbA1c', {}).get('value', 0))
    diabetes_markers["hba1c"]["current"] = f"{hba1c_value}%"
    if hba1c_value >= 6.0:
        diabetes_markers["hba1c"]["target"] = "6.0% by Week 12*"
    else:
        diabetes_markers["hba1c"]["target"] = "Within Target"

    # Average Glucose (informational only)
    avg_glucose_value = raw_data.get('AVERAGE BLOOD GLUCOSE (ABG)', {}).get('value', 'N/A')
    diabetes_markers["avg_glucose"]["current"] = f"~{avg_glucose_value} mg/dL"

    # Fasting Glucose
    fasting_value = float(raw_data.get('FASTING BLOOD SUGAR(GLUCOSE)', {}).get('value', 0))
    diabetes_markers["fasting_glucose"]["current"] = f"{fasting_value} mg/dL"
    if fasting_value >= 100:
        diabetes_markers["fasting_glucose"]["target"] = "85 mg/dL by Week 8*"
    else:
        diabetes_markers["fasting_glucose"]["target"] = "Within Target"

    # Liver glucose release note (only if glucose or HbA1c elevated)
    if hba1c_value >= 6.0 or fasting_value >= 100:
        diabetes_markers["liver_glucose"] = "Liver releasing excess glucose overnight → will normalize"

    # C-Peptide and Pancreatic Function
    c_peptide_value = float(raw_data.get("C-PEPTIDE", {}).get("value", 0))
    c_peptide_assessment = get_c_peptide_assessment(c_peptide_value, lookups)
    diabetes_markers["c_peptide"]["current"] = f"{c_peptide_value} ng/mL"
    diabetes_markers["c_peptide"]["function"] = c_peptide_assessment["function"]
    diabetes_markers["pancreas_insulin"] = (
        f"Your pancreas can still make {c_peptide_assessment['insulin_text']} insulin - reversal {c_peptide_assessment['reversal_text']}"
    )

    # Metabolic Health Markers
    metabolic_markers = personalized_data["current_metabolic_state"]["lab_profile_targets"]["metabolic_health_markers"]
    def _get_raw_value(keys):
        """Try multiple possible raw data key names in order; return None if not found."""
        for k in keys:
            val = raw_data.get(k)
            if isinstance(val, dict) and val.get("value") not in (None, ""):
                return val.get("value")
            # sometimes raw_data stores the numeric directly in analysisInput — try that too
            if raw_data.get(k) not in (None, "") and not isinstance(raw_data.get(k), dict):
                return raw_data.get(k)
        return None

    # ALT
    alt_raw_keys = ["ALANINE TRANSAMINASE (SGPT)", "ALANINE TRANSAMINASE (ALT)", "ALANINE TRANSAMINASE"]
    alt_val = _get_raw_value(alt_raw_keys)
    alt_num = float(alt_val) if alt_val not in (None, "") else None
    alt_assess = get_liver_marker_assessment(alt_num if alt_num is not None else 0, "alt_liver_fat", lookups)

    metabolic_markers["liver_health_alt"]["current"] = f"{alt_num if alt_num is not None else 'N/A'} U/L"
    # use lookup target if provided; otherwise mark "Within Target" when assessment is "Normal"
    if alt_assess.get("target"):
        metabolic_markers["liver_health_alt"]["target"] = alt_assess["target"]
    else:
        metabolic_markers["liver_health_alt"]["target"] = "Within Target" if alt_assess["assessment"] == "Normal" else f"<{alt_assess['threshold']} U/L by Week 10*"

    # AST (SGOT)
    ast_raw_keys = ["Aspartate Aminotransferase (SGOT)", "ASPARTATE AMINOTRANSFERASE (SGOT)", "AST", "SGOT"]
    ast_val = _get_raw_value(ast_raw_keys)
    ast_num = float(ast_val) if ast_val not in (None, "") else None
    ast_assess = get_liver_marker_assessment(ast_num if ast_num is not None else 0, "ast_liver_fat", lookups)

    metabolic_markers["liver_health_ast"]["current"] = f"{ast_num if ast_num is not None else 'N/A'} U/L"
    if ast_assess.get("target"):
        metabolic_markers["liver_health_ast"]["target"] = ast_assess["target"]
    else:
        metabolic_markers["liver_health_ast"]["target"] = "Within Target" if ast_assess["assessment"] == "Normal" else f"<{ast_assess['threshold']} U/L by Week 10*"

    # GGT
    ggt_raw_keys = ["GAMMA GLUTAMYL TRANSFERASE (GGT)", "GGT"]
    ggt_val = _get_raw_value(ggt_raw_keys)
    ggt_num = float(ggt_val) if ggt_val not in (None, "") else None
    ggt_assess = get_liver_marker_assessment(ggt_num if ggt_num is not None else 0, "ggt_liver_fat", lookups)

    metabolic_markers["liver_health_ggt"]["current"] = f"{ggt_num if ggt_num is not None else 'N/A'} U/L"
    if ggt_assess.get("target"):
        metabolic_markers["liver_health_ggt"]["target"] = ggt_assess["target"]
    else:
        metabolic_markers["liver_health_ggt"]["target"] = "Within Target" if ggt_assess["assessment"] == "Normal" else f"<{ggt_assess['threshold']} U/L by Week 10*"

    # Triglycerides
    tri_val = _get_raw_value(["TRIGLYCERIDES", "Triglycerides"])
    tri_num = float(tri_val) if tri_val not in (None, "") else None
    metabolic_markers["triglycerides"]["current"] = f"{tri_num if tri_num is not None else 'N/A'} mg/dL"
    # use lookups if available or simple rule
    tri_lookup = lookups.get("triglyceride_ranges", {})  # optional
    if tri_num is not None:
        # simple rule fallback
        metabolic_markers["triglycerides"]["target"] = ("Within Target" if tri_num < 100 else "<100 mg/dL by Week 10*")
    else:
        metabolic_markers["triglycerides"]["target"] = "<100 mg/dL by Week 10*"

    # --- BLOOD PRESSURE (lookup-driven) ---
    bp_lookup = lookups.get("blood_pressure_target") or lookups.get("bp_target") or {}
    # default thresholds (if lookups not present)
    systolic_max = bp_lookup.get("normal", {}).get("systolic_max", 130)
    diastolic_max = bp_lookup.get("normal", {}).get("diastolic_max", 80)
    goal_text = bp_lookup.get("normal", {}).get("target", f"<{systolic_max}/{diastolic_max} by Week 8*")

    # fetch bp from backend safely
    user_id = input_data.get("userProfile", {}).get("content", {}).get("id")
    bp_data = {}
    try:
        bp_data = fetch_bp_summary(user_id, minimal=True) or {}
    except Exception as e:
        print(f"⚠️ Warning: failed to fetch BP summary: {e}")
        bp_data = {}

    systolic = bp_data.get("systolic_avg")
    diastolic = bp_data.get("diastolic_avg")
    if isinstance(systolic, (int, float)) and isinstance(diastolic, (int, float)):
        bp_string = f"{int(round(systolic))}/{int(round(diastolic))} mmHg"
    else:
        bp_string = bp_data.get("average") or "[Current - Data Not Available]"

    # ensure nested path exists
    if "current_metabolic_state" not in personalized_data:
        personalized_data["current_metabolic_state"] = {}
    if "lab_profile_targets" not in personalized_data["current_metabolic_state"]:
        personalized_data["current_metabolic_state"]["lab_profile_targets"] = {}
    if "diabetes_markers" not in personalized_data["current_metabolic_state"]["lab_profile_targets"]:
        personalized_data["current_metabolic_state"]["lab_profile_targets"]["diabetes_markers"] = {}

    diabetes_markers = personalized_data["current_metabolic_state"]["lab_profile_targets"]["diabetes_markers"]
    diabetes_markers.setdefault("blood_pressure", {})
    diabetes_markers["blood_pressure"]["current"] = bp_string

    # use lookup to decide "Within Target" vs goal text
    if isinstance(systolic, (int, float)) and isinstance(diastolic, (int, float)):
        if systolic <= systolic_max and diastolic <= diastolic_max:
            diabetes_markers["blood_pressure"]["target"] = "Within Target"
        else:
            # if lookups define other buckets, try to find one
            # look for an 'elevated' or 'high' bucket to use its target
            if isinstance(bp_lookup, dict):
                for k, rng in bp_lookup.items():
                    if isinstance(rng, dict) and rng.get("target") and rng.get("systolic_min") is not None:
                        # simple fallback: if systolic outside normal, use this bucket's target
                        if systolic > systolic_max or diastolic > diastolic_max:
                            diabetes_markers["blood_pressure"]["target"] = rng.get("target")
                            break
                else:
                    diabetes_markers["blood_pressure"]["target"] = goal_text
            else:
                diabetes_markers["blood_pressure"]["target"] = goal_text
    else:
        diabetes_markers["blood_pressure"]["target"] = goal_text

    # Energy Expenditure 
    gender = patient_info.get("gender", "male").lower()
    weight = anthropometric.get("weight", 0)
    height = anthropometric.get("height", 0)
    age = patient_info.get("age", 0)

    # RMR Calculation
    rmr = calculate_rmr(gender, weight, height, age, lookups)
    energy = personalized_data["current_metabolic_state"]["energy_expenditure_analysis"]
    energy["rmr"]["value"] = f"{rmr} calories/day"
    energy["rmr"]["calculated_from"] = f"(calculated: age {age}, {gender}, {weight}kg, {height*30.48}cm)"

    # Load activity average from JSON
    try:
            avg_active_burn = activity_summary.get("average_calories_burned", 0)
            activity_level_text = activity_summary.get("activityLevel", "Unknown")
            activity_description = activity_summary.get("description", "")
    except Exception as e:
        print(f"⚠️ Could not load activity summary: {e}")
        avg_active_burn = 200  # fallback
        activity_level_text = "sedentary"
        activity_description = "Minimal movement"

    # Energy Expenditure - Active Energy (using placeholder logic for activity level)
    
    energy["active_energy"]["activity_level"] = f"{activity_level_text} ({activity_description})"
    energy["active_energy"]["daily_burn"] = f"{avg_active_burn:.1f} calories (7-day avg activity)"
    energy["active_energy"]["total_daily"] = f"{rmr + int(avg_active_burn)} calories (RMR + activity)"
    
    # --- Calorie Target Calculation
    total_daily_energy = rmr + int(avg_active_burn)
    calorie_target = max(total_daily_energy - 1100, 800)  # Safety net minimum

    energy["calorie_target"] = {
        "explanation": "Calorie Target = RMR + Active Burn - 1100 (for fat loss)",
        "target_range": f"{calorie_target} calories/day"
}

  # --- Body Composition Assessment ---

    def normalize_height(height):
        """Normalize height into meters from cm, feet, or meters."""
        if not height:
            return None

        try:
            h = float(height)
        except Exception:
            return None

        # Case 1: Clearly in cm (e.g. 150–220)
        if h > 100:
            return h / 100.0

        # Case 2: In feet (common values 4.5–7.5)
        if 3.0 < h < 8.0:
            return h * 0.3048  # feet → meters

        # Case 3: Already meters (e.g. 1.2–2.5)
        if 1.0 < h < 2.5:
            return h

        return None


    def normalize_weight(weight):
        """Extract numeric weight in kg (handles 'kg' suffix)."""
        if not weight:
            return None
        if isinstance(weight, (int, float)):
            return float(weight)
        match = re.search(r"[\d\.]+", str(weight))
        return float(match.group()) if match else None


    # --- BMI calculation ---
    body_comp = personalized_data["current_metabolic_state"]["body_composition_assessment"]
    weight = anthropometric.get("weight", 0)
    height = anthropometric.get("height", 0)
    
    weight_kg = normalize_weight(weight)
    height_m = normalize_height(height)

    if weight_kg and height_m:
        try:
            bmi_float = round(weight_kg / (height_m ** 2), 1)
            classification = get_classification(bmi_float, lookups["bmi_classification"])
        except Exception:
            bmi_float = None
            classification = "N/A"
    else:
        bmi_float = None
        classification = "N/A"

    body_comp["current_status"]["bmi"] = f"{bmi_float}" if bmi_float else "N/A"
    body_comp["current_status"]["classification"] = classification
    body_comp["current_status"]["waist_circumference"] = "[Value Not Available]"

    

    body_comp["current_status"]["weight"] = f"{weight}kg"

    # --- Body Fat & Lean Mass Estimates ---
    if weight and weight > 0:
        gender_key = gender if gender in lookups["body_fat_estimates"] else "male"
        body_fat_range = lookups["body_fat_estimates"][gender_key]

        estimated_fat_mass = round(weight * ((body_fat_range["min"] + body_fat_range["max"]) / 2) / 100, 1)
        estimated_lean_mass = round(weight * body_fat_range["lean_mass_factor"], 1)

        body_comp["current_status"]["body_fat"] = f"{body_fat_range['min']}-{body_fat_range['max']}% (~{estimated_fat_mass}kg fat mass)"
        body_comp["current_status"]["lean_mass"] = f"~{estimated_lean_mass}kg (muscle, organs, bones)"
    else:
        body_comp["current_status"]["body_fat"] = "N/A"
        body_comp["current_status"]["lean_mass"] = "N/A"

    # --- Fat Loss Targets ---
    if bmi_float is not None and weight and weight > 0:
        bmi_class = next(
            (range_data for key, range_data in lookups["bmi_classification"].items()
            if range_data["min"] <= bmi_float <= range_data["max"]),
            lookups["bmi_classification"]["normal"]
        )
        fat_loss_goal = bmi_class.get("fat_loss_goal_kg", "N/A")
        body_comp["fat_loss_targets"]["total_fat_loss"] = f"{fat_loss_goal}kg over 14 weeks*"

        body_comp["fat_loss_targets"]["target_body_fat"] = f"{lookups['body_fat_estimates'][gender]['target']}% (healthy range for {gender})" if gender in lookups["body_fat_estimates"] else "N/A"

        try:
            fat_loss_min = float(fat_loss_goal.split('-')[0])
            fat_loss_max = float(fat_loss_goal.split('-')[1])
            final_weight_high = round(weight - fat_loss_min, 1)
            final_weight_low = round(weight - fat_loss_max, 1)
            body_comp["fat_loss_targets"]["final_weight"] = f"{final_weight_low}-{final_weight_high}kg (depends on muscle retention)"
            body_comp["fat_loss_targets"]["muscle_preservation"] = f"Maintain all {estimated_lean_mass}kg lean mass" if weight > 0 else "N/A"
        except Exception:
            body_comp["fat_loss_targets"]["final_weight"] = "N/A"
            body_comp["fat_loss_targets"]["muscle_preservation"] = "N/A"
    else:
        body_comp["fat_loss_targets"]["total_fat_loss"] = "N/A"
        body_comp["fat_loss_targets"]["final_weight"] = "N/A"
        body_comp["fat_loss_targets"]["target_body_fat"] = "N/A"
        body_comp["fat_loss_targets"]["muscle_preservation"] = "N/A"

    # Visceral Fat Focus

    alt_value = raw_data.get('ALANINE TRANSAMINASE (SGPT)', {}).get('value')

    if alt_value is not None:
        try:
            alt_value = float(alt_value)
            alt_result = get_liver_marker_assessment(alt_value, "alt_liver_fat", lookups)
            assessment = alt_result["assessment"]

            if assessment == "Normal":
                alt_comment = f" (ALT {alt_value} U/L – within normal range)"
                liver_fat_msg = (
                    "ALT is within normal range, which is reassuring, "
                    "but liver fat may still be present and will reduce with reversal" + alt_comment
                )
            else:
                alt_comment = f" (ALT {alt_value} U/L – {assessment.lower()})"
                liver_fat_msg = (
                    "Elevated ALT suggests possible liver fat accumulation – reversal will reduce intrahepatic fat"
                    + alt_comment
                )

        except Exception:
            liver_fat_msg = "Liver fat likely present – ALT data not interpretable"
    else:
        liver_fat_msg = "Liver fat assessment not available – ALT data missing"

    body_comp["visceral_fat_focus"]["liver_fat"] = liver_fat_msg



    # Science Behind Reversal - Why Reversal is Possible
    science = personalized_data["science_behind_reversal"]
    hba1c_value = raw_data.get('HbA1c', {}).get('value', 0)
    hba1c_onset = get_hba1c_onset(hba1c_value, lookups)
    age_assessment = get_age_assessment(age, lookups)
    science["why_reversal_possible"] = [
        f"{c_peptide_assessment['reserve']} Pancreatic Reserve: C-peptide {c_peptide_value} ng/mL (pancreas {c_peptide_assessment['functional']} functional)",
        f"{hba1c_onset['text']} Onset: {hba1c_onset['description']}",
        f"{c_peptide_assessment['reserve']} Health Foundation: No advanced complications",
        f"{age_assessment['text']} Age: {age} years ({age_assessment['potential']} metabolic flexibility potential)"
    ]

    # Energy & Calorie Strategy
    energy_strategy = personalized_data["energy_calorie_strategy"]
    total_daily_exp = rmr + int(avg_active_burn)
    deficit = total_daily_exp - lookups["energy_deficit"]["base_calories"]
    deficit_range = next((range_data for key, range_data in lookups["energy_deficit"]["deficit_ranges"].items() if range_data["min"] <= deficit <= range_data["max"]), lookups["energy_deficit"]["deficit_ranges"]["moderate"])
    energy_strategy["energy_deficit_calculation"]["daily_energy_balance"]["total_daily_expenditure"] = f"{total_daily_exp} calories average (RMR {rmr} + Avg Activity {int(avg_active_burn)})"
    energy_strategy["energy_deficit_calculation"]["daily_energy_balance"]["created_deficit"] = f"{deficit} calories/day"
    energy_strategy["energy_deficit_calculation"]["daily_energy_balance"]["weekly_fat_loss"] = f"{deficit_range['weekly_fat_loss_lbs']} lbs ({deficit_range['calculation']} calories/lb)"

    # Macronutrient Targets 
    reference_weight = float(anthropometric.get("weight", 0))  # in kg
    protein_min = int(round(reference_weight * 1.0))
    protein_max = int(round(reference_weight * 1.2))

    carb_min = 50
    carb_max = 75

    target_kcal_min = max(1000, int(rmr + avg_active_burn - 1100))  # Ensure it doesn't drop too low
    target_kcal_max = target_kcal_min + 300


    protein_kcal_min = protein_min * 4
    protein_kcal_max = protein_max * 4

    carb_kcal_min = carb_min * 4
    carb_kcal_max = carb_max * 4

    fat_kcal_min = target_kcal_min - (protein_kcal_min + carb_kcal_min)
    fat_kcal_max = target_kcal_max - (protein_kcal_max + carb_kcal_max)

    fat_grams_min = int(fat_kcal_min / 9)
    fat_grams_max = int(fat_kcal_max / 9)

    
    personalized_data["macro_targets"] = {
        "base_day": {
            "calories": f"Base Day ({target_kcal_min} calories):",
            "protein": f"{protein_min}g protein (~{round(protein_kcal_min/target_kcal_min*100)}%) - Preserves muscle & metabolic rate",
            "fat": f"{fat_grams_min}g fat (~{round(fat_kcal_min/target_kcal_min*100)}%) - Supports hormones, prevents gallstones",
            "carbs": f"{carb_min}g carbs (~{round(carb_kcal_min/target_kcal_min*100)}%) - Strictly regulated for glucose control"
        },
        "active_day": {
            "calories": f"Active Day (+300 calories = {target_kcal_max} calories):",
            "protein": f"{protein_max}g protein (~{round(protein_kcal_max/target_kcal_max*100)}%) - Enhanced muscle preservation",
            "fat": f"{fat_grams_max}g fat (~{round(fat_kcal_max/target_kcal_max*100)}%) - Continued hormone support",
            "carbs": f"{carb_max}g carbs (~{round(carb_kcal_max/target_kcal_max*100)}%) - Strategic post-exercise fuel"
        },
        "why_preserves_metabolism": [
            "High Protein: Maintains muscle mass (primary driver of metabolic rate)",
            "Adequate Fats: Supports thyroid, testosterone, and hormone production",
            "Strategic Timing: Post-exercise carbs maintain leptin and metabolic flexibility",
            "Short Duration: Prevents long-term metabolic adaptation"
        ]
    }


    # --- Step: Inject calculated daily_combination_targets into final JSON ---
    base_day_calories = f"BASE DAY ({target_kcal_min} calories):"
    active_day_calories = f"ACTIVE DAY (+300 calories from exercise = {target_kcal_max} total):"

    personalized_data["food_combination_plan"]["daily_combination_targets"] = {
        "base_day": {
            "calories": base_day_calories,
            "build_meals": f"Build meals using combinations above to reach: {protein_min}g protein + {carb_min}g carbs + {fat_grams_min}g fat",
            "meal_distribution": "Divide these targets across 2-3 meals as preferred",
            "timing_flexibility": "Post-exercise carbs optimal but not mandatory"
        },
        "active_day": {
            "calories": active_day_calories,
            "build_meals": f"Build meals to reach: {protein_max}g protein + {carb_max}g carbs + {fat_grams_max}g fat",
            "extra_calories_from": "Additional protein portions (preferred) or healthy fats",
            "timing": "Consume within 2 hours post-exercise when possible"
        }
    }

        # Inject personalized daily combination targets
    daily_targets = personalized_data["food_combination_plan"]["daily_combination_targets"]

    daily_targets["base_day"]["calories"] = f"BASE DAY ({target_kcal_min} calories):"
    daily_targets["base_day"]["build_meals"] = (
        f"Build meals using combinations above to reach: {protein_min}g protein + {carb_min}g carbs + {fat_grams_min}g fat"
    )

    daily_targets["active_day"]["calories"] = f"ACTIVE DAY (+300 calories from exercise = {target_kcal_max} total):"
    daily_targets["active_day"]["build_meals"] = (
        f"Build meals to reach: {protein_max}g protein + {carb_max}g carbs + {fat_grams_max}g fat"
    )


    # Food Combination Plan (using default cultural preference for now)
    cultural_key = "default"  # Can be updated based on patient data if available
    food_prefs = lookups["cultural_food_preferences"].get(cultural_key, lookups["cultural_food_preferences"]["default"])
    food_plan = personalized_data["food_combination_plan"]
    food_plan["cultural_preferences"] = f"Based on {cultural_key.capitalize()} Preferences:"
    food_plan["unlimited_combinations"]["non_starchy_vegetables"] = ", ".join(food_prefs["vegetables"])

    # Protein Building Blocks
    food_plan["measured_combinations"]["protein_building_blocks"]["choose_combinations"] = [
        f"{source['name']}: {source['amount']} = {source['protein']}g protein" for source in food_prefs["protein_sources"]
    ]
    food_plan["measured_combinations"]["protein_building_blocks"]["sample_daily_protein_combinations"] = [
        f"Option A: {food_prefs['meal_examples']['protein']['option_a']}",
        f"Option B: {food_prefs['meal_examples']['protein']['option_b']}",
        f"Option C: {food_prefs['meal_examples']['protein']['option_c']}"
    ]

    # Carbohydrate Building Blocks
    food_plan["measured_combinations"]["carbohydrate_building_blocks"]["choose_combinations"] = [
        f"{source['name']}: {source['amount']} = {source['carbs']}g carbs" for source in food_prefs["carb_sources"]
    ]
    food_plan["measured_combinations"]["carbohydrate_building_blocks"]["sample_daily_carb_combinations"] = [
        f"Option A: {food_prefs['meal_examples']['carbs']['option_a']}",
        f"Option B: {food_prefs['meal_examples']['carbs']['option_b']}",
        f"Option C: {food_prefs['meal_examples']['carbs']['option_c']}"
    ]

    # Healthy Fat Building Blocks
    fats = food_prefs["fat_sources"]
    food_plan["measured_combinations"]["healthy_fat_building_blocks"]["choose_combinations"] = [
        f"Cooking Oils: {fats['cooking_oils']['name']} ({fats['cooking_oils']['amount']}) = {fats['cooking_oils']['fat']}g fat",
        f"Nuts: {fats['nuts']['name']} ({fats['nuts']['amount']}) = {fats['nuts']['fat']}g fat",
        f"Seeds: {fats['seeds']['name']} ({fats['seeds']['amount']}) = {fats['seeds']['fat']}g fat",
        f"Natural Sources: From {fats['natural']['name']} = {fats['natural']['fat']}g fat"
    ]
    food_plan["measured_combinations"]["healthy_fat_building_blocks"]["sample_daily_fat_combinations"] = [
        f"Option A: {food_prefs['meal_examples']['fats']['option_a']}",
        f"Option B: {food_prefs['meal_examples']['fats']['option_b']}",
        f"Option C: {food_prefs['meal_examples']['fats']['option_c']}"
    ]

    # Avoid During Healing Phase
    food_plan["avoid_during_healing_phase"]["foods"] = ",".join(food_prefs["foods_to_avoid"])

    # Hydration Targets (Daily Safety Minimums)
    safety = personalized_data["critical_safety_protocols_requirements"]
    hydration_target = max(lookups["hydration_targets"]["minimum"]["liters"], 
                          lookups["hydration_targets"]["weight_based"]["base_liters"] + weight * lookups["hydration_targets"]["weight_based"]["per_kg"])
    safety["daily_safety_minimums"]["hydration"]["target"] = f"{round(hydration_target, 1)} liters daily (based on {weight}kg weight + protocol demands)"
    safety["daily_safety_minimums"]["dietary_fats"]["sources"] = ", ".join([f"{fats['cooking_oils']['name']}", f"{fats['nuts']['name']}", f"{fats['seeds']['name']}"])
    safety["daily_safety_minimums"]["protein"]["daily_minimum"] = f"80g ({round(1.0 * weight, 1)}g per kg body weight if active)"

    # Daily Implementation Plan - CGM and HRV Patterns (using lookups for initial and target values)
    daily_plan = personalized_data["daily_implementation_plan"]
    glucose_initial = lookups["glucose_targets"]["initial"]
    glucose_week6 = lookups["glucose_targets"]["week_6"]
    glucose_week8 = lookups["glucose_targets"]["week_8"]
    
    hrv_target = lookups["hrv_targets"]["target"]
    hrv_initial= lookups["hrv_targets"]["target"]

    # Update Morning Routine
    daily_plan["morning_routine"]["activities"][0] = f"6:30 AM: Wake up → Check glucose Expected CGM: {glucose_initial['avg_glucose']} initially → targeting {glucose_week6['avg_glucose']} by Week 6* Expected HRV: {hrv_initial['morning']} initially → targeting {hrv_target['morning']} with improvement"
    daily_plan["morning_routine"]["activities"][2] = f"7:00 AM: Breakfast + morning supplements (if prescribed) Expected Post-Breakfast CGM: Peak {glucose_initial['avg_glucose']} initially → targeting {glucose_week8['avg_glucose']} by Week 8* Energy Expenditure: ~75-100 calories (morning routine, preparation)"

    # Update Midday Execution
    daily_plan["midday_execution"]["activities"][0] = f"1:00 PM: Lunch (maintain protein target) Pre-Lunch CGM: {glucose_initial['avg_glucose']} initially → targeting {glucose_week6['avg_glucose']} by Week 6*"
    daily_plan["midday_execution"]["activities"][4] = f"2:30 PM: Post-exercise meal adjustment Post-Exercise CGM: {glucose_initial['avg_glucose']} initially → targeting {glucose_week6['avg_glucose']} by Week 6* Post-Exercise Burn: Additional 50-75 calories (EPOC effect)"

    # Update Evening Routine
    daily_plan["evening_routine"]["activities"][0] = f"7:30 PM: Dinner (complete daily protein target) Pre-Dinner CGM: {glucose_initial['avg_glucose']} initially → targeting {glucose_week6['avg_glucose']} by Week 6*"
    daily_plan["evening_routine"]["activities"][1] = f"8:30 PM: Evening supplements, light activity Light Activity: 50-75 calories (walking, household tasks) Post-Dinner CGM: Peak {glucose_initial['avg_glucose']} initially → targeting {glucose_week8['avg_glucose']} by Week 8*"
    daily_plan["evening_routine"]["activities"][3] = f"10:30 PM: Target bedtime (7+ hours for metabolic restoration) Overnight CGM: Gradual decline to morning baseline Sleep HRV: Target  peak during deep sleep phases"

    # Daily Totals & Targets
    daily_totals = daily_plan["daily_totals_targets"]
    daily_totals["total_daily_energy_expenditure"]["resting"] = f"{rmr} calories (basal metabolic needs)"
    daily_totals["total_daily_energy_expenditure"]["total"] = f"{total_daily_exp}-{total_daily_exp + 300} calories daily"
    daily_totals["daily_hrv_targets"]["morning_baseline"] = f"{hrv_initial['morning']} → targeting {hrv_target['morning']}"
    daily_totals["daily_hrv_targets"]["post_exercise_recovery"] = hrv_target["post_exercise_recovery"]
    daily_totals["daily_cgm_patterns"]["time_in_range"] = f"Time in Range (70-140): {glucose_initial['time_in_range']}% initially → targeting {glucose_week8['time_in_range']}% by Week 8*"
    #daily_totals["daily_cgm_patterns"]["average_glucose"] = f"Average Glucose: {glucose_initial['avg_glucose']} initially → targeting {glucose_week8['avg_glucose']} by Week 8*"
    daily_totals["daily_cgm_patterns"]["glucose_variability"] = f"Glucose Variability: {glucose_initial['variability']} initially → low and stable by Week 8*"

    # --- Transformation Timeline - Populate dynamic glucose headlines ---
    timeline = personalized_data["transformation_timeline"]
    glucose_targets = lookups.get("glucose_targets", {})

    if fasting_value:
        # Phase 1 - Week 1 (fasting glucose → target)
        week1_target = glucose_targets.get("week_1", "150-180")
        timeline["phase_by_phase_expectations"]["phase_1"]["week_1"]["expected"] = (
            f"Some fatigue as metabolism adapts, current fasting glucose {fasting_value:.0f}→target {week1_target}"
        )

        # Phase 1 - Week 2
        week2_target = glucose_targets.get("week_2", "120-140")
        timeline["phase_by_phase_expectations"]["phase_1"]["week_2"]["expected"] = (
            f"Energy returning, glucose {week2_target}, first medication reduction"
        )

        # Phase 1 - Week 4
        week4_target = glucose_targets.get("week_4", "<120")
        timeline["phase_by_phase_expectations"]["phase_1"]["week_4"]["expected"] = (
            f"Glucose {week4_target}, steady energy, 8-10 lbs lost"
        )

        # Phase 2 - Week 6
        week6_target = glucose_targets.get("week_6", "100-110")
        timeline["phase_by_phase_expectations"]["phase_2"]["week_6"]["expected"] = (
            f"Glucose {week6_target}, energy excellent, 12-15 lbs lost"
        )

        # Phase 2 - Week 8
        week8_target = glucose_targets.get("week_8", "90-100")
        timeline["phase_by_phase_expectations"]["phase_2"]["week_8"]["expected"] = (
            f"Glucose {week8_target}, feeling better than years, 15-20 lbs lost"
        )

        # Phase 3 - Week 12
        week12_target = glucose_targets.get("week_12", "80-90")
        timeline["phase_by_phase_expectations"]["phase_3"]["week_12"]["expected"] = (
            f"Glucose {week12_target}, optimal energy, 20-25 lbs lost"
        )
    # Generated Date
    personalized_data["generated"]["date"] = datetime.now().strftime("%Y-%m-%d")

    # Populate Medication Management Plan
    medications = input_data.get("medications", {}).get("current_medications", [])
    med_plan = personalized_data.get("medication_management_plan", {})

    supporting = []
    adjustment = []

    for med in medications:
        name = med.get("name", "").strip().lower()
        dose = med.get("dosage", "")
        note = med.get("raw_data", {}).get("note", "")
        frequency = med.get("frequency", "")
        duration = med.get("duration_string", "")
        med_type = med.get("raw_data", {}).get("medicationType", "").lower()

        # Categorize only if this is a true medication, not a supplement
        if med_type == "supplement":
            continue  # skip here, handled under supplement logic

        # Supporting meds (e.g., metformin, sglt2)
        if name in ["metformin", "vokanamet", "sglt2"]:
            supporting.append({
                "medication": f"{med['name']} ({dose})",
                "how_it_helps": "Improves insulin sensitivity and reduces glucose load",
                "our_plan": "Continue initially; monitor for hypoglycemia",
                "synergy": "Supports calorie deficit and fat oxidation",
                "note": note,
                "frequency": frequency,
                "duration": duration
            })

        # Meds needing tapering (e.g., sulfonylureas)
        elif name in ["gliclazide", "glimepiride", "sulfonylureas"]:
            adjustment.append({
                "medication": f"{med['name']} ({dose})",
                "problem": "May cause hypoglycemia when diet is adjusted",
                "risk": "Fatigue, dizziness, potential crash in sugar",
                "tapering_schedule": {
                    "week_1_2": "Reduce dose by 25%",
                    "week_3_4": "Evaluate fasting sugars, reduce further",
                    "week_5_plus": "Consider discontinuation if sugars remain stable"
                },
                "safety": "Monitor glucose every morning; contact provider if <70 mg/dL",
                "note": note,
                "frequency": frequency,
                "duration": duration
            })

    # Save back into the JSON
    med_plan["supporting_medications"] = supporting
    med_plan["medications_to_be_adjusted"] = adjustment

  
    # Supplement suggestions based on deficiencies
    lab_markers = {
    "vitamin_d": raw_data.get("25-OH VITAMIN D (TOTAL)", {}).get("value"),
    "vitamin_b12": raw_data.get("VITAMIN B-12", {}).get("value"),
    "magnesium": raw_data.get("MAGNESIUM", {}).get("value"),
    "iron": raw_data.get("IRON", {}).get("value"),
    "zinc": raw_data.get("Zinc", {}).get("value"),
    # Cholesterol markers (required for omega-3 logic)
    "triglycerides": raw_data.get("Triglycerides", {}).get("value"),
    "ldl": raw_data.get("LDL Cholesterol - Direct", {}).get("value"),
    "hdl": raw_data.get("HDL Cholesterol - Direct", {}).get("value"),
    "tg_hdl_ratio": raw_data.get("TRIG / HDL RATIO", {}).get("value")
    }

    supplements = add_supplement_recommendations(lab_markers, lookups)

    personalized_data["supplement_plan"]["required_supplements"]["morning"]["supplements"] = supplements["morning"]
    personalized_data["supplement_plan"]["required_supplements"]["evening"]["supplements"] = supplements["evening"]
    personalized_data["supplement_recommendations"] = add_supplement_recommendations(lab_markers, lookups)

    # Ensure the key exists in the final structure

    metabolic_reversal = personalized_data["transformation_timeline"]["comorbidity_improvements"]["metabolic_syndrome_reversal"]

    # --- Triglycerides replacement ---
    tri = raw_data.get("TRIGLYCERIDES", {}).get("value")
    if tri is not None:
        try:
            tri = float(tri)
            tri_lookup = lookups.get("triglycerides_target", {})
            if tri_lookup:
                if tri <= tri_lookup["normal"]["max"]:
                    target_text = tri_lookup["normal"]["assessment"]
                else:
                    target_text = tri_lookup["above_normal"]["assessment"]

                template_string = template["transformation_timeline"]["comorbidity_improvements"]["metabolic_syndrome_reversal"]["triglycerides"]
                metabolic_reversal["triglycerides"] = (
                    template_string
                    .replace("[Current]", f"{tri} mg/dL")
                    .replace("[Target ranges <150 by week 12]", target_text)
                )
            else:
                # fallback if no lookup found
                metabolic_reversal["triglycerides"] = f"Triglycerides: {tri} mg/dL – Target logic missing in lookups"
        except ValueError:
            metabolic_reversal["triglycerides"] = "Triglycerides: Invalid value"
    else:
        metabolic_reversal["triglycerides"] = "Triglycerides: N/A"

# --- Liver Function replacement (ALT, AST, GGT) ---
    liver_function = {}

    # ALT
    alt = raw_data.get("ALANINE TRANSAMINASE (SGPT)", {}).get("value")
    if alt is not None:
        try:
            alt = float(alt)
            alt_lookup = lookups.get("alt_target", {})
            if alt_lookup:
                if alt <= alt_lookup["normal"]["max"]:
                    target_text = alt_lookup["normal"]["assessment"]
                else:
                    target_text = alt_lookup["above_normal"]["assessment"]
            else:
                target_text = "Target logic missing"
            template_string = template["transformation_timeline"]["comorbidity_improvements"]["metabolic_syndrome_reversal"]["liver_function"]["alt"]
            liver_function["alt"] = (
                template_string
                .replace("[Current]", f"{alt} U/L")
                .replace("[current]", f"{alt} U/L")
                .replace("[progressive targets]", target_text)
            )
        except ValueError:
            liver_function["alt"] = "ALT: Invalid value"
    else:
        liver_function["alt"] = "ALT: N/A"

    # AST
    ast = raw_data.get("Aspartate Aminotransferase (SGOT)", {}).get("value")
    if ast is not None:
        try:
            ast = float(ast)
            ast_lookup = lookups.get("ast_target", {})
            if ast_lookup:
                if ast <= ast_lookup["normal"]["max"]:
                    target_text = ast_lookup["normal"]["assessment"]
                else:
                    target_text = ast_lookup["above_normal"]["assessment"]
            else:
                target_text = "Target logic missing"
            template_string = template["transformation_timeline"]["comorbidity_improvements"]["metabolic_syndrome_reversal"]["liver_function"]["ast"]
            liver_function["ast"] = (
                template_string
                .replace("[Current]", f"{ast} U/L")
                .replace("[current]", f"{ast} U/L")
                .replace("[progressive targets]", target_text)
            )
        except ValueError:
            liver_function["ast"] = "AST: Invalid value"
    else:
        liver_function["ast"] = "AST: N/A"

    # GGT
    ggt = raw_data.get("GAMMA GLUTAMYL TRANSFERASE (GGT)", {}).get("value")
    if ggt is not None:
        try:
            ggt = float(ggt)
            ggt_lookup = lookups.get("ggt_target", {})
            if ggt_lookup:
                if ggt <= ggt_lookup["normal"]["max"]:
                    target_text = ggt_lookup["normal"]["assessment"]
                else:
                    target_text = ggt_lookup["above_normal"]["assessment"]
            else:
                target_text = "Target logic missing"
            template_string = template["transformation_timeline"]["comorbidity_improvements"]["metabolic_syndrome_reversal"]["liver_function"]["ggt"]
            liver_function["ggt"] = (
                template_string
                .replace("[Current]", f"{ggt} U/L")
                .replace("[current]", f"{ggt} U/L")
                .replace("[progressive targets]", target_text)
            )
        except ValueError:
            liver_function["ggt"] = "GGT: Invalid value"
    else:
        liver_function["ggt"] = "GGT: N/A"

    # Assign final structured block
    metabolic_reversal["liver_function"] = liver_function



    # --- Finish building protocol ---
    med_plan["medications_supporting_reversal"] = supporting
    med_plan["medications_requiring_adjustment"] = adjustment

    # ✅ Make sure we return the final dict so intermediate_data is not None
    return personalized_data


def transform_for_display(intermediate_data, input_data):
    """Transform intermediate JSON into a final display format with a summary."""
    final_display = intermediate_data.copy()
    final_display["quick_view"] = {
        "key_metrics": {
            "hba1c": final_display["current_metabolic_state"]["lab_profile_targets"]["diabetes_markers"]["hba1c"]["current"],
            "fasting_glucose": final_display["current_metabolic_state"]["lab_profile_targets"]["diabetes_markers"]["fasting_glucose"]["current"],
            "bmi": final_display["current_metabolic_state"]["body_composition_assessment"]["current_status"]["bmi"]
        },
        "overall_risk_score": input_data.get("analysisResults", {}).get("overallRiskScore", "[Risk score not found]")

    }
    final_display["generated_date"] = datetime.now().strftime("%Y-%m-%d")
    final_display["macronutrient_targets"] = intermediate_data.get("macronutrient_targets", {})
    final_display["medication_management_plan"] = intermediate_data.get("medication_management_plan", {})
    final_display["supplement_plan"] = intermediate_data.get("supplement_plan", {})
    final_display["activity_summary"] = intermediate_data.get("activity_summary", {})
    final_display["hrv_summary"] = intermediate_data.get("hrv_summary", {})
    final_display["stress_summary"] = intermediate_data.get("stress_summary", {})
    final_display["sleep_summary"] = intermediate_data.get("sleep_summary", {})

    return final_display

def main():
    parser = argparse.ArgumentParser(description="Generate personalized protocol")
    parser.add_argument(
        "--input", "-i",
        type=str,
        default="input_data.json",
        help="Path to the input JSON file (default: input_data.json)"
    )
    parser.add_argument(
        "--output", "-o",
        type=str,
        default="final_display.json",
        help="Path for the output JSON file (default: final_display.json)"
    )
    args = parser.parse_args()

    # Load input files
    input_data = load_json(args.input)
    lookups = load_json("lookups.json")
    template = load_json("template.json")

    if not input_data or not lookups or not template:
        print("One or more input files are missing or invalid. Exiting.")
        return

    # Extract user ID
    user_id = input_data.get("id") or input_data.get("userProfile", {}).get("content", {}).get("id")
 
    health_data = fetch_all_data(user_id)  # <- Now fetched before generating protocol

    # Generate personalized protocol
    personalized_protocol = generate_personalized_protocol(input_data, lookups, template, health_data)

    # Save intermediate output
    save_json(personalized_protocol, "intermediate_protocol.json")

    # Transform for final display
    final_display = transform_for_display(personalized_protocol, input_data)

    # Save final output to user-specified file
    save_json(final_display, args.output)

 

    # Step 0: Fetch dynamic health data first
 

    # Save health data
    with open("all_health_data_summary.json", "w", encoding="utf-8") as f:
        json.dump(health_data, f, indent=4, ensure_ascii=False)
 


if __name__ == "__main__":
    main()

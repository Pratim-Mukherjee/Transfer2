import requests
import json
from datetime import datetime, timedelta

def fetch_all_data(user_id):
    activity_data = fetch_activity_summary(user_id)
    bp_data = fetch_bp_summary(user_id)
    cgm_data = fetch_cgm_summary(user_id)
    hrv_data = fetch_hrv_summary(user_id)
    stress_data = fetch_stress_summary(user_id)
    sleep_data = fetch_sleep_summary(user_id)

    return {
        "user_id": user_id,
        "activity_summary": activity_data,
        "blood_pressure_summary": bp_data,
        "cgm_summary": cgm_data,
        "hrv_summary": hrv_data,
        "stress_summary": stress_data,
        "sleep_summary": sleep_data
    }

def fetch_activity_summary(patient_id, max_days=14, minimal=False):
    base_url = "https://devapi.revival365ai.com/data/chart/activity_readings"
    today = datetime.today()

    total_calories = 0
    valid_days = 0
    raw_days_data = []

    for i in range(max_days):  
        day = today - timedelta(days=i)
        date_str = day.strftime("%Y-%m-%d")
        url = f"{base_url}/{patient_id}/{date_str}"

        try:
            response = requests.get(url)
            response.raise_for_status()
            data = response.json()

            if data.get("status") == 200 and data.get("activityReadings"):
                readings = data["activityReadings"]

                for reading in readings:
                    calories = reading.get("totalCaloriesBurned", 0)
                    duration_min = reading.get("totalDuration", 0)  # in minutes
                    wear_hours = duration_min / 60

                    # ✅ Include only if worn for ≥12 hours
                    if calories > 0 and duration_min >= 720:
                        total_calories += calories
                        valid_days += 1
                        raw_days_data.append({
                            "date": date_str,
                            "totalCaloriesBurned": round(calories, 2),
                            "wear_duration_hours": round(wear_hours, 1)
                        })

        except Exception as e:
            print(f"⚠️ Skipped {date_str} due to error: {e}")

    average_calories = total_calories / valid_days if valid_days > 0 else 0

    if average_calories >= 400:
        activity_level = "active"
        description = "You are regularly active throughout the day."
    elif average_calories >= 200:
        activity_level = "moderate"
        description = "You have a moderate level of daily movement."
    else:
        activity_level = "sedentary"
        description = "Minimal movement observed during most days."

    return {
        "patient_id": patient_id,
        "average_calories_burned": round(average_calories, 2),
        "days_used": valid_days,
        "activityLevel": activity_level,
        "description": description,
        "note": "Only days with ≥12 hours of wearable use were included.",
        "raw_data": raw_days_data
    }

def fetch_bp_summary(user_id, days=7, minimal=False):
    base_url = "https://devapi.revival365ai.com/data/chart/bp_readings"
    today = datetime.today()

    total_systolic = 0
    total_diastolic = 0
    count = 0
    raw_bp_data = []

    for i in range(days):
        date = today - timedelta(days=i)
        date_str = date.strftime("%Y-%m-%d")
        url = f"{base_url}/{user_id}/{date_str}"

        try:
            response = requests.get(url)
            response.raise_for_status()
            data = response.json()
            #print(f"📡 Fetching BP data for {date_str}")
            #print("📨 Raw BP API response:", json.dumps(data, indent=2))
            if data.get("status") == 200 and data.get("bloodpressure_readings"):
                readings = data["bloodpressure_readings"]
                for reading in readings:
                    sys = reading.get("systolic")
                    dia = reading.get("diastolic")
                    if sys is not None and dia is not None:
                        total_systolic += sys
                        total_diastolic += dia
                        count += 1
                        raw_bp_data.append({"date": date_str, "systolic": sys, "diastolic": dia})

        except Exception as e:
            print(f"⚠️ Failed to fetch BP for {date_str}: {e}")

    if count > 0:
        avg_sys = round(total_systolic / count)
        avg_dia = round(total_diastolic / count)
        return {
            "average": f"{avg_sys}/{avg_dia} mmHg",
            "readings_count": count,
            "raw_data": raw_bp_data,
            "note": f"averaged over {count} readings in the last {days} days"
        }
    else:
        return {
            "average": "Data Not Available",
            "readings_count": 0,
            "raw_data": [],
            "note":f"No valid BP readings found in the past {days} days"
        }

def fetch_cgm_summary(user_id, minimal=False):

    base_url = "https://devapi.revival365ai.com/data/chart/glucose-readings"
    today = datetime.today()
    total = 0
    count = 0
    valid_days = 0
    raw_data = []

    for i in range(14):
        date = today - timedelta(days=i)
        date_str = date.strftime("%Y-%m-%d")
        url = f"{base_url}/{user_id}/{date_str}"

        try:
            response = requests.get(url)
            response.raise_for_status()
            data = response.json()

            #print(f"\n📅 Date: {date_str}")
            #print("🔍 CGM API top-level keys:", list(data.keys()) if isinstance(data, dict) else "Response is a list")
            #print("👀 First item:", data["glucose_readings"][0] if "glucose_readings" in data and len(data["glucose_readings"]) > 0 else "No readings")

            if data.get("status") == 200 and "glucose_readings" in data:
                readings = data["glucose_readings"]
                if readings:
                    valid_days += 1
                for reading in readings:
                    val = reading.get("value")
                    if val is not None:
                        total += val
                        count += 1
                        raw_data.append({
                            "date": date_str,
                            "glucose": val
                        })

        except Exception as e:
            print(f"⚠️ Error fetching or parsing CGM for {date_str}: {e}")
            continue

    average_glucose = round(total / count, 2) if count > 0 else None

    return {
        "tag": "CGM",
        "unit": "mg/dL",
        "average_glucose": average_glucose if average_glucose is not None else "Data not available",
        "valid_days": valid_days,
        "note": f"Glucose data collected from {valid_days} of past 14 days.",
        "raw_data": raw_data
    }

def fetch_hrv_summary(user_id, minimal=False):
    import requests
    from datetime import datetime, timedelta

    base_url = "https://devapi.revival365ai.com/data/chart/hrv_readings"
    today = datetime.today()
    total = 0
    count = 0
    valid_days = 0
    raw_data = []

    for i in range(14):
        date = today - timedelta(days=i)
        date_str = date.strftime("%Y-%m-%d")
        url = f"{base_url}/{user_id}/{date_str}"

        try:
            response = requests.get(url)
            response.raise_for_status()
            data = response.json()

            #print(f"\n📅 Date: {date_str}")
            #print("🔍 HRV API top-level keys:", list(data.keys()) if isinstance(data, dict) else "Response is a list")
            #print("👀 First item:", data["hrv_readings"][0] if "hrv_readings" in data and len(data["hrv_readings"]) > 0 else "No readings")

            if data.get("status") == 200 and "hrv_readings" in data:
                readings = data["hrv_readings"]
                if readings:
                    valid_days += 1
                for reading in readings:
                    val = reading.get("value")
                    if val is not None:
                        total += val
                        count += 1
                        raw_data.append({"date": date_str, "hrv": val})

        except Exception as e:
            print(f"⚠️ Error fetching or parsing HRV for {date_str}: {e}")
            continue

    average_hrv = round(total / count, 2) if count > 0 else None

    return {
        "tag": "hrv",
        "unit": "ms",
        "average": average_hrv if average_hrv is not None else "Data Not Available",
        "readings_count": count,
        "raw_data": raw_data,
        "note": f"Averaged over {count} readings from {valid_days} out of 14 days"
    }

def fetch_stress_summary(user_id, minimal=False):
    import requests
    from datetime import datetime, timedelta

    base_url = "https://devapi.revival365ai.com/data/chart/stress_readings"
    today = datetime.today()
    total = 0
    count = 0
    valid_days = 0
    raw_data = []

    for i in range(14):
        date = today - timedelta(days=i)
        date_str = date.strftime("%Y-%m-%d")
        url = f"{base_url}/{user_id}/{date_str}"

        try:
            response = requests.get(url)
            response.raise_for_status()
            data = response.json()

            #print(f"\n📅 Date: {date_str}")
            #print("🔍 Stress API top-level keys:", list(data.keys()) if isinstance(data, dict) else "Response is a list")
            #print("👀 First item:", data["stress_readings"][0] if "stress_readings" in data and len(data["stress_readings"]) > 0 else "No readings")

            if data.get("status") == 200 and "stress_readings" in data:
                readings = data["stress_readings"]
                if readings:
                    valid_days += 1
                for reading in readings:
                    val = reading.get("value")
                    if val is not None:
                        total += val
                        count += 1
                        raw_data.append({"date": date_str, "stress": val})

        except Exception as e:
            print(f"⚠️ Error fetching or parsing Stress for {date_str}: {e}")
            continue

    average_stress = round(total / count, 2) if count > 0 else None

    return {
        "tag": "stress",
        "unit": "score",
        "average": average_stress if average_stress is not None else "Data Not Available",
        "readings_count": count,
        "raw_data": raw_data,
        "note": f"Averaged over {count} readings from {valid_days} out of 14 days"
    }
def parse_sleep_string(sleep_str):
    import re
    hours = mins = 0
    h_match = re.search(r"(\d+)\s*H", sleep_str)
    m_match = re.search(r"(\d+)\s*M", sleep_str)
    if h_match:
        hours = int(h_match.group(1))
    if m_match:
        mins = int(m_match.group(1))
    return hours * 60 + mins

def minutes_to_hours_minutes(minutes):
    hours = minutes // 60
    mins = minutes % 60
    return f"{hours}h {mins}m"

def fetch_sleep_summary(user_id, minimal=False):
    import requests
    from datetime import datetime, timedelta

    base_url = "https://devapi.revival365ai.com/data/chart/sleep_readings"
    today = datetime.today()
    total_minutes = 0
    count = 0
    valid_days = 0
    raw_data = []

    for i in range(14):
        date = today - timedelta(days=i)
        date_str = date.strftime("%Y-%m-%d")
        url = f"{base_url}/{user_id}/{date_str}"

        try:
            response = requests.get(url)
            response.raise_for_status()
            data = response.json()

            #print(f"\n📅 Date: {date_str}")
            #print("🔍 Sleep API top-level keys:", list(data.keys()))
            #print("🛌 totalSleep string:", data.get("totalSleep", "Missing"))

            if data.get("status") == 200 and "totalSleep" in data:
                sleep_str = data["totalSleep"]
                minutes = parse_sleep_string(sleep_str)
                if minutes > 0:
                    total_minutes += minutes
                    count += 1
                    valid_days += 1
                    raw_data.append({
                        "date": date_str,
                        "totalSleepMinutes": minutes,
                        "duration": minutes_to_hours_minutes(minutes)
                    })

        except Exception as e:
            print(f"⚠️ Error fetching or parsing Sleep for {date_str}: {e}")
            continue

    average_minutes = round(total_minutes / count) if count > 0 else None

    return {
        "tag": "sleep",
        "unit": "minutes",
        "average": minutes_to_hours_minutes(average_minutes) if average_minutes is not None else "Data Not Available",
        "readings_count": count,
        "raw_data": raw_data,
        "note": f"Averaged over {count} readings from {valid_days} out of 14 days"
    }


if __name__ == "__main__":

    # Load input_data.json to extract user_id
    try:
        with open("input_data.json") as f:
            input_data = json.load(f)
            user_id = input_data.get("userProfile", {}).get("content", {}).get("id")
            if not user_id:
                raise ValueError("User ID not found in input_data.json")
    except Exception as e:
        print(f"❌ Error loading user ID from input_data.json: {e}")
        exit(1)

    # Fetch all data using user_id
    result = {
        "user_id": user_id,
        "activity_summary": fetch_activity_summary(user_id),
        "blood_pressure_summary": fetch_bp_summary(user_id),
        "cgm_summary": fetch_cgm_summary(user_id),
        "hrv_summary": fetch_hrv_summary(user_id),
        "stress_summary": fetch_stress_summary(user_id),
        "sleep_summary": fetch_sleep_summary(user_id),
    }

    # Print the full JSON
    #print(json.dumps(result, indent=4))

    # Save the result to a file
    with open("all_health_data_summary.json", "w") as f:
        json.dump(result, f, indent=4)

    print("✅ All health data saved to health_data_summary.json")

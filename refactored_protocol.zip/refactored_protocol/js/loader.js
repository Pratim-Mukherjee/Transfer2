function updateLoader(percent, message) {
  document.getElementById("loaderBar").style.width = percent + "%";
  document.getElementById("loaderMessage").textContent = message;
}

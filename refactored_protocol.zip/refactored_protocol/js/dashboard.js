// Show dashboard after data loads
function showDashboard() {
  document.getElementById('dashboard').style.display = 'block';
  populateHeader();
  createNavTabs();
  createContentSections();

  // Auto-click first tab
  setTimeout(() => {
    const firstTab = document.querySelector('.tab-btn');
    if (firstTab) firstTab.click();
  }, 100);
}

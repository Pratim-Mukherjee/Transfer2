

// ===== Original Script, adjusted for sidebar =====
let protocolData = null;

document.addEventListener('DOMContentLoaded', () => {

document.getElementById("runButton").addEventListener("click", async () => {
    const userId = document.getElementById("patientSelect").value.trim();
    if (!userId) {
        alert("Please enter a User ID.");
        return;
    }

    // Show overlay
    document.getElementById("loadingOverlay").style.display = "flex";

    try {
        // Step 1
        updateLoader(10, "Fetching patient data");
        await fetch("run_analysis.php", {
            method: "POST",
            headers: { "Content-Type": "application/x-www-form-urlencoded" },
            body: "xml_file=" + encodeURIComponent(userId),
        });

        // Step 2
        updateLoader(40, "Analyzing health metrics");
        await new Promise(r => setTimeout(r, 500)); // smooth wait

        // Step 3 (long stage)
       updateLoader(70, "Generating personalized protocol");

// Change to second message after 4.5s
setTimeout(() => {
    document.getElementById("loaderMessage").textContent = "Optimizing final recommendations";
}, 6500);

// Change to third message after 8s
setTimeout(() => {
    document.getElementById("loaderMessage").textContent = "Almost there...";
}, 12000);

        const resp = await fetch("run_generate_protocol.php", {
            method: "POST",
            headers: { "Content-Type": "application/x-www-form-urlencoded" },
            body: "user_id=" + encodeURIComponent(userId),
        });

        const data = await resp.json();

        // Step 4
        updateLoader(100, "Finalizing report");
        await new Promise(r => setTimeout(r, 500));

        protocolData = data;
        document.getElementById("loadingOverlay").style.display = "none";
        showDashboard();

    } catch (error) {
        console.error("Error:", error);
        alert("Failed to load protocol data.");
        document.getElementById("loadingOverlay").style.display = "none";
    }
});

function updateLoader(percent, message) {
    document.getElementById("loaderBar").style.width = percent + "%";
    document.getElementById("loaderMessage").textContent = message;
}

});

function showDashboard() {
    document.getElementById('dashboard').style.display = 'block';
    populateHeader();
    createNavTabs();
    createContentSections();
    setTimeout(() => {
        const firstTab = document.querySelector('.tab-btn');
        if (firstTab) firstTab.click();
    }, 100);
}

function populateHeader() {
    const header = document.getElementById('headerSection');
    const profile = protocolData?.profile || {};
    const safeValue = (val, fallback = 'N/A') => val ? String(val) : fallback;
    header.innerHTML = `
        <h3>${safeValue(protocolData?.title, 'Diabetes Reversal Protocol')}</h3>
        <p><strong>Patient:</strong> ${safeValue(profile.name)} | 
           <strong>Age:</strong> ${safeValue(profile.age)} | 
           <strong>Gender:</strong> ${safeValue(profile.gender)}</p>
    `;
}

function createNavTabs() {
    const navTabs = document.getElementById('navTabs');
    const sections = [
        { id: 'overview', title: '📋 Overview' },
        { id: 'metabolic', title: '📊 Metabolic State' },
        { id: 'science', title: '🔬 Science Behind' },
        { id: 'energy', title: '⚡ Energy Strategy' },
        { id: 'macros', title: '🍽️ Macro Targets' },
        { id: 'food', title: '🥗 Food Plan' },
        { id: 'timeline', title: '📅 Timeline' },
        { id: 'daily', title: '📋 Daily Plan' },
        
        { id: 'supplements', title: '💊 Supplements' },
        { id: 'checklist', title: '✅ Checklists' },
        { id: 'safety', title: '🚨 Safety' },
    ];
    navTabs.innerHTML = sections.map(section => `
        <button class="tab-btn" onclick="showSection('${section.id}')" data-section="${section.id}">
            ${section.title}
        </button>
    `).join('');
}

function createContentSections() {
    const container = document.getElementById('contentContainer');
    container.innerHTML = `
        ${createOverviewSection()}
        ${createMetabolicSection()}
        ${createScienceSection()}
        ${createEnergySection()}
        ${createMacroSection()}
        ${createFoodSection()}
        ${createTimelineSection()}
        ${createDailySection()}
        ${createSafetySection()}
        ${createSupplementsSection()}
        ${createChecklistSection()}
    `;
}
function createOverviewSection() {
    const quickView = protocolData.quick_view || {};
    const keyMetrics = quickView.key_metrics || {};
    const message = protocolData.success_mindset?.message || '';
    const closing = protocolData.success_mindset?.closing || '';
    const timeline = protocolData.transformation_timeline || {};

    const metrics = [
        { label: 'HbA1c', value: keyMetrics.hba1c },
        { label: 'Fasting Glucose', value: keyMetrics.fasting_glucose },
        { label: 'BMI', value: keyMetrics.bmi },
        { label: 'Risk Score', value: quickView.overall_risk_score }
    ];

    const metricsHTML = metrics.map(m => `
        <div class="metric-card">
            <div class="metric-label">${m.label}</div>
            <div class="metric-value">${m.value || 'N/A'}</div>
        </div>
    `).join('');

    // --- Phase by Phase Expectations ---
    const phases = timeline.phase_by_phase_expectations || {};
    const phaseKeys = Object.keys(phases).filter(k => k.startsWith('phase_'));
    const phasesHTML = phaseKeys.map(phaseKey => {
        const phase = phases[phaseKey];
        const weekKeys = Object.keys(phase).filter(k => k.startsWith('week_'));

        const weeksHTML = weekKeys.map(weekKey => {
            const week = phase[weekKey];
            return `
                <div class="week-card" style="
                    background:#fdfdff;
                    border-radius:10px;
                    padding:12px 15px;
                    margin-bottom:15px;
                    border:1px solid #ddd;
                    box-shadow:0 2px 6px rgba(0,0,0,0.05);
                ">
                    <div class="week-title" style="
                        font-weight:bold;
                        font-size:1.05em;
                        color:#2c5aa0;
                        margin-bottom:8px;
                    ">📅 ${week.title || ''}</div>
                    <ul style="margin:0; padding-left:18px; list-style:none;">
                        ${week.expected ? `<li>⚡ <strong>Expected:</strong> ${week.expected}</li>` : ''}
                        ${week.celebrate ? `<li>🎉 <strong>Celebrate:</strong> ${week.celebrate}</li>` : ''}
                        ${week.lab_changes ? `<li>🧪 <strong>Lab Changes:</strong> ${week.lab_changes}</li>` : ''}
                        ${week.improvements ? `<li>💤 <strong>Improvements:</strong> ${week.improvements}</li>` : ''}
                        ${week.major_wins ? `<li>🏆 <strong>Major Wins:</strong> ${week.major_wins}</li>` : ''}
                        ${week.lab_improvements ? `<li>🩺 <strong>Lab Improvements:</strong> ${week.lab_improvements}</li>` : ''}
                        ${week.major_markers ? `<li>📊 <strong>Major Markers:</strong> ${week.major_markers}</li>` : ''}
                        ${week.freedom ? `<li>🕊️ <strong>Freedom:</strong> ${week.freedom}</li>` : ''}
                    </ul>
                </div>
            `;
        }).join('');

        return `
            <div class="phase-card" style="
                background:#f7faff;
                border-left:5px solid #2c5aa0;
                border-radius:8px;
                padding:15px;
                margin-bottom:20px;
            ">
                <div class="phase-title" style="font-size:1.2em;font-weight:bold;color:#2c5aa0;margin-bottom:5px;">
                    ${phase.title || ''}
                </div>
                <div class="phase-subtitle" style="font-style:italic;color:#666;margin-bottom:10px;">
                    ${phase.what_happening || ''}
                </div>
                <div class="phase-weeks">${weeksHTML}</div>
            </div>
        `;
    }).join('');

    // --- Comorbidity Improvements ---
// --- Comorbidity Improvements ---
const comorbid = {
    blood_pressure_normalization: timeline.comorbidity_improvements?.blood_pressure_normalization || [],
    metabolic_syndrome_reversal: protocolData.metabolic_syndrome_reversal || {} // <-- fixed
};

// Helper: check if metabolic_syndrome_reversal has any data
const hasMSRData = Object.values(comorbid.metabolic_syndrome_reversal || {}).some(v => v && v.trim() !== '');

let comorbidHTML = '';
if (comorbid.blood_pressure_normalization.length > 0 || hasMSRData) {
    comorbidHTML = `
        <div class="comorbidity-section" style="display:grid;grid-template-columns:1fr 1fr;gap:15px;">
            ${comorbid.blood_pressure_normalization.length > 0 ? `
                <div class="comorbidity-card" style="background:#fdfdfd;padding:12px;border-radius:6px;border:1px solid #e0e0e0;">
                    <h4>🫀 Blood Pressure Normalization</h4>
                    <ul>${comorbid.blood_pressure_normalization.map(bp => `<li>${bp}</li>`).join('')}</ul>
                </div>
            ` : ''}

            ${hasMSRData ? `
                <div class="comorbidity-card" style="background:#fdfdfd;padding:12px;border-radius:6px;border:1px solid #e0e0e0;">
                    <h4>🧬 Metabolic Syndrome Reversal</h4>
                    <ul>
                        ${comorbid.metabolic_syndrome_reversal.triglycerides ? `<li>${comorbid.metabolic_syndrome_reversal.triglycerides}</li>` : ''}
                        ${comorbid.metabolic_syndrome_reversal.liver_function ? `<li>${comorbid.metabolic_syndrome_reversal.liver_function}</li>` : ''}
                        ${comorbid.metabolic_syndrome_reversal.insulin_sensitivity ? `<li>${comorbid.metabolic_syndrome_reversal.insulin_sensitivity}</li>` : ''}
                    </ul>
                </div>
            ` : ''}
        </div>
    `;
}

    return `
        <div class="content-section" id="overview">
            <h2 class="section-title">📋 Protocol Overview</h2>
            <div class="metrics-grid">${metricsHTML}</div>
            
            ${message || closing ? `
                <div class="data-card">
                    <div class="data-title">💡 Success Message</div>
                    <p class="success-message">${message}</p>
                    <p class="success-closing">${closing}</p>
                </div>
            ` : ''}

            ${phaseKeys.length > 0 ? `
                <div class="timeline-section">
                    <div class="data-title">🗓️ Transformation Timeline</div>
                    <p><em>${phases.note || ''}</em></p>
                    ${phasesHTML}
                </div>
            ` : ''}

            ${comorbidHTML}
        </div>
    `;
}

function createMetabolicSection() {
    const data = protocolData.current_metabolic_state || {};

    return `
        <div class="content-section" id="metabolic">
            <h2 class="section-title">📊 Current Metabolic State</h2>
            ${renderObjectAsCards(data.lab_profile_targets, '🧪 Lab Profile Targets')}
            ${renderObjectAsCards(data.energy_expenditure_analysis, '🔥 Energy Expenditure Analysis')}
            ${renderObjectAsCards(data.body_composition_assessment, '💪 Body Composition Assessment')}
        </div>
    `;
}

        
       function createScienceSection() {
    const data = protocolData.science_behind_reversal || {};

    // Map JSON keys to proper section titles
   // Map JSON keys to proper section titles
const renamedData = {
    "The Science Behind Reversal": {
        "Why Diabetes Developed": {
            "Explanation": data.why_developed_diabetes?.explanation,
            "Vicious Cycle": data.why_developed_diabetes?.vicious_cycle
        },
        "How to Reverse the Cycle": {
            "Our Approach": data.how_reverse_cycle?.approach,
            "Comparison of Approaches": data.how_reverse_cycle?.comparison,
            "The Reversal Process": data.how_reverse_cycle?.reversal_process
        },
        "Why Reversal Is Possible for You": data.why_reversal_possible
    }
};


    return `
        <div class="content-section" id="science">
            <h2 class="section-title">🔬 The Science Behind Reversal</h2>
            ${renderObjectAsCards(renamedData, 'Science Behind Reversal')}
        </div>
    `;
}

        
        function createEnergySection() {
            const data = protocolData.energy_calorie_strategy || {};
            
            return `
                <div class="content-section" id="energy">
                    <h2 class="section-title">⚡ Energy & Calorie Strategy</h2>
                    
                    ${renderObjectAsCards(data, 'Energy Strategy')}
                </div>
            `;
        }
        
        function createMacroSection() {
            const data = protocolData.macro_targets || {};
            
            return `
                <div class="content-section" id="macros">
                    <h2 class="section-title">🍽️ Macro Targets</h2>
                    
                    ${renderObjectAsCards(data, 'Macro Targets')}
                </div>
            `;
        }
       function createFoodSection() {
    const plan = protocolData.food_combination_plan || {};
    return `
        <div class="content-section" id="food">
            <h2 class="section-title">🥗 Food Combination Plan</h2>
            
            <!-- Cultural Preferences -->
            <div class="food-block">
                <h3>🌍 Cultural Preferences</h3>
                <p>${plan.cultural_preferences}</p>
            </div>

            <!-- Unlimited Combinations -->
            <div class="food-block">
                <h3>♾ Unlimited Combinations</h3>
                <ul>
                    <li><strong>Non-Starchy Vegetables:</strong> ${plan.unlimited_combinations?.non_starchy_vegetables}</li>
                    <li><strong>Use These To:</strong> ${plan.unlimited_combinations?.use_these_to}</li>
                </ul>
            </div>

            <!-- Protein Table -->
            ${renderMacroTable("Protein", plan.measured_combinations?.protein_building_blocks, "sample_daily_protein_combinations")}

            <!-- Carbohydrate Table -->
            ${renderMacroTable("Carbohydrates", plan.measured_combinations?.carbohydrate_building_blocks, "sample_daily_carb_combinations")}

            <!-- Healthy Fats Table -->
            ${renderMacroTable("Healthy Fats", plan.measured_combinations?.healthy_fat_building_blocks, "sample_daily_fat_combinations")}

            <!-- Avoid During Healing -->
            <div class="food-block warning">
                <h3>🚫 Avoid During Healing Phase</h3>
                <p><strong>Foods:</strong> ${plan.avoid_during_healing_phase?.foods}</p>
                <p><strong>Reason:</strong> ${plan.avoid_during_healing_phase?.reason}</p>
                <p><strong>Reintroduction:</strong> ${plan.avoid_during_healing_phase?.reintroduction}</p>
            </div>

            <!-- Daily Targets -->
            <div class="food-block">
                <h3>📅 Daily Combination Targets</h3>
                <div class="targets-grid">
                    <div class="target-card">
                        <h4>Base Day</h4>
                        <p><strong>Calories:</strong> ${plan.daily_combination_targets?.base_day?.calories}</p>
                        <p><strong>Build Meals:</strong> ${plan.daily_combination_targets?.base_day?.build_meals}</p>
                        <p><strong>Meal Distribution:</strong> ${plan.daily_combination_targets?.base_day?.meal_distribution}</p>
                        <p><strong>Timing Flexibility:</strong> ${plan.daily_combination_targets?.base_day?.timing_flexibility}</p>
                    </div>
                    <div class="target-card active">
                        <h4>Active Day</h4>
                        <p><strong>Calories:</strong> ${plan.daily_combination_targets?.active_day?.calories}</p>
                        <p><strong>Build Meals:</strong> ${plan.daily_combination_targets?.active_day?.build_meals}</p>
                        <p><strong>Extra Calories From:</strong> ${plan.daily_combination_targets?.active_day?.extra_calories_from}</p>
                        <p><strong>Timing:</strong> ${plan.daily_combination_targets?.active_day?.timing}</p>
                    </div>
                </div>
            </div>
        </div>
    `;
}

function renderMacroTable(title, macro, sampleKey) {
    if (!macro) return '';
    return `
        <div class="food-block">
            <h3>${title} (Daily Target: ${macro.daily_target})</h3>
            <table class="macro-table">
                <thead>
                    <tr><th>Item</th><th>Amount</th></tr>
                </thead>
                <tbody>
                    ${macro.choose_combinations.map(item => {
                        const [name, amount] = item.split("=");
                        return `<tr><td>${name.trim()}</td><td>${amount.trim()}</td></tr>`;
                    }).join('')}
                </tbody>
            </table>
            <div class="sample-combos">
                <strong>Sample Daily ${title} Combinations:</strong>
                <ul>
                    ${macro[sampleKey]?.map(opt => `<li>${opt}</li>`).join('')}
                </ul>
            </div>
        </div>
    `;
}

        
 function renderTransformationTimeline(timeline) {
    if (!timeline || !timeline.phase_by_phase_expectations) return '';

    const phases = timeline.phase_by_phase_expectations;
    let html = '';

    Object.keys(phases).forEach(phaseKey => {
        if (phaseKey === 'note') return; // Skip note

        const phase = phases[phaseKey];
        if (!phase) return;

        html += `
            <div class="phase-card">
                <h3 class="phase-title">${phase.title || ''}</h3>
                <p class="phase-desc">${phase.what_happening || ''}</p>
                <div class="weeks-grid">
        `;

        Object.keys(phase)
            .filter(k => k.startsWith('week_'))
            .sort((a, b) => parseInt(a.replace('week_', '')) - parseInt(b.replace('week_', '')))
            .forEach(weekKey => {
                const week = phase[weekKey];
                html += `
                    <div class="week-card">
                        <h4>${week.title || ''}</h4>
                        ${week.expected ? `<p><span class="label">Expected:</span> ${week.expected}</p>` : ''}
                        ${week.celebrate ? `<p><span class="label">Celebrate:</span> ${week.celebrate}</p>` : ''}
                        ${week.lab_changes ? `<p><span class="label">Lab Changes:</span> ${week.lab_changes}</p>` : ''}
                        ${week.improvements ? `<p><span class="label">Improvements:</span> ${week.improvements}</p>` : ''}
                        ${week.major_wins ? `<p><span class="label">Major Wins:</span> ${week.major_wins}</p>` : ''}
                        ${week.lab_improvements ? `<p><span class="label">Lab Improvements:</span> ${week.lab_improvements}</p>` : ''}
                        ${week.major_markers ? `<p><span class="label">Major Markers:</span> ${week.major_markers}</p>` : ''}
                        ${week.freedom ? `<p><span class="label">Freedom:</span> ${week.freedom}</p>` : ''}
                    </div>
                `;
            });

        html += `</div></div>`;
    });

    // Comorbidity improvements
    if (timeline.comorbidity_improvements) {
        const ci = timeline.comorbidity_improvements;
        html += `
            <div class="phase-card comorbidity-card">
                <h3>Comorbidity Improvements</h3>
                ${ci.blood_pressure_normalization ? `
                    <div class="ci-section">
                        <h4>Blood Pressure Normalization</h4>
                        <ul>
                            ${ci.blood_pressure_normalization.map(item => `<li>${item}</li>`).join('')}
                        </ul>
                    </div>
                ` : ''}
                ${ci.metabolic_syndrome_reversal ? `
                    <div class="ci-section">
                        <h4>Metabolic Syndrome Reversal</h4>
                        <ul>
                            ${Object.entries(ci.metabolic_syndrome_reversal)
                                .map(([key, val]) => `<li><strong>${key.replace(/_/g, ' ')}:</strong> ${val}</li>`)
                                .join('')}
                        </ul>
                    </div>
                ` : ''}
            </div>
        `;
    }

    return html;
}

  function createTimelineSection() {
    const data = protocolData.transformation_timeline || {};
    return `
        <div class="content-section" id="timeline">
            <h2 class="section-title">📅 Transformation Timeline</h2>
            ${renderTransformationTimeline(data)}
        </div>
    `;
}


        
        function createDailySection() {
            const data = protocolData.daily_implementation_plan || {};
            
            return `
                <div class="content-section" id="daily">
                    <h2 class="section-title">📋 Daily Implementation Plan</h2>
                    
                    ${renderObjectAsCards(data, 'Daily Plan')}
                </div>
            `;
        }
        
        function createSafetySection() {
            const data = protocolData.critical_safety_protocols_requirements || {};
            
            return `
                <div class="content-section" id="safety">
                    <h2 class="section-title">🚨 Critical Safety Protocols</h2>
                    
                    ${renderObjectAsCards(data, 'Safety Protocols')}
                </div>
            `;
        }
        
      function createSupplementsSection() {
    const data = protocolData.supplement_plan || protocolData.supplement_recommendations || {};

    // Get "Based On" text
    let basedOnHTML = data.based_on ? `<p></p>` : '';

    // Build Morning/Evening supplement lists
    let supplementsHTML = '';
    if (data.required_supplements) {
        ['morning', 'evening'].forEach(time => {
            if (data.required_supplements[time]) {
                const section = data.required_supplements[time];
                const listItems = (section.supplements || [])
                    .map(s => `<li><strong>${s.supplement}</strong> – ${s.dose}${s.reason ? ` <em>(${s.reason})</em>` : ''}</li>`)
                    .join('');

                supplementsHTML += `
                    <div class="supplement-time">
                        <h3>${section.title || time.toUpperCase()}</h3>
                        <ul>${listItems || '<li>No supplements</li>'}</ul>
                    </div>
                `;
            }
        });
    }

    return `
        <div class="content-section" id="supplements">
            <h2 class="section-title">💊 Supplement Plan</h2>
            ${basedOnHTML}
            ${supplementsHTML}
        </div>
    `;
}

        
     function renderDailyImplementationPlan(plan) {
    if (!plan) return '';

    const sections = [
        { key: 'morning_routine', title: 'Morning Routine' },
        { key: 'midday_execution', title: 'Midday Execution' },
        { key: 'evening_routine', title: 'Evening Routine' }
    ];

    let html = '';

    // Render routines with activities
    sections.forEach(section => {
        const data = plan[section.key];
        if (!data) return;

        const time = data.time || '';
        const activities = Array.isArray(data.activities) ? data.activities : [];

        const activityItems = activities.map(activity => `
            <li class="checklist-item">
                <label>
                    <input type="checkbox">
                    ${activity}
                </label>
            </li>
        `).join('');

        html += `
            <div class="content-section routine-section" id="${section.key}">
                <h3 class="section-subtitle">✅ ${section.title}</h3>
                <div class="routine-time"><strong>Time:</strong> ${time}</div>
                <ul class="checklist-list">
                    ${activityItems}
                </ul>
            </div>
        `;
    });

    // Render daily targets
    if (plan.daily_totals_targets) {
        const targets = plan.daily_totals_targets;
        html += `
            <div class="content-section daily-targets">
                <h3 class="section-subtitle">🎯 Daily Targets</h3>
                <ul class="target-list">
                    <li><strong>Energy Expenditure:</strong> Resting: ${targets.total_daily_energy_expenditure?.resting}, 
                        Activity: ${targets.total_daily_energy_expenditure?.activity}, 
                        Thermic Effect: ${targets.total_daily_energy_expenditure?.thermic_effect}, 
                        Total: ${targets.total_daily_energy_expenditure?.total}</li>
                    <li><strong>HRV Targets:</strong> Morning Baseline: ${targets.daily_hrv_targets?.morning_baseline}, 
                        Post-Exercise Recovery: ${targets.daily_hrv_targets?.post_exercise_recovery}, 
                        Evening Preparation: ${targets.daily_hrv_targets?.evening_preparation}, 
                        Overnight Peak: ${targets.daily_hrv_targets?.overnight_peak}</li>
                    <li><strong>CGM Patterns:</strong> Time in Range: ${targets.daily_cgm_patterns?.time_in_range}, 
                        Avg Glucose: ${targets.daily_cgm_patterns?.average_glucose}, 
                        Variability: ${targets.daily_cgm_patterns?.glucose_variability}</li>
                    <li><strong>Daily Step Target:</strong> ${targets.daily_step_target}</li>
                </ul>
            </div>
        `;
    }

    return html;
}

function createChecklistSection() {
    const checklists = protocolData.quick_reference_checklists || {};
    const dailyPlan = protocolData.daily_implementation_plan;

    return `
        <div class="content-section" id="checklist">
            <h2 class="section-title">✅ Quick Reference Checklists</h2>
            ${renderObjectAsCards(checklists, 'Checklists')}
            ${renderDailyImplementationPlan(dailyPlan)}
        </div>
    `;
}

function renderObjectAsCards(obj, title = '') {
    if (!obj || typeof obj !== 'object') {
        return `<div class="data-card"><p>No data available for ${title}</p></div>`;
    }

    let html = title ? `<h3 class="subsection-title">${title}</h3>` : '';

    html += '<div class="card-container">';

    for (const key in obj) {
        const value = obj[key];
        const label = formatKey(key);

        // 👇 Nested subsection rendering
        if (typeof value === 'object' && !Array.isArray(value)) {
            const keys = Object.keys(value);
            const hasNestedStructure = keys.some(k => typeof value[k] === 'object');

            // If children are objects with current/target or nested → treat as subsection
            if (hasNestedStructure && !('current' in value || 'target' in value)) {
                html += `
                    <div class="sub-subsection-title">${label}</div>
                    ${renderObjectAsCards(value)} <!-- RECURSIVE -->
                `;
                continue;
            }

            // 👇 Handle current/target display
            if ('current' in value || 'target' in value) {
                html += `
                    <div class="data-card">
                        <div class="data-title">${label}</div>
                        <p><strong>Current:</strong> ${value.current || '—'}</p>
                        <p><strong>Target:</strong> ${value.target || '—'}</p>
                    </div>
                `;
                continue;
            }

            // 👇 Fallback: key-value object (e.g. c_peptide, liver_glucose)
            const fallback = Object.entries(value)
                .map(([k, v]) => `<p><strong>${formatKey(k)}:</strong> ${v}</p>`)
                .join('');
            html += `
                <div class="data-card">
                    <div class="data-title">${label}</div>
                    ${fallback}
                </div>
            `;
        }

        // 👇 Plain string or number
        else if (typeof value === 'string' || typeof value === 'number') {
            html += `
                <div class="data-card">
                    <div class="data-title">${label}</div>
                    <p>${value}</p>
                </div>
            `;
        }

        // 👇 List of strings (e.g. checklists)
        else if (Array.isArray(value) && value.every(v => typeof v === 'string')) {
            html += `
                <div class="data-card">
                    <div class="data-title">${label}</div>
                    <ul class="data-list">
                        ${value.map(item => `<li>✅ ${item}</li>`).join('')}
                    </ul>
                </div>
            `;
        }
    }

    html += '</div>';
    return html;
}



        function renderValue(value) {
    if (typeof value === 'object') {
        return Object.entries(value)
            .map(([k, v]) => `<p><strong>${formatKey(k)}:</strong> ${v}</p>`)
            .join('');
    } else {
        return `<p>${value}</p>`;
    }
}
function formatKey(key) {
    return key.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
}


// ==== All your original section functions pasted here ====
/* paste full createOverviewSection, createMetabolicSection, createScienceSection, createEnergySection, createMacroSection, createFoodSection, createTimelineSection, createDailySection, createSafetySection, createSupplementsSection, createChecklistSection, renderObjectAsCards, formatKey exactly from your file */

function showSection(sectionId) {
    document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
    document.querySelector(`[data-section="${sectionId}"]`).classList.add('active');
    document.querySelectorAll('.content-section').forEach(sec => sec.classList.remove('active'));
    document.getElementById(sectionId).classList.add('active');
}


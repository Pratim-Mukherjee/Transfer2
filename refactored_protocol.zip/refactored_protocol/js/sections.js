// ======================
// SECTION HELPERS
// ======================
function renderObjectAsCards(obj, container) {
  Object.entries(obj).forEach(([key, value]) => {
    const card = document.createElement("div");
    card.className = "card";
    card.innerHTML = `<h3>${formatKey(key)}</h3><p>${value}</p>`;
    container.appendChild(card);
  });
}

function formatKey(key) {
  return key.replace(/_/g, " ").replace(/\b\w/g, c => c.toUpperCase());
}

// ======================
// SECTION BUILDERS
// ======================
function populateHeader() {
  if (!protocolData?.patient_info) return;
  document.getElementById("headerSection").innerHTML = `
    <h2>${protocolData.patient_info.name}</h2>
    <p>Age: ${protocolData.patient_info.age}, Gender: ${protocolData.patient_info.gender}</p>
  `;
}

function createNavTabs() {
  const tabs = [
    "Overview", "Metabolic Health", "Medication", "Lifestyle",
    "Protocol", "Timeline", "Adherence"
  ];
  const navTabs = document.getElementById("navTabs");
  navTabs.innerHTML = "";

  tabs.forEach(tab => {
    const btn = document.createElement("button");
    btn.textContent = tab;
    btn.className = "tab-btn";
    btn.addEventListener("click", () => showSection(tab.toLowerCase().replace(/ /g, "_")));
    navTabs.appendChild(btn);
  });
}

function createContentSections() {
  const sections = {
    overview: createOverviewSection,
    metabolic_health: createMetabolicSection,
    medication: createMedicationSection,
    lifestyle: createLifestyleSection,
    protocol: createProtocolSection,
    timeline: createTimelineSection,
    adherence: createAdherenceSection,
  };

  const container = document.getElementById("contentContainer");
  container.innerHTML = "";

  Object.entries(sections).forEach(([id, builder]) => {
    const sec = document.createElement("div");
    sec.id = id;
    sec.className = "content-section";
    sec.style.display = "none";
    builder(sec);
    container.appendChild(sec);
  });
}

function showSection(sectionId) {
  document.querySelectorAll(".content-section").forEach(sec => sec.style.display = "none");
  const active = document.getElementById(sectionId);
  if (active) active.style.display = "block";
}

// ======================
// INDIVIDUAL SECTIONS
// ======================
function createOverviewSection(container) {
  container.innerHTML = `<h2>Overview</h2>`;
  if (protocolData?.overview) renderObjectAsCards(protocolData.overview, container);
}

function createMetabolicSection(container) {
  container.innerHTML = `<h2>Metabolic Health</h2>`;
  if (protocolData?.metabolic_health) renderObjectAsCards(protocolData.metabolic_health, container);
}

function createMedicationSection(container) {
  container.innerHTML = `<h2>Medication</h2>`;
  if (protocolData?.medication) renderObjectAsCards(protocolData.medication, container);
}

function createLifestyleSection(container) {
  container.innerHTML = `<h2>Lifestyle</h2>`;
  if (protocolData?.lifestyle) renderObjectAsCards(protocolData.lifestyle, container);
}

function createProtocolSection(container) {
  container.innerHTML = `<h2>Protocol</h2>`;
  if (protocolData?.protocol) renderObjectAsCards(protocolData.protocol, container);
}

function createTimelineSection(container) {
  container.innerHTML = `<h2>Timeline</h2>`;
  if (protocolData?.timeline) renderObjectAsCards(protocolData.timeline, container);
}

function createAdherenceSection(container) {
  container.innerHTML = `<h2>Adherence</h2>`;
  if (protocolData?.adherence) renderObjectAsCards(protocolData.adherence, container);
}

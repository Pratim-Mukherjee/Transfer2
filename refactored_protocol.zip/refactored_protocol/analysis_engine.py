import xml.etree.ElementTree as ET
import pandas as pd
import re
import json
import argparse  
from datetime import datetime
import os
import requests
from requests.exceptions import RequestException
import tempfile

# Hardcoded credentials for API authentication
EMAIL = "pythonapi@yopmail.com"
PASSWORD = "Stixis@123"

# Base URLs
LOGIN_URL = "https://devapi.revival365ai.com/admin/user/login"
PROFILE_URL = "https://devapi.revival365ai.com/user/getProfile"
QUESTIONNAIRE_URL = "https://devapi.revival365ai.com/questions/patients/{user_id}"
XML_REPORT_URL = "https://devapi.revival365ai.com/medicalreport/getxmlreports/{user_id}"
#XML_REPORT_URL = "http://192.168.1.20:8084/medicalreport/getxmlreports/{user_id}"


ACCESS_TOKEN = None

CONFIG = {
    "biomarkers": {
        "Fasting Blood Sugar (Glucose)": {"range": [75, 90]},
        "HbA1c": {"range": [4.6, 5.6]},
        "Glucagon": {"range": [50, 100]},
        "Average Blood Glucose (ABG)": {"range": [90, 120]},
        "Insulin - Fasting": {"range": [2, 5]},
        "C-PEPTIDE": {"range": [1.9, 3]},
        "HOMA-IR": {"range": [0.75, 1.25]},
        "Total Cholesterol": {"range": [0, 190]},
        "HDL Cholesterol - Direct": {"range": [60, 150]},
        "LDL Cholesterol - Direct": {"range": [0, 120]},
        "TRIG / HDL RATIO": {"range": [0, 2]},
        "Triglycerides": {"range": [0, 100]},
        "Apolipoprotein - B (APO-B)": {"range": [52, 80]},
        "Erythrocyte Sedimentation Rate (ESR)": {"range": [0, 10]},
        "Ferritin": {"range": [75, 150]},
        "Iron": {"range": [80, 100]},
        "Total Iron Binding Capacity (TIBC)": {"range": [250, 350]},
        "% Transferrin Saturation": {"range": [30, 40]},
        "Unsat.Iron-Binding Capacity(UIBC)": {"range": [130, 300]},
        "Alanine Transaminase (SGPT)": {"range": [10, 26]},
        "Aspartate Aminotransferase (SGOT)": {"range": [10, 26]},
        "Gamma Glutamyl Transferase (GGT)": {"range": [10, 26]},
        "Bilirubin - Total": {"range": [0.5, 0.9]},
        "Bilirubin -Direct": {"range": [0.1, 0.15]},
        "Bilirubin (Indirect)": {"range": [0.4, 0.75]},
        "Alkaline Phosphatase": {"range": [45, 90]},
        "Blood Urea Nitrogen (BUN)": {"range": [12, 22]},
        "Creatinine - Serum": {"range": [0.8, 1.1]},
        "Est. Glomerular Filtration Rate (eGFR)": {"range": [90, 120]},
        "Uric Acid": {"range": [4.2, 5.4]},
        "Calcium": {"range": [9.4, 9.8]},
        "High Sensitivity C-Reactive Protein (HS-CRP)": {"range": [0, 0.9]},
        "Homocysteine": {"range": [5.0, 12]},
        "Neutrophil-Lymphocyte Ratio (NLR)": {"range": [1.0, 2.4]},
        "Estradiol/Oestrogen (E2)": {"gender_specific": True,
                                     "male": {"range": [0, 40]},
                                     "female": {"range": [30, 350]}},
        "Interleukin 6 (IL-6)": {"range": [0, 7]},
        "Adiponectin": {"range": [5, 37]},
        "Lactate Dehydrogenase (LDH)": {"range": [150, 175]},
        "Microalbumin/ACR": {"range": [0, 30]},
        "Parathyroid Hormone (PTH)": {"range": [10, 65]},
        "TSH - Ultrasensitive": {"range": [0.4, 2.8]},
        "Free Testosterone": {"gender_specific": True,
                              "male": {"range": [15, 25]},
                              "female": {"range": [0, 15]}},
        "Potassium": {"range": [4, 4.4]},
        "Magnesium": {"range": [2, 2.4]},
        "Sodium": {"range": [135, 145]},
        "Vitamin B-12": {"range": [500, 1100]},
        "25-OH Vitamin D (Total)": {"range": [50, 100]},
        "Albumin - Serum": {"range": [4.0, 5.0]},
        "Serum Globulin": {"range": [2.0, 3.0]},
        "UIBC": {"range": [162, 368]},
        "FT3": {"range": [3.2, 4.4]},
        "FT4": {"range": [1.0, 1.5]},
        "Protein": {"range": [6.0, 8.5]},
        "Albumin:Globulin": {"range": [1.8, 2.0]},
        "BUN / SR.CREATININE RATIO": {"range": [9, 23]},
        "Amylase": {"range": [30, 115]},
        "Lipase": {"range": [30, 140]},
        "GAD Antibodies": {"present"},
        "TNF-alpha": {"range": [0, 8.1]},
        "Leptin": {"range": [0.5, 15]},
        "Insulin:Proinsulin": {"range": [0, 0.15]},
        "HDL / LDL RATIO": {"range": [0.4, 5]},
        "SGOT / SGPT RATIO": {"range": [0, 2]},
        "UREA / SR.CREATININE RATIO": {"range": [0, 52]},
        "NON-HDL CHOLESTEROL": {"range": [0, 160]},
        "Retinol binding protein-4": {"range": [15, 60]},
        "Free fatty acids": {"range": [0.2, 0.7]},
        "Plassma Fibronectin": {"range": [300, 400]},
        "Basophils - Absolute Count": {"range": [0.02, 0.1]},
        "Eosinophils - Absolute Count": {"range": [0.02, 0.5]},
        "Lymphocytes - Absolute Count": {"range": [1.0, 3.0]},
        "Monocytes - Absolute Count": {"range": [0.2, 1.0]},
        "NEUTROPHILS - ABSOLUTE COUNT": {"range": [2.0, 7.0]},
        "BASOPHILS": {"range": [0, 2]},
        "EOSINOPHILS": {"range": [1, 6]},
        "HEMOGLOBIN": {"range": [12.0, 15.0]},
        "TOTAL LEUCOCYTES COUNT (WBC)": {"range": [4.0, 10.0]},
        "URINARY PROTEIN": {"present"},
        "LYMPHOCYTE": {"range": [20, 40]},
        "MEAN CORPUSCULAR HEMOGLOBIN(MCH)": {"range": [27.0, 32.0]},
        "MEAN CORP.HEMO.CONC(MCHC)": {"range": [31.5, 34.5]},
        "MEAN CORPUSCULAR VOLUME(MCV)": {"range": [83.0, 101.0]},
        "MONOCYTES": {"range": [2, 10]},
        "MEAN PLATELET VOLUME(MPV)": {"range": [6.5, 12]},
        "NEUTROPHILS": {"range": [40, 80]},
        "PLATELET COUNT": {"range": [150, 410]},
        "TOTAL RBC": {"range": [3.8, 4.8]},
        "RED CELL DISTRIBUTION WIDTH (RDW-CV)": {"range": [11.6, 14.0]},
        "PROTEIN - TOTAL": {"range": [5.7, 8.2]},
        "UREA (CALCULATED)": {"range": [17, 43]},
        "VLDL CHOLESTEROL": {"range": [5, 40]},
        "Waist to height ratio": {"gender_specific": True,
                                  "male": {"range": [0, 0.9]},
                                  "female": {"range": [0, 0.85]}},
        "BMI": {"range": [15, 25]}
    },
    "marker_groups": {
    "Liver Markers": [
        "ALANINE TRANSAMINASE (SGPT)",
        "Aspartate Aminotransferase (SGOT)",  
        "GAMMA GLUTAMYL TRANSFERASE (GGT)",
        "BILIRUBIN - TOTAL",
        "BILIRUBIN -DIRECT",
        "BILIRUBIN (INDIRECT)",
        "ALKALINE PHOSPHATASE",
        "SGOT / SGPT RATIO",
        "URINARY BILIRUBIN"
    ],
    "Kidney Markers": [
        "CREATININE - SERUM",
        "BLOOD UREA NITROGEN (BUN)",
        "URIC ACID",
        "EST. GLOMERULAR FILTRATION RATE (eGFR)",
        "MICROALBUMIN/ACR",
        "BUN / SR.CREATININE RATIO",
        "UREA / SR.CREATININE RATIO",
        "UREA (CALCULATED)"
    ],
    "Cardiac Markers": [
        "HIGH SENSITIVITY C-REACTIVE PROTEIN (HS-CRP)",
        "HOMOCYSTEINE",
        "TOTAL CHOLESTEROL",
        "HDL CHOLESTEROL - DIRECT",
        "LDL CHOLESTEROL - DIRECT",
        "TRIGLYCERIDES",
        "TRIG / HDL RATIO",
        "APOLIPOPROTEIN - B (APO-B)",
        "VLDL CHOLESTEROL",
        "HDL / LDL RATIO",
        "LDL / HDL RATIO",
        "NON-HDL CHOLESTEROL",
        "TC/ HDL CHOLESTEROL RATIO"
    ],
    "Blood Sugar Markers": [
        "FASTING BLOOD SUGAR(GLUCOSE)",
        "HbA1c",
        "INSULIN - FASTING",
        "HOMA-IR",
        "AVERAGE BLOOD GLUCOSE (ABG)",
        "C-PEPTIDE",
        "URINARY GLUCOSE"
    ],
    "Inflammatory Markers": [
        "ERYTHROCYTE SEDIMENTATION RATE (ESR)",
        "LACTATE DEHYDROGENASE (LDH)",
        "INTERLEUKIN 6 (IL-6)",
        "TNF-ALPHA",
        "NEUTROPHIL-LYMPHOCYTE RATIO (NLR)"
    ],
    "Hematological Markers": [
        "HEMOGLOBIN",
        "TOTAL LEUCOCYTES COUNT (WBC)",
        "PLATELET COUNT",
        "TOTAL RBC",
        "BASOPHILS - ABSOLUTE COUNT",
        "EOSINOPHILS - ABSOLUTE COUNT",
        "LYMPHOCYTES - ABSOLUTE COUNT",
        "MONOCYTES - ABSOLUTE COUNT",
        "NEUTROPHILS - ABSOLUTE COUNT",
        "BASOPHILS",
        "EOSINOPHILS",
        "LYMPHOCYTE",
        "MONOCYTES",
        "NEUTROPHILS",
        "IMMATURE GRANULOCYTES(IG)",
        "IMMATURE GRANULOCYTE PERCENTAGE(IG%)",
        "NUCLEATED RED BLOOD CELLS",
        "NUCLEATED RED BLOOD CELLS %",
        "PLATELETCRIT(PCT)",
        "HEMATOCRIT(PCV)",
        "PLATELET DISTRIBUTION WIDTH(PDW)",
        "PLATELET TO LARGE CELL RATIO(PLCR)",
        "RED CELL DISTRIBUTION WIDTH (RDW-CV)",
        "RED CELL DISTRIBUTION WIDTH - SD(RDW-SD)",
        "MEAN CORPUSCULAR HEMOGLOBIN(MCH)",
        "MEAN CORP.HEMO.CONC(MCHC)",
        "MEAN CORPUSCULAR VOLUME(MCV)",
        "MEAN PLATELET VOLUME(MPV)",
        "RED BLOOD CELLS",
        "URINARY LEUCOCYTES (PUS CELLS)"
    ],
    "Nutritional and Endocrine Markers": [
        "VITAMIN B-12",
        "25-OH VITAMIN D (TOTAL)",
        "CALCIUM",
        "MAGNESIUM",
        "POTASSIUM",
        "SODIUM",
        "FERRITIN",
        "IRON",
        "CHLORIDE",
        "PHOSPHOROUS",
        "TOTAL IRON BINDING CAPACITY (TIBC)",
        "% TRANSFERRIN SATURATION",
        "UNSAT.IRON-BINDING CAPACITY(UIBC)",
        "ESTRADIOL/OESTROGEN (E2)",
        "FREE TESTOSTERONE",
        "TSH - ULTRASENSITIVE",
        "FREE TRIIODOTHYRONINE (FT3)",
        "FREE THYROXINE (FT4)",
        "PARATHYROID HORMONE (PTH)"
    ],
    "Protein and Other Markers": [
        "PROTEIN - TOTAL",
        "ALBUMIN - SERUM",
        "SERUM GLOBULIN",
        "SERUM ALB/GLOBULIN RATIO",
        "URINARY PROTEIN",
        "URINE KETONE"
    ]
},
    

    "marker_suggestions": {
    "Liver Markers": {
        "high": "Consider liver detox protocols or  supplementation to support liver health. ",
        "low": "Monitor liver function through regular check-ups. "
    },
    "Kidney Markers": {
        "high": "Increase hydration and reduce protein overload to support kidney function. ",
        "low": "Ensure adequate protein intake and hydration. "
    },
    "Cardiac Markers": {
        "high": "Adopt a heart-healthy diet (low saturated fats, high omega-3s) and increase physical activity. ",
        "low": "Maintain a balanced diet and active lifestyle to support heart health. Low values may require monitoring."
    },
    "Blood Sugar Markers": {
        "high": "Focus on a low-glycemic diet, reduce refined carbs, and increase physical activity. ",
        "low": "Monitor for hypoglycemia risk and eat small, frequent meals to stabilize blood sugar."
    },
    "Inflammatory Markers": {
        "high": "Adopt an anti-inflammatory diet (e.g., rich in antioxidants, omega-3s) and reduce stress.",
        "low": "Low inflammation is generally positive."
    },
    "Hematological Markers": {
        "high": "Evaluate for conditions like dehydration or infection.",
        "low": "Ensure a nutrient-rich diet (e.g., iron, B-vitamins) to support blood health."
    },
    "Nutritional and Endocrine Markers": {
        "high": "Evaluate diet and lifestyle for excesses in certain nutrients or hormonal imbalances.",
        "low": "Consider supplementation (e.g., Vitamin D, B-12) or dietary adjustments to address deficiencies."
    },
    "Protein and other markers":{
        "high": "Elevated protein levels or related markers may indicate dehydration or other conditions.",
        "low": "Low protein levels could suggest malnutrition or absorption issues. Increase protein intake through diet."
    }

    },

    "phenotypes": {
        "insulin_resistant": {
            "HbA1c": {"greater_than": 5.3},
            "Insulin - Fasting": {"greater_than": 5},
            "C-PEPTIDE": {"greater_than": 1.6},
            "HOMA-IR": {"greater_than": 1.25},
            "male": {
                "Waist to height ratio": {"greater_than": 9},
                "BMI": {"greater_than": 25}
            },
            "female": {
                "Waist to height ratio": {"greater_than": 0.85},
                "BMI": {"greater_than": 25}
            }
        },
        "Beta_cell_dysfunction": {
            "HbA1c": {"greater_than": 5.3},
            "Insulin - Fasting": {"less_than": 2},
            "C-PEPTIDE": {"less_than": 1.6},
            "HOMA-IR": {"less_than": 0.75}
        },
        "Glycemic_instability": {

            "Glycemic stability scale": {
                # add
            },
            "Time in Range": {"greater_than": 180},
            "IPI": {"less_than": 80}
        },
        "Mixed_Phenotype": {
            "HbA1c": {"greater_than": 5.3},
            "Insulin - Fasting": {"less_than": 2},
            "C-PEPTIDE": {"less_than": 1.6},
            "HOMA-IR": {"greater_than": 1.25}
        },
        "Early_prediabetic": {
            "HbA1c": {"greater_than": 5.0, "less_than":5.4},
            "HOMA-IR": {"less_than": 1.25},
            "HDL Cholesterol - Direct": {"less_than": 52},
            "LDL Cholesterol - Direct": {"greater_than": 120},
            "Apolipoprotein - B (APO-B)": {"greater_than": 90},
            "Total Cholesterol": {"greater_than": 190},
            "Triglycerides": {"greater_than": 100},
            "Vitamin B-12": {"less_than": 500},
            "25-OH Vitamin D (Total)": {"less_than": 50},
            "male": {
                "Waist to height ratio": {"greater_than": 9},
                "BMI": {"greater_than": 25}
            },
            "female": {
                "Waist to height ratio": {"greater_than": 0.85},
                "BMI": {"greater_than": 25}
            }
        }
    },
    "pathways": {
        "Polyol_pathway": {
            "HbA1c": {"greater_than": 5.6},
            "Insulin - Fasting": {"greater_than": 5},
            "Average Blood Glucose (ABG)": {"greater_than": 120},
            "HOMA-IR": {"greater_than": 1.25},
            "C-PEPTIDE": {"greater_than": 1.6}
        },
        "AGE_pathway": {
            "HbA1c": {"greater_than": 5.6},
            "Average Blood Glucose (ABG)": {"greater_than": 120},
            "Homocysteine": {"greater_than": 7.2},
            "Ferritin": {"greater_than": 150},
            "Creatinine - Serum": {"greater_than": 1.1},
            "Est. Glomerular Filtration Rate (eGFR)": {"less_than": 90},
            "Lactate Dehydrogenase (LDH)": {"greater_than": 175},
            "High Sensitivity C-Reactive Protein (HS-CRP)": {"greater_than": 0.9},
            "Microalbumin/ACR": {"greater_than": 30},
            "Gamma Glutamyl Transferase (GGT)": {"greater_than": 26},
            "Vitamin B-12": {"less_than": 500}
        },
        "PKC_pathway": {
            "HDL Cholesterol - Direct": {"less_than": 52},
            "LDL Cholesterol - Direct": {"greater_than": 120},
            "Apolipoprotein - B (APO-B)": {"greater_than": 90},
            "Total Cholesterol": {"greater_than": 190},
            "Triglycerides": {"greater_than": 100},
            "TRIG / HDL RATIO": {"greater_than": 2.9},
            "Alanine Transaminase (SGPT)": {"greater_than": 26},
            "Aspartate Aminotransferase (SGOT)": {"greater_than": 26},
            "Gamma Glutamyl Transferase (GGT)": {"greater_than": 26},
            "Lactate Dehydrogenase (LDH)": {"greater_than": 175},
            "Ferritin": {"greater_than": 150},
            "Uric Acid": {"greater_than": 5.4}
        },
        "Hexoseamine_Pathway": {
            "Average Blood Glucose (ABG)": {"greater_than": 120},
            "Insulin - Fasting": {"greater_than": 5},
            "HOMA-IR": {"greater_than": 1.25},
            "C-PEPTIDE": {"greater_than": 1.6},
            "25-OH Vitamin D (Total)": {"less_than": 50},
            "Magnesium": {"less_than": 2},
            "Lactate Dehydrogenase (LDH)": {"greater_than": 175},
            "Triglycerides": {"greater_than": 100}
        },
        "Oxidative_stress_and_inflammation_Pathway": {
            "Erythrocyte Sedimentation Rate (ESR)": {"greater_than": 10},
            "High Sensitivity C-Reactive Protein (HS-CRP)": {"greater_than": 0.9},
            "Interleukin 6 (IL-6)": {"greater_than": 7},
            "TNF-alpha": {"greater_than": 8.1},
            "Neutrophil-Lymphocyte Ratio (NLR)": {"greater_than": 2.4},
            "Leptin": {"greater_than": 15},
            "Adiponectin": {"less_than": 5},
            "Homocysteine": {"greater_than": 7.2},
            "HDL Cholesterol - Direct": {"less_than": 52},
            "LDL Cholesterol - Direct": {"greater_than": 99},
            "Apolipoprotein - B (APO-B)": {"greater_than": 90},
            "Total Cholesterol": {"greater_than": 190},
            "TRIG / HDL RATIO": {"greater_than": 2.9},
            "Ferritin": {"greater_than": 150},
            "Lactate Dehydrogenase (LDH)": {"greater_than": 175},
            "Alanine Transaminase (SGPT)": {"greater_than": 26},
            "Aspartate Aminotransferase (SGOT)": {"greater_than": 26},
            "Gamma Glutamyl Transferase (GGT)": {"greater_than": 26}
        },
        "Dyslipidemia": {
            "HDL Cholesterol - Direct": {"less_than": 52},
            "LDL Cholesterol - Direct": {"greater_than": 99},
            "Apolipoprotein - B (APO-B)": {"greater_than": 90},
            "Total Cholesterol": {"greater_than": 190},
            "Triglycerides": {"greater_than": 100},
            "TRIG / HDL RATIO": {"greater_than": 2.9},
            "male": {
                "Waist to height ratio": {"greater_than": 9},
            },
            "female": {
                "Waist to height ratio": {"greater_than": 0.85},
                "BMI": {"greater_than": 25}

            },
            "RAS_Pathway": {
                "Creatinine - Serum": {"greater_than": 1.1},
                "Est. Glomerular Filtration Rate (eGFR)": {"less_than": 90},
                "Blood Urea Nitrogen (BUN)": {"greater_than": 22},
                "Uric Acid": {"greater_than": 5.4},
                "Albumin - Serum": {"less_than": 3.5},
                "Microalbumin/ACR": {"greater_than": 30},
                "Insulin - Fasting": {"greater_than": 5},
                "HOMA-IR": {"greater_than": 1.25},
                "HbA1c": {"greater_than": 5.6}
            
           
            }
        }
    },
    "complications": {
        "CVD": {
            "HbA1c": {"greater_than": 5.6, "weight": 9},
            "Average Blood Glucose (ABG)": {"greater_than": 120, "weight": 9},
            "Insulin - Fasting": {"greater_than": 5, "weight": 10},
            "HOMA-IR": {"greater_than": 1.25, "weight": 10},
            "Total Cholesterol": {"greater_than": 190, "weight": 8},
            "HDL Cholesterol - Direct": {"less_than": 52, "weight": 8},
            "LDL Cholesterol - Direct": {"greater_than": 120, "weight": 8},
            "Triglycerides": {"greater_than": 100, "weight": 8},
            "TRIG / HDL RATIO": {"greater_than": 2.9, "weight": 8},
            "Apolipoprotein - B (APO-B)": {"greater_than": 80, "weight": 8},
            "High Sensitivity C-Reactive Protein (HS-CRP)": {"greater_than": 0.9, "weight": 9},
            "Homocysteine": {"greater_than": 12, "weight": 7},
            "Neutrophil-Lymphocyte Ratio (NLR)": {"greater_than": 2.4, "weight": 7},
            "Uric Acid": {"greater_than": 5.4, "weight": 7},
            "Ferritin": {"greater_than": 150, "weight": 7},
            "% Transferrin Saturation": {"less_than": 24, "weight": 7},
            "Total Iron Binding Capacity (TIBC)": {"less_than": 250, "weight": 7},
            "Erythrocyte Sedimentation Rate (ESR)": {"greater_than": 5, "weight": 7}
        },
        "Retinopathy": {
            "Erythrocyte Sedimentation Rate (ESR)": {"greater_than": 5, "weight": 5},
            "Microalbumin/ACR": {"greater_than": 30, "weight": 9},
            "HbA1c": {"greater_than": 5.6, "weight": 10},
            "Average Blood Glucose (ABG)": {"greater_than": 120, "weight": 9},
            "HOMA-IR": {"greater_than": 1.25, "weight": 8},
            "Albumin - Serum": {"less_than": 4.5, "weight": 7},
            "HEMOGLOBIN": {"less_than": 4.5, "weight": 6},
            "Blood pressure": {"greater_than": 120, "weight": 8},
            "Homocysteine": {"greater_than": 12, "weight": 7},
            "Triglycerides": {"greater_than": 100, "weight": 6},
            "LDL Cholesterol - Direct": {"greater_than": 120, "weight": 6},
            "High Sensitivity C-Reactive Protein (HS-CRP)": {"greater_than": 0.9, "weight": 8}
        },
        "Neuropathy": {
            "High Sensitivity C-Reactive Protein (HS-CRP)": {"greater_than": 0.9, "weight": 8},
            "Homocysteine": {"greater_than": 7.2, "weight": 7},
            "Vitamin B-12": {"less_than": 200, "weight": 6},
            "Erythrocyte Sedimentation Rate (ESR)": {"greater_than": 5, "weight": 6},
            "HbA1c": {"greater_than": 5.6, "weight": 9},
            "Insulin - Fasting": {"greater_than": 5, "weight": 7},
            "Triglycerides": {"greater_than": 100, "weight": 6},
            "HDL Cholesterol - Direct": {"less_than": 52, "weight": 5}
        },
        "Nephropathy": {
            "Creatinine - Serum": {"greater_than": 1.1, "weight": 9},
            "Est. Glomerular Filtration Rate (eGFR)": {"less_than": 90, "weight": 9},
            "Blood Urea Nitrogen (BUN)": {"greater_than": 22, "weight": 8},
            "Microalbumin/ACR": {"greater_than": 30, "weight": 10},
            "BUN/Creatinine": {"greater_than": 23, "weight": 7},
            "Albumin - Serum": {"less_than": 4.5, "weight": 6},
            "Uric Acid": {"greater_than": 5.4, "weight": 7},
            "25-OH Vitamin D (Total)": {"less_than": 50, "weight": 5},
            "Iron": {"less_than": 80, "weight": 5},
            "HEMOGLOBIN": {"less_than": 4.5, "weight": 6},
            
        },
        "NAFLD/Hepatic complications": {
            "Alanine Transaminase (SGPT)": {"greater_than": 26, "weight": 7},
            "Aspartate Aminotransferase (SGOT)": {"greater_than": 26, "weight": 7},
            "Gamma Glutamyl Transferase (GGT)": {"greater_than": 26, "weight": 8},
            "Bilirubin - Total": {"greater_than": 0.9, "weight": 5},
            "Bilirubin -Direct": {"greater_than": 0.15, "weight": 5},
            "Bilirubin (Indirect)": {"greater_than": 0.75, "weight": 5},
            "Alkaline Phosphatase": {"greater_than": 90, "weight": 6},
            "Lactate Dehydrogenase (LDH)": {"greater_than": 175, "weight": 6},
            "Total Cholesterol": {"greater_than": 190, "weight": 6},
            "HDL Cholesterol - Direct": {"less_than": 52, "weight": 7},
            "LDL Cholesterol - Direct": {"greater_than": 120, "weight": 7},
            "Triglycerides": {"greater_than": 100, "weight": 8},
            "TRIG / HDL RATIO": {"greater_than": 2.9, "weight": 8},
            "Apolipoprotein - B (APO-B)": {"greater_than": 80, "weight": 7}
        },
        "Endocrine and nutritional metabolic disruption": {
            "Vitamin B-12": {"less_than": 500, "weight": 6},
            "25-OH Vitamin D (Total)": {"less_than": 50, "weight": 7},
            "Albumin - Serum": {"less_than": 4.0, "weight": 6},
            "Free Testosterone": {"less_than": 15, "weight": 7},
            "TSH - Ultrasensitive": {"greater_than": 2.8, "weight": 7},
            "Parathyroid Hormone (PTH)": {"greater_than": 65, "weight": 6},
            "Potassium": {"less_than": 4, "weight": 8},
            "Magnesium": {"less_than": 2, "weight": 7},
            "Ferritin": {"less_than": 75, "weight": 6},
            "Iron": {"less_than": 80, "weight": 6},
            "Total Iron Binding Capacity (TIBC)": {"greater_than": 350, "weight": 6},
            "% Transferrin Saturation": {"less_than": 30, "weight": 6},
            "Unsat.Iron-Binding Capacity(UIBC)": {"less_than": 130, "weight": 5},
            "Protein": {"less_than": 6.0, "weight": 6},
            "Retinol binding protein-4": {"less_than": 15, "weight": 6},
            "Calcium": {"less_than": 9.4, "weight": 6},
            "Sodium": {"less_than": 135, "weight": 7},
            "HEMOGLOBIN": {"less_than": 4.5, "weight": 8},
            "male": {
                "Free Testosterone": {"less_than": 15, "weight": 8},
                "Estradiol/Oestrogen (E2)": {"greater_than": 40, "weight": 7}
            },
            "female": {
                "Free Testosterone": {"greater_than": 2.85, "weight": 8},
                "Estradiol/Oestrogen (E2)": {"greater_than": 350, "weight": 7}
            }
        },
        "Osteoporosis": {
            "Calcium": {"less_than": 9.4, "weight": 7},
            "25-OH Vitamin D (Total)": {"less_than": 50, "weight": 8},
            "Alkaline Phosphatase": {"greater_than": 90, "weight": 6}
        },
        "Sudden Cardiac Death (SCD)": {

        }
    },

    "complication_questionnaires": {
        "CVD": {
            "questions": [
                "Chest tightness/Chest pain while walking",
                "Can walk two flights of stairs without feeling breathless ",
                "Sudden falls or blackout?",
                "Swelling of leg/ankle/feet"
            ],
            "threshold": 1
        },
        "Retinopathy": {
            "questions": [
                "Floaters/Flashes of light in the eye/Intermittent blurred vision",
                "Eye Pain/Excessive eye watering"

            ],
            "threshold": 1
        },
        "Neuropathy": {
            "questions": [
                "Numbness/Tingling/Burning in your hands or feet",


            ],
            "threshold": 1
        },
        "Nephropathy": {
            "questions": [
                "Urinary Infection in the last 1 year",
                "Swelling of leg/ankle/feet",
            ],
            "threshold": 1
        },
        "NAFLD/Hepatic complications": {
            "questions": [
                "Jaundice or Hepatitis in the past"
            ],
            "threshold": 1
        },
        "Gastroparesis": {
            "questions": [
                "Bloating/Gas after meals",
                "Excessive Belching/Burping/Farting",
                "Acidity/Heartburn?",
                "Diarrhoea/Constipation?",
                "Indigestion"

            ],
            "threshold": 1
        },
        "Osteoporesis": {
            "questions": [
                "Chronic back pain/Stiff Joints/Shoulder Pain/Knee pain"
                "A fracture"


            ],
            "threshold": 1

        }
    }
}

def get_access_token():
    """
    Fetch access token using hardcoded email and password.
    Returns:
    - str: Access token or None if login fails.
    """
    global ACCESS_TOKEN
    if ACCESS_TOKEN:
        return ACCESS_TOKEN

    login_payload = {
        "email": EMAIL,
        "password": PASSWORD
    }

    try:
        response = requests.post(LOGIN_URL, json=login_payload)
        response.raise_for_status()
        data = response.json()

        if data.get("status") == 200:
            ACCESS_TOKEN = data["content"]["accessToken"]
            print("✅ Successfully obtained access token.")
            return ACCESS_TOKEN
        else:
            print("❌ Login failed:", data)
            return None
    except requests.exceptions.RequestException as e:
        print("❌ Request failed:", str(e))
        return None

def get_user_profile(user_id):
    
    token = get_access_token()
    if not token:
        return {"error": "Failed to get access token"}

    headers = {"Authorization": f"Bearer {token}"}
    url = f"{PROFILE_URL}/{user_id}"

    try:
        response = requests.get(url, headers=headers)
        response.raise_for_status()
        return response.json()
    except requests.exceptions.RequestException as e:
        return {"error": "Request failed", "details": str(e)}

def fetch_questionnaire_from_api(user_id):
    
    token = get_access_token()
    if not token:
        print("❌ Failed to fetch questionnaire: No access token available.")
        return None

    headers = {"Authorization": f"Bearer {token}"}
    url = QUESTIONNAIRE_URL.format(user_id=user_id)

    try:
        response = requests.get(url, headers=headers)
        response.raise_for_status()
        data = response.json()
        print(f"✅ Successfully fetched questionnaire data for user ID: {user_id}")

        questionnaire_responses = {}
        content = data.get("content", {})
        if not content:
            print("❌ No content found in API response.")
            return None

        complication_map = {}
        for complication, details in CONFIG["complication_questionnaires"].items():
            for question in details["questions"]:
                norm_question = question.lower().strip()
                if norm_question not in complication_map:
                    complication_map[norm_question] = []
                complication_map[norm_question].append(complication)

        for topic, questions in content.items():
            print(f"Processing topic: {topic}")
            for question_data in questions:
                description = question_data.get("description", "").lower().strip()
                optionals = question_data.get("optionals", "")
                answer = question_data.get("answer", None)

                if answer is None:
                    print(f"⚠ No answer provided for question: {description}")
                    continue

                if question_data.get("optionalType") == "checkbox" and optionals:
                    options_list = optionals.split(",")
                    if isinstance(answer, str):
                        answered_options = [opt.strip().lower() for opt in answer.split(",") if opt.strip()]
                    else:
                        answered_options = []

                    for option in options_list:
                        option_norm = option.lower().strip()
                        matched_complications = None
                        for q in complication_map:
                            if option_norm in q or any(opt.lower() in q for opt in option_norm.split("/")):
                                matched_complications = complication_map[q]
                                break

                        if matched_complications:
                            is_selected = any(opt in answered_options for opt in option_norm.split("/"))
                            for comp in matched_complications:
                                if comp not in questionnaire_responses:
                                    questionnaire_responses[comp] = [False] * len(CONFIG["complication_questionnaires"][comp]["questions"])
                                for idx, cfg_q in enumerate(CONFIG["complication_questionnaires"][comp]["questions"]):
                                    if option_norm in cfg_q.lower() or any(opt.lower() in cfg_q.lower() for opt in option_norm.split("/")):
                                        questionnaire_responses[comp][idx] = is_selected
                                        break
                else:
                    print(f"Skipping non-checkbox or text question: {description}")

        print(f"✅ Processed questionnaire responses for {len(questionnaire_responses)} complications")
        return questionnaire_responses

    except RequestException as e:
        print(f"❌ Error fetching questionnaire from API: {e}")
        return None
    except ValueError as e:
        print(f"❌ Error parsing API response: {e}")
        return None
    except Exception as e:
        print(f"❌ Unexpected error processing questionnaire data: {e}")
        return None

def fetch_xml_report(user_id):
    """Fetch XML report URL from the dummy API using user_id, download the content, and save to a temporary file."""
    url = XML_REPORT_URL.format(user_id=user_id)
    print(f"Attempting to connect to: {url}")
    try:
        
        response = requests.get(url, timeout=5)
        response.raise_for_status()
        data = response.json()

        if data.get("status") == 200 and data.get("content"):
            xml_report_url = data["content"][0]  
            print(f"✅ Retrieved XML report URL: {xml_report_url}")

            
            xml_response = requests.get(xml_report_url, timeout=10)
            xml_response.raise_for_status()
            xml_content = xml_response.text

           
            with tempfile.NamedTemporaryFile(mode='w', delete=False, suffix='.xml', encoding='utf-8') as temp_file:
                temp_file.write(xml_content)
                temp_file_path = temp_file.name
            print(f"✅ Successfully downloaded and saved XML report for user ID: {user_id} to {temp_file_path}")
            return temp_file_path
        else:
            print(f"❌ Failed to fetch XML report URL: {data}")
            return None
    except RequestException as e:
        print(f"❌ Error fetching XML report or URL from API: {e}")
        return None



def extract_patient_info(root):
    """Extracts patient demographics from the XML root."""
    patient_info = {
        "name": "N/A",
        "gender": "N/A",
        "age": "N/A",
        "age_sex": "N/A",
        "mobile": "N/A",
        "email": "N/A",
        "order_no": "N/A",
        "report_date": datetime.now().strftime("%Y-%m-%d")
    }
    try:
        lead_details = root.find(".//LEADDETAILS")
        if lead_details is not None:
            patient_text = lead_details.findtext("PATIENT", "N/A")
            if "(" in patient_text:
                name_part = patient_text.split("(")[0].strip()
                details_part = patient_text.split("(")[1].replace(")", "").strip()
                if "/" in details_part:
                    age_part, gender_part = details_part.split("/")
                    age_number = ''.join(filter(str.isdigit, age_part))
                    gender = gender_part.strip().upper()
                    gender = 'male' if gender == 'M' else 'female' if gender == 'F' else 'N/A'
                    patient_info.update({
                        "name": name_part,
                        "age": int(age_number) if age_number.isdigit() else "N/A",
                        "gender": gender,
                        "age_sex": details_part
                    })
            patient_info.update({
                "mobile": lead_details.findtext("MOBILE", "N/A"),
                "email": lead_details.findtext("EMAIL", "N/A"),
                "order_no": lead_details.findtext("ORDERNO", "N/A").strip(),
                "report_date": lead_details.findtext("RRT", datetime.now().strftime("%Y-%m-%d")).split("T")[0]
            })
    except Exception as e:
        print(f"Warning: Could not parse some patient info - {e}")
    return patient_info



def get_reference_range_from_config(test_name, patient_gender=None):
    """Get the reference range for a test from CONFIG, default to 'Normal' if not found"""
    biomarker_config = CONFIG["biomarkers"].get(test_name)
    
   
    if biomarker_config and isinstance(biomarker_config, dict):
        if biomarker_config.get("gender_specific") and patient_gender and patient_gender in ["male", "female"]:
            return biomarker_config[patient_gender]["range"]
        return biomarker_config.get("range", "Normal")
    
    
    normalized_test_name = test_name.lower().replace(" ", "").replace("-", "").replace("_", "").replace("(", "").replace(")", "")
    for config_test_name, config in CONFIG["biomarkers"].items():
        normalized_config_name = config_test_name.lower().replace(" ", "").replace("-", "").replace("_", "").replace("(", "").replace(")", "")
        if normalized_test_name == normalized_config_name:
            if isinstance(config, dict):
                if config.get("gender_specific") and patient_gender and patient_gender in ["male", "female"]:
                    return config[patient_gender]["range"]
                return config.get("range", "Normal")
    
    return "Normal"

def parse_thyrocare_xml(xml_file_path):
    """Parses the Thyrocare XML and extracts test results into a dictionary."""
    try:
        tree = ET.parse(xml_file_path)
        root = tree.getroot()
    except ET.ParseError as e:
        print(f"Error parsing XML file: {e}")
        return None, None, None
    except FileNotFoundError:
        print(f"Error: XML file not found at {xml_file_path}")
        return None, None, None

    patient_info = extract_patient_info(root)
    patient_gender = patient_info.get('gender', '').lower()

    test_mapping = {
        "HBA": "HbA1c",
        "FBS": "Fasting Blood Sugar (Glucose)",
        "ABAS": "Basophils - Absolute Count",
        "AEOS": "Eosinophils - Absolute Count",
        "ALYM": "Lymphocytes - Absolute Count",
        "AMON": "Monocytes - Absolute Count",
        "ANEU": "NEUTROPHILS - ABSOLUTE COUNT",
        "HB": "HEMOGLOBIN",
        "LEUC": "TOTAL LEUCOCYTES COUNT (WBC)",
        "PLT": "PLATELET COUNT",
        "RBC": "TOTAL RBC"
    }

    test_results = {}

    for test_detail in root.findall(".//TESTDETAIL"):
        description = test_detail.findtext("Description", "").strip()
        test_code = test_detail.findtext("TEST_CODE", "").strip()
        test_value_str = test_detail.findtext("TEST_VALUE", "").strip()
        units = test_detail.findtext("UNITS", "").strip()
        normal_val_from_xml = test_detail.findtext("NORMAL_VAL", "").strip()
        indicator = test_detail.findtext("INDICATOR", "WHITE").strip()

        if "ASPARTATE AMINOTRANSFERASE (SGOT" in description:
            description = "Aspartate Aminotransferase (SGOT)"

        key_name = description if description else test_mapping.get(test_code)

        if not key_name:
            continue

        numeric_value = None
        if test_value_str:
            try:
                numeric_value = float(test_value_str)
            except ValueError:
                numeric_match = re.search(r'(\d+\.?\d*)', test_value_str)
                if numeric_match:
                    numeric_value = float(numeric_match.group(1))

        # Get reference range from config
        normal_val = get_reference_range_from_config(key_name, patient_gender)
        if normal_val == "Normal" and normal_val_from_xml:
            normal_val = normal_val_from_xml

        # Determine the indicator based on comparison with the range
        indicator = "WHITE"  # Default to WHITE if no valid range or value
        if numeric_value is not None and isinstance(normal_val, list) and len(normal_val) == 2:
            low, high = normal_val
            # Ensure low and high are numeric and not None
            if low is not None and high is not None:
                try:
                    low = float(low)
                    high = float(high)
                    if numeric_value > high:
                        indicator = "RED"  # Above normal range
                    elif numeric_value < low:
                        indicator = "BLUE"  # Below normal range
                except (ValueError, TypeError):
                    indicator = "WHITE"  # If conversion fails, default to WHITE

        test_results[key_name] = {
            "value": numeric_value,
            "unit": units,
            "normal_range": normal_val,
            "indicator": indicator
        }

    if "Fasting Blood Sugar (Glucose)" in test_results and "Insulin - Fasting" in test_results:
        glucose = test_results["Fasting Blood Sugar (Glucose)"]["value"]
        insulin = test_results["Insulin - Fasting"]["value"]
        if glucose is not None and insulin is not None and glucose > 0:
            homa_ir = (glucose * insulin) / 405
            test_results["HOMA-IR"] = {
                "value": round(homa_ir, 2),
                "unit": "Ratio",
                "normal_range": get_reference_range_from_config("HOMA-IR") or "0.75-1.25",
                "indicator": "CALCULATED"
            }

    analysis_input_data = {k: v['value'] for k, v in test_results.items() if v['value'] is not None}

    return patient_info, test_results, analysis_input_data


def classify_patient(report_values, config, patient_info=None):
    """Classifies patient based on report values and config rules."""
    gender = patient_info.get('gender', '').lower() if patient_info else None
    inflammatory_markers = {
        'High Sensitivity C-Reactive Protein (HS-CRP)',
        'Homocysteine',
        'Erythrocyte Sedimentation Rate (ESR)',
        'Lactate Dehydrogenase (LDH)'
    }

    # Check neutrophil count
    neutrophil_value = report_values.get('NEUTROPHILS - ABSOLUTE COUNT')
    ignore_inflammatory = False
    if neutrophil_value is not None and neutrophil_value > 80:
        ignore_inflammatory = True
        print(f"High neutrophil count detected ({neutrophil_value}). Ignoring inflammatory markers.")

    def check_condition(marker_value, condition_rules):
        """Checks if marker_value meets the condition rules."""
        if marker_value is None:
            return False

        # Create a copy of condition_rules without the weight key for checking
        check_rules = {k: v for k, v in condition_rules.items() if k != "weight"}

        for rule_type, rule_value in check_rules.items():
            if rule_type == "greater_than":
                if not (marker_value > rule_value): return False
            elif rule_type == "less_than":
                if not (marker_value < rule_value): return False
            elif rule_type == "outside_range":
                if isinstance(rule_value, list) and len(rule_value) == 2:
                    low, high = rule_value
                    if not (marker_value < low or marker_value > high): return False
                else:
                    print(f"Warning: Invalid outside_range format {rule_value}")
                    return False
            else:
                print(f"Warning: Unknown rule type '{rule_type}'")
                return False

        return True

    normalized_report = {}
    for key, value in report_values.items():
        norm_key = key.lower().replace(" ", "").replace("-", "").replace("_", "").replace("(", "").replace(")", "")
        normalized_report[norm_key] = value
        normalized_report[key] = value

    def find_marker_value(marker_name):
        """Find marker value using normalized key first, then original."""
        if ignore_inflammatory and marker_name in inflammatory_markers:
            return None

        norm_marker = marker_name.lower().replace(" ", "").replace("-", "").replace("_", "").replace("(", "").replace(
            ")", "")
        value = normalized_report.get(norm_marker)
        if value is None:
            value = normalized_report.get(marker_name)
        return value

    def calculate_match_percentage(category_conditions, category_type):
        """
        Calculates match percentage based on biomarker contributions.
        For complications, uses weights; for phenotypes and pathways, uses simple counting.
        Args:
            category_conditions: Dictionary of conditions to check
            category_type: Type of category ('phenotypes', 'pathways', or 'complications')
        """
        matched_markers_list = []

        
        if category_type == 'complications':
            total_weighted_score_possible = 0
            total_weighted_score_matched = 0

            for marker, conditions in category_conditions.items():
                # Skip gender-specific sections if not matching current gender
                if marker in ["male", "female"]:
                    if marker != gender:
                        continue
                    # Process gender-specific markers
                    for gender_marker, gender_conditions in conditions.items():
                        weight = gender_conditions.get("weight", 1)
                        total_weighted_score_possible += weight
                        value = find_marker_value(gender_marker)
                        if value is not None and check_condition(value, gender_conditions):
                            total_weighted_score_matched += weight
                            matched_markers_list.append(gender_marker)
                    continue

                if ignore_inflammatory and marker in inflammatory_markers:
                    continue

                # Get weight directly from the condition
                weight = conditions.get("weight", 1)
                total_weighted_score_possible += weight

                value = find_marker_value(marker)
                if value is not None and check_condition(value, conditions):
                    total_weighted_score_matched += weight
                    matched_markers_list.append(marker)

            if total_weighted_score_possible == 0:
                return [], 0.0

            match_percentage = (total_weighted_score_matched / total_weighted_score_possible * 100)

        # For phenotypes and pathways - use simple counting (no weights)
        else:
            # Count total available markers (those that have values in the report)
            available_markers = []
            matched_markers = []

            for marker, conditions in category_conditions.items():
                # Skip gender-specific sections if not matching current gender
                if marker in ["male", "female"]:
                    if marker != gender:
                        continue
                    # Process gender-specific markers
                    for gender_marker, gender_conditions in conditions.items():
                        value = find_marker_value(gender_marker)
                        if value is not None:  # Only count markers that have values
                            available_markers.append(gender_marker)
                            if check_condition(value, gender_conditions):
                                matched_markers.append(gender_marker)
                                matched_markers_list.append(gender_marker)
                    continue

                if ignore_inflammatory and marker in inflammatory_markers:
                    continue

                value = find_marker_value(marker)
                if value is not None:  # Only count markers that have values
                    available_markers.append(marker)
                    if check_condition(value, conditions):
                        matched_markers.append(marker)
                        matched_markers_list.append(marker)

            if not available_markers:
                return [], 0.0

            # Simple percentage calculation: matched / available * 100
            match_percentage = (len(matched_markers) / len(available_markers) * 100)

        return matched_markers_list, round(match_percentage, 2)

    phenotype_results = {}
    for name, conditions in config["phenotypes"].items():
        if conditions:
            matched_markers, percentage = calculate_match_percentage(conditions, 'phenotypes')
            phenotype_results[name] = {
                "match_percentage": percentage,
                "matched_markers": matched_markers
            }

    pathway_results = {}
    for name, conditions in config["pathways"].items():
        if conditions:
            matched_markers, percentage = calculate_match_percentage(conditions, 'pathways')
            pathway_results[name] = {
                "match_percentage": percentage,
                "matched_markers": matched_markers
            }

    complication_results = {}
    for name, conditions in config["complications"].items():
        if conditions:
            matched_markers, percentage = calculate_match_percentage(conditions, 'complications')
            complication_results[name] = {
                "match_percentage": percentage,
                "matched_markers": matched_markers
            }

    def calculate_overall_risk(comp_res, conf):
        """Calculate risk score based only on complications."""
        max_possible_score = 0
        achieved_score = 0

        # Only consider complications for risk calculation
        for complication_name, complication_results in comp_res.items():
            complication_conditions = conf["complications"].get(complication_name, {})

            # Calculate maximum possible score for this complication
            for marker, conditions in complication_conditions.items():
                # Skip gender-specific sections if not matching
                if marker in ["male", "female"]:
                    if marker != gender:
                        continue
                    # Process gender-specific markers
                    for gender_marker, gender_conditions in conditions.items():
                        weight = gender_conditions.get("weight", 1)
                        max_possible_score += weight
                    continue

                # Regular markers
                if isinstance(conditions, dict):
                    weight = conditions.get("weight", 1)
                    max_possible_score += weight

            # Calculate achieved score based on matched markers
            for matched_marker in complication_results["matched_markers"]:
                # Check if the marker is in the main complication conditions
                if matched_marker in complication_conditions:
                    marker_conditions = complication_conditions[matched_marker]
                    if isinstance(marker_conditions, dict):
                        weight = marker_conditions.get("weight", 1)
                        achieved_score += weight
                # Check if the marker is in gender-specific conditions
                elif gender in ["male", "female"] and gender in complication_conditions:
                    gender_conditions = complication_conditions[gender]
                    if matched_marker in gender_conditions:
                        weight = gender_conditions[matched_marker].get("weight", 1)
                        achieved_score += weight

        risk_score_raw = (achieved_score / max_possible_score) * 10 if max_possible_score > 0 else 0
        return min(round(risk_score_raw, 2), 10)

    # Calculate risk based only on complications
    overall_risk_score = calculate_overall_risk(complication_results, config)

    def find_best_match(results_dict):
        if not results_dict:
            return "N/A", 0.0
        best_name = max(results_dict, key=lambda k: results_dict[k]['match_percentage'])
        return best_name, results_dict[best_name]['match_percentage']

    best_phenotype_name, best_phenotype_score = find_best_match(phenotype_results)
    best_pathway_name, best_pathway_score = find_best_match(pathway_results)
    best_complication_name, best_complication_score = find_best_match(complication_results)

    final_results = {
        "phenotypeResults": phenotype_results,
        "pathwayResults": pathway_results,
        "complicationResults": complication_results,
        "overallRiskScore": overall_risk_score,
        "bestMatches": {
            "phenotype": {"name": best_phenotype_name, "value": best_phenotype_score},
            "pathway": {"name": best_pathway_name, "value": best_pathway_score},
            "complication": {"name": best_complication_name, "value": best_complication_score}
        },
        "analysisNotes": {
            "inflammatoryMarkersIgnored": ignore_inflammatory,
            "neutrophilCount": neutrophil_value,
            "ignoredMarkers": list(inflammatory_markers) if ignore_inflammatory else [],
            "riskCalculationMethod": "Complications-only weighted calculation"
        }
    }
    return final_results

def process_questionnaire_responses(questionnaire_responses, config):
    current_complications = {}

    # Added validation for empty questionnaire responses
    if not questionnaire_responses:
        return current_complications

    for complication, responses in questionnaire_responses.items():
        if complication not in config["complication_questionnaires"]:
            continue

        questionnaire_config = config["complication_questionnaires"][complication]
        threshold = questionnaire_config.get("threshold", 3)

        # Added validation for empty responses
        if not responses:
            current_complications[complication] = {
                "is_present": False,
                "confidence_score": 0.0,
                "yes_responses": 0,
                "total_questions": 0
            }
            continue

        # Count 'yes' responses
        yes_count = sum(1 for response in responses if response)

        # Calculate confidence score (percentage of 'yes' responses)
        total_questions = len(responses)
        confidence_score = (yes_count / total_questions) * 100 if total_questions > 0 else 0

        # Determine if the complication is present based on threshold
        is_present = yes_count >= threshold

        current_complications[complication] = {
            "is_present": is_present,
            "confidence_score": round(confidence_score, 2),
            "yes_responses": yes_count,
            "total_questions": total_questions
        }

    return current_complications

def process_report(xml_file_path, output_json_path="analysis_output.json", height=None, weight=None, waist=None,
                   questionnaire_responses=None, user_profile=None):
    print(f"Processing report: {xml_file_path}...")

    if os.path.exists(output_json_path):
        try:
            os.remove(output_json_path)
            print(f"Deleted old output file: {output_json_path}")
        except Exception as e:
            print(f"Warning: Could not delete existing file: {e}")

    patient_info, full_test_results, analysis_input_data = parse_thyrocare_xml(xml_file_path)

    if analysis_input_data is None:
        print("Failed to parse XML. Exiting.")
        return

    if user_profile and "error" not in user_profile:
        content = user_profile.get("content", {})
        if content:
            height = content.get("height", height) if content.get("height") is not None else height
            weight = content.get("weight", weight) if content.get("weight") is not None else weight
            waist = content.get("waistCircumference", waist) if content.get("waistCircumference") is not None else waist
            print(f"✅ Using anthropometric data from profile: Height={height}, Weight={weight}, Waist={waist}")

    if height is not None and weight is not None and height > 0:
        height_m = height * 0.3048
        bmi = weight / (height_m ** 2)
        analysis_input_data['BMI'] = round(bmi, 2)
        print(f"Calculated BMI: {bmi:.2f}")
    else:
        print("⚠ BMI calculation skipped: Missing height or weight data.")

    if height is not None and waist is not None and height > 0:
        waist_height_ratio = waist / height
        analysis_input_data['Waist to height ratio'] = round(waist_height_ratio, 2)
        print(f"Calculated Waist-to-height ratio: {waist_height_ratio:.2f}")
    else:
        print("⚠ Waist-to-height ratio calculation skipped: Missing height or waist data.")

    print("Patient Info Extracted.")
    print(f"Gender: {patient_info.get('gender', 'N/A')}")
    print(f"Age: {patient_info.get('age', 'N/A')}")
    print("Running classification...")
    classification_results = classify_patient(analysis_input_data, CONFIG, patient_info)
    print("Classification complete.")

    current_complications = None
    if questionnaire_responses:
        print("Processing questionnaire responses...")
        current_complications = process_questionnaire_responses(questionnaire_responses, CONFIG)
        print(
            f"Identified {sum(1 for comp in current_complications.values() if comp['is_present'])} current complications.")

    # Organize ALL test results into marker groups for UI display under analytic_drivers
    analytic_drivers = {group_name: {"markers": []} for group_name in CONFIG["marker_groups"].keys()}
    analytic_drivers["Other"] = {"markers": []}  # Default category for markers not in any group

    for marker, result in full_test_results.items():
        value = result.get("value")
        normal_range = result.get("normal_range")
        indicator = result.get("indicator", "WHITE")
        
        # Determine status based on indicator
        if indicator == "RED":
            status = "high"
        elif indicator == "BLUE":
            status = "low"
        else:
            status = "normal"
        
        range_display = normal_range if normal_range != "Normal" else "Within Normal Limits"
        if isinstance(normal_range, list) and len(normal_range) == 2:
            low, high = normal_range
            range_display = f"{low}-{high}"

        marker_data = {
            "marker": marker,
            "value": value if value is not None else "N/A",
            "unit": result.get("unit", ""),
            "normal_range": range_display,
            "status": status,
            "indicator": indicator  # Include the color indicator for UI styling
        }

        # Find the category for this marker, default to "Other" if not found in any group
        category = next((g for g, m in CONFIG["marker_groups"].items() if marker in m), "Other")
        analytic_drivers[category]["markers"].append(marker_data)

    # Remove empty categories from analytic_drivers (except keep "Other" if it has markers)
    analytic_drivers = {k: v for k, v in analytic_drivers.items() if v["markers"] or k == "Other"}

    # Create a separate section for abnormal markers summary by category with a single suggestion
    abnormal_markers_summary = {}
    abnormal_markers = []

    for marker, result in full_test_results.items():
        indicator = result.get("indicator", "WHITE")
        if indicator in ["RED", "BLUE"]:  # Only include abnormal markers
            status = "high" if indicator == "RED" else "low"
            abnormal_markers.append({
                "marker": marker,
                "value": result.get("value") if result.get("value") is not None else "N/A",
                "unit": result.get("unit", ""),
                "status": status,
                "category": next((g for g, m in CONFIG["marker_groups"].items() if marker in m), "Other")
            })

    # Group abnormal markers by category and provide a consolidated suggestion (irrespective of high/low)
    for category in list(CONFIG["marker_groups"].keys()) + ["Other"]:
        markers_in_category = [m for m in abnormal_markers if m["category"] == category]
        if markers_in_category:
            marker_names = ", ".join([m["marker"] for m in markers_in_category])
            description = f"{category} Markers: {marker_names} are abnormal"
            
            # Determine a suggestion for the category; prioritize "high" suggestion if available, else "low", else default
            high_suggestion = CONFIG["marker_suggestions"].get(category, {}).get("high", "")
            low_suggestion = CONFIG["marker_suggestions"].get(category, {}).get("low", "")
            suggestion = high_suggestion if high_suggestion else low_suggestion
            if not suggestion:
                suggestion = "Consult a healthcare provider for abnormal markers in this category."
            
            abnormal_markers_summary[category] = {
                "description": description,
                "markers": markers_in_category,
                "suggestion": suggestion
            }

    # Enhance current complications with questions that led to the result
    enhanced_complications = {}
    if current_complications:
        for comp_name, comp_data in current_complications.items():
            if comp_name in CONFIG["complication_questionnaires"]:
                questions = CONFIG["complication_questionnaires"][comp_name]["questions"]
                responses = questionnaire_responses.get(comp_name, []) if questionnaire_responses else []
                question_responses = []

                for i, (question, response) in enumerate(zip(questions, responses)):
                    if response:  # Only include questions answered 'yes'
                        question_responses.append({
                            "question": question,
                            "answer": "Yes"
                        })

                enhanced_complications[comp_name] = {
                    "is_present": comp_data["is_present"],
                    "confidence_score": comp_data["confidence_score"],
                    "yes_responses": comp_data["yes_responses"],
                    "total_questions": comp_data["total_questions"],
                    "contributing_questions": question_responses
                }

    marker_insights = []
    if abnormal_markers:
        marker_insights.append({
            "insight": "Abnormal Markers",
            "description": "Markers outside normal range indicating potential health concerns.",
            "markers": abnormal_markers,
            "suggestion": "Review lifestyle factors  for targeted interventions."
        })

    output_data = {
        "patientInfo": patient_info,
        "reportDate": patient_info.get("report_date", datetime.now().strftime("%Y-%m-%d")),
        "rawData": full_test_results,
        "analysisInput": analysis_input_data,
        "anthropometricMeasures": {
            "height": height,
            "weight": weight,
            "waist": waist,
            "bmi": analysis_input_data.get('BMI'),
            "waistToHeightRatio": analysis_input_data.get('Waist to height ratio')
        },
        "analysisResults": classification_results,
        "currentComplications": enhanced_complications if enhanced_complications else current_complications,
        "analyticDrivers": analytic_drivers,  
        "abnormalMarkersSummary": abnormal_markers_summary,  
        "userProfile": user_profile if user_profile and "error" not in user_profile else {}
    }

    print(f"Saving analysis results to: {output_json_path}")
    try:
        with open(output_json_path, 'w') as f:
            json.dump(output_data, f, indent=4)
        print("Successfully saved JSON output.")
    except IOError as e:
        print(f"Error saving JSON file: {e}")
    except TypeError as e:
        print(f"Error serializing data to JSON: {e}")

    print(f"Saving analysis results to: {output_json_path}")
    try:
        with open(output_json_path, 'w') as f:
            json.dump(output_data, f, indent=4)
        print("Successfully saved JSON output.")
    except IOError as e:
        print(f"Error saving JSON file: {e}")
    except TypeError as e:
        print(f"Error serializing data to JSON: {e}")
        
if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Fetch and process Thyrocare XML report based on user ID.")
    parser.add_argument("--user-id", type=int, required=True, help="User ID to fetch XML report, profile, and questionnaire data from APIs")
    parser.add_argument("-o", "--output", default="analysis_output.json",
                        help="Path to save the output JSON file (default: analysis_output.json)")
    parser.add_argument("--height", type=float, help="Height in cm (overrides profile data if provided)")
    parser.add_argument("--weight", type=float, help="Weight in kg (overrides profile data if provided)")
    parser.add_argument("--waist", type=float, help="Waist circumference in cm (overrides profile data if provided)")
    parser.add_argument("--questionnaire", action="store_true",
                        help="Run interactive questionnaire for current complications")

    args = parser.parse_args()

  
    xml_file_path = fetch_xml_report(args.user_id)
    if not xml_file_path:
        print("Failed to fetch XML report. Exiting.")
        exit(1)

    questionnaire_responses = None
    if args.user_id:
        print(f"Fetching questionnaire data for user ID: {args.user_id}")
        questionnaire_responses = fetch_questionnaire_from_api(args.user_id)

    user_profile = None
    if args.user_id:
        print(f"Fetching user profile for user ID: {args.user_id}")
        user_profile = get_user_profile(args.user_id)
        print("User Profile:", user_profile)


    if not questionnaire_responses and args.questionnaire:
        print("\n=== Current Complications Questionnaire ===\n")
        questionnaire_responses = {}

        for complication, questionnaire in CONFIG["complication_questionnaires"].items():
            print(f"\n{complication} Assessment:")
            responses = []

            for i, question in enumerate(questionnaire["questions"], 1):
                while True:
                    response = input(f"{i}. {question} (y/n): ").lower()
                    if response in ['y', 'n', 'yes', 'no']:
                        break
                    print("Please answer with 'y' or 'n'.")

                responses.append(response in ['y', 'yes'])

            questionnaire_responses[complication] = responses

    
    process_report(
        xml_file_path=xml_file_path,
        output_json_path=args.output,
        height=args.height,
        weight=args.weight,
        waist=args.waist,
        questionnaire_responses=questionnaire_responses,
        user_profile=user_profile
    )

    
    if xml_file_path and os.path.exists(xml_file_path):
        try:
            os.remove(xml_file_path)
            print(f"Cleaned up temporary file: {xml_file_path}")
        except Exception as e:
            print(f"Warning: Could not delete temporary file {xml_file_path}: {e}")





import os
import json
import psycopg2
from datetime import date, timedelta
import google.generativeai as genai

# ------------------------
# Gemini setup
# ------------------------
GEMINI_API_KEY = "AIzaSyB7zp9mqQTnQ9VMtD5queh8fCu8wXvdZO8"
GEMINI_MODEL_NAME = "gemini-2.5-flash"

genai.configure(api_key=GEMINI_API_KEY)
model = genai.GenerativeModel(GEMINI_MODEL_NAME)

# Load prompt template (combined for all meals)
with open("/home/ubuntu/scripts/receipe_update/prompt.json", "r", encoding="utf-8") as f:
    prompt_data = json.load(f)
PROMPT_TEMPLATE = prompt_data["template"]

# ------------------------
# Constants
# ------------------------
MAX_HISTORY_DAYS = 7
HISTORY_FILE = "user_recipe_history.json"

# Load existing history or create empty dict
try:
    with open(HISTORY_FILE, "r", encoding="utf-8") as f:
        content = f.read().strip()
        user_histories = json.loads(content) if content else {}
except (FileNotFoundError, json.JSONDecodeError):
    user_histories = {}

# ------------------------
# Helper functions
# ------------------------
def parse_macro_value(value):
    if isinstance(value, (int, float)):
        return round(float(value))
    value = str(value).lower().replace('g','').strip()
    if '-' in value:
        parts = value.split('-')
        try:
            numbers = [float(p) for p in parts]
            return round(sum(numbers)/len(numbers))
        except ValueError:
            return 0
    else:
        try:
            return round(float(value))
        except ValueError:
            return 0
def extract_recipe_names(user_recipes):
    """
    Return only the names of recipes per meal.
    Handles both dict-based and list-based Gemini responses.
    """
    recipe_headings = {}

    # Case 1: Dict format { "breakfast": [ {...}, {...} ], ... }
    if isinstance(user_recipes, dict):
        for meal, recipes in user_recipes.items():
            recipe_headings[meal] = [r.get("name") for r in recipes if "name" in r]

    # Case 2: List format [ { "mealType": "breakfast", "exampleMeals": [...] }, ... ]
    elif isinstance(user_recipes, list):
        for item in user_recipes:
            meal = item.get("mealType")
            recipes = item.get("exampleMeals", [])
            if meal:
                recipe_headings[meal] = [r.get("name") for r in recipes if "name" in r]

    return recipe_headings



def get_recent_recipes():
    """Return a flat list of recipe names from last MAX_HISTORY_DAYS."""
    today = date.today()
    recent_recipes = []
    history = user_histories  # no user_id

    for i in range(1, MAX_HISTORY_DAYS+1):
        d_str = (today - timedelta(days=i)).strftime("%Y-%m-%d")
        if d_str in history:
            for meal in ["breakfast", "lunch", "dinner"]:
                recent_recipes.extend(history[d_str].get(meal, []))
    return recent_recipes


def save_today_recipes(recipe_headings):
    """Save today's recipe names into JSON file (flat, deduplicated, no user ID)."""
    today_str = date.today().strftime("%Y-%m-%d")

    # Load existing history
    try:
        with open(HISTORY_FILE, "r", encoding="utf-8") as f:
            content = f.read().strip()
            history = json.loads(content) if content else {}
    except (FileNotFoundError, json.JSONDecodeError):
        history = {}

    # Ensure today's section exists
    if today_str not in history:
        history[today_str] = {"breakfast": [], "lunch": [], "dinner": []}

    # Merge with deduplication
    for meal, recipes in recipe_headings.items():
        existing = set(history[today_str].get(meal, []))
        new = set(recipes)
        combined = list(existing.union(new))  # merge + dedup
        history[today_str][meal] = combined

    # Keep only last MAX_HISTORY_DAYS
    sorted_dates = sorted(history.keys(), reverse=True)
    pruned = {d: history[d] for d in sorted_dates[:MAX_HISTORY_DAYS]}

    # Save back
    with open(HISTORY_FILE, "w", encoding="utf-8") as f:
        json.dump(pruned, f, indent=2)


def generate_recipes_for_user(meals, recent_recipes=None):
    """Generate all meals in one API call, avoiding recent recipes."""
    parsed_meals = {meal: {k: parse_macro_value(v) for k,v in macros.items()} for meal, macros in meals.items()}

    exclude_text = ""
    if recent_recipes:
        exclude_text = " Do not repeat any protein, vegetable, or spice combinations used in the last 7 days.: " + ", ".join(recent_recipes)

    prompt = PROMPT_TEMPLATE.format(
        breakfast_protein=parsed_meals["breakfast"]["protein"],
        breakfast_carbs=parsed_meals["breakfast"]["carbs"],
        breakfast_fat=parsed_meals["breakfast"]["fat"],
        breakfast_calories=parsed_meals["breakfast"]["calories"],
        lunch_protein=parsed_meals["lunch"]["protein"],
        lunch_carbs=parsed_meals["lunch"]["carbs"],
        lunch_fat=parsed_meals["lunch"]["fat"],
        lunch_calories=parsed_meals["lunch"]["calories"],
        dinner_protein=parsed_meals["dinner"]["protein"],
        dinner_carbs=parsed_meals["dinner"]["carbs"],
        dinner_fat=parsed_meals["dinner"]["fat"],
        dinner_calories=parsed_meals["dinner"]["calories"]
    ) + exclude_text

    try:
        response = model.generate_content(prompt)
        text_response = response.text.strip()
        if text_response.startswith("```"):
            text_response = "\n".join(text_response.splitlines()[1:-1])
        return json.loads(text_response)
    except Exception as e:
        print(f"❌ Failed to generate recipes for user: {e}")
        return {}

# ------------------------
# Main function
# ------------------------
def main():
    conn = psycopg2.connect(
        host="localhost",
        database="healthsync",
        user="postgres",
        password="Revival365ai@2025@healthsyncV1.5",
        port=5432
    )

    with conn.cursor() as cursor:
        cursor.execute("SELECT user_id, user_protocol FROM user_protocols")
        rows = cursor.fetchall()

        for user_id, protocol_json in rows:
            if isinstance(protocol_json, dict):
                protocol = protocol_json
            elif isinstance(protocol_json, str):
                try:
                    protocol = json.loads(protocol_json)
                except json.JSONDecodeError:
                    print(f"Skipping user {user_id} (invalid JSON)")
                    continue
            else:
                print(f"Skipping user {user_id} (unknown format)")
                continue

            # Collect macros for all meals
            meal_macros = {}
            for meal in protocol.get("mealPlan", {}).get("dailySchedule", []):
                macros = meal.get("nutritionalTargets")
                if macros:
                    meal_macros[meal["mealType"]] = macros

            if not meal_macros:
                print(f"ℹ️ No macros found for user {user_id}, skipping")
                continue

            # Get last 15 days of recipe names
            recent_recipes = get_recent_recipes()

            # Generate recipes avoiding recent ones
            user_recipes = generate_recipes_for_user(meal_macros, recent_recipes)
            if not user_recipes:
                print(f"❌ Failed to generate recipes for user {user_id}")
                continue

            # Update protocol with recipes
            updated = False
            for meal in protocol.get("mealPlan", {}).get("dailySchedule", []):
                if meal["mealType"] in user_recipes:
                    meal["exampleMeals"] = user_recipes[meal["mealType"]]
                    updated = True

            # Save today’s recipe names in JSON file
            recipe_headings = extract_recipe_names(user_recipes)
            save_today_recipes(recipe_headings)

            if updated:
                cursor.execute(
                    "UPDATE user_protocols SET user_protocol = %s WHERE user_id = %s",
                    (json.dumps(protocol), user_id)
                )
                conn.commit()
                print(f"✅ Updated recipes for user {user_id}")
            else:
                print(f"ℹ️ No updates needed for user {user_id}")

    conn.close()

# ------------------------
# Run
# ------------------------
if __name__ == "__main__":
    main()
